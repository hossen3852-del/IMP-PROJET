'use strict';

const { serviceResponse, serviceJson } = require('./serviceResult');


const { z } = require('zod');
const repository = require('../repositories');

const { isOrganizationWide, assertBranchAccess, enforceRequestedBranch } = require('../application/accessScope');
const { savePhoto, resolvePhotoUrl, UPLOAD_ROOT } = require('../utils/photoStorage');
const { computeSavingsSummary } = require('./savingsService');
const fs = require('node:fs');
const path = require('node:path');


;
const memberCreateSchema = z.object({
  fullName: z.string().trim().min(2).max(200),
  fatherName: z.string().trim().max(200).optional().default(''),
  motherName: z.string().trim().max(200).optional().default(''),
  spouseName: z.string().trim().max(200).optional().default(''),
  dateOfBirth: z.string().trim().max(20).optional().default(''),
  gender: z.string().trim().max(30).optional().default(''),
  nid: z.string().trim().max(100).min(1),
  mobile: z.string().trim().max(50).min(1),
  email: z.string().trim().email().max(254).optional().or(z.literal('')).default(''),
  address: z.string().trim().max(5000).optional().default(''),
  occupation: z.string().trim().max(200).optional().default(''),
  monthlyIncome: z.coerce.number().min(0).optional().default(0),
  admissionFee: z.coerce.number().min(0).max(100000000).optional().default(0),
  sourceOfIncome: z.string().trim().max(200).optional().default(''),
  branchId: z.string().uuid().nullable().optional(),
  memberOrigin: z.enum(['new','previous_borrower']).optional().default('new'),
  legacyCurrentInstallmentsPaid: z.coerce.number().int().min(0).optional().default(0),
  legacyCurrentInstallmentAmount: z.coerce.number().min(0).optional().default(0),
  legacySavingsBalance: z.coerce.number().min(0).optional().default(0),
  nominee: z.object({ name:z.string().trim().min(1).max(200), relation:z.string().trim().max(100).optional().default(''), mobile:z.string().trim().max(50).optional().default(''), nid:z.string().trim().max(100).optional().default(''), address:z.string().trim().max(5000).optional().default('') }).nullable().optional(),
  memberPhoto: z.string().regex(/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/).max(3000000).nullable().optional(),
  nomineePhoto: z.string().regex(/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/).max(3000000).nullable().optional()
}).strict();

const memberUpdateSchema = z.object({
  fullName: z.string().trim().min(2).max(200).optional(),
  fatherName: z.string().trim().max(200).optional(),
  motherName: z.string().trim().max(200).optional(),
  spouseName: z.string().trim().max(200).optional(),
  dateOfBirth: z.string().trim().max(20).optional(),
  gender: z.string().trim().max(30).optional(),
  nid: z.string().trim().max(100).optional(),
  mobile: z.string().trim().max(50).optional(),
  email: z.string().trim().email().max(254).optional().or(z.literal('')),
  address: z.string().trim().max(5000).optional(),
  occupation: z.string().trim().max(200).optional(),
  monthlyIncome: z.coerce.number().min(0).optional(),
  sourceOfIncome: z.string().trim().max(200).optional(),
  branchId: z.string().uuid().nullable().optional(),
  status: z.enum(['active','suspended','inactive']).optional()
}).strict();

const nomineeSchema = z.object({
  name: z.string().trim().min(1).max(200),
  relation: z.string().trim().max(100).optional().default(''),
  mobile: z.string().trim().max(50).optional().default(''),
  nid: z.string().trim().max(100).optional().default(''),
  address: z.string().trim().max(5000).optional().default('')
}).strict();

const documentSchema = z.object({
  documentType: z.string().trim().min(1).max(100),
  name: z.string().trim().min(1).max(255),
  reference: z.string().trim().max(255).optional().default(''),
  storageKey: z.string().trim().max(1000).optional().default(''),
  description: z.string().trim().max(5000).optional().default('')
}).strict();

const familySchema = z.object({
  members: z.array(z.object({
    id: z.string().max(100).optional(),
    name: z.string().trim().min(1).max(200),
    relation: z.string().trim().max(100).optional().default(''),
    mobile: z.string().trim().max(50).optional().default(''),
    occupation: z.string().trim().max(200).optional().default(''),
    dateOfBirth: z.string().trim().max(20).optional().default('')
  }).strict()).max(100),
  notes: z.string().max(5000).optional().default('')
}).strict();


function toMember(row, nominee = null, documents = [], activities = []) {
  // Merge column values under personal_info so empty JSONB {} never blanks the UI.
  const stored = (row.personal_info && typeof row.personal_info === 'object') ? row.personal_info : {};
  const personal = {
    fullName: stored.fullName || row.full_name || '',
    fatherName: stored.fatherName || '',
    motherName: stored.motherName || '',
    spouseName: stored.spouseName || '',
    dateOfBirth: stored.dateOfBirth || '',
    gender: stored.gender || '',
    nid: stored.nid || row.nid_or_passport || '',
    mobile: stored.mobile || row.phone || '',
    email: stored.email || row.email || '',
    address: stored.address || row.address || ''
  };
  const financial = (row.financial && typeof row.financial === 'object') ? row.financial : {};
  return {
    id: row.id,
    memberId: row.id,
    organizationId: row.organization_id,
    branchId: row.branch_id,
    memberCode: row.member_code,
    fullName: row.full_name || personal.fullName || '',
    email: row.email || personal.email || '',
    phone: row.phone || personal.mobile || '',
    mobile: row.phone || personal.mobile || '',
    address: row.address || personal.address || '',
    nidOrPassport: row.nid_or_passport || personal.nid || '',
    nid: row.nid_or_passport || personal.nid || '',
    status: row.status,
    personalInfo: personal,
    financial,
    family: row.family || { members: [], notes: '' },
    memberPhoto: (row.photo_path || row.photo_data || row.has_photo) ? `/api/members/${row.id}/photo` : null,
    nominee: nominee ? { ...nominee, nomineePhoto: (nominee.photo_path || nominee.photo_data || nominee.hasPhoto) ? `/api/members/${row.id}/nominee/photo` : null } : null,
    documents,
    activities,
    createdBy: row.created_by,
    updatedBy: row.updated_by,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    memberOrigin: row.member_origin || 'new',
    legacyCurrentInstallmentsPaid: Number(row.legacy_current_installments_paid || 0),
    legacyCurrentInstallmentAmount: Number(row.legacy_current_installment_amount || 0),
    legacySavingsBalance: Number(row.legacy_savings_balance || 0),
    hasBlockingLoan: Boolean(row.has_blocking_loan),
    canDelete: !Boolean(row.has_blocking_loan)
  };
}

async function assertBranch(tx, organizationId, branchId) {
  if (!branchId) return;
  const { rows } = await tx.queryNamed("membersService.js:131:159", [branchId, organizationId], {  });
  if (!rows[0]) {
    const error = new Error('Branch not found or does not belong to this organization');
    error.status = 400;
    throw error;
  }
}

async function loadMember(tx, id, organizationId, includeChildren = true) {
  const { rows } = await tx.queryNamed("membersService.js:143:160", [id, organizationId], {});
  if (!rows[0]) return null;
  let nominee = null, documents = [], activities = [];
  if (includeChildren) {
    const n = await tx.queryNamed("membersService.js:150:161", [id, organizationId], {  });
    nominee = n.rows[0] || null;
    const d = await tx.queryNamed("membersService.js:152:162", [id, organizationId], {  });
    documents = d.rows;
    const a = await tx.queryNamed("membersService.js:154:163", [id, organizationId], {  });
    activities = a.rows;
  }
  return toMember(rows[0], nominee, documents, activities);
}

async function writeAudit(tx, auth, action, id, metadata = {}) {
  await tx.queryNamed("membersService.js:161:164", [auth.organization_id, auth.user_id, action, id, JSON.stringify(metadata)], {  });
}

;

;

;

;

;

;

;

;

;

;

;

;

;

;

;

;

;

;

async function guard_members(context) {
  context.cookies ||= [];

  if (isOrganizationWide(context.auth) || !context.params.id) return null;
  try {
    const { rows } = await repository.queryNamed("membersService.js:4:131", [context.params.id, context.auth.organization_id], {  });
    if (!rows[0]) return serviceResponse(404, { error: 'Member not found' }, context);
    if (!context.auth.branch_id || String(rows[0].branch_id) !== String(context.auth.branch_id)) return serviceResponse(403, { error: 'Branch access denied' }, context);
    return null;
  } catch (e) { throw e; }

}

async function get_root_1(context) {
  context.cookies ||= [];

  try {
    const org = context.auth.organization_id;
    const q = typeof context.query.q === 'string' ? context.query.q.trim() : '';
    const status = typeof context.query.status === 'string' ? context.query.status : '';
    const branchId = typeof context.query.branch_id === 'string' ? context.query.branch_id : '';
    const limit = Math.min(Math.max(Number.parseInt(context.query.limit || '100', 10) || 100, 1), 500);
    const offset = Math.max(Number.parseInt(context.query.offset || '0', 10) || 0, 0);
    const values = [org];
    const filters = [];
    if (q) { values.push(`%${q}%`); filters.push('search'); }
    if (status) { values.push(status); filters.push('status'); }
    if (branchId) { values.push(branchId); filters.push('branchId'); }
    if (!isOrganizationWide(context.auth)) {
      if (!context.auth.branch_id) filters.push('denyAll');
      else { values.push(context.auth.branch_id); filters.push('scopedBranchId'); }
    }
    values.push(limit, offset);
    const { rows } = await repository.queryNamed("membersService.js:16:132", values, { filters });
    return serviceJson(context, {
      members: rows.map(r => {
        const nominee = r.nominee_id ? {
          id: r.nominee_id,
          name: r.nominee_name || '',
          relation: r.nominee_relation || '',
          mobile: r.nominee_mobile || '',
          nid: r.nominee_nid || '',
          address: r.nominee_address || '',
          hasPhoto: Boolean(r.nominee_has_photo),
          photo_path: r.nominee_photo_path || null
        } : null;
        // Delete is allowed only when member has no open/disbursed loan.
        return toMember(r, nominee);
      }),
      pagination: { limit, offset, returned: rows.length }
    });
  } catch (e) { throw e; }

}

async function post_root_2(context) {
  context.cookies ||= [];

  try {
    const parsed = memberCreateSchema.safeParse(context.body);
    if (!parsed.success) return serviceResponse(400, { error: 'Invalid member data' }, context);
    const d = parsed.data, org = context.auth.organization_id, tx = await repository.begin();
    try {
      await tx.begin();
      const effectiveBranchId = isOrganizationWide(context.auth) ? d.branchId : context.auth.branch_id;
      if (!effectiveBranchId) { await tx.rollback(); return serviceResponse(403, { error: 'Your account is not assigned to a branch' }, context); }
      assertBranchAccess(context.auth, effectiveBranchId);
      await assertBranch(tx, org, effectiveBranchId);
      // Enforce unique NID per organization (non-empty). The unique index in the
      // database covers every row regardless of status (including previously
      // deleted/inactive members), so this check must too — otherwise a create
      // that looks valid here can still fail with an unhandled 500 at insert time.
      if (d.nid && d.nid.trim()) {
        const dup = await tx.queryNamed("membersService.js:14:133", [org, d.nid.trim()], {  });
        if (dup.rows[0]) {
          await tx.rollback();
          const msg = dup.rows[0].status === 'inactive'
            ? 'This NID/Passport belongs to a previously deleted member in this organization and cannot be reused. Please contact an administrator.'
            : 'A member with this NID/Passport already exists in this organization';
          return serviceResponse(409, { error: msg }, context);
        }
      }
      // Race-safe member code: lock org row range then take max+1
      await tx.queryNamed("membersService.js:24:134", [org], {  });
      const maxRow = await tx.queryNamed("membersService.js:25:135", [org], {  });
      const nextNum = (maxRow.rows[0].mx || 0) + 1;
      const code = `MEM-${String(org).slice(-4)}-${String(nextNum).padStart(5, '0')}`;
      const personal = { fullName:d.fullName, fatherName:d.fatherName, motherName:d.motherName, spouseName:d.spouseName, dateOfBirth:d.dateOfBirth, gender:d.gender, nid:d.nid, mobile:d.mobile, email:d.email, address:d.address };
      const financial = { occupation:d.occupation, monthlyIncome:d.monthlyIncome, sourceOfIncome:d.sourceOfIncome };
      let rows;
      try {
        ({ rows } = await tx.queryNamed("membersService.js:34:136", [org,effectiveBranchId,code,d.fullName,d.email,d.mobile,d.address,d.nid,d.memberOrigin,d.legacyCurrentInstallmentsPaid,d.legacyCurrentInstallmentAmount,d.legacySavingsBalance,JSON.stringify(personal),JSON.stringify(financial),context.auth.user_id], {}));
      } catch (e) {
        if (e.code === '23505') {
          await tx.rollback();
          return serviceResponse(409, { error: 'A member with this NID/Passport already exists in this organization' }, context);
        }
        throw e;
      }
      // Prefer disk storage; keep BYTEA null for new writes to avoid bloating DB.
      let memberPhotoPath = null;
      if (d.memberPhoto) {
        memberPhotoPath = savePhoto({ organizationId: org, kind: 'members', entityId: rows[0].id, dataUrl: d.memberPhoto });
        if (memberPhotoPath) {
          await tx.queryNamed("membersService.js:44:137", [memberPhotoPath, rows[0].id, org], {  });
          rows[0].photo_path = memberPhotoPath;
          rows[0].photo_data = null;
          rows[0].photo_mime = null;
        }
      }
      if (d.admissionFee > 0) {
        const fee = await tx.queryNamed("membersService.js:54:138", [org, effectiveBranchId, d.admissionFee, `Member admission fee — ${code}`, context.auth.user_id], {  });
        await tx.queryNamed("membersService.js:61:139", [org, context.auth.user_id, fee.rows[0].id, JSON.stringify({ memberId: rows[0].id, memberCode: code, amount: d.admissionFee, source: 'member_registration' })], {  });
      }

      if (d.nominee) {
        let nomineePhotoPath = null;
        if (d.nomineePhoto) {
          nomineePhotoPath = savePhoto({ organizationId: org, kind: 'nominees', entityId: rows[0].id, dataUrl: d.nomineePhoto });
        }
        await tx.queryNamed("membersService.js:73:140", [org,rows[0].id,d.nominee.name,d.nominee.relation,d.nominee.mobile,d.nominee.nid,d.nominee.address,nomineePhotoPath], {  });
      }
      await writeAudit(tx, context.auth, 'MEMBER_CREATED', rows[0].id, { member_code: code, nominee_created: !!d.nominee, photo_path: memberPhotoPath });
      await tx.commit();
      return serviceResponse(201, { member: toMember(rows[0]) }, context);
    } catch (e) { await tx.rollback(); throw e; } finally { tx.release(); }
  } catch (e) { throw e; }

}

async function get_id_photo_3(context) {
  context.cookies ||= [];

  try {
    const {rows}=await repository.queryNamed("membersService.js:3:141", [context.params.id,context.auth.organization_id], {  });
    const row=rows[0]; if(!row) return serviceResponse(404, null, context);
    if(row.photo_path){
      const abs=path.resolve(path.join(__dirname,'..','..',String(row.photo_path).replace(/^\/+/,'')));
      if(!abs.startsWith(path.resolve(UPLOAD_ROOT)+path.sep) || !fs.existsSync(abs)) return serviceResponse(404, null, context);
      return serviceResponse(200, null, context, { file: abs });
    }
    if(row.photo_data && row.photo_mime){return serviceResponse(200, row.photo_data, context, { contentType: row.photo_mime });return;}
    return serviceResponse(404, null, context);
  }catch(e){throw e;}

}

async function get_id_nominee_photo_4(context) {
  context.cookies ||= [];

  try {
    const {rows}=await repository.queryNamed("membersService.js:3:142", [context.params.id,context.auth.organization_id], {  });
    const row=rows[0]; if(!row) return serviceResponse(404, null, context);
    if(row.photo_path){
      const abs=path.resolve(path.join(__dirname,'..','..',String(row.photo_path).replace(/^\/+/,'')));
      if(!abs.startsWith(path.resolve(UPLOAD_ROOT)+path.sep) || !fs.existsSync(abs)) return serviceResponse(404, null, context);
      return serviceResponse(200, null, context, { file: abs });
    }
    if(row.photo_data && row.photo_mime){return serviceResponse(200, row.photo_data, context, { contentType: row.photo_mime });return;}
    return serviceResponse(404, null, context);
  }catch(e){throw e;}

}

async function get_id_5(context) {
  context.cookies ||= [];

  try {
    const tx = await repository.begin();
    try {
      const member = await loadMember(tx, context.params.id, context.auth.organization_id);
      if (!member) return serviceResponse(404, { error: 'Member not found' }, context);
      return serviceJson(context, { member });
    } finally { tx.release(); }
  } catch (e) { throw e; }

}

async function patch_id_6(context) {
  context.cookies ||= [];

  try {
    const parsed = memberUpdateSchema.safeParse(context.body);
    if (!parsed.success) return serviceResponse(400, { error: 'Invalid member update' }, context);
    const d = parsed.data, org = context.auth.organization_id, tx = await repository.begin();
    try {
      await tx.begin();
      const current = await loadMember(tx, context.params.id, org, false);
      if (!current) { await tx.rollback(); return serviceResponse(404, { error: 'Member not found' }, context); }
      const effectiveBranchId = isOrganizationWide(context.auth) ? (d.branchId === undefined ? current.branchId : d.branchId) : context.auth.branch_id;
      if (!effectiveBranchId) { await tx.rollback(); return serviceResponse(403, { error: 'Your account is not assigned to a branch' }, context); }
      assertBranchAccess(context.auth, effectiveBranchId);
      await assertBranch(tx, org, effectiveBranchId);
      // Enforce unique NID on update (exclude self)
      const newNid = (d.nid !== undefined ? d.nid : current.nidOrPassport) || '';
      if (newNid.trim()) {
        const dup = await tx.queryNamed("membersService.js:17:143", [org, newNid.trim(), context.params.id], {  });
        if (dup.rows[0]) {
          await tx.rollback();
          const msg = dup.rows[0].status === 'inactive'
            ? 'This NID/Passport belongs to a previously deleted member in this organization and cannot be reused. Please contact an administrator.'
            : 'A member with this NID/Passport already exists in this organization';
          return serviceResponse(409, { error: msg }, context);
        }
      }
      // A member being switched to 'inactive' here must satisfy the same
      // guard as delete_id_7: no open/disbursed loan and no positive
      // savings balance — otherwise PATCH status='inactive' would silently
      // bypass the checks that block DELETE for exactly the same reason.
      if (d.status === 'inactive' && current.status !== 'inactive') {
        const activeLoan = await tx.queryNamed("membersService.js:delete:activeLoan", [context.params.id, org], {  });
        if (activeLoan.rows[0]) {
          await tx.rollback();
          return serviceResponse(409, { error: 'This member has an open loan (including an approved/pending loan). Cancel the loan first, or fully settle an active loan, before making the member inactive.' }, context);
        }
        const savings = await computeSavingsSummary(org, tx, context.params.id);
        if (savings.balance > 0.009) {
          await tx.rollback();
          return serviceResponse(409, { error: 'This member has a positive savings balance and cannot be deactivated. Withdraw or transfer the balance first.' }, context);
        }
      }
      const personal = { ...current.personalInfo };
      const financial = { ...current.financial };
      for (const k of ['fullName','fatherName','motherName','spouseName','dateOfBirth','gender','nid','mobile','email','address']) if (d[k] !== undefined) personal[k] = d[k];
      for (const k of ['occupation','monthlyIncome','sourceOfIncome']) if (d[k] !== undefined) financial[k] = d[k];
      const fullName = d.fullName ?? current.fullName, email = d.email ?? current.email, phone = d.mobile ?? current.phone, address = d.address ?? current.address, nid = d.nid ?? current.nidOrPassport;
      let rows;
      try {
        ({ rows } = await tx.queryNamed("membersService.js:31:144", [effectiveBranchId,fullName,email,phone,address,nid,d.status ?? null,d.memberOrigin ?? null,d.legacyCurrentInstallmentsPaid ?? null,d.legacyCurrentInstallmentAmount ?? null,d.legacySavingsBalance ?? null,JSON.stringify(personal),JSON.stringify(financial),context.auth.user_id,context.params.id,org], {}));
      } catch (e) {
        if (e.code === '23505') {
          await tx.rollback();
          return serviceResponse(409, { error: 'A member with this NID/Passport already exists in this organization' }, context);
        }
        throw e;
      }
      await writeAudit(tx, context.auth, 'MEMBER_UPDATED', context.params.id, { fields: Object.keys(d) });
      await tx.commit();
      return serviceJson(context, { member: toMember(rows[0]) });
    } catch (e) { await tx.rollback(); throw e; } finally { tx.release(); }
  } catch (e) { throw e; }

}

async function delete_id_7(context) {
  context.cookies ||= [];

  try {
    const org = context.auth.organization_id;
    const tx = await repository.begin();
    try {
      await tx.begin();

      // A soft-deleted ("inactive") member must not still have money tied to
      // them — an active/disbursed loan with a remaining balance, or a
      // positive savings balance — otherwise those balances keep moving
      // (payments, withdrawals) against a member no longer visible in the UI.
      const activeLoan = await tx.queryNamed("membersService.js:delete:activeLoan", [context.params.id, org], {  });
      if (activeLoan.rows[0]) {
        await tx.rollback();
        return serviceResponse(409, { error: 'This member has an open loan (including an approved/pending loan). Cancel the loan first, or fully settle an active loan, before making the member inactive.' }, context);
      }

      const savings = await computeSavingsSummary(org, tx, context.params.id);
      if (savings.balance > 0.009) {
        await tx.rollback();
        return serviceResponse(409, { error: 'This member has a positive savings balance and cannot be deleted. Withdraw or transfer the balance first.' }, context);
      }

      const { rows } = await tx.queryNamed("membersService.js:6:145", [context.auth.user_id,context.params.id,context.auth.organization_id], {  });
      if (!rows[0]) { await tx.rollback(); return serviceResponse(404, { error: 'Member not found' }, context); }
      await writeAudit(tx, context.auth, 'MEMBER_DELETED', context.params.id);
      await tx.commit();
      return serviceResponse(204, null, context);
    } catch (e) { await tx.rollback(); throw e; } finally { tx.release(); }
  } catch (e) { throw e; }

}

async function get_id_nominee_8(context) {
  context.cookies ||= [];

  try {
    const { rows } = await repository.queryNamed("membersService.js:3:146", [context.params.id, context.auth.organization_id], {  });
    return serviceJson(context, { nominee: rows[0] || null });
  } catch (e) { throw e; }

}

async function put_id_nominee_9(context) {
  context.cookies ||= [];

  try {
    const p = nomineeSchema.safeParse(context.body);
    if (!p.success) return serviceResponse(400, { error: 'Invalid nominee data' }, context);
    const tx = await repository.begin();
    try {
      await tx.begin();
      const member = await tx.queryNamed("membersService.js:8:147", [context.params.id, context.auth.organization_id], {  });
      if (!member.rows[0]) { await tx.rollback(); return serviceResponse(404, { error: 'Member not found' }, context); }
      const { rows } = await tx.queryNamed("membersService.js:10:148", [context.auth.organization_id, context.params.id, p.data.name, p.data.relation, p.data.mobile, p.data.nid, p.data.address], {  });
      await writeAudit(tx, context.auth, 'MEMBER_NOMINEE_UPDATED', context.params.id, {});
      await tx.commit();
      return serviceJson(context, { nominee: rows[0] });
    } catch (e) { await tx.rollback(); throw e; } finally { tx.release(); }
  } catch (e) { throw e; }

}

async function get_id_documents_10(context) {
  context.cookies ||= [];

  try {
    const { rows } = await repository.queryNamed("membersService.js:3:149", [context.params.id, context.auth.organization_id], {  });
    return serviceJson(context, { documents: rows });
  } catch (e) { throw e; }

}

async function post_id_documents_11(context) {
  context.cookies ||= [];

  try {
    const p = documentSchema.safeParse(context.body);
    if (!p.success) return serviceResponse(400, { error: 'Invalid document data' }, context);
    const d = p.data;
    const { rows } = await repository.queryNamed("membersService.js:6:150", [context.auth.organization_id, context.params.id, d.documentType, d.name, d.reference, d.storageKey, d.description, context.auth.user_id], {  });
    return serviceResponse(201, { document: rows[0] }, context);
  } catch (e) { throw e; }

}

async function delete_id_documents_documentId_12(context) {
  context.cookies ||= [];

  try {
    const { rowCount } = await repository.queryNamed("membersService.js:3:151", [context.params.documentId, context.params.id, context.auth.organization_id], {  });
    if (!rowCount) return serviceResponse(404, { error: 'Document not found' }, context);
    return serviceResponse(204, null, context);
  } catch (e) { throw e; }

}

async function get_id_activities_13(context) {
  context.cookies ||= [];

  try {
    const { rows } = await repository.queryNamed("membersService.js:3:152", [context.params.id, context.auth.organization_id], {  });
    return serviceJson(context, { activities: rows });
  } catch (e) { throw e; }

}

async function post_id_activities_14(context) {
  context.cookies ||= [];

  try {
    const schema = z.object({
      activityType: z.string().trim().min(1).max(100),
      description: z.string().trim().max(5000).optional().default(''),
      metadata: z.record(z.string(), z.any()).optional().default({})
    }).strict();
    const p = schema.safeParse(context.body);
    if (!p.success) return serviceResponse(400, { error: 'Invalid activity data' }, context);
    const { rows } = await repository.queryNamed("membersService.js:10:153", [context.auth.organization_id, p.data.activityType, p.data.description, JSON.stringify(p.data.metadata), context.auth.user_id, context.params.id], {  });
    if (!rows[0]) return serviceResponse(404, { error: 'Member not found' }, context);
    return serviceResponse(201, { activity: rows[0] }, context);
  } catch (e) { throw e; }

}

async function get_id_family_15(context) {
  context.cookies ||= [];

  try {
    const { rows } = await repository.queryNamed("membersService.js:3:154", [context.params.id, context.auth.organization_id], {  });
    if (!rows[0]) return serviceResponse(404, { error: 'Member not found' }, context);
    return serviceJson(context, { family: rows[0].family || { members: [], notes: '' } });
  } catch (e) { throw e; }

}

async function put_id_family_16(context) {
  context.cookies ||= [];

  try {
    const p = familySchema.safeParse(context.body);
    if (!p.success) return serviceResponse(400, { error: 'Invalid family data' }, context);
    const { rows } = await repository.queryNamed("membersService.js:5:155", [JSON.stringify(p.data), context.auth.user_id, context.params.id, context.auth.organization_id], {  });
    if (!rows[0]) return serviceResponse(404, { error: 'Member not found' }, context);
    return serviceJson(context, { family: rows[0].family });
  } catch (e) { throw e; }

}

async function get_id_financial_17(context) {
  context.cookies ||= [];

  try {
    const { rows } = await repository.queryNamed("membersService.js:3:156", [context.params.id, context.auth.organization_id], {  });
    if (!rows[0]) return serviceResponse(404, { error: 'Member not found' }, context);
    return serviceJson(context, { financial: rows[0].financial || {} });
  } catch (e) { throw e; }

}

async function patch_id_financial_18(context) {
  context.cookies ||= [];

  try {
    const p = z.object({
      occupation: z.string().max(200).optional(),
      monthlyIncome: z.coerce.number().min(0).optional(),
      sourceOfIncome: z.string().max(200).optional(),
      bankAccount: z.string().max(100).optional(),
      mobileBanking: z.string().max(100).optional()
    }).strict().safeParse(context.body);
    if (!p.success) return serviceResponse(400, { error: 'Invalid financial data' }, context);
    const current = await repository.queryNamed("membersService.js:11:157", [context.params.id, context.auth.organization_id], {  });
    if (!current.rows[0]) return serviceResponse(404, { error: 'Member not found' }, context);
    const financial = { ...(current.rows[0].financial || {}), ...p.data };
    const { rows } = await repository.queryNamed("membersService.js:14:158", [JSON.stringify(financial), context.auth.user_id, context.params.id, context.auth.organization_id], {  });
    return serviceJson(context, { financial: rows[0].financial });
  } catch (e) { throw e; }

}


async function get_legacy_borrowers_19(context) {
  const org=context.auth.organization_id;
  const limit=Math.min(Math.max(parseInt(context.query.limit||'200',10)||200,1),500);
  const branchId = isOrganizationWide(context.auth) ? null : context.auth.branch_id;
  if (!isOrganizationWide(context.auth) && !branchId) return serviceResponse(403, { error: 'Your account is not assigned to a branch' }, context);
  const values = branchId ? [org, branchId, limit] : [org, limit];
  const r=await repository.queryNamed("membersService.js:legacyBorrowers",values,{ hasBranch: Boolean(branchId) });
  return serviceJson(context,{members:r.rows.map(x=>toMember(x)),pagination:{returned:r.rows.length,limit}});
}

module.exports = { get_root_1, post_root_2, get_id_photo_3, get_id_nominee_photo_4, get_id_5, patch_id_6, delete_id_7, get_id_nominee_8, put_id_nominee_9, get_id_documents_10, post_id_documents_11, delete_id_documents_documentId_12, get_id_activities_13, post_id_activities_14, get_id_family_15, put_id_family_16, get_id_financial_17, patch_id_financial_18, get_legacy_borrowers_19, guard_members };
