"use strict";

/**
 * IMP — Daily Collection / Member-by-Member Collection
 *
 * Flow:
 * Member -> Installment / Savings -> Save
 *                          |
 *                          +-> POST /collections/daily
 *                          +-> server transaction
 *                          +-> installment schedule updated
 *                          +-> route sheet reloaded
 *
 * Installment is read-only and comes from the member's active loan.
 * Admission fee is collected during Member Add; insurance is collected at Loan Disbursement.
 */


  function showCollectorIdentity() {
    const nameEl = document.getElementById("collectorName");
    const codeEl = document.getElementById("collectorCode");
    if (!nameEl) return;
    try {
      const u = (typeof SessionManager !== "undefined" && SessionManager.getSession)
        ? SessionManager.getSession()
        : null;
      if (!u) {
        nameEl.textContent = "—";
        return;
      }
      const name = u.name || u.fullName || u.email || "User";
      const code = u.userCode || u.user_code || "";
      nameEl.textContent = name;
      if (codeEl) {
        codeEl.textContent = code ? ("কোড: " + code) : "";
      }
    } catch (e) {
      nameEl.textContent = "—";
    }
  }

  document.addEventListener("DOMContentLoaded", async function () {
  const esc = (value) =>
    String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");

  const money = (value) =>
    `৳${Number(value || 0).toLocaleString("bn-BD", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`;

  const t = (key) => {
    try {
      if (
        window.IMP_I18N &&
        typeof window.IMP_I18N.translateValue === "function"
      ) {
        return window.IMP_I18N.translateValue(key) || key;
      }
    } catch (_) {}

    return key;
  };

  const todayISO = () => {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");

    return `${y}-${m}-${day}`;
  };

  const state = {
    config: null,
    members: [],
    submittedFrequencies: [],
    date: todayISO(),
    branchId: "",
    canPickBranch: false,
    savingRows: new Set(),
    // Regenerated whenever the sheet (re)loads for a date/branch — reused
    // across repeated submitSheet() attempts for that same load so a
    // resubmit after a failed/timed-out request can't double-post the
    // daily expense.
    dailyExpenseIdemKey: "",
  };

  function newIdemKey() {
    return (window.crypto && crypto.randomUUID)
      ? crypto.randomUUID()
      : `key-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }

  function normFreq(f) {
    const s = String(f || "monthly").toLowerCase();
    if (s === "all") return "all";
    if (s.startsWith("d") || s === "daily" || s === "দৈনিক") return "daily";
    if (s.startsWith("w") || s === "weekly" || s === "সাপ্তাহিক") return "weekly";
    return "monthly";
  }

  function isFrequencySubmittedToday(freq) {
    const f = normFreq(freq);
    if (f === "all") return false;
    if (Array.isArray(state.submittedFrequencies) && state.submittedFrequencies.length) {
      if (state.submittedFrequencies.some(x => normFreq(x.frequency || x) === f)) return true;
    }
    return false;
  }

  function markFrequencySubmitted(freq, names) {
    const f = normFreq(freq);
    if (!Array.isArray(state.submittedFrequencies)) state.submittedFrequencies = [];
    const existing = state.submittedFrequencies.find(x => normFreq(x.frequency || x) === f);
    const mergedNames = Array.from(new Set([...(existing?.names || []), ...(names || [])]));
    if (existing) existing.names = mergedNames;
    else state.submittedFrequencies.push({ frequency: f, names: mergedNames });
  }

  function getSubmittedNames(freq) {
    const f = normFreq(freq);
    const fromState = (state.submittedFrequencies || []).find(x => normFreq(x.frequency || x) === f);
    return Array.isArray(fromState?.names) ? fromState.names : [];
  }

  function updateFrequencySubmitUI() {
    const raw = String(els.frequencyFilter?.value || "all").toLowerCase();
    const freq = raw === "all" ? "all" : normFreq(raw);
    let done = false;
    if (freq === "all") {
      const present = new Set();
      (state.members || []).forEach(m => (m.loans || []).forEach(l => present.add(normFreq(l.installmentFrequency || l.installment_frequency))));
      if (!present.size) present.add("monthly");
      done = [...present].every(f => isFrequencySubmittedToday(f));
    } else {
      done = isFrequencySubmittedToday(freq);
    }
    if (els.submitBtn) {
      if (done) {
        els.submitBtn.disabled = true;
        els.submitBtn.title = "আজকের জন্য এই সময়কালের কালেকশন ইতিমধ্যে জমা হয়েছে";
      } else {
        els.submitBtn.title = "";
      }
    }
    if (els.frequencyStatus) {
      const labels = { daily: "দৈনিক", weekly: "সাপ্তাহিক", monthly: "মাসিক", all: "সব সময়কাল" };
      els.frequencyStatus.textContent = done
        ? `আজ (${state.date}) ${labels[freq] || freq} কিস্তির কালেকশন ইতিমধ্যে জমা — জমা দিন বন্ধ (সার্ভার)।`
        : `নির্বাচিত: ${labels[freq] || freq} — আজকের জন্য জমা দেওয়া যাবে।`;
      els.frequencyStatus.className = "message " + (done ? "success" : "");
    }
    if (els.submittedSuccessList) {
      const showFreq = freq === "all" ? "monthly" : freq;
      const names = getSubmittedNames(showFreq);
      const labels = { daily: "দৈনিক", weekly: "সাপ্তাহিক", monthly: "মাসিক" };
      els.submittedSuccessList.innerHTML = names.length
        ? `<div class="success-list"><strong>আজ জমা হওয়া ${labels[showFreq] || showFreq} সদস্য:</strong><ul>${names.map(n => `<li>${esc(n)}</li>`).join("")}</ul></div>`
        : "";
    }
  }



  const els = {
    message: document.getElementById("collectionMessage"),
    sheetState: document.getElementById("sheetState"),
    memberList: document.getElementById("memberList"),
    date: document.getElementById("collectionDate"),
    branchWrap: document.getElementById("branchFieldWrap"),
    branchSelect: document.getElementById("branchSelect"),
    search: document.getElementById("memberSearch"),
    refresh: document.getElementById("refreshSheet"),
    totalInstallment: document.getElementById("totalInstallment"),
    totalSavings: document.getElementById("totalSavings"),
    totalGrand: document.getElementById("totalGrand"),
    submitBtn: document.getElementById("submitCollection"),
    frequencyFilter: document.getElementById("frequencyFilter"),
    frequencyStatus: document.getElementById("frequencySubmitStatus"),
    submittedSuccessList: document.getElementById("submittedSuccessList"),
    dailyExpense: document.getElementById("dailyExpense"),
  };

  try {
    const me = await IMP_API.get('/auth/me');
    const u = me?.user || me;
    const ci = document.getElementById('collectorInfo');
    if (ci) ci.textContent = `কালেকশন ব্যবহারকারী: ${u?.fullName || u?.name || u?.email || '-'}`;
  } catch (_) {}

  if (
    !els.memberList ||
    !els.date ||
    !els.search ||
    !els.refresh ||
    !els.submitBtn
  ) {
    console.error("[IMP] daily-collection: required UI element missing.");
    return;
  }

  /* =========================================================
       UI STATE
    ========================================================= */

  function showState(text, kind) {
    if (els.sheetState) {
      els.sheetState.hidden = false;
      els.sheetState.textContent = text;

      els.sheetState.className =
        "collection-state" + (kind === "error" ? " error" : "");
    }

    els.memberList.hidden = true;
  }

  function showMessage(text, type = "success") {
    if (
      typeof Utils !== "undefined" &&
      typeof Utils.showMessage === "function"
    ) {
      try {
        Utils.showMessage("collectionMessage", text, type);

        return;
      } catch (_) {}
    }

    if (els.message) {
      els.message.textContent = text;
      els.message.className = `message ${type}`;
    }
  }

  function activeConfig() {
    const base = {
      collectionTypes: {
        installment: true,
        savings: true,
      },
      defaultPaymentMethod: "cash",
      showOverdueHint: true,
      showInstallmentColumn: true,
      allowBranchOverride: false,
      requireNoteOnAdvance: false,
      allowAdvance: true,
    };
    const current = state.config || {};
    return {
      ...base,
      ...current,
      collectionTypes: { ...base.collectionTypes, ...(current.collectionTypes || {}) },
    };
  }

  /* =========================================================
       TOTAL CALCULATION
    ========================================================= */

  function recalcTotals() {
    let installment = 0;
    let savings = 0;

    els.memberList.querySelectorAll(".member-row").forEach((row) => {
      const status = row.dataset.status || "paid";

      if (status !== "baki") {
        installment += Number(row.querySelector(".in-installment")?.value || 0);
        installment += Number(row.querySelector(".in-advance")?.value || 0);

        savings += Number(row.querySelector(".in-savings")?.value || 0);

      }
    });

    const expense = Number(els.dailyExpense?.value || 0);

    const total = installment + savings;

    const net = total - expense;

    if (els.totalInstallment) {
      els.totalInstallment.textContent = money(installment);
    }

    if (els.totalSavings) {
      els.totalSavings.textContent = money(savings);
    }

    if (els.totalGrand) {
      els.totalGrand.textContent = money(net);
    }

    const netEl = document.getElementById("totalNetLabel");

    if (netEl) {
      netEl.textContent = money(net);
    }

    let hasPending = false;

    els.memberList.querySelectorAll(".member-row").forEach((row) => {
      if (row.dataset.saved === "true") {
        return;
      }

      const status = row.dataset.status || "paid";

      const i = Number(row.querySelector(".in-installment")?.value || 0);
      const a = Number(row.querySelector(".in-advance")?.value || 0);

      const s = Number(row.querySelector(".in-savings")?.value || 0);

      if (status === "baki" || i > 0 || a > 0 || s > 0) {
        hasPending = true;
      }

      const saveButton = row.querySelector(".btn-save-member");
      if (saveButton && status !== "baki") {
        const due = Number(row.dataset.defaultAmount || i || 0);
        const canSave = due > 0.009 || a > 0.009;
        saveButton.disabled = canSave ? false : true;
        saveButton.title = a > 0.009
          ? t("Save installment and advance collection")
          : canSave
            ? t("Save installment collection")
            : t("No installment balance is due; use Submit for savings-only collection");
      }
    });

    const _rf = String(els.frequencyFilter?.value || "all").toLowerCase();
    let freqLocked = false;
    if (_rf === "all") {
      const present = new Set();
      (state.members || []).forEach(m => (m.loans || []).forEach(l => present.add(normFreq(l.installmentFrequency || l.installment_frequency))));
      if (!present.size) present.add("monthly");
      freqLocked = [...present].every(f => isFrequencySubmittedToday(f));
    } else {
      freqLocked = isFrequencySubmittedToday(normFreq(_rf));
    }
    els.submitBtn.disabled = freqLocked || !hasPending || state.savingRows.size > 0;
  }

  /* =========================================================
       MEMBER ROW
    ========================================================= */

  function memberRowHTML(member, config) {
    /*
     * The route-sheet API may return either camelCase
     * or snake_case loan fields.
     */

    const loan =
      Array.isArray(member.loans) && member.loans.length
        ? member.loans[0]
        : null;

    /* -----------------------------------------------------
           Loan installment
        ----------------------------------------------------- */

    // IMPORTANT: Daily collection must use the CURRENT amount due,
    // not the loan's original scheduled installment. The API returns
    // dueTodayAmount as the remaining outstanding amount through the
    // selected date (including overdue installments).
    const installmentAmount = loan
      ? Number(
          loan.dueTodayAmount ??
            loan.due_today_amount ??
            loan.installmentAmount ??
            loan.installment_amount ??
            0,
        )
      : 0;
    /* -----------------------------------------------------
           Today's due amount
           IMPORTANT:
           Do NOT use an undeclared dueToday variable.
        ----------------------------------------------------- */

    const dueToday = loan
      ? Number(
          loan.dueTodayAmount ??
            loan.due_today_amount ??
            loan.dueToday ??
            loan.due_today ??
            installmentAmount,
        )
      : 0;

    /* -----------------------------------------------------
           Overdue amount
        ----------------------------------------------------- */

    const overdueAmt = loan
      ? Number(loan.overdueAmount ?? loan.overdue_amount ?? 0)
      : 0;

    const noLoan = !loan;

    /*
     * Default installment always comes from the loan.
     * Collector cannot manually change it.
     */

    const defaultAmt = Math.max(0, dueToday);
    const hasInstallmentDue = defaultAmt > 0.009;

    /* -----------------------------------------------------
           Due badge
        ----------------------------------------------------- */

    const badge =
      config.showOverdueHint && dueToday > 0
        ? `
                    <span class="due-badge">
                        ${
                          overdueAmt > 0.009
                            ? esc(t("Overdue included")) + ": "
                            : esc(t("Due today")) + ": "
                        }
                        ${money(dueToday)}
                    </span>
                  `
        : "";

    /* -----------------------------------------------------
           Installment field
        ----------------------------------------------------- */

    const installmentField =
      config.showInstallmentColumn !== false
        ? `

                <div class="input-field installment-field">

                    <label>
                        ${esc(t("Installment"))}

                        ${
                          loan
                            ? " (" +
                              esc(loan.loanNumber ?? loan.loan_number ?? "") +
                              ")"
                            : ""
                        }
                    </label>

                    <div class="input-wrap">

                        <input
                            type="number"
                            class="in-installment"
                            min="0"
                            step="0.01"
                            value="${defaultAmt.toFixed(2)}"
                            ${noLoan ? "disabled" : ""}
                            readonly
                            tabindex="-1"
                            data-loan-id="${
                              loan
                                ? esc(
                                    loan.loanId ??
                                      loan.loan_id ??
                                      loan.id ??
                                      "",
                                  )
                                : ""
                            }"
                            data-default="${defaultAmt.toFixed(2)}"
                        >

                    </div>

                    ${
                      loan
                        ? `
                                <small class="auto-installment-note">
                                    Auto: ঋণের নির্ধারিত কিস্তি
                                </small>
                              `
                        : `
                                <small class="auto-installment-note">
                                    কোনো সক্রিয় ঋণ নেই
                                </small>
                              `
                    }

                </div>

            `
        : "";

    /* -----------------------------------------------------
           Advance installment
        ----------------------------------------------------- */

    const advanceField =
      loan && config.allowAdvance
        ? `
                    <div class="input-field advance-field">
                        <label>${esc(t("Advance Installment"))}</label>
                        <div class="input-wrap">
                            <input
                                type="number"
                                class="in-advance"
                                min="0"
                                step="0.01"
                                value="0"
                                placeholder="0.00"
                            >
                        </div>
                        <small class="balance-hint">
                            ${esc(t("Excess will be allocated to future installments automatically."))}
                        </small>
                    </div>
                  `
        : "";

    /* -----------------------------------------------------
           Savings
        ----------------------------------------------------- */

    const savingsField =
      config.collectionTypes?.savings !== false
        ? `

                    <div class="input-field">

                        <label>
                            ${esc(t("Savings"))}
                        </label>

                        <div class="input-wrap">

                            <input
                                type="number"
                                class="in-savings"
                                min="0"
                                step="0.01"
                                placeholder="0.00"
                                value="${Number(loan?.savingsAmount ?? loan?.savings_amount ?? 0).toFixed(2)}"
                            >

                        </div>

                        <small class="balance-hint">
                            ${esc(t("Auto from loan"))}: ${money(loan?.savingsAmount ?? loan?.savings_amount ?? 0)}
                            · ${esc(t("Current balance"))}: ${money(member.savingsBalance || 0)}
                        </small>

                    </div>

                  `
        : "";

    /* -----------------------------------------------------
           Notes
        ----------------------------------------------------- */

    const notesField = `

            <div class="input-field">

                <label>
                    ${esc(t("Note"))}
                </label>

                <input
                    type="text"
                    class="in-notes"
                    maxlength="2000"
                    placeholder="${esc(t("Optional"))}"
                >

            </div>

        `;

    /* -----------------------------------------------------
           Final row
        ----------------------------------------------------- */

    return `

            <article
                class="member-row"
                data-frequency="${normFreq((member.loans&&member.loans[0]&&(member.loans[0].installmentFrequency||member.loans[0].installment_frequency))||'monthly')}" data-member-id="${esc(
                  member.memberId || member.member_id || member.id || "",
                )}"
                data-status="paid"
                data-saved="false"
                data-default-amount="${defaultAmt.toFixed(2)}"
                data-installment-due="${hasInstallmentDue ? "true" : "false"}"
            >

                <div class="member-row-top">

                    <div class="member-identity">

                        <strong class="member-name">
                            ${esc(member.fullName || member.full_name || "")}
                        </strong>

                        <span class="member-meta">

                            ${esc(
                              member.memberCode || member.member_code || "",
                            )}

                            ${member.phone ? " · " + esc(member.phone) : ""}

                        </span>

                        ${badge}

                    </div>


                    <div class="member-status-actions">

                        <span class="status-badge status-paid">
                            ${esc(t("Paid"))}
                        </span>

                        <button
                            type="button"
                            class="btn-status-paid active"
                            data-action="paid"
                        >
                            ${esc(t("Paid"))}
                        </button>

                        <button
                            type="button"
                            class="btn-status-edit"
                            data-action="baki"
                        >
                            ${esc(t("Baki"))}
                        </button>

                    </div>

                </div>


                <div class="member-inputs">

                    ${installmentField}

                    ${advanceField}

                    ${savingsField}

                    ${notesField}

                </div>


                <div
                    class="baki-panel"
                    hidden
                >

                    <p class="baki-hint">
                        ${esc(
                          t(
                            "Mark this member as arrears. Installment will be excluded from today's total.",
                          ),
                        )}
                    </p>

                    <button
                        type="button"
                        class="btn-confirm-baki"
                    >
                        ${esc(t("Set as Baki"))}
                    </button>

                    <button
                        type="button"
                        class="btn-cancel-baki"
                    >
                        ${esc(t("Cancel"))}
                    </button>

                </div>


                <div class="member-row-footer">

                    <span
                        class="row-feedback"
                        aria-live="polite"
                    ></span>

                    <button
                        type="button"
                        class="btn-save-member"
                        data-action="save-member"
                        ${hasInstallmentDue ? "" : "disabled"}
                        title="${esc(hasInstallmentDue ? t("Save installment collection") : t("Click Baki to enable Save Member, or use Submit for savings-only collection"))}"
                    >
                        ${esc(t("Save Member"))}
                    </button>

                </div>

            </article>

        `;
  }

  /* =========================================================
       PAID
    ========================================================= */

  function setPaid(row) {
    row.dataset.status = "paid";
    row.dataset.saved = "false";

    const badge = row.querySelector(".status-badge");

    const paidBtn = row.querySelector(".btn-status-paid");

    const bakiBtn = row.querySelector(".btn-status-edit");

    const panel = row.querySelector(".baki-panel");

    const input = row.querySelector(".in-installment");
    const savingsInput = row.querySelector(".in-savings");
    const advanceInput = row.querySelector(".in-advance");

    if (badge) {
      badge.className = "status-badge status-paid";

      badge.textContent = t("Paid");
    }

    paidBtn?.classList.add("active");
    bakiBtn?.classList.remove("active");

    if (panel) {
      panel.hidden = true;
    }

    /*
     * Installment remains read-only.
     * It is always restored from data-default-amount.
     */

    if (input && !input.disabled) {
      input.value = Number(row.dataset.defaultAmount || 0).toFixed(2);
      input.readOnly = true;
    }

    if (savingsInput) {
      savingsInput.readOnly = false;
    }

    if (advanceInput) {
      advanceInput.value = "0.00";
      advanceInput.readOnly = false;
    }

    // Paid rows can be saved only when there is an installment balance.
    // Savings-only rows are submitted through the global Submit button.
    const saveButton = row.querySelector(".btn-save-member");
    if (saveButton) {
      const due = Number(row.dataset.defaultAmount || 0);
      const advance = Number(advanceInput?.value || 0);
      saveButton.disabled = due <= 0.009 && advance <= 0.009;
      saveButton.title = saveButton.disabled
        ? t("No installment balance is due; use Submit for savings-only collection")
        : advance > 0.009
          ? t("Save installment and advance collection")
          : t("Save installment collection");
    }

    recalcTotals();
  }

  /* =========================================================
       BAKI
    ========================================================= */

  function setBaki(row) {
    row.dataset.status = "baki";
    row.dataset.saved = "false";

    const badge = row.querySelector(".status-badge");

    const paidBtn = row.querySelector(".btn-status-paid");

    const bakiBtn = row.querySelector(".btn-status-edit");

    const panel = row.querySelector(".baki-panel");

    const input = row.querySelector(".in-installment");
    const savingsInput = row.querySelector(".in-savings");
    const advanceInput = row.querySelector(".in-advance");

    if (badge) {
      badge.className = "status-badge status-baki";

      badge.textContent = t("Baki");
    }

    paidBtn?.classList.remove("active");
    bakiBtn?.classList.add("active");

    if (panel) {
      panel.hidden = true;
    }

    if (input && !input.disabled) {
      input.value = "0.00";
      input.readOnly = true;
    }

    // Baki means no money movement for this daily-collection row.
    // Clear every collection field so the UI and submitted payload cannot
    // disagree after a Paid → Baki toggle.
    if (advanceInput) {
      advanceInput.value = "0.00";
      advanceInput.readOnly = true;
    }

    if (savingsInput) {
      savingsInput.value = "0.00";
      savingsInput.readOnly = true;
    }

    // IMPORTANT: Clicking Baki means the collector is explicitly recording
    // this member as arrears. Therefore Save Member must become enabled even
    // when the installment balance is zero. The save records the Baki status
    // without moving money.
    const saveButton = row.querySelector(".btn-save-member");
    if (saveButton) {
      saveButton.disabled = false;
      saveButton.title = t("Save member as Baki");
    }

    recalcTotals();
  }

  /* =========================================================
       ROW ENTRY
    ========================================================= */

  function getRowEntry(row) {
    const status = row.dataset.status || "paid";

    const due = Number(
      row.querySelector(".in-installment")?.value || 0,
    );

    const advance = Number(
      row.querySelector(".in-advance")?.value || 0,
    );

    const installment = due + advance;

    const savings = Number(row.querySelector(".in-savings")?.value || 0);


    const loanId = row.querySelector(".in-installment")?.dataset.loanId || null;

    const notes = row.querySelector(".in-notes")?.value.trim() || "";

    if (
      status !== "baki" &&
      installment <= 0 &&
      savings <= 0
    ) {
      return null;
    }

    return {
      memberId: row.dataset.memberId,

      loanId: installment > 0 || status === "baki" ? loanId : null,

      /*
       * Installment comes from the loan.
       * Frontend sends the current readonly value.
       * Server must validate it against the loan schedule.
       */

      installmentAmount: status === "baki" ? 0 : installment,

      savingsAmount: status === "baki" ? 0 : savings,

      paymentMethod: activeConfig().defaultPaymentMethod || "cash",

      notes,

      status,

      // Stable per-row key: reused across a manual resubmit of the same
      // unsaved row (e.g. after a timeout/network error), so the server can
      // tell a genuine retry apart from a new collection and never post the
      // same installment/savings amount twice. A fresh row (after the sheet
      // reloads) gets a fresh key.
      idempotencyKey: getRowIdempotencyKey(row),
    };
  }

  function getRowIdempotencyKey(row) {
    if (!row.dataset.idempotencyKey) {
      row.dataset.idempotencyKey = newIdemKey();
    }
    return row.dataset.idempotencyKey;
  }

  /* =========================================================
       ROW SAVE
    ========================================================= */

  function setRowSaving(row, saving) {
    const button = row.querySelector(".btn-save-member");

    if (button) {
      const canSave =
        row.dataset.status === "baki" ||
        Number(row.dataset.defaultAmount || 0) > 0.009 ||
        Number(row.querySelector(".in-advance")?.value || 0) > 0.009;

      button.disabled = saving || !canSave;

      button.textContent = saving ? t("Saving...") : t("Save Member");
    }

    row.classList.toggle("row-saving", saving);
  }

  function setRowFeedback(row, text, type) {
    const feedback = row.querySelector(".row-feedback");

    if (!feedback) return;

    feedback.className = `row-feedback ${type || ""}`;

    feedback.textContent = text || "";
  }

  async function saveSingleRow(row) {
    const memberId = row.dataset.memberId;
    if (!memberId) return false;

    const entry = getRowEntry(row);
    if (!entry) {
      setRowFeedback(row, t("No collection amount. Use Baki only when the member did not pay."), "error");
      return false;
    }

    // "Save Member" is a local preparation step. Money is NOT posted here.
    // The final "জমা দিন" button posts every prepared/eligible member in one
    // daily collection batch, which matches the organization's workflow.
    row.dataset.prepared = "true";
    row.dataset.saved = "false";
    row.classList.remove("row-failed");
    row.classList.add("row-prepared");
    setRowFeedback(
      row,
      entry.status === "baki"
        ? t("Baki saved. Click Submit to post today's collection.")
        : t("Member prepared. Click Submit to post today's collection."),
      "success"
    );
    recalcTotals();
    return true;
  }

  /* =========================================================
       BIND ROW EVENTS
    ========================================================= */

  function bindRows() {
    els.memberList.querySelectorAll(".member-row").forEach((row) => {

      row.querySelectorAll("input[type=number]").forEach((input) => {
        input.addEventListener("input", () => {
          row.dataset.saved = "false";

          recalcTotals();
        });
      });

      row.querySelector(".in-notes")?.addEventListener("input", () => {
        row.dataset.saved = "false";

        recalcTotals();
      });

      row
        .querySelector(".btn-status-paid")
        ?.addEventListener("click", () => setPaid(row));

      // Baki is a direct row action. A single click changes the row to Baki
      // and enables Save Member, including when installment balance is zero.
      row
        .querySelector(".btn-status-edit")
        ?.addEventListener("click", () => setBaki(row));

      // Kept for backward compatibility with the existing Baki confirmation
      // panel, if it is rendered by an older cached page.
      row
        .querySelector(".btn-confirm-baki")
        ?.addEventListener("click", () => setBaki(row));

      row.querySelector(".btn-cancel-baki")?.addEventListener("click", () => {
        const panel = row.querySelector(".baki-panel");

        if (panel) {
          panel.hidden = true;
        }
      });

      row
        .querySelector(".btn-save-member")
        ?.addEventListener("click", () => saveSingleRow(row));
    });
  }

  /* =========================================================
       RENDER
    ========================================================= */

  function renderMembers(members) {
    const rawFreq = String(els.frequencyFilter?.value || "all").toLowerCase();
    const freq = rawFreq === "all" ? "all" : normFreq(rawFreq);
    // Filter by loan installment frequency (or show all)
    const filtered = (members || []).filter((member) => {
      if (freq === "all") return true;
      const loans = member.loans || member.Loans || [];
      if (!loans.length) return true; // savings-only visible in all + monthly contexts
      return loans.some((loan) => normFreq(loan.installmentFrequency || loan.installment_frequency || loan.frequency) === freq);
    }).map((member) => {
      if (freq === "all") return member;
      const loans = (member.loans || []).filter(
        (loan) => normFreq(loan.installmentFrequency || loan.installment_frequency || loan.frequency) === freq
      );
      return loans.length ? { ...member, loans } : member;
    });

    if (!filtered.length) {
      showState(t("No active members found for this date/branch/search.") + ` (${freq})`);
      els.memberList.hidden = true;
      els.memberList.innerHTML = "";
      recalcTotals();
      updateFrequencySubmitUI();
      return;
    }

    els.sheetState.hidden = true;
    els.memberList.hidden = false;

    els.memberList.innerHTML = filtered
      .map((member) => memberRowHTML(member, activeConfig()))
      .join("");

    bindRows();
    recalcTotals();
    updateFrequencySubmitUI();
  }

  /* =========================================================
       BRANCHES
    ========================================================= */

  async function loadBranches() {
    if (!els.branchSelect || !els.branchWrap) {
      return;
    }

    try {
      const branches = await BranchManager.getAll();

      if (!Array.isArray(branches) || !branches.length) {
        return;
      }

      state.canPickBranch = true;

      els.branchWrap.hidden = false;

      const currentBranch = SessionManager.getBranchId();

      els.branchSelect.innerHTML =
        `<option value="">${esc(
          currentBranch ? t("My Branch") : t("All Branches"),
        )}</option>` +
        branches
          .map(
            (branch) =>
              `<option value="${esc(branch.id)}">${esc(
                branch.name || branch.branch_name || "Branch",
              )}</option>`,
          )
          .join("");

      if (currentBranch) {
        const session = SessionManager.getCurrentUser?.() || {};

        const role = session.role_code || session.role || "";

        const orgWide = ["organization_admin", "super_admin"].includes(role);

        if (!orgWide) {
          state.branchId = currentBranch;

          els.branchSelect.value = currentBranch;

          els.branchSelect.disabled = true;
        }
      }
    } catch (error) {
      console.warn("[IMP] branch list unavailable:", error?.message || error);
    }
  }

  /* =========================================================
       OFFLINE-FIRST DAILY COLLECTION
    ========================================================= */

  const offlineKey = () =>
    `daily|${state.date}|${state.branchId || ""}|${els.search.value.trim()}`;

  function offlineStatus(text, kind = "offline") {
    const el = document.getElementById("offlineStatus");
    if (!el) return;
    el.textContent = text;
    el.dataset.state = kind;
    el.hidden = false;
  }

  async function cacheCurrentSheet(result) {
    if (!window.IMP_OFFLINE) return;
    try {
      await IMP_OFFLINE.cacheRoute(offlineKey(), {
        members: Array.isArray(result?.members) ? result.members : [],
        config: result?.config || null
      });
    } catch (e) {
      console.warn("[IMP] offline route cache failed:", e);
    }
  }

  async function loadCachedSheet() {
    if (!window.IMP_OFFLINE) return false;
    try {
      const cached = await IMP_OFFLINE.getRoute(offlineKey());
      if (!cached?.value) return false;
      state.members = Array.isArray(cached.value.members) ? cached.value.members : [];
      state.config = cached.value.config || state.config;
      renderMembers(state.members);
      offlineStatus("Offline cache — সর্বশেষ সংরক্ষিত Route Sheet", "offline");
      return true;
    } catch (e) {
      console.warn("[IMP] offline route cache read failed:", e);
      return false;
    }
  }

  async function syncDailyCollectionQueue() {
    if (!window.IMP_OFFLINE || !navigator.onLine) return;
    const queued = await IMP_OFFLINE.allQueued().catch(() => []);
    if (!queued.length) return;

    let completed = 0;
    for (const item of queued.sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt)))) {
      try {
        await IMP_API.post(item.endpoint, item.payload);
        await IMP_OFFLINE.remove(item.queueId);
        completed++;
      } catch (e) {
        item.attempts = Number(item.attempts || 0) + 1;
        item.lastError = e?.message || String(e);
        await IMP_OFFLINE.update(item).catch(() => {});
      }
    }
    if (completed) {
      offlineStatus(`Offline queue sync সম্পন্ন — ${completed}টি জমা`, "online");
      await loadSheet({ silent: true });
    }
  }

  /* =========================================================
       LOAD SHEET
    ========================================================= */

  async function loadSheet(options = {}) {
    if (!options.silent) {
      showState(t("Loading...") + "…");
    }

    // Only mint a new daily-expense idempotency key when the sheet is for a
    // different date/branch than the one it currently covers — NOT on every
    // silent reload after a submit, since a submit that only partially
    // succeeded (entries failed, expense not yet saved) still reloads the
    // sheet and must keep the same key so a resubmit stays a true retry.
    const sheetIdentity = `${state.date}|${state.branchId || ""}`;
    if (state.dailyExpenseIdemFor !== sheetIdentity) {
      state.dailyExpenseIdemKey = newIdemKey();
      state.dailyExpenseIdemFor = sheetIdentity;
    }

    els.submitBtn.disabled = true;

    try {
      const query = new URLSearchParams();

      query.set("date", state.date);

      if (state.branchId) {
        query.set("branchId", state.branchId);
      }

      const term = els.search.value.trim();

      if (term) {
        query.set("q", term);
      }

      const result = await IMP_API.get(
        `/collections/route-sheet?${query.toString()}`,
      );

      state.members = Array.isArray(result?.members) ? result.members : [];
      state.submittedFrequencies = Array.isArray(result?.submittedFrequencies) ? result.submittedFrequencies : [];
      // The server lock is authoritative. Keep the response in memory only;
      // financial collection state must never be persisted in browser storage APIs.
      state.config = result?.config || state.config;

      renderMembers(state.members);
      await cacheCurrentSheet(result);
      offlineStatus("Online — Route Sheet live", "online");
    } catch (error) {
      const usedCache = await loadCachedSheet();
      if (!usedCache) {
        showState(error?.message || t("Could not load route sheet."), "error");
      }
      console.warn("[IMP] daily-collection load:", error);
    }
  }

  /* =========================================================
       PENDING ENTRIES
    ========================================================= */

  function collectPendingEntries() {
    const entries = [];

    els.memberList.querySelectorAll(".member-row").forEach((row) => {
      // The organization wants the final Submit action to post the complete
      // daily sheet. Every member with a due installment, savings amount, or
      // explicit Baki status is therefore eligible for the batch.
      const entry = getRowEntry(row);
      if (entry) {
        entries.push({ row, entry });
      }
    });

    return entries;
  }

  /* =========================================================
       SUBMIT SHEET
    ========================================================= */

  async function submitSheet() {
    const rawFreq = String(els.frequencyFilter?.value || "all").toLowerCase();
    // Server lock is per concrete frequency — "all" submits as the dominant
    // frequency of pending rows (must be single frequency in one submit).
    let freq = rawFreq === "all" ? null : normFreq(rawFreq);
    const pending = collectPendingEntries();
    if (!freq && pending.length) {
      const freqs = new Set();
      pending.forEach(({ row }) => {
        const f = row.dataset.frequency || row.dataset.installmentFrequency;
        if (f) freqs.add(normFreq(f));
      });
      if (freqs.size === 1) freq = [...freqs][0];
      else if (freqs.size === 0) freq = "monthly";
      else {
        showMessage("একসাথে একাধিক সময়কালের কিস্তি জমা দেওয়া যাবে না। ড্রপডাউন থেকে দৈনিক/সাপ্তাহিক/মাসিক বেছে নিন।", "error");
        return;
      }
    }
    freq = freq || "monthly";
    if (isFrequencySubmittedToday(freq)) {
      showMessage("আজকের জন্য এই সময়কালের কালেকশন ইতিমধ্যে জমা হয়েছে।", "error");
      updateFrequencySubmitUI();
      return;
    }

    // pending already collected above


    if (!pending.length && !els.memberList.querySelector(".member-row")) {
      showMessage(t("No members are available for this collection sheet."), "error");
      return;
    }

    els.submitBtn.disabled = true;

    els.submitBtn.textContent = t("Submitting...") + "…";

    try {
      const result = await IMP_API.post("/collections/daily", {
        date: state.date,
        branchId: state.branchId || null,
        frequency: freq,
        dailyExpense: Number(els.dailyExpense?.value || 0),
        dailyExpenseIdempotencyKey: state.dailyExpenseIdemKey,
        entries: pending.map((x) => x.entry),
      });

      const byMember = new Map(
        (result?.results || []).map((item) => [item.memberId, item]),
      );

      let success = 0;
      let failure = 0;

      pending.forEach(({ row }) => {
        const item = byMember.get(row.dataset.memberId);

        if (item?.success) {
          row.dataset.saved = "true";
          // Saved — any later resubmit of a fresh amount on this row must
          // not be deduped against this one.
          delete row.dataset.idempotencyKey;

          row.classList.add("row-success");

          row.classList.remove("row-failed");

          setRowFeedback(row, t("Saved successfully."), "success");

          success++;
        } else {
          row.dataset.saved = "false";

          row.classList.add("row-failed");

          row.classList.remove("row-success");

          setRowFeedback(row, item?.error || t("Save failed."), "error");

          failure++;
        }
      });

      const summary = result?.summary || {};

      // The expense was actually recorded — a later, genuinely new expense
      // entry for this same date/branch must not be deduped against it.
      if (summary.dailyExpenseSaved) {
        state.dailyExpenseIdemKey = newIdemKey();
      }

      showMessage(
        `${t("Today's collection saved")} — ` +
          `${t("Successful")}: ${success}, ` +
          `${t("Failed")}: ${failure}, ` +
          `${t("Total")}: ${money(summary.totalCollected || 0)}`,
        failure ? "error" : "success",
      );

      if (success > 0) {
        const freq = normFreq(els.frequencyFilter?.value || "monthly");
        const names = [];
        pending.forEach(({ row }) => {
          const item = byMember.get(row.dataset.memberId);
          if (item?.success) {
            const nm = row.dataset.memberName || row.querySelector(".member-name")?.textContent || row.dataset.memberId;
            names.push(String(nm || "").trim());
          }
        });
        markFrequencySubmitted(freq, names.filter(Boolean));
        updateFrequencySubmitUI();
      }

      await loadSheet({
        preserveSearch: true,
        silent: true,
      });
    } catch (error) {
      // Network/server-unavailable: persist the complete batch locally.
      // The existing per-entry and daily-expense idempotency keys make replay safe.
      if (window.IMP_OFFLINE) {
        try {
          const queueId = newIdemKey();
          await IMP_OFFLINE.queue({
            queueId,
            endpoint: "/collections/daily",
            payload: {
              date: state.date,
              branchId: state.branchId || null,
              dailyExpense: Number(els.dailyExpense?.value || 0),
              dailyExpenseIdempotencyKey: state.dailyExpenseIdemKey,
              entries: pending.map((x) => x.entry),
            }
          });
          pending.forEach(({ row }) => {
            row.dataset.saved = "true";
            row.classList.add("row-prepared");
            setRowFeedback(row, "Offline queue-তে সংরক্ষিত — Internet এলে স্বয়ংক্রিয়ভাবে Sync হবে।", "success");
          });
          offlineStatus("Offline — Collection queued for sync", "offline");
          showMessage("ইন্টারনেট নেই/সার্ভার পাওয়া যাচ্ছে না। আজকের কালেকশন Offline Queue-তে নিরাপদে রাখা হয়েছে।", "success");
        } catch (queueError) {
          showMessage(queueError?.message || error?.message || t("Could not submit collection."), "error");
        }
      } else {
        if (error?.status === 409 || error?.payload?.code === "FREQUENCY_ALREADY_SUBMITTED") {
          markFrequencySubmitted(freq, []);
          state.submittedFrequencies = [...(state.submittedFrequencies || []), { frequency: freq }];
          updateFrequencySubmitUI();
        }
        showMessage(error?.message || error?.payload?.error || t("Could not submit collection."), "error");
      }
      console.error("[IMP] daily-collection submit:", error);
    } finally {
      els.submitBtn.textContent = t("Submit");

      recalcTotals();
    }
  }

  /* =========================================================
       INITIALIZE
    ========================================================= */

  try {
    if (
      typeof SessionManager === "undefined" ||
      !(await SessionManager.requireAuth())
    ) {
      return;
    }
    showCollectorIdentity();

    await RBACManager.bootstrap();

    if (!RBACManager.hasPermission("collection.create")) {
      throw new Error(
        t("You do not have permission to enter daily collections."),
      );
    }

    els.date.value = state.date;

    await loadBranches();

    await syncDailyCollectionQueue();
    await loadSheet();

    window.addEventListener("online", async () => {
      offlineStatus("Online — Sync চলছে…", "online");
      await syncDailyCollectionQueue();
      await loadSheet({ silent: true });
    });

    window.addEventListener("offline", () => {
      offlineStatus("Offline — cached Route Sheet ব্যবহার হচ্ছে", "offline");
    });

    els.date.addEventListener("change", () => {
      state.date = els.date.value || todayISO();

      loadSheet();
    });

    els.branchSelect?.addEventListener("change", () => {
      if (!els.branchSelect.disabled) {
        state.branchId = els.branchSelect.value;

        loadSheet();
      }
    });

    els.refresh.addEventListener("click", () => loadSheet());

    els.frequencyFilter?.addEventListener("change", () => {
      renderMembers(state.members || []);
      updateFrequencySubmitUI();
    });

    let searchTimer = null;

    els.search.addEventListener("input", () => {
      clearTimeout(searchTimer);

      searchTimer = setTimeout(() => loadSheet(), 300);
    });

    els.dailyExpense?.addEventListener("input", recalcTotals);

    els.submitBtn.addEventListener("click", submitSheet);

    window.addEventListener("imp:languagechange", () => {
      if (state.members.length) {
        renderMembers(state.members);
      }

      if (window.IMP_I18N) {
        window.IMP_I18N.apply();
      }
    });
  } catch (error) {
    showState(
      error?.message || t("Could not open daily collection sheet."),
      "error",
    );

    showMessage(
      error?.message || t("Could not open daily collection sheet."),
      "error",
    );

    console.error("[IMP] daily-collection init:", error);
  }
});
