'use strict';

if ('serviceWorker' in navigator) {
  navigator.serviceWorker
    .register('../../sw.js', { scope: '../../' })
    .catch((error) => console.warn('[IMP] service worker registration failed:', error));
}
