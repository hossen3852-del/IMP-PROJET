const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "../..");
const daily = fs.readFileSync(path.join(root, "js/collections/daily-collection.js"), "utf8");
const html = fs.readFileSync(path.join(root, "pages/collections/daily-collection.html"), "utf8");
const sw = fs.readFileSync(path.join(root, "sw.js"), "utf8");
const swRegister = fs.readFileSync(path.join(root, "js/core/service-worker-register.js"), "utf8");
const manifest = JSON.parse(fs.readFileSync(path.join(root, "manifest.json"), "utf8"));

test("daily collection has IndexedDB route cache and offline queue", () => {
  assert.match(daily, /IMP_OFFLINE\.cacheRoute/);
  assert.match(daily, /IMP_OFFLINE\.getRoute/);
  assert.match(daily, /IMP_OFFLINE\.queue/);
  assert.match(daily, /syncDailyCollectionQueue/);
});

test("daily collection registers PWA shell and offline store", () => {
  assert.match(html, /offline-store\.js/);
  assert.match(html, /service-worker-register\.js/);
  assert.match(swRegister, /serviceWorker[\s\S]*\.register/);
  assert.match(html, /manifest\.json/);
});

test("service worker avoids caching API responses", () => {
  assert.match(sw, /url\.pathname\.includes\("\/api\/"\)/);
  assert.match(sw, /caches\.match\(req\)/);
});

test("manifest is standalone and has install icons", () => {
  assert.equal(manifest.display, "standalone");
  assert.ok(Array.isArray(manifest.icons) && manifest.icons.length >= 2);
});
