# IMP Fixes — Member Profile, Loan Member List, Dashboard Session, i18n

Date: 2026-09-13

## Bugs fixed

### 1. Member profile / list showing "-"
- **Cause:** `toMember()` treated empty JSONB `personal_info = {}` as truthy, so column fallbacks never ran.
- **Fix:** Always merge `full_name`, `phone`, `nid_or_passport`, etc. under `personalInfo`.
- **Files:** `server/routes/members.js`, `js/members/member-profile.js`, `js/members/member-list.js`

### 2. Loan form not showing members after add
- **Cause:** Weak display fallbacks; silent empty list; auth race (`requireAuth` was not truly async).
- **Fix:**
  - Loan form shows `fullName || personalInfo.fullName` and warns if no active members.
  - `SessionManager.requireAuth()` now awaits `/auth/me`.
  - `setSession` / `clearSession` invalidate bootstrap cache.
- **Files:** `js/loans/loan-form.js`, `js/auth/session.js`

### 3. Dashboard profile menu — org name / role blank
- **Cause:** Login response had no `organization`; client did not refresh session from `/auth/me`.
- **Fix:**
  - Login API now returns `organization` (name, status, branch).
  - `AuthManager.login` / `register` call `SessionManager.refresh()` after cookie is set.
- **Files:** `server/routes/auth.js`, `js/auth/auth.js`, `js/auth/session.js`

### 4. Language — Bangla default, English switch
- Default remains `localStorage imp_ui_language || 'bn'`.
- Expanded BN dictionary for loan form, profile, dashboard labels.
- All non-empty HTML pages already load `js/core/i18n.js` + `css/i18n.css`.

## Tests
- Full suite: **172/172 PASS**

## Deploy note
```bash
npm ci
npm run db:migrate
npm run db:validate   # requires DATABASE_URL
npm test
npm start             # serve app and API on same origin (e.g. :3000)
```
Prefer same-origin (`http://localhost:3000`) so session cookies are sent reliably.

## Additional fix 2026-09-14 — Profile still showing "-"

**Root cause:** `js/core/i18n.js` MutationObserver captured initial placeholder text `-` as `data-i18n-original`. After the member API filled real values, the observer re-applied translations from the stored `-` and wiped the profile fields.

**Fix:**
1. `i18n.js` — if live text differs from original and its translation, adopt the new text as source (do not revert API data).
2. `member-profile.js` — set `data-i18n-original` + `data-i18n-skip=1` when filling fields; better error handling.
3. `member-profile.html` — use `ensureAuthenticated()` before load.

**Verify:** Hard refresh profile page (Ctrl+F5). Network tab should show `GET /api/members/:id` → 200 with member payload; UI should show name/code/status.
