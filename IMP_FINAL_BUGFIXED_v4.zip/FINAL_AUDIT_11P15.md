# IMP Production Final Audit — 11.P.15 Dashboard / Capital / Settings

Date: 2026-09-12

## Result

- Automated repository test suite: **165 passed / 0 failed**.
- JavaScript syntax audit: **0 syntax errors** across all JS files.
- HTML local-reference audit: **0 missing relative references**.
- PostgreSQL live validation: **NOT EXECUTED in this build environment** because no configured DATABASE_URL / PostgreSQL staging connection was available. The project retains `npm run db:validate` as a hard production gate.

## Repairs applied

1. Updated stale dashboard tests to the current `/api/dashboard/summary` architecture.
2. Updated migration-chain tests to include migrations 011 and 012.
3. Added canonical, unit-testable financial KPI formulas in `server/utils/dashboardKpis.js`.
4. Implemented the required seven dashboard formulas:
   - Current Balance = installment + savings + insurance + admission fee - loan - savings withdrawal - conditional insurance payout.
   - Loan = loan + re-loan + interest - collection - savings-funded installment payment.
   - Daily Collection = installment + savings + admission fee - daily expense.
   - Total Savings = savings + daily savings - savings withdrawal - savings-funded installment payment.
   - Total Insurance = insurance + new insurance - conditional insurance payout.
   - Total Admission Fee = admission fee + new admission fee.
   - Total Expense = office + travel + equipment.
5. Dashboard default cards now put the seven required financial cards first and visible by default; other operational KPI cards remain available for customization.
6. Dashboard daily calculations use Bangladesh (`Asia/Dhaka`) date boundaries.
7. Savings balance-changing transactions lock the member row with `FOR UPDATE` to serialize concurrent balance mutations.
8. PostgreSQL production validator now checks the new capital, savings, expense tables and related permissions/constraints.
9. Added dedicated financial formula and 11.P.15 integration tests.

## Important deployment gate

Before production go-live, run from the project directory with a real PostgreSQL staging database:

```text
npm ci
npm run db:migrate
npm run db:validate
npm test
```

`db:validate` must pass against the actual staging PostgreSQL instance. This ZIP must not be treated as a substitute for that live database gate.
