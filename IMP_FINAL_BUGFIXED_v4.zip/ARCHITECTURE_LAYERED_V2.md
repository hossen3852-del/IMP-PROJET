# IMP — Layered Production Architecture V2

## Target

Browser → Express Route → Middleware → Controller → Service → Repository → PostgreSQL

## Implemented foundation

- `server/controllers/` — HTTP/controller boundary
- `server/services/` — domain/application service boundary
- `server/repositories/` — PostgreSQL persistence boundary
- `server/services/transactionService.js` — transaction boundary for financial operations

## Migration rule

Existing production routes are migrated incrementally. The public API contract and business behavior must remain unchanged. New business logic must not be added directly to route files.

## Financial rule

Payment, allocation, installment, loan-balance and receipt mutations remain PostgreSQL transactions. The repository layer is the intended persistence boundary for new/refactored code.

## Important

This package establishes the layered architecture without a big-bang rewrite. Existing legacy route handlers are intentionally preserved until each module passes its regression suite. Therefore this ZIP is a **layered-architecture migration build**, not a claim that every existing SQL statement has already been physically moved out of every legacy route file.
