# Commercial Production Runbook

## Database
1. Set `DATABASE_URL` to the production PostgreSQL instance.
2. Run `npm run db:migrate`.
3. Run `npm run db:validate`.
4. Confirm `schema_migrations` contains `021_commercial_expansion` and `022_financial_gl_integration`.

## Notification worker
Configure a real provider adapter, then run:

```bash
npm run notifications:process
```

Run it from a controlled worker/cron environment. Do not expose provider secrets to the browser.

## Backup

```bash
BACKUP_DIR=/secure/backups npm run db:backup
```

Backups must be encrypted, retained according to business requirements, and copied outside the application host.

## Restore drill
Use a clean PostgreSQL database and restore a recent custom-format dump with `pg_restore`. Run `npm run db:validate` and a smoke test after restore.

## Monitoring
Authenticated organization administrators can use `/api/expansion/ops/monitoring`. The existing `/api/health` endpoint remains the load-balancer health check.

## Field/offline safety
The field app stores only queued sync events in IndexedDB. A collection payment is posted through the canonical Payment API during synchronization and is protected by an idempotency key. If synchronization fails, the event remains locally queued.
