# IMP 11.P.14 — Production Deployment

## Gate status
Prepared deployment package. **NOT GO-LIVE PASS yet.** Real staging PostgreSQL E2E and production infrastructure checks remain required.

## Required production topology
Browser -> HTTPS reverse proxy -> Node/Express -> PostgreSQL

## Before deployment
1. Provision a dedicated production PostgreSQL database and least-privilege application user.
2. Configure `.env` from `.env.production.example`; never commit `.env`.
3. Use `DATABASE_SSL=require` (or a stronger certificate-verified configuration where the provider requires it).
4. Set `CORS_ORIGIN` to the exact HTTPS application origin; never `*`.
5. Keep `COOKIE_NAME=__Host-imp_session`, HTTPS, and `TRUST_PROXY=1` behind a trusted TLS reverse proxy.
6. Run `npm ci --omit=dev` on the deployment host after validating the lockfile.

## Staging gate
Run against a real staging PostgreSQL instance:
- `npm run db:migrate`
- `npm run db:validate`
- `npm test`
- Browser E2E: Register -> Login -> Organization -> Branch -> User/Role -> Member -> Loan -> Approve -> Disburse -> Installment -> Payment -> Allocation -> Receipt -> Payment History
- Financial tests: partial, advance, duplicate/idempotency, cancel, reverse, rollback, concurrent payment attempts, cross-tenant denial.

Do not promote if any gate fails.

## Production migration
Only after staging passes:
- Take/verify a production DB backup.
- Run `npm run db:migrate` once using the production connection.
- Verify `npm run db:validate`.
- Start the API under a process supervisor (systemd or equivalent).
- Put Nginx/Caddy/another trusted reverse proxy in front with HTTPS.
- Verify `GET /api/health` through the public HTTPS origin.

## Rollback
Application rollback must be paired with a database rollback strategy. Do not blindly reverse already-applied financial migrations in production. Restore from a verified backup or use a tested forward-fix migration according to the incident plan.
