# IMP — Pure Clean Architecture

## Final Frozen Build

This build is the **API-only / PostgreSQL-backed** application architecture. Browser storage is not an authoritative source for authentication, tenant data, members, loans, installments, payments, collections, settings, or RBAC.

### Architecture

```text
Browser UI
   ↓
API Client
   ↓
Express Routes
   ↓
Controllers
   ↓
Services
   ↓
Repositories / Query Registry
   ↓
PostgreSQL
```

### Security boundaries

- Authentication and sessions are server-authoritative.
- Session credentials use HttpOnly cookies.
- Organization/tenant scope is derived from authenticated server context.
- Branch access is enforced server-side.
- RBAC permissions are enforced server-side.
- Financial and business records are persisted in PostgreSQL.
- No legacy `js/core/storage.js` module remains.
- No runtime business module uses `localStorage` or the legacy `Storage` API.
- UI language preference is non-authoritative and uses a browser cookie only.

### Layer rules

- Routes: HTTP wiring only.
- Controllers: request/response adaptation only.
- Services: business rules; no raw SQL.
- Repositories/query registry: database access boundary.
- Frontend managers/services: API clients; no business-data persistence.

### Setup

Install dependencies:

```bash
npm install
```

Configure environment from `.env.example` / `.env.production.example`, then initialize/validate the database as appropriate for the deployment environment.

### Test

```bash
npm test
```

The production test suite validates architecture boundaries, API-only frontend cutover, tenant/branch isolation, RBAC, authentication/session behavior, SQL boundaries, and UI integration.

### Production validation

```bash
npm run db:validate
```

A real PostgreSQL environment is required for live end-to-end validation. Source-level tests do not replace deployment-specific database, environment, TLS, reverse-proxy, backup, monitoring, and dependency-security checks.

## Freeze status

**V6.0.7 Commercial Expansion — financial-integrity hardened build over the V5.2 pure layered architecture.**

Cleanup included:

1. README aligned with the API-only architecture.
2. Legacy browser `Storage` implementation removed.
3. Legacy storage regression test removed from the test command.
4. UI-only language persistence moved from `localStorage` to a cookie.
5. `authService.js` login schema cleaned so login validates only login fields.

## Commercial Expansion — Final Frozen

The frozen build now includes the Commercial Expansion Pack described in `COMMERCIAL_EXPANSION_FINAL.md`:
- mobile field officer + IndexedDB offline sync
- SMS/WhatsApp notification outbox/provider boundary
- digital member passbook
- advanced loan products and term calculator
- loan adjustment/audit layer for penalty, waiver, reschedule, write-off and partial-payment workflows
- MRA-oriented management reporting
- double-entry accounting/GL foundation with automatic payment and disbursement posting
- operational report engine
- production monitoring, backup and disaster-recovery runbook

The expansion is still API-first and PostgreSQL-backed. No business data is stored in browser LocalStorage.
