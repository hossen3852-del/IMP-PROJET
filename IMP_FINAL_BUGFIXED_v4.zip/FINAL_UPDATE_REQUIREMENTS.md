# IMP — Single Organization Production Update V1

## Business model
This build is configured for one pre-existing organization. Public organization registration is removed from the UI and `POST /api/auth/register` is no longer exposed by the Express router. Existing organization/user records remain the authoritative database records.

`organization_id` remains internally in the database/API as an integrity key; it is not a SaaS tenant registration/selection feature.

## Implemented requirements
1. Single organization mode — registration form/link removed.
2. Add Loan:
   - installment amount is manually entered;
   - daily savings amount is entered;
   - opening deposit/amanat amount is entered;
   - these values are stored with the loan.
3. Daily Collection:
   - current due installment remains read-only and comes from the active loan schedule;
   - default daily savings amount comes from the loan's saved savings amount;
   - Baki -> Save Member is a local preparation action;
   - final `জমা দিন` posts the daily sheet as one batch;
   - Paid and Baki states are retained in the batch flow;
   - savings-only rows are allowed when no installment is due;
   - zero-collection sheet submission is allowed when the member list exists.
4. Insurance:
   - fixed rule: `loan amount × 2%`;
   - manually entered insurance is no longer used;
   - opening deposit is posted once at disbursement;
   - installment schedule is generated automatically at disbursement.
5. Member/Loan Profile:
   - member photo at the top;
   - member name and phone immediately below;
   - live savings section:
     `balance = deposit + daily savings − withdrawal − savings-funded installment payment`.
6. Mobile focus:
   - existing responsive foundation retained;
   - loan/member savings/profile cards and loan member hero are mobile optimized.

## Database
Run the normal production migration command. New migration:
`028_single_org_manual_loan_savings.sql`

## Important
The existing organization and its initial administrator must already exist in PostgreSQL before deployment because public registration is intentionally disabled.
