# IMP V6.0.17 Final Hardening Patch

## Fixes
- Per-user UI visibility GET is now available to every authenticated tenant user, while non-admin users receive only their own visibility configuration.
- Organization users with `ui.visibility.manage` can still read the full organization visibility map for administration.
- UI visibility now uses stable module identifiers instead of permission-name/index pairs.
- Existing V6.0.17 legacy `permission#index` visibility values are normalized on read for backward compatibility.
- Dashboard sidebar links now carry stable `data-ui-module` identifiers.
- Fixed malformed script tag on the share profile page.
- Added regression coverage for the above fixes.

## Verification
- Production tests: 278 passed, 0 failed.
- JavaScript syntax checks: passed.
- No suspicious consecutive `<script>` tags found in HTML pages.

## Runtime note
A real PostgreSQL deployment should still run `npm ci`, `npm run db:migrate`, `npm run db:validate`, and end-to-end business-flow tests before production go-live.
