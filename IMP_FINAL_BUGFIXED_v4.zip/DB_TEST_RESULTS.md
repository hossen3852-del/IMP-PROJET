# Database Test Results — 2026-09-18

## Environment
- PostgreSQL 16.15
- Database: imp_db / User: imp
- All 18 migrations applied (001→018) — 24 tables

## Seed verified
- Org + Branch + 2 members (M001 রহিম, M002 করিম)
- 2 loans, 3 pending installments

## Route-sheet SQL (collections.js logic) — PASS
M001: due_today=1000 (overdue 500 + today 500)
M002: due_today=750 (today only)

## Baki exclusion unit test — PASS
status=baki → installment+savings+insurance all skipped from total

## Frontend fix already in package
recalcTotals + setBaki zero all money fields for baki rows
