# 11.P.15.3 — Member + Nominee Registration UI

Implemented from the requested IMP requirement.

- Desktop: Member panel on the left; Nominee panel on the right.
- Member photo at the top of the left panel; member registration form below.
- Nominee photo at the top of the right panel; nominee registration form below.
- Responsive/mobile layout stacks the two panels vertically.
- Settings customization controls photo visibility/required state, nominee section visibility/required state, and member/nominee field visibility.
- Member + nominee creation is sent through the authenticated API and persisted in one server-side database transaction.
- Member and nominee photos are validated as JPEG/PNG/WebP data URLs and stored as PostgreSQL BYTEA with MIME type.
- Browser storage is used only for UI customization and never as authority for authentication, tenant identity, member/nominee data, or financial data.

New migration: `013_member_nominee_registration.sql`.

Full project test suite after this update: **171/171 PASS**.

For an existing PostgreSQL staging database run:

```text
npm run db:migrate
npm run db:validate
npm test
npm start
```
