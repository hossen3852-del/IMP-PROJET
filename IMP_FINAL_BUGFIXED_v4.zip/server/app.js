const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const env = require('./config/env');
const health = require('./routes/health');
const auth = require('./routes/auth');
const organization = require('./routes/organization');
const branches = require('./routes/branches');
const rbac = require('./routes/rbac');
const members = require('./routes/members');
const loans = require('./routes/loans');
const installments = require('./routes/installments');
const payments = require('./routes/payments');
const dashboard = require('./routes/dashboard');
const capital = require('./routes/capital');
const savings = require('./routes/savings');
const insurance = require('./routes/insurance');
const collections = require('./routes/collections');
const expenses = require('./routes/expenses');
const settings = require('./routes/settings');
const users = require('./routes/users');
const commercialExpansion = require('./routes/commercialExpansion');
const { requireSameOrigin } = require('./middleware/origin');
const errorHandler = require('./middleware/errorHandler');
const requestId = require('./middleware/requestId');

const app = express();
if (env.trustProxy) app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(requestId);
app.use(helmet({ contentSecurityPolicy: env.isProduction ? undefined : false, crossOriginResourcePolicy: { policy: 'same-site' } }));
app.use(cors({ origin: env.corsOrigin, credentials: true }));
app.use(express.json({ limit: env.bodyLimit, strict: true }));
app.use(cookieParser());
app.use('/api', requireSameOrigin);
const writeLimit = rateLimit({ windowMs: 60 * 1000, max: 120, standardHeaders: true, legacyHeaders: false, skip: req => !['POST','PUT','PATCH','DELETE'].includes(req.method) });
const paymentWriteLimit = rateLimit({ windowMs: 60 * 1000, max: 30, standardHeaders: true, legacyHeaders: false, skip: req => !['POST','PUT','PATCH','DELETE'].includes(req.method) });
const authLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  // Session bootstrap (/api/auth/me) is a read-only request and must not
  // consume the login brute-force budget. Keep the limiter on auth writes.
  skip: req => req.method === 'GET'
});
app.use('/api/auth', authLimit, auth);
app.use('/api', writeLimit);
app.use('/api/payments', paymentWriteLimit);
app.use('/api/organization', organization);
app.use('/api/branches', branches);
app.use('/api/rbac', rbac);
app.use('/api/members', members);
app.use('/api/loans', loans);
app.use('/api/installments', installments);
app.use('/api/payments', payments);
app.use('/api/dashboard', dashboard);
app.use('/api/capital', capital);
app.use('/api/savings', savings);
app.use('/api/insurance', insurance);
app.use('/api/collections', collections);
app.use('/api/expenses', expenses);
app.use('/api/settings', settings);
app.use('/api/users', users);
app.use('/api/expansion', commercialExpansion);
app.use('/api/health', health);
const path = require('path');
const publicRoot = path.join(__dirname, '..');

// Never expose the project root.  The server source, database migrations,
// scripts, package files and environment examples are not public assets.
// Only explicitly approved frontend directories are static.
app.get('/', (req, res) => res.sendFile(path.join(publicRoot, 'index.html')));
app.use('/pages', express.static(path.join(publicRoot, 'pages'), { dotfiles: 'deny', redirect: false }));
app.use('/js', express.static(path.join(publicRoot, 'js'), { dotfiles: 'deny', redirect: false }));
app.use('/css', express.static(path.join(publicRoot, 'css'), { dotfiles: 'deny', redirect: false }));
app.use('/assets', express.static(path.join(publicRoot, 'assets'), { dotfiles: 'deny', redirect: false }));
app.get('/favicon.svg', (req, res) => res.sendFile(path.join(publicRoot, 'favicon.svg')));
app.use((req, res, next) => {
  if (req.path === '/uploads' || req.path.startsWith('/uploads/')) return res.status(404).end();
  next();
});
app.use(errorHandler);
module.exports = app;
