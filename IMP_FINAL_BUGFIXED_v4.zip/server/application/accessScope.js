'use strict';

const ORG_WIDE_ROLES = new Set(['organization_admin', 'super_admin']);

function isOrganizationWide(auth) {
  return !!auth && ORG_WIDE_ROLES.has(auth.role_code || auth.role);
}

function scopedBranchId(auth) {
  return isOrganizationWide(auth) ? null : (auth?.branch_id || null);
}

function assertBranchAccess(auth, branchId) {
  if (isOrganizationWide(auth)) return;
  if (!auth?.branch_id || String(auth.branch_id) !== String(branchId)) {
    const error = new Error('Branch access denied');
    error.status = 403;
    throw error;
  }
}

function enforceRequestedBranch(auth, requestedBranchId) {
  if (isOrganizationWide(auth)) return requestedBranchId || null;
  assertBranchAccess(auth, requestedBranchId);
  return auth.branch_id;
}

module.exports = { ORG_WIDE_ROLES, isOrganizationWide, scopedBranchId, assertBranchAccess, enforceRequestedBranch };
