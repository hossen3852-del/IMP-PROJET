'use strict';

const router = require('express').Router();
const controller = require('../controllers/savings');
const { requireAuth, requirePermission, requireAnyPermission } = require('../middleware/auth');
const { requireTenant } = require('../middleware/tenant');

router.get('/summary', requireAuth, requireTenant, requirePermission('savings.view'), controller.get_summary_1);
router.get('/transactions', requireAuth, requireTenant, requirePermission('savings.view'), controller.get_transactions_2);
router.post('/transactions', requireAuth, requireTenant, requirePermission('savings.manage'), controller.post_transactions_3);
router.delete('/transactions/:id', requireAuth, requireTenant, requirePermission('savings.manage'), controller.delete_transactions_id_4);

module.exports = router;
