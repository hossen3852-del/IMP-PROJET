'use strict';

const router = require('express').Router();
const controller = require('../controllers/branches');
const { requireAuth, requirePermission, requireAnyPermission } = require('../middleware/auth');
const { requireTenant } = require('../middleware/tenant');

router.get('/', requireAuth, requirePermission('branch.view'), controller.get_root_1);
router.get('/:id', requireAuth, requirePermission('branch.view'), controller.get_id_2);
router.post('/', requireAuth, requirePermission('branch.create'), controller.post_root_3);
router.patch('/:id', requireAuth, requirePermission('branch.update'), controller.patch_id_4);
router.post('/:id/deactivate', requireAuth, requirePermission('branch.update'), controller.post_id_deactivate_5);

module.exports = router;
