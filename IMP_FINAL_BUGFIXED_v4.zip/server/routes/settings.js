'use strict';

const router = require('express').Router();
const controller = require('../controllers/settings');
const { requireAuth, requirePermission, requireAnyPermission } = require('../middleware/auth');
const { requireTenant } = require('../middleware/tenant');

router.get('/user-ui-visibility', requireAuth, requireTenant, controller.get_user_ui_visibility_4);
router.put('/user-ui-visibility', requireAuth, requireTenant, requirePermission('ui.visibility.manage'), controller.put_user_ui_visibility_5);
router.get('/', requireAuth, requireTenant, requirePermission('settings.view'), controller.get_root_1);
router.get('/:key', requireAuth, requireTenant, requirePermission('settings.view'), controller.get_key_2);
router.put('/:key', requireAuth, requireTenant, controller.canUpdateSettings, controller.put_key_3);

module.exports = router;
