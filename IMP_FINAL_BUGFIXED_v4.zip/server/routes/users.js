'use strict';

const router = require('express').Router();
const controller = require('../controllers/users');
const { requireAuth, requirePermission, requireAnyPermission } = require('../middleware/auth');
const { requireTenant } = require('../middleware/tenant');

router.get('/', requireAuth, requireTenant, requirePermission('user.view'), controller.get_root_1);
router.post('/', requireAuth, requireTenant, requirePermission('user.create'), controller.post_root_2);
router.patch('/:id', requireAuth, requireTenant, requirePermission('user.update'), controller.patch_id_3);
router.delete('/:id', requireAuth, requireTenant, requirePermission('user.delete'), controller.delete_id_4);

module.exports = router;
