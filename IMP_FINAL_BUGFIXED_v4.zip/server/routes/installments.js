'use strict';

const router = require('express').Router();
const controller = require('../controllers/installments');
const { requireAuth, requirePermission, requireAnyPermission } = require('../middleware/auth');
const { requireTenant } = require('../middleware/tenant');

router.get('/', requireAuth, requireTenant, requirePermission('loan.view'), controller.get_root_1);
router.get('/:id', requireAuth, requireTenant, requirePermission('loan.view'), controller.get_id_2);
router.post('/generate', requireAuth, requireTenant, requirePermission('loan.schedule.update'), controller.post_generate_3);
router.patch('/:id/status', requireAuth, requireTenant, requirePermission('loan.schedule.update'), controller.patch_id_status_4);

module.exports = router;
