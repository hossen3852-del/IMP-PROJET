'use strict';

const router = require('express').Router();
const controller = require('../controllers/capital');
const { requireAuth, requirePermission, requireAnyPermission } = require('../middleware/auth');
const { requireTenant } = require('../middleware/tenant');

router.get('/shares/summary', requireAuth, requireTenant, requirePermission('capital.share.view'), controller.get_shares_summary_5);
router.get('/shares', requireAuth, requireTenant, requirePermission('capital.share.view'), controller.get_shares_6);
router.get('/shares/:id', requireAuth, requireTenant, requirePermission('capital.share.view'), controller.get_share_id_7);
router.post('/shares', requireAuth, requireTenant, requirePermission('capital.share.manage'), controller.post_shares_8);
router.put('/shares/market-value', requireAuth, requireTenant, requirePermission('capital.share.manage'), controller.put_share_market_value_11);
router.put('/shares/:id', requireAuth, requireTenant, requirePermission('capital.share.manage'), controller.put_share_id_9);
router.patch('/shares/:id', requireAuth, requireTenant, requirePermission('capital.share.manage'), controller.put_share_id_9);
router.delete('/shares/:id', requireAuth, requireTenant, requirePermission('capital.share.manage'), controller.delete_share_id_10);
router.get('/summary', requireAuth, requireTenant, requirePermission('capital.view'), controller.get_summary_1);
router.get('/entries', requireAuth, requireTenant, requirePermission('capital.view'), controller.get_entries_2);
router.post('/entries', requireAuth, requireTenant, requirePermission('capital.manage'), controller.post_entries_3);
router.delete('/entries/:id', requireAuth, requireTenant, requirePermission('capital.manage'), controller.delete_entries_id_4);

module.exports = router;
