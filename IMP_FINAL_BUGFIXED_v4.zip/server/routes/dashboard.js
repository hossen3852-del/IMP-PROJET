'use strict';

const router = require('express').Router();
const controller = require('../controllers/dashboard');
const { requireAuth, requirePermission, requireAnyPermission } = require('../middleware/auth');
const { requireTenant } = require('../middleware/tenant');

router.get('/summary', requireAuth, requireTenant, requirePermission('dashboard.view'), controller.get_summary_1);
router.get('/config', requireAuth, requireTenant, requirePermission('dashboard.view'), controller.get_config_2);
router.put('/config', requireAuth, requireTenant, requirePermission('dashboard.customize'), controller.put_config_3);

module.exports = router;
