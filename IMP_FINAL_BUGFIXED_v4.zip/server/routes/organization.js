'use strict';

const router = require('express').Router();
const controller = require('../controllers/organization');
const { requireAuth, requirePermission, requireAnyPermission } = require('../middleware/auth');
const { requireTenant } = require('../middleware/tenant');

router.get('/', requireAuth, requirePermission('organization.view'), controller.get_root_1);
router.get('/dashboard-summary', requireAuth, requirePermission('dashboard.view'), controller.get_dashboard_summary_2);
router.patch('/', requireAuth, requirePermission('organization.update'), controller.patch_root_3);

module.exports = router;
