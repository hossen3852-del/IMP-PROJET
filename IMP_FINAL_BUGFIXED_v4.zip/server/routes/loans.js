'use strict';

const router = require('express').Router();
const controller = require('../controllers/loans');
const { requireAuth, requirePermission, requireAnyPermission } = require('../middleware/auth');
const { requireTenant } = require('../middleware/tenant');

router.post("/legacy-import", requireAuth, requireTenant, requirePermission("loan.create"), controller.post_legacy_import_9);
router.get("/", requireAuth, requireTenant, requirePermission("loan.view"), controller.guard_loans, controller.get_root_1);
router.post("/", requireAuth, requireTenant, requirePermission("loan.create"), controller.guard_loans, controller.post_root_2);
router.get("/:id", requireAuth, requireTenant, requirePermission("loan.view"), controller.guard_loans, controller.get_id_3);
router.patch("/:id", requireAuth, requireTenant, requirePermission("loan.update"), controller.guard_loans, controller.patch_id_4);
router.post("/:id/approve", requireAuth, requireTenant, requirePermission("loan.approve"), controller.guard_loans, controller.post_id_approve_5);
router.post("/:id/disburse", requireAuth, requireTenant, requirePermission("loan.status.update"), controller.guard_loans, controller.post_id_disburse_6);
router.post("/:id/status", requireAuth, requireTenant, requirePermission("loan.status.update"), controller.guard_loans, controller.post_id_status_7);
router.delete("/:id", requireAuth, requireTenant, requirePermission("loan.delete"), controller.guard_loans, controller.delete_id_8);

module.exports = router;
