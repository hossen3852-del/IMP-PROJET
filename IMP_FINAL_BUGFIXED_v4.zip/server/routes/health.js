'use strict';

const router = require('express').Router();
const controller = require('../controllers/health');

router.get('/', controller.health);

module.exports = router;
