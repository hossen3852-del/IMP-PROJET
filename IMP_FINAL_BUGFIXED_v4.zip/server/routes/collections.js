'use strict';

const router = require('express').Router();
const controller = require('../controllers/collections');
const { requireAuth, requirePermission, requireAnyPermission } = require('../middleware/auth');
const { requireTenant } = require('../middleware/tenant');

router.get('/config', requireAuth, requireTenant, requirePermission('settings.view'), controller.get_config_1);
router.put('/config', requireAuth, requireTenant, requirePermission('settings.update'), controller.put_config_2);
router.get('/route-sheet', requireAuth, requireTenant, requirePermission('collection.create'), controller.get_route_sheet_3);
router.post('/daily', requireAuth, requireTenant, requirePermission('collection.create'), controller.post_daily_4);

module.exports = router;
