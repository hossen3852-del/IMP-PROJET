'use strict';

const router = require('express').Router();
const controller = require('../controllers/expenses');
const { requireAuth, requirePermission, requireAnyPermission } = require('../middleware/auth');
const { requireTenant } = require('../middleware/tenant');

router.get('/summary', requireAuth, requireTenant, requirePermission('expense.view'), controller.get_summary_1);
router.get('/entries', requireAuth, requireTenant, requirePermission('expense.view'), controller.get_entries_2);
router.post('/entries', requireAuth, requireTenant, requirePermission('expense.manage'), controller.post_entries_3);
router.delete('/entries/:id', requireAuth, requireTenant, requirePermission('expense.manage'), controller.delete_entries_id_4);

module.exports = router;
