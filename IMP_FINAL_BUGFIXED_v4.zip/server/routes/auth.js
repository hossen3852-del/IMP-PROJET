'use strict';

const router = require('express').Router();
const controller = require('../controllers/auth');
const { requireAuth, requirePermission, requireAnyPermission } = require('../middleware/auth');
const { requireTenant } = require('../middleware/tenant');

router.post('/login', controller.post_login_2);
router.get('/me', requireAuth, controller.get_me_3);
router.post('/logout', controller.post_logout_4);
router.post('/logout-all', requireAuth, controller.post_logout_all_5);
router.post('/password-reset/request', controller.post_password_reset_request_6);
router.post('/password-reset/confirm', controller.post_password_reset_confirm_7);
router.put('/admin-credentials', requireAuth, controller.put_admin_credentials_8);

module.exports = router;
