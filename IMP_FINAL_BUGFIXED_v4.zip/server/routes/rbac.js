'use strict';

const router = require('express').Router();
const controller = require('../controllers/rbac');
const { requireAuth, requirePermission, requireAnyPermission } = require('../middleware/auth');
const { requireTenant } = require('../middleware/tenant');

router.get('/permissions', requireAuth, requirePermission('permission.view'), controller.get_permissions_1);
router.get('/roles', requireAuth, requirePermission('role.view'), controller.get_roles_2);
router.post('/roles', requireAuth, requirePermission('role.create'), controller.post_roles_3);
router.get('/roles/:id', requireAuth, requirePermission('role.view'), controller.get_roles_id_4);
router.patch('/roles/:id', requireAuth, requirePermission('role.update'), controller.patch_roles_id_5);
router.delete('/roles/:id', requireAuth, requirePermission('role.delete'), controller.delete_roles_id_6);
router.get('/roles/:id/permissions', requireAuth, requirePermission('role.view'), controller.get_roles_id_permissions_7);
router.put('/roles/:id/permissions', requireAuth, requirePermission('role.manage'), controller.put_roles_id_permissions_8);

module.exports = router;
