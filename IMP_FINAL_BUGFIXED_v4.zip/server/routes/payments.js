'use strict';

const router = require('express').Router();
const controller = require('../controllers/payments');
const { requireAuth, requirePermission, requireAnyPermission } = require('../middleware/auth');
const { requireTenant } = require('../middleware/tenant');

router.get('/', requireAuth, requireTenant, requirePermission('payment.view'), controller.guard_payments, controller.get_root_1);
router.post('/', requireAuth, requireTenant, requirePermission('payment.create'), controller.guard_payments, controller.post_root_2);
router.get('/collection-report', requireAuth, requireTenant, requirePermission('payment.view'), controller.guard_payments, controller.get_collection_report_3);
router.get('/reconciliation', requireAuth, requireTenant, requirePermission('payment.view'), controller.guard_payments, controller.get_reconciliation_4);
router.get('/:id', requireAuth, requireTenant, requirePermission('payment.view'), controller.guard_payments, controller.get_id_5);
router.get('/:id/allocations', requireAuth, requireTenant, requirePermission('payment.view'), controller.guard_payments, controller.get_id_allocations_6);
router.get('/:id/audit', requireAuth, requireTenant, requirePermission('payment.view'), controller.guard_payments, controller.get_id_audit_7);
router.post('/:id/cancel', requireAuth, requireTenant, requirePermission('payment.cancel'), controller.guard_payments, controller.post_id_cancel_8);
router.post('/:id/reverse', requireAuth, requireTenant, requirePermission('payment.reverse'), controller.guard_payments, controller.post_id_reverse_9);
router.get('/:id/receipt', requireAuth, requireTenant, requirePermission('payment.view'), controller.guard_payments, controller.get_id_receipt_10);

module.exports = router;
