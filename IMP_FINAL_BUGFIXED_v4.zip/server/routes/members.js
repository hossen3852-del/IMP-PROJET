'use strict';

const router = require('express').Router();
const controller = require('../controllers/members');
const { requireAuth, requirePermission, requireAnyPermission } = require('../middleware/auth');
const { requireTenant } = require('../middleware/tenant');

router.get('/', requireAuth, requireTenant, requirePermission('member.view'), controller.guard_members, controller.get_root_1);
router.post('/', requireAuth, requireTenant, requirePermission('member.create'), controller.guard_members, controller.post_root_2);
router.get('/legacy-borrowers', requireAuth, requireTenant, requirePermission('member.view'), controller.guard_members, controller.get_legacy_borrowers_19);
router.get('/:id/photo', requireAuth, requireTenant, requirePermission('member.view'), controller.guard_members, controller.get_id_photo_3);
router.get('/:id/nominee/photo', requireAuth, requireTenant, requirePermission('member.view'), controller.guard_members, controller.get_id_nominee_photo_4);
router.get('/:id', requireAuth, requireTenant, requirePermission('member.view'), controller.guard_members, controller.get_id_5);
router.patch('/:id', requireAuth, requireTenant, requirePermission('member.update'), controller.guard_members, controller.patch_id_6);
router.delete('/:id', requireAuth, requireTenant, requirePermission('member.delete'), controller.guard_members, controller.delete_id_7);
router.get('/:id/nominee', requireAuth, requireTenant, requirePermission('member.view'), controller.guard_members, controller.get_id_nominee_8);
router.put('/:id/nominee', requireAuth, requireTenant, requirePermission('member.update'), controller.guard_members, controller.put_id_nominee_9);
router.get('/:id/documents', requireAuth, requireTenant, requirePermission('member.view'), controller.guard_members, controller.get_id_documents_10);
router.post('/:id/documents', requireAuth, requireTenant, requirePermission('member.document.upload'), controller.guard_members, controller.post_id_documents_11);
router.delete('/:id/documents/:documentId', requireAuth, requireTenant, requirePermission('member.document.delete'), controller.guard_members, controller.delete_id_documents_documentId_12);
router.get('/:id/activities', requireAuth, requireTenant, requirePermission('member.view'), controller.guard_members, controller.get_id_activities_13);
router.post('/:id/activities', requireAuth, requireTenant, requirePermission('member.update'), controller.guard_members, controller.post_id_activities_14);
router.get('/:id/family', requireAuth, requireTenant, requirePermission('member.view'), controller.guard_members, controller.get_id_family_15);
router.put('/:id/family', requireAuth, requireTenant, requirePermission('member.update'), controller.guard_members, controller.put_id_family_16);
router.get('/:id/financial', requireAuth, requireTenant, requirePermission('member.view'), controller.guard_members, controller.get_id_financial_17);
router.patch('/:id/financial', requireAuth, requireTenant, requirePermission('member.financial.update'), controller.guard_members, controller.patch_id_financial_18);

module.exports = router;
