'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const UPLOAD_ROOT = path.join(__dirname, '..', '..', 'uploads');
const MAX_BYTES = 2.5 * 1024 * 1024; // ~2.5MB decoded
const ALLOWED = new Set(['image/jpeg', 'image/png', 'image/webp']);

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

/**
 * Verify the decoded bytes actually start with the magic number for the
 * claimed MIME type. A client can label arbitrary bytes (e.g. HTML/SVG/JS)
 * with an `image/png` prefix in the data-URL; without this check that
 * content would be written to disk and later served back with an image
 * content-type based purely on the untrusted claim.
 */
function matchesMagicBytes(mime, buffer) {
  if (mime === 'image/png') {
    const sig = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a];
    return sig.every((b, i) => buffer[i] === b);
  }
  if (mime === 'image/jpeg') {
    return buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
  }
  if (mime === 'image/webp') {
    return (
      buffer.length >= 12 &&
      buffer.toString('ascii', 0, 4) === 'RIFF' &&
      buffer.toString('ascii', 8, 12) === 'WEBP'
    );
  }
  return false;
}

/**
 * Decode a data-URL (data:image/jpeg;base64,...) into { mime, buffer }.
 * Returns null if invalid, oversized, or if the decoded bytes don't match
 * the claimed image type's file signature.
 */
function decodeDataUrl(value) {
  if (typeof value !== 'string' || !value.startsWith('data:')) return null;
  const m = value.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/);
  if (!m) return null;
  const mime = m[1];
  if (!ALLOWED.has(mime)) return null;
  let buffer;
  try {
    buffer = Buffer.from(m[2], 'base64');
  } catch {
    return null;
  }
  if (!buffer.length || buffer.length > MAX_BYTES) return null;
  if (!matchesMagicBytes(mime, buffer)) return null;
  return { mime, buffer };
}

function extForMime(mime) {
  if (mime === 'image/png') return 'png';
  if (mime === 'image/webp') return 'webp';
  return 'jpg';
}

/**
 * Save photo under uploads/{organizationId}/{kind}/{id}.{ext}
 * Returns public path starting with /uploads/...
 */
function savePhoto({ organizationId, kind, entityId, dataUrl }) {
  const decoded = decodeDataUrl(dataUrl);
  if (!decoded) return null;

  const org = String(organizationId).replace(/[^a-zA-Z0-9_-]/g, '');
  const safeKind = String(kind || 'misc').replace(/[^a-zA-Z0-9_-]/g, '');
  const idPart = String(entityId || crypto.randomUUID()).replace(/[^a-zA-Z0-9_-]/g, '');
  const dir = path.join(UPLOAD_ROOT, org, safeKind);
  ensureDir(dir);

  const filename = `${idPart}.${extForMime(decoded.mime)}`;
  const abs = path.join(dir, filename);
  fs.writeFileSync(abs, decoded.buffer);

  // Internal storage key. Files are served only through authenticated API routes.
  return `/uploads/${org}/${safeKind}/${filename}`;
}

/**
 * Prefer disk path; fall back to legacy BYTEA base64 data-URL.
 */
function resolvePhotoUrl(row, pathField = 'photo_path', dataField = 'photo_data', mimeField = 'photo_mime') {
  if (row && row[pathField]) return row[pathField];
  if (row && row[dataField] && row[mimeField]) {
    try {
      return `data:${row[mimeField]};base64,${Buffer.from(row[dataField]).toString('base64')}`;
    } catch {
      return null;
    }
  }
  return null;
}

module.exports = {
  UPLOAD_ROOT,
  decodeDataUrl,
  savePhoto,
  resolvePhotoUrl
};
