'use strict';

/**
 * Canonical IMP dashboard financial formulas.
 * All inputs are already server-computed ledger totals.
 */
function n(value) {
  const x = Number(value);
  return Number.isFinite(x) ? x : 0;
}

function calculateCurrentBalance({ previousCapital, newCapital, installmentCollection, savings, insurance, admissionFee, loanDisbursement, savingsWithdrawal, insuranceClaim }) {
  // Canonical IMP formula:
  // Previous Capital + New Capital + Installment + Savings + Insurance +
  // Admission Fee - Loan - Savings Withdrawal - Conditional Insurance Payout.
  return n(previousCapital) + n(newCapital) + n(installmentCollection) + n(savings)
    + n(insurance) + n(admissionFee) - n(loanDisbursement)
    - n(savingsWithdrawal) - n(insuranceClaim);
}

function calculateLoanBalance({ loanDisbursement, reloan, interest, collection, savingsInstallmentPayment }) {
  // Re-loans are represented by additional disbursed loan rows; callers may
  // pass the explicit reloan component when the source ledger distinguishes it.
  return n(loanDisbursement) + n(reloan) + n(interest)
    - n(collection) - n(savingsInstallmentPayment);
}

function calculateDailyCollection({ installmentCollection, savings, dailyExpense }) {
  // Daily Collection is only installment + savings minus daily expense.
  // Admission Fee is owned by Member Add and Insurance Premium by Loan Disbursement.
  return n(installmentCollection) + n(savings) - n(dailyExpense);
}

function calculateTotalSavings({ savings, dailySavings, withdrawal, savingsInstallmentPayment }) {
  return n(savings) + n(dailySavings) - n(withdrawal) - n(savingsInstallmentPayment);
}

function calculateTotalInsurance({ insurance, newInsurance, conditionalPayout }) {
  return n(insurance) + n(newInsurance) - n(conditionalPayout);
}

function calculateTotalAdmissionFee({ admissionFee, newAdmissionFee }) {
  return n(admissionFee) + n(newAdmissionFee);
}

function calculateTotalExpense({ officeExpense, travelExpense, equipmentExpense, otherExpense }) {
  // মোট খরচ = office + travel + equipment + other (daily collection field expense)
  return n(officeExpense) + n(travelExpense) + n(equipmentExpense) + n(otherExpense);
}

module.exports = {
  calculateCurrentBalance,
  calculateLoanBalance,
  calculateDailyCollection,
  calculateTotalSavings,
  calculateTotalInsurance,
  calculateTotalAdmissionFee,
  calculateTotalExpense
};
