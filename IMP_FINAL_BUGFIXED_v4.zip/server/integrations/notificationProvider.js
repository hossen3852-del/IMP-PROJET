'use strict';
/** Provider abstraction. Configure SMS/WhatsApp adapters without coupling domain services to vendors. */
async function send({ channel, recipient, templateCode, payload }) {
  const provider = process.env[`${channel.toUpperCase()}_PROVIDER`] || 'outbox';
  if (provider === 'outbox') return { accepted: true, provider: 'outbox', channel, recipient, templateCode, providerMessageId: null };
  // Vendor adapters are intentionally isolated here. Add credentials and HTTP SDK in deployment.
  return { accepted: false, provider, reason: 'Provider adapter is not configured in this build' };
}
module.exports = { send };
