'use strict';

const repository = require('../repositories');

async function executeFinancialTransaction(work) {
  return repository.withTransaction(work);
}

module.exports = { executeFinancialTransaction };
