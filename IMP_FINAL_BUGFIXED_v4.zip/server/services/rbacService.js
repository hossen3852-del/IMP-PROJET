'use strict';

const { serviceResponse, serviceJson } = require('./serviceResult');


const { z } = require('zod');
const repository = require('../repositories');

const roleCreateSchema = z.object({
  code: z.string().trim().regex(/^[a-z][a-z0-9_]{1,79}$/),
  name: z.string().trim().min(2).max(120),
  description: z.string().trim().max(500).nullable().optional()
}).strict();

const roleUpdateSchema = z.object({
  name: z.string().trim().min(2).max(120).optional(),
  description: z.string().trim().max(500).nullable().optional()
}).strict();

const permissionListSchema = z.array(z.string().trim().min(1).max(120)).max(200).refine(
  list => new Set(list).size === list.length,
  { message: 'Duplicate permissions are not allowed' }
);


function isGlobalSystemRole(role) {
  return role.is_system === true && role.organization_id == null;
}

async function getRole(tx, id) {
  const { rows } = await tx.queryNamed("rbacService.js:30:223", [id], {});
  return rows[0] || null;
}

function roleVisibleToAuth(role, auth) {
  if (!role) return false;
  if (isGlobalSystemRole(role)) return auth.role_is_system === true;
  return String(role.organization_id) === String(auth.organization_id);
}

async function writeAudit(tx, auth, action, resourceId, metadata = {}) {
  await tx.queryNamed("rbacService.js:44:224", [auth.organization_id, auth.user_id, action, resourceId, JSON.stringify(metadata)], {  });
}

;

;

;

;

;

;

;

;


async function get_permissions_1(context) {
  context.cookies ||= [];

  try {
    const { rows } = await repository.queryNamed("rbacService.js:3:211", [], {  });
    return serviceJson(context, { permissions: rows });
  } catch (error) { throw error; }

}

async function get_roles_2(context) {
  context.cookies ||= [];

  try {
    const { rows } = await repository.queryNamed("rbacService.js:3:212", [context.auth.organization_id, context.auth.role_is_system === true], {});
    return serviceJson(context, { roles: rows });
  } catch (error) { throw error; }

}

async function post_roles_3(context) {
  context.cookies ||= [];

  try {
    const parsed = roleCreateSchema.safeParse(context.body);
    if (!parsed.success) return serviceResponse(400, { error: 'Invalid role data' }, context);
    const data = parsed.data;
    const tx = await repository.begin();
    try {
      await tx.begin();
      const duplicate = await tx.queryNamed("rbacService.js:9:213", [context.auth.organization_id, data.code], {  });
      if (duplicate.rows[0]) {
        await tx.rollback();
        return serviceResponse(409, { error: 'Role code already exists in this organization' }, context);
      }
      const { rows } = await tx.queryNamed("rbacService.js:17:214", [context.auth.organization_id, data.code, data.name, data.description ?? null, context.auth.user_id], {});
      await writeAudit(tx, context.auth, 'ROLE_CREATED', rows[0].id, { code: data.code, name: data.name });
      await tx.commit();
      return serviceResponse(201, { role: rows[0] }, context);
    } catch (error) { await tx.rollback(); throw error; }
    finally { tx.release(); }
  } catch (error) { throw error; }

}

async function get_roles_id_4(context) {
  context.cookies ||= [];

  try {
    const tx = await repository.begin();
    try {
      const role = await getRole(tx, context.params.id);
      if (!role || !roleVisibleToAuth(role, context.auth)) return serviceResponse(404, { error: 'Role not found' }, context);
      const { rows: permissions } = await tx.queryNamed("rbacService.js:7:215", [role.id], {  });
      return serviceJson(context, { role, permissions });
    } finally { tx.release(); }
  } catch (error) { throw error; }

}

async function patch_roles_id_5(context) {
  context.cookies ||= [];

  try {
    const parsed = roleUpdateSchema.safeParse(context.body);
    if (!parsed.success) return serviceResponse(400, { error: 'Invalid role data' }, context);
    const tx = await repository.begin();
    try {
      await tx.begin();
      const role = await getRole(tx, context.params.id);
      if (!role || !roleVisibleToAuth(role, context.auth)) {
        await tx.rollback(); return serviceResponse(404, { error: 'Role not found' }, context);
      }
      if (role.is_system || role.is_protected) {
        await tx.rollback(); return serviceResponse(403, { error: 'Protected system role cannot be modified' }, context);
      }
      const data = parsed.data;
      const nextName = data.name !== undefined ? data.name : role.name;
      const nextDescription = data.description !== undefined ? data.description : role.description;
      const { rows } = await tx.queryNamed("rbacService.js:18:216", [nextName, nextDescription, role.id], {});
      await writeAudit(tx, context.auth, 'ROLE_UPDATED', role.id, { fields: Object.keys(data) });
      await tx.commit();
      return serviceJson(context, { role: rows[0] });
    } catch (error) { await tx.rollback(); throw error; }
    finally { tx.release(); }
  } catch (error) { throw error; }

}

async function delete_roles_id_6(context) {
  context.cookies ||= [];

  try {
    const tx = await repository.begin();
    try {
      await tx.begin();
      const role = await getRole(tx, context.params.id);
      if (!role || !roleVisibleToAuth(role, context.auth)) {
        await tx.rollback(); return serviceResponse(404, { error: 'Role not found' }, context);
      }
      if (role.is_system || role.is_protected) {
        await tx.rollback(); return serviceResponse(403, { error: 'Protected role cannot be deleted' }, context);
      }
      const users = await tx.queryNamed("rbacService.js:13:217", [role.id], {  });
      if (users.rows[0].count > 0) {
        await tx.rollback(); return serviceResponse(409, { error: 'Role is assigned to active users' }, context);
      }
      await tx.queryNamed("rbacService.js:20:218", [role.id], {  });
      await writeAudit(tx, context.auth, 'ROLE_DELETED', role.id, { code: role.code });
      await tx.commit();
      return serviceResponse(204, null, context);
    } catch (error) { await tx.rollback(); throw error; }
    finally { tx.release(); }
  } catch (error) { throw error; }

}

async function get_roles_id_permissions_7(context) {
  context.cookies ||= [];

  try {
    const tx = await repository.begin();
    try {
      const role = await getRole(tx, context.params.id);
      if (!role || !roleVisibleToAuth(role, context.auth)) return serviceResponse(404, { error: 'Role not found' }, context);
      const { rows } = await tx.queryNamed("rbacService.js:7:219", [role.id], {  });
      return serviceJson(context, { roleId: role.id, permissions: rows });
    } finally { tx.release(); }
  } catch (error) { throw error; }

}

async function put_roles_id_permissions_8(context) {
  context.cookies ||= [];

  try {
    const parsed = permissionListSchema.safeParse(context.body?.permissions);
    if (!parsed.success) return serviceResponse(400, { error: 'Invalid permissions data' }, context);

    const tx = await repository.begin();
    try {
      await tx.begin();
      const role = await getRole(tx, context.params.id);
      if (!role || !roleVisibleToAuth(role, context.auth)) {
        await tx.rollback(); return serviceResponse(404, { error: 'Role not found' }, context);
      }
      if (role.is_system || role.is_protected) {
        await tx.rollback(); return serviceResponse(403, { error: 'Protected role permissions cannot be modified' }, context);
      }

      const permissionRows = await tx.queryNamed("rbacService.js:17:220", [parsed.data], {  });
      if (permissionRows.rows.length !== parsed.data.length) {
        await tx.rollback(); return serviceResponse(400, { error: 'One or more permissions do not exist' }, context);
      }

      await tx.queryNamed("rbacService.js:25:221", [role.id], {  });
      for (const permission of permissionRows.rows) {
        await tx.queryNamed("rbacService.js:27:222", [role.code, permission.id, role.id], {  });
      }
      await writeAudit(tx, context.auth, 'ROLE_PERMISSIONS_UPDATED', role.id, {
        permissionCodes: parsed.data
      });
      await tx.commit();
      return serviceJson(context, { roleId: role.id, permissions: permissionRows.rows.sort((a,b) => a.code.localeCompare(b.code)) });
    } catch (error) { await tx.rollback(); throw error; }
    finally { tx.release(); }
  } catch (error) { throw error; }

}

module.exports = { get_permissions_1, get_roles_2, post_roles_3, get_roles_id_4, patch_roles_id_5, delete_roles_id_6, get_roles_id_permissions_7, put_roles_id_permissions_8 };
