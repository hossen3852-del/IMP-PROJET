'use strict';

const { serviceResponse, serviceJson } = require('./serviceResult');


/**
 * 11.P.15.1/15.5 — Dashboard API / Financial KPI Contract + Dashboard
 * Customization API.
 *
 * All KPI numbers are computed live from PostgreSQL on every request.
 * Nothing here is cached in or trusted from localStorage. The dashboard
 * customization config (which cards are shown, in what order, which
 * sections are enabled) is stored per-organization in the existing
 * organization_settings table under setting_key='dashboard_config' — it
 * only controls presentation, never the underlying numbers.
 */

const { z } = require('zod');
const repository = require('../repositories');

const { isOrganizationWide, assertBranchAccess, enforceRequestedBranch } = require('../application/accessScope');
const { computeCapitalSummary } = require('./capitalService');
const { computeSavingsSummary } = require('./savingsService');
const { computeExpenseSummary } = require('./expensesService');
const {
  calculateCurrentBalance, calculateLoanBalance, calculateDailyCollection,
  calculateTotalSavings, calculateTotalInsurance, calculateTotalAdmissionFee, calculateTotalExpense
} = require('../utils/dashboardKpis');

const SETTING_KEY = 'dashboard_config';

const KPI_CARD_KEYS = [
  'totalMembers', 'totalLoans', 'totalCollection', 'totalDue', 'currentCapital', 'loanBalance',
  'admissionFee', 'insurance', 'todayCollection', 'todayLoan', 'overdue',
  'totalSavings', 'totalExpense', 'closedLoans', 'cancelledLoans'
];

const SECTION_KEYS = [
  'collectionSummary', 'loanSummary', 'dueOverdueSummary', 'recentPayments',
  'recentLoans', 'recentMembers', 'collectionChart', 'loanChart',
  'recoveryPerformance', 'branchWiseSummary', 'centerGroupWiseSummary'
];

const DEFAULT_CONFIG = {
  kpiCards: [
    { key: 'currentCapital', visible: true },
    { key: 'loanBalance', visible: true },
    { key: 'todayCollection', visible: true },
    { key: 'totalSavings', visible: true },
    { key: 'insurance', visible: true },
    { key: 'admissionFee', visible: true },
    { key: 'totalExpense', visible: true },
    { key: 'totalMembers', visible: false },
    { key: 'totalLoans', visible: false },
    { key: 'totalCollection', visible: false },
    { key: 'totalDue', visible: false },
    { key: 'todayLoan', visible: false },
    { key: 'overdue', visible: false },
    { key: 'closedLoans', visible: true },
    { key: 'cancelledLoans', visible: false }
  ],
  sections: SECTION_KEYS.reduce((acc, key) => {
    acc[key] = true;
    return acc;
  }, {})
};

const configSchema = z.object({
  kpiCards: z.array(z.object({
    key: z.enum(KPI_CARD_KEYS),
    visible: z.boolean(),
    title: z.string().trim().max(120).optional()
  })).max(KPI_CARD_KEYS.length),
  sections: z.record(z.enum(SECTION_KEYS), z.boolean())
}).strict();

function money(v) { return Number(v); }

/**
 * GET /api/dashboard/summary
 * Full KPI contract for the clickable dashboard cards.
 */
;

/**
 * GET /api/dashboard/config
 * Organization-scoped dashboard customization (KPI visibility/order,
 * section toggles). Falls back to DEFAULT_CONFIG if never saved.
 */
;

/**
 * PUT /api/dashboard/config
 * Requires dashboard.customize (organization_admin by default). This only
 * changes what is shown and in which order — never the KPI values
 * themselves, which are always recomputed live in /summary.
 */
;


async function get_summary_1(context) {
  context.cookies ||= [];

  try {
    const org = context.auth.organization_id;
    const branchId = isOrganizationWide(context.auth) ? null : context.auth.branch_id;
    if (!isOrganizationWide(context.auth) && !branchId) return serviceResponse(403, { error: 'Your account is not assigned to a branch' }, context);
    const values = branchId ? [org, branchId] : [org];
    const today = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Dhaka' }).format(new Date());

    const [orgRow, members, loans, interest, dueOverdue, todayCollection, todayLoan, capital, savings, expense, todaySavings] = await Promise.all([
      repository.queryNamed("dashboardService.js:11:76", branchId ? [org, branchId] : [org], { hasBranch: Boolean(branchId) }),
      repository.queryNamed("dashboardService.js:18:77", values, { hasBranch: Boolean(branchId) }),
      repository.queryNamed("dashboardService.js:22:78", values, { hasBranch: Boolean(branchId) }),
      repository.queryNamed("dashboardService.js:31:79", values, { hasBranch: Boolean(branchId) }),
      repository.queryNamed("dashboardService.js:36:80", values, { hasBranch: Boolean(branchId) }),
      repository.queryNamed("dashboardService.js:46:81", branchId ? [org, today, branchId] : [org, today], { hasBranch: Boolean(branchId) }),
      repository.queryNamed("dashboardService.js:51:82", branchId ? [org, today, branchId] : [org, today], { hasBranch: Boolean(branchId) }),
      computeCapitalSummary(org, repository, branchId),
      computeSavingsSummary(org, repository, null, branchId),
      computeExpenseSummary(org, repository, today, branchId),
      repository.queryNamed("dashboardService.js:59:83", branchId ? [org, today, branchId] : [org, today], { hasBranch: Boolean(branchId) }),
    ]);

    if (!orgRow.rows[0]) return serviceResponse(404, { error: 'Organization not found' }, context);

    const loanRow = loans.rows[0];
    const dueRow = dueOverdue.rows[0];
    const interestTotal = money(interest.rows[0].total);

    // "লোন" KPI — loan + re-loan + interest - collection - savings-funded installment:
    // loan disbursed (every disbursement, re-loan included) + interest
    // − collection (cash repayment) − installments paid via savings transfer.
    const loanOutstanding = calculateLoanBalance({
      loanDisbursement: capital.loanDisbursement,
      reloan: 0,
      interest: interestTotal,
      collection: capital.collection,
      savingsInstallmentPayment: savings.installmentPayments
    });

    const dailyCollection = calculateDailyCollection({
      installmentCollection: money(todayCollection.rows[0].total),
      savings: money(todaySavings.rows[0].total),
      dailyExpense: expense.totalOnDate
    });

    const currentBalance = calculateCurrentBalance({
      previousCapital: capital.capitalIn,
      newCapital: capital.capitalAdjustment,
      installmentCollection: capital.collection,
      savings: capital.savingsDeposits + capital.dailySavingsDeposits,
      insurance: capital.insuranceGross,
      admissionFee: capital.admissionFee,
      loanDisbursement: capital.loanDisbursement,
      savingsWithdrawal: capital.savingsWithdrawals,
      insuranceClaim: capital.insuranceClaim
    });

    const totalSavings = calculateTotalSavings({
      savings: savings.deposits,
      dailySavings: savings.dailyDeposits,
      withdrawal: savings.withdrawals,
      savingsInstallmentPayment: savings.installmentPayments
    });

    const totalInsurance = calculateTotalInsurance({
      insurance: capital.insuranceGross,
      newInsurance: 0,
      conditionalPayout: capital.insuranceClaim
    });

    // capital.admissionFee is the live SUM of capital_entries.entry_type='admission_fee'
    // (posted on member registration). There is no separate base/new split in the ledger.
    const totalAdmissionFee = calculateTotalAdmissionFee({
      admissionFee: capital.admissionFee,
      newAdmissionFee: 0
    });

    // মোট খরচ must include category 'other' — Daily Collection field expense
    // is stored as expense_entries.category='other'.
    const totalExpense = calculateTotalExpense({
      officeExpense: expense.office,
      travelExpense: expense.travel,
      equipmentExpense: expense.equipment,
      otherExpense: expense.other
    });

    return serviceJson(context, {
      summary: {
        organization: { id: orgRow.rows[0].id, name: orgRow.rows[0].name, status: orgRow.rows[0].status },
        branchCount: orgRow.rows[0].branch_count,
        userCount: orgRow.rows[0].user_count,

        totalMembers: members.rows[0].total,

        totalLoans: loanRow.active_count,
        totalLoanAmount: money(loanRow.active_amount),
        loanOutstanding,
        closedLoans: loanRow.closed_count,
        writtenOffLoans: loanRow.written_off_count,
        cancelledLoans: loanRow.cancelled_count,

        totalCollection: capital.collection,
        totalDue: money(dueRow.total_due),

        currentCapital: currentBalance,
        loanBalance: loanOutstanding,
        admissionFee: totalAdmissionFee,
        insurance: totalInsurance,
        loanDisbursement: capital.loanDisbursement,

        totalSavings,
        savingsDeposits: savings.deposits,
        dailySavings: savings.dailyDeposits,
        savingsWithdrawals: savings.withdrawals,
        savingsInstallmentPayments: savings.installmentPayments,
        totalExpense,

        todayCollection: dailyCollection,
        todayLoan: money(todayLoan.rows[0].total),

        overdue: dueRow.overdue_count,
        overdueAmount: money(dueRow.overdue_amount)
      }
    });
  } catch (e) { throw e; }

}

async function get_config_2(context) {
  context.cookies ||= [];

  try {
    const { rows } = await repository.queryNamed("dashboardService.js:3:84", [context.auth.organization_id, SETTING_KEY], {  });
    return serviceJson(context, { config: rows[0] ? rows[0].setting_value : DEFAULT_CONFIG });
  } catch (e) { throw e; }

}

async function put_config_3(context) {
  context.cookies ||= [];

  const parsed = configSchema.safeParse(context.body);
  if (!parsed.success) return serviceResponse(400, { error: 'Invalid dashboard config', details: parsed.error.issues }, context);

  const org = context.auth.organization_id;
  const tx = await repository.begin();
  try {
    await tx.begin();
    const { rows } = await tx.queryNamed("dashboardService.js:9:85", [org, SETTING_KEY, JSON.stringify(parsed.data), context.auth.user_id], {  });
    await tx.queryNamed("dashboardService.js:17:86", [org, context.auth.user_id, JSON.stringify(parsed.data)], {  });
    await tx.commit();
    return serviceJson(context, { config: rows[0].setting_value });
  } catch (e) {
    await tx.rollback();
    throw e;
  } finally {
    tx.release();
  }

}

module.exports = { get_summary_1, get_config_2, put_config_3 };
