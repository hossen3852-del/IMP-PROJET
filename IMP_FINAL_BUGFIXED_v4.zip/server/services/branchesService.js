'use strict';

const { serviceResponse, serviceJson } = require('./serviceResult');


const { z } = require('zod');
const crypto = require('node:crypto');
const repository = require('../repositories');

const { isOrganizationWide, assertBranchAccess, enforceRequestedBranch } = require('../application/accessScope');

const branchSchema = z.object({
  name: z.string().trim().min(2).max(200),
  phone: z.string().trim().max(50).nullable().optional(),
  address: z.string().trim().max(5000).nullable().optional(),
  managerName: z.string().trim().max(200).nullable().optional()
}).strict();

const updateSchema = branchSchema.partial().extend({ status: z.enum(['active','inactive']).optional() }).strict();

function normalizeOptional(data) {
  for (const key of ['phone','address','managerName']) {
    if (data[key] === '') data[key] = null;
  }
  return data;
}

async function makeBranchCode(tx, organizationId) {
  for (let i = 0; i < 5; i += 1) {
    const suffix = crypto.randomBytes(4).toString('hex').toUpperCase();
    const code = `BR-${suffix}`;
    const check = await tx.queryNamed("branchesService.js:29:37", [organizationId, code], {  });
    if (!check.rows[0]) return code;
  }
  throw new Error('Unable to generate a unique branch code');
}


;

;

;

;

;


async function get_root_1(context) {
  context.cookies ||= [];

  try {
    const { rows } = await repository.queryNamed("branchesService.js:3:26", isOrganizationWide(context.auth) ? [context.auth.organization_id] : [context.auth.organization_id, context.auth.branch_id], { orgWide: isOrganizationWide(context.auth) });
    return serviceJson(context, { branches: rows });
  } catch (error) { throw error; }

}

async function get_id_2(context) {
  context.cookies ||= [];

  try {
    const { rows } = await repository.queryNamed("branchesService.js:3:27", isOrganizationWide(context.auth) ? [context.auth.organization_id, context.params.id] : [context.auth.organization_id, context.params.id, context.auth.branch_id], { orgWide: isOrganizationWide(context.auth) });
    if (!rows[0]) return serviceResponse(404, { error: 'Branch not found' }, context);
    return serviceJson(context, { branch: rows[0] });
  } catch (error) { throw error; }

}

async function post_root_3(context) {
  context.cookies ||= [];

  try {
    const parsed = branchSchema.safeParse(context.body);
    if (!parsed.success) return serviceResponse(400, { error: 'Invalid branch data' }, context);
    const data = normalizeOptional(parsed.data);
    const tx = await repository.begin();
    try {
      await tx.begin();
      const duplicate = await tx.queryNamed("branchesService.js:9:28", [context.auth.organization_id, data.name], {  });
      if (duplicate.rows[0]) {
        await tx.rollback();
        return serviceResponse(409, { error: 'A branch with this name already exists.' }, context);
      }
      const code = await makeBranchCode(tx, context.auth.organization_id);
      const result = await tx.queryNamed("branchesService.js:18:29", [context.auth.organization_id, code, data.name, data.phone ?? null, data.address ?? null, data.managerName ?? null, context.auth.user_id], {});
      await tx.queryNamed("branchesService.js:23:30", [context.auth.organization_id, context.auth.user_id, result.rows[0].id, JSON.stringify({ branchCode: code, name: data.name })], {  });
      await tx.commit();
      return serviceResponse(201, { branch: result.rows[0] }, context);
    } catch (error) { await tx.rollback(); throw error; }
    finally { tx.release(); }
  } catch (error) { throw error; }

}

async function patch_id_4(context) {
  context.cookies ||= [];

  try {
    const parsed = updateSchema.safeParse(context.body);
    if (!parsed.success) return serviceResponse(400, { error: 'Invalid branch data' }, context);
    const data = normalizeOptional(parsed.data);
    const tx = await repository.begin();
    try {
      await tx.begin();
      const current = await tx.queryNamed("branchesService.js:9:31", [context.auth.organization_id, context.params.id], {});
      if (!current.rows[0]) { await tx.rollback(); return serviceResponse(404, { error: 'Branch not found' }, context); }
      const b = current.rows[0];
      const next = {
        name: data.name !== undefined ? data.name : b.name,
        phone: data.phone !== undefined ? data.phone : b.phone,
        address: data.address !== undefined ? data.address : b.address,
        managerName: data.managerName !== undefined ? data.managerName : b.manager_name,
        status: data.status !== undefined ? data.status : b.status
      };
      if (data.name !== undefined) {
        const duplicate = await tx.queryNamed("branchesService.js:23:32", [context.auth.organization_id, next.name, context.params.id], {  });
        if (duplicate.rows[0]) { await tx.rollback(); return serviceResponse(409, { error: 'A branch with this name already exists.' }, context); }
      }
      const result = await tx.queryNamed("branchesService.js:29:33", [next.name, next.phone, next.address, next.managerName, next.status, context.auth.organization_id, context.params.id], {});
      await tx.queryNamed("branchesService.js:34:34", [context.auth.organization_id, context.auth.user_id, context.params.id, JSON.stringify({ fields: Object.keys(data) })], {  });
      await tx.commit();
      return serviceJson(context, { branch: result.rows[0] });
    } catch (error) { await tx.rollback(); throw error; }
    finally { tx.release(); }
  } catch (error) { throw error; }

}

async function post_id_deactivate_5(context) {
  context.cookies ||= [];

  try {
    const tx = await repository.begin();
    try {
      await tx.begin();
      const result = await tx.queryNamed("branchesService.js:6:35", [context.auth.organization_id, context.params.id], {});
      if (!result.rows[0]) { await tx.rollback(); return serviceResponse(404, { error: 'Active branch not found' }, context); }
      await tx.queryNamed("branchesService.js:13:36", [context.auth.organization_id, context.auth.user_id, context.params.id], {  });
      await tx.commit();
      return serviceJson(context, { branch: result.rows[0] });
    } catch (error) { await tx.rollback(); throw error; }
    finally { tx.release(); }
  } catch (error) { throw error; }

}

module.exports = { get_root_1, get_id_2, post_root_3, patch_id_4, post_id_deactivate_5 };
