'use strict';

const { serviceResponse, serviceJson } = require('./serviceResult');


const { z } = require('zod');
const repository = require('../repositories');

const STATUS = ['pending','partial','paid','overdue','waived','cancelled'];
const statusSchema = z.object({ status: z.enum(STATUS) }).strict();

function money(value) { return Number(Number(value).toFixed(2)); }
function toYMD(date) {
  // node-postgres returns DATE columns as JS Date objects by default, but
  // callers may also pass a plain "YYYY-MM-DD" string (e.g. from request
  // input before it round-trips through the database). Handle both.
  if (date instanceof Date) {
    return { y: date.getUTCFullYear(), m: date.getUTCMonth() + 1, day: date.getUTCDate() };
  }
  const match = String(date).match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (!match) throw new Error(`Invalid date value for installment scheduling: ${date}`);
  return { y: Number(match[1]), m: Number(match[2]), day: Number(match[3]) };
}

function addPeriod(date, frequency, n) {
  const { y, m, day } = toYMD(date);
  if (frequency === 'weekly' || frequency === 'biweekly') {
    const d = new Date(Date.UTC(y, m - 1, day));
    d.setUTCDate(d.getUTCDate() + n * (frequency === 'weekly' ? 7 : 14));
    return d.toISOString().slice(0,10);
  }
  // Monthly: clamp to the last valid day of the target month so that a
  // loan starting on the 29th/30th/31st does not overflow into the wrong
  // month (e.g. Jan 31 + 1 month must land on Feb 28/29, not Mar 3).
  const targetMonthIndex = (m - 1) + n;
  const targetYear = y + Math.floor(targetMonthIndex / 12);
  const targetMonth = ((targetMonthIndex % 12) + 12) % 12;
  const lastDayOfTargetMonth = new Date(Date.UTC(targetYear, targetMonth + 1, 0)).getUTCDate();
  const clampedDay = Math.min(day, lastDayOfTargetMonth);
  return new Date(Date.UTC(targetYear, targetMonth, clampedDay)).toISOString().slice(0,10);
}
function toInstallment(row) {
  return {
    id: row.id, installmentId: row.id, organizationId: row.organization_id,
    loanId: row.loan_id, installmentNumber: row.installment_number,
    dueDate: row.due_date, amount: Number(row.installment_amount),
    installmentAmount: Number(row.installment_amount), paidAmount: Number(row.paid_amount),
    outstandingAmount: Number(row.outstanding_amount), status: row.status,
    paidDate: row.paid_date, createdAt: row.created_at, updatedAt: row.updated_at
  };
}

async function audit(tx, auth, action, id, metadata={}) {
  await tx.queryNamed("installmentsService.js:51:102", [auth.organization_id, auth.user_id, action, id, JSON.stringify(metadata)], {  });
}


;

;

;

;


async function get_root_1(context) {
  context.cookies ||= [];

  try {
    const org = context.auth.organization_id;
    const loanId = typeof context.query.loan_id === 'string' ? context.query.loan_id.trim() : '';
    const limit = Math.min(Math.max(Number.parseInt(context.query.limit || '500', 10) || 500, 1), 2000);
    const values = [org];
    if (loanId) values.push(loanId);
    values.push(limit);
    const { rows } = await repository.queryNamed("installmentsService.js:14:95", values, { hasLoanId: Boolean(loanId) });
    return serviceJson(context, { installments: rows.map(toInstallment), count: rows.length });
  } catch(e) { throw e; }

}

async function get_id_2(context) {
  context.cookies ||= [];

  try {
    const { rows } = await repository.queryNamed("installmentsService.js:3:96", [context.params.id, context.auth.organization_id], {});
    if (!rows[0]) return serviceResponse(404, { error:'Installment not found' }, context);
    return serviceJson(context, { installment: toInstallment(rows[0]) });
  } catch(e) { throw e; }

}

async function post_generate_3(context) {
  context.cookies ||= [];

  const parsed = z.object({ loanId: z.string().uuid() }).strict().safeParse(context.body);
  if (!parsed.success) return serviceResponse(400, { error:'Invalid loanId' }, context);
  const org = context.auth.organization_id, tx = await repository.begin();
  try {
    await tx.begin();
    const loanResult = await tx.queryNamed("installmentsService.js:7:97", [parsed.data.loanId, org], {  });
    const loan = loanResult.rows[0];
    if (!loan) { await tx.rollback(); return serviceResponse(404, {error:'Loan not found'}, context); }
    if (!['approved','disbursed','active','completed'].includes(loan.status)) { await tx.rollback(); return serviceResponse(409, {error:'Installment schedule can only be generated for an approved or later loan'}, context); }
    const existing = await tx.queryNamed("installmentsService.js:11:98", [loan.id, org], {  });
    if (existing.rows[0]) { await tx.rollback(); return serviceResponse(409, {error:'Installment schedule already exists'}, context); }
    const count = Number(loan.number_of_installments), total = Number(loan.total_payable);
    const base = Number(loan.installment_amount) > 0 ? money(Number(loan.installment_amount)) : money(total / count);
    const firstDate = loan.first_installment_date || loan.start_date;
    const created = [];
    for (let n=1; n<=count; n++) {
      const amount = n === count ? money(Math.max(0, total - base * (count - 1))) : base;
      const { rows } = await tx.queryNamed("installmentsService.js:18:99", [org,loan.id,n,addPeriod(firstDate,loan.installment_frequency,n-1),amount], {});
      created.push(rows[0]);
    }
    await audit(tx, context.auth, 'INSTALLMENT_SCHEDULE_GENERATED', loan.id, { count, total_payable: total });
    await tx.commit();
    return serviceResponse(201, { installments: created.map(toInstallment), count: created.length }, context);
  } catch(e) { await tx.rollback(); throw e; } finally { tx.release(); }

}

async function patch_id_status_4(context) {
  context.cookies ||= [];

  const parsed = statusSchema.safeParse(context.body);
  if (!parsed.success) return serviceResponse(400, {error:'Invalid installment status'}, context);
  const tx = await repository.begin(), org = context.auth.organization_id;
  try {
    await tx.begin();
    const current = await tx.queryNamed("installmentsService.js:7:100", [context.params.id,org], {});
    if (!current.rows[0]) { await tx.rollback(); return serviceResponse(404, {error:'Installment not found'}, context); }
    const from=current.rows[0].status, to=parsed.data.status;
    const allowed = {pending:['partial','paid','overdue','waived','cancelled'],partial:['paid','overdue','waived','cancelled'],overdue:['partial','paid','waived','cancelled'],paid:[],waived:[],cancelled:[]};
    if (from !== to && !allowed[from].includes(to)) { await tx.rollback(); return serviceResponse(409, {error:`Invalid installment status transition: ${from} -> ${to}`}, context); }
    const paidDate = to === 'paid' ? new Date().toISOString().slice(0,10) : null;
    const { rows } = await tx.queryNamed("installmentsService.js:13:101", [to,paidDate,context.params.id,org], {});
    await audit(tx,context.auth,'INSTALLMENT_STATUS_UPDATED',context.params.id,{from,to});
    await tx.commit();
    return serviceJson(context, {installment:toInstallment(rows[0])});
  } catch(e) { await tx.rollback(); throw e; } finally { tx.release(); }

}

module.exports = { get_root_1, get_id_2, post_generate_3, patch_id_status_4 };
