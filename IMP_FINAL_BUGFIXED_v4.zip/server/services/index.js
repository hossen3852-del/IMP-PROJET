'use strict';

// Service registry intentionally exposes application-domain service factories only.
// The repository/DB boundary is never re-exported through this module.
function createDomainService(domain, handlers = {}) {
  return Object.freeze({ domain, ...handlers });
}

module.exports = Object.freeze({ createDomainService });
