'use strict';

const { serviceResponse, serviceJson } = require('./serviceResult');


/**
 * 11.P.15.3/15.4 — Capital Management + Capital Financial Calculation.
 *
 * Current Balance = Previous Capital + New Capital + Installment Collection
 *                  + Savings + Insurance + Admission Fee
 *                  - Loan Disbursement - Savings Withdrawal
 *                  - Conditional Insurance Payout
 *
 * "Collection" and "Loan Disbursement" are never entered manually here —
 * they are derived live from the existing payments/loans tables (the
 * payment-allocation architecture from 11.P.9/11.P.10 remains the single
 * source of truth for money movement). Only opening capital, admission fee,
 * insurance, adjustments and withdrawals are posted through this ledger.
 */

const { z } = require('zod');
const repository = require('../repositories');

const { isOrganizationWide, assertBranchAccess, enforceRequestedBranch } = require('../application/accessScope');
const { calculateCurrentBalance, calculateTotalInsurance } = require('../utils/dashboardKpis');

const ENTRY_TYPES = [
  'capital_in', 'capital_adjustment', 'capital_withdrawal'
];

const createSchema = z.object({
  entryType: z.enum(ENTRY_TYPES),
  amount: z.coerce.number().refine(v => v !== 0, 'Amount must not be zero'),
  entryDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'entryDate must be YYYY-MM-DD'),
  branchId: z.string().uuid().nullable().optional(),
  description: z.string().trim().max(2000).optional().default('')
}).strict().superRefine((data, ctx) => {
  if (data.entryType !== 'capital_adjustment' && data.amount <= 0) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['amount'], message: 'Only capital_adjustment may be negative; other entry types must be positive amounts' });
  }
});

function money(v) { return Number(v); }

function toEntry(r) {
  return {
    id: r.id,
    organizationId: r.organization_id,
    branchId: r.branch_id,
    entryType: r.entry_type,
    amount: money(r.amount),
    entryDate: r.entry_date,
    description: r.description || '',
    createdBy: r.created_by,
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}

async function audit(tx, auth, action, entityId, metadata = {}) {
  await tx.queryNamed("capitalService.js:58:43", [auth.organization_id, auth.user_id, action, entityId, JSON.stringify(metadata)], {  });
}

/**
 * Computes the live capital breakdown for an organization from PostgreSQL.
 * Nothing here is cached or trusted from the tx.
 */
async function computeCapitalSummary(org, repo = repository, branchId = null) {
  const values = branchId ? [org, branchId] : [org];
  const ledger = await repo.queryNamed("capitalService.js:72:44", values, { hasBranch: Boolean(branchId) });

  const collection = await repo.queryNamed("capitalService.js:83:45", values, { branchId: branchId });

  const disbursement = await repo.queryNamed("capitalService.js:90:46", values, { branchId: branchId });

  const savings = await repo.queryNamed("capitalService.js:97:47", values, { branchId: branchId });

  // Insurance premium is authoritative in the member-wise insurance ledger.
  // Capital entries are intentionally NOT used for insurance premiums, which
  // prevents duplicate premium postings.
  const memberInsurance = await repo.queryNamed("capitalService.js:111:48", values, { branchId: branchId });

  const l = ledger.rows[0];
  const capitalIn = money(l.capital_in);
  const admissionFee = money(l.admission_fee);
  const memberInsurancePremiums = money(memberInsurance.rows[0].premiums);
  const memberInsuranceClaims = money(memberInsurance.rows[0].claims);
  const insuranceGross = memberInsurancePremiums;
  const insuranceClaim = memberInsuranceClaims;
  const insurance = calculateTotalInsurance({ insurance: insuranceGross, newInsurance: 0, conditionalPayout: insuranceClaim });
  const capitalWithdrawal = money(l.capital_withdrawal);
  const capitalAdjustment = money(l.capital_adjustment);
  const totalCollection = money(collection.rows[0].total);
  const totalDisbursement = money(disbursement.rows[0].total);
  const savingsDeposits = money(savings.rows[0].deposits);
  const dailySavingsDeposits = money(savings.rows[0].daily_deposits);
  const savingsWithdrawals = money(savings.rows[0].withdrawals);
  const savingsInstallmentPayments = money(savings.rows[0].installment_payments);

  // Canonical Current Balance:
  // previous capital + new capital + installment + savings + insurance +
  // admission fee - loan - savings withdrawal - conditional insurance payout.
  // capital_adjustment is part of the capital base (it may be negative).
  // Both normal and daily savings deposits are included in the savings
  // component. Capital withdrawal is reported separately and is NOT deducted
  // here because the canonical formula supplied for this dashboard does not
  // include it.
  const currentCapital = calculateCurrentBalance({
    previousCapital: capitalIn,
    newCapital: capitalAdjustment,
    installmentCollection: totalCollection,
    savings: savingsDeposits + dailySavingsDeposits,
    insurance: insuranceGross,
    admissionFee,
    loanDisbursement: totalDisbursement,
    savingsWithdrawal: savingsWithdrawals,
    insuranceClaim
  });

  return {
    capitalIn,
    admissionFee,
    insuranceGross,
    insurance,
    insuranceClaim,
    collection: totalCollection,
    capitalWithdrawal,
    capitalAdjustment,
    loanDisbursement: totalDisbursement,
    savingsDeposits,
    dailySavingsDeposits,
    savingsWithdrawals,
    savingsInstallmentPayments,
    currentCapital
  };
}

;

;

;

;

module.exports.computeCapitalSummary = computeCapitalSummary;

async function get_summary_1(context) {
  context.cookies ||= [];

  try {
    const branchId = isOrganizationWide(context.auth) ? null : context.auth.branch_id;
    if (!isOrganizationWide(context.auth) && !branchId) return serviceResponse(403, { error: 'Your account is not assigned to a branch' }, context);
    const summary = await computeCapitalSummary(context.auth.organization_id, repository, branchId);
    return serviceJson(context, { summary });
  } catch (e) { throw e; }

}

async function get_entries_2(context) {
  context.cookies ||= [];

  try {
    const org = context.auth.organization_id;
    const values = [org];
    const filters = [];
    if (!isOrganizationWide(context.auth)) {
      if (!context.auth.branch_id) filters.push('denyAll');
      else { values.push(context.auth.branch_id); filters.push('branchId'); }
    }
    if (typeof context.query.entryType === 'string' && context.query.entryType) { values.push(context.query.entryType); filters.push('entryType'); }
    if (typeof context.query.fromDate === 'string' && context.query.fromDate) { values.push(context.query.fromDate); filters.push('fromDate'); }
    if (typeof context.query.toDate === 'string' && context.query.toDate) { values.push(context.query.toDate); filters.push('toDate'); }
    const limit = Math.min(Math.max(parseInt(context.query.limit || '100', 10) || 100, 1), 500);
    const offset = Math.max(parseInt(context.query.offset || '0', 10) || 0, 0);
    values.push(limit, offset);
    const { rows } = await repository.queryNamed("capitalService.js:25:38", values, { filters });

    return serviceJson(context, { entries: rows.map(toEntry), pagination: { limit, offset, returned: rows.length } });
  } catch (e) { throw e; }

}

async function post_entries_3(context) {
  context.cookies ||= [];

  const parsed = createSchema.safeParse(context.body);
  if (!parsed.success) return serviceResponse(400, { error: 'Invalid capital entry', details: parsed.error.issues }, context);
  const data = parsed.data;
  const org = context.auth.organization_id;

  const tx = await repository.begin();
  try {
    await tx.begin();

    const effectiveBranchId = isOrganizationWide(context.auth) ? (data.branchId || null) : context.auth.branch_id;
    if (!isOrganizationWide(context.auth) && !effectiveBranchId) { await tx.rollback(); return serviceResponse(403, { error: 'Your account is not assigned to a branch' }, context); }
    if (effectiveBranchId) {
      assertBranchAccess(context.auth, effectiveBranchId);
      const branch = await tx.queryNamed("capitalService.js:15:39", [effectiveBranchId, org], {  });
      if (!branch.rows[0]) {
        await tx.rollback();
        return serviceResponse(400, { error: 'Branch does not belong to this organization' }, context);
      }
    }

    const { rows } = await tx.queryNamed("capitalService.js:25:40", [org, effectiveBranchId, data.entryType, data.amount, data.entryDate, data.description, context.auth.user_id], {  });

    await audit(tx, context.auth, 'capital_entry.create', rows[0].id, { entryType: data.entryType, amount: data.amount });
    await tx.commit();
    return serviceResponse(201, { entry: toEntry(rows[0]) }, context);
  } catch (e) {
    await tx.rollback();
    throw e;
  } finally {
    tx.release();
  }

}

async function delete_entries_id_4(context) {
  context.cookies ||= [];

  const tx = await repository.begin();
  try {
    await tx.begin();
    const org = context.auth.organization_id;
    const existing = await tx.queryNamed("capitalService.js:6:41", [context.params.id, org], {  });
    if (!existing.rows[0]) {
      await tx.rollback();
      return serviceResponse(404, { error: 'Capital entry not found' }, context);
    }
    if (!isOrganizationWide(context.auth)) assertBranchAccess(context.auth, existing.rows[0].branch_id);
    await tx.queryNamed("capitalService.js:15:42", [context.params.id, org], {  });
    await audit(tx, context.auth, 'capital_entry.delete', context.params.id, { entryType: existing.rows[0].entry_type, amount: money(existing.rows[0].amount) });
    await tx.commit();
    return serviceResponse(204, null, context);
  } catch (e) {
    await tx.rollback();
    throw e;
  } finally {
    tx.release();
  }

}



const shareSchema=z.object({memberId:z.string().uuid().nullable().optional(),shareholderName:z.string().trim().min(1).max(200),shareholderPhone:z.string().trim().max(50).optional().default(''),shareholderEmail:z.string().trim().email().max(254).optional().or(z.literal('')).default(''),shareUnits:z.coerce.number().positive(),issuePricePerShare:z.coerce.number().positive(),investedAmount:z.coerce.number().min(0),acquisitionDate:z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),status:z.enum(['active','inactive']).optional().default('active'),notes:z.string().trim().max(5000).optional().default(''),photoDataUrl:z.string().max(3500000).optional()}).strict();
async function get_shares_summary_5(context){const org=context.auth.organization_id;const t=await repository.queryNamed('capitalService.js:shareTotals',[org],{});const mv=await repository.queryNamed('capitalService.js:shareMarketValue',[org],{});const totalUnits=Number(t.rows[0].total_units||0),invested=Number(t.rows[0].invested_capital||0),marketValue=Number(mv.rows[0]?.market_value||invested||0);return serviceJson(context,{summary:{totalUnits,investedCapital:invested,marketValue,marketPricePerShare:totalUnits?marketValue/totalUnits:0}});}
async function get_shares_6(context){const org=context.auth.organization_id;const limit=Math.min(Math.max(parseInt(context.query.limit||'200',10)||200,1),500),offset=Math.max(parseInt(context.query.offset||'0',10)||0,0);const r=await repository.queryNamed('capitalService.js:shareList',[org,limit,offset],{});const t=await repository.queryNamed('capitalService.js:shareTotals',[org],{});const mv=await repository.queryNamed('capitalService.js:shareMarketValue',[org],{});const totalUnits=Number(t.rows[0].total_units||0),marketValue=Number(mv.rows[0]?.market_value||t.rows[0].invested_capital||0);return serviceJson(context,{shares:r.rows.map(x=>({...x,id:x.id,memberId:x.member_id,shareholderName:x.shareholder_name,shareholderPhone:x.shareholder_phone||'',shareholderEmail:x.shareholder_email||'',shareUnits:Number(x.share_units),issuePricePerShare:Number(x.issue_price_per_share),investedAmount:Number(x.invested_amount),ownershipPercent:totalUnits?Number(x.share_units)/totalUnits*100:0,currentMarketValue:totalUnits?Number(x.share_units)/totalUnits*marketValue:0,acquisitionDate:x.acquisition_date,status:x.status,notes:x.notes||'',photoUrl:x.photo_url||'',memberName:x.member_name||'',memberCode:x.member_code||''})),summary:{totalUnits,investedCapital:Number(t.rows[0].invested_capital||0),marketValue,marketPricePerShare:totalUnits?marketValue/totalUnits:0}});}
async function get_share_id_7(context){const r=await repository.queryNamed('capitalService.js:shareOne',[context.params.id,context.auth.organization_id],{});if(!r.rows[0])return serviceResponse(404,{error:'Share profile not found'},context);const t=await repository.queryNamed('capitalService.js:shareTotals',[context.auth.organization_id],{});const mv=await repository.queryNamed('capitalService.js:shareMarketValue',[context.auth.organization_id],{});const totalUnits=Number(t.rows[0].total_units||0),marketValue=Number(mv.rows[0]?.market_value||t.rows[0].invested_capital||0),x=r.rows[0];return serviceJson(context,{share:{...x,id:x.id,memberId:x.member_id,shareholderName:x.shareholder_name,shareholderPhone:x.shareholder_phone||'',shareholderEmail:x.shareholder_email||'',shareUnits:Number(x.share_units),issuePricePerShare:Number(x.issue_price_per_share),investedAmount:Number(x.invested_amount),ownershipPercent:totalUnits?Number(x.share_units)/totalUnits*100:0,currentMarketValue:totalUnits?Number(x.share_units)/totalUnits*marketValue:0,acquisitionDate:x.acquisition_date,status:x.status,notes:x.notes||'',memberName:x.member_name||'',memberCode:x.member_code||''}});}
async function post_shares_8(context){const p=shareSchema.safeParse(context.body);if(!p.success)return serviceResponse(400,{error:'Invalid share profile',details:p.error.issues,message:'শেয়ার প্রোফাইল ডাটা সঠিক নয়'},context);const d=p.data;if(Math.abs(Number(d.shareUnits)*Number(d.issuePricePerShare)-Number(d.investedAmount))>0.01)return serviceResponse(400,{error:'Invested amount must equal share units × issue price per share',message:'বিনিয়োগ = ইউনিট × ইস্যু মূল্য হতে হবে'},context);const org=context.auth.organization_id;const photo=d.photoDataUrl||null;const r=await repository.queryNamed('capitalService.js:shareInsert',[org,d.memberId||null,d.shareholderName,d.shareholderPhone,d.shareholderEmail,d.shareUnits,d.issuePricePerShare,d.investedAmount,d.acquisitionDate||new Date().toISOString().slice(0,10),d.status,d.notes,photo,context.auth.user_id],{});return serviceResponse(201,{shareId:r.rows[0].id},context);}
async function put_share_id_9(context){const p=shareSchema.partial().safeParse(context.body);if(!p.success)return serviceResponse(400,{error:'Invalid share update',details:p.error.issues,message:'শেয়ার আপডেট ডাটা সঠিক নয়'},context);const cur=await repository.queryNamed('capitalService.js:shareOne',[context.params.id,context.auth.organization_id],{});if(!cur.rows[0])return serviceResponse(404,{error:'Share profile not found'},context);const x=cur.rows[0],d=p.data;const units=d.shareUnits??Number(x.share_units),price=d.issuePricePerShare??Number(x.issue_price_per_share),invested=d.investedAmount??Number(x.invested_amount);if(Math.abs(Number(units)*Number(price)-Number(invested))>0.01)return serviceResponse(400,{error:'Invested amount must equal share units × issue price per share',message:'বিনিয়োগ = ইউনিট × ইস্যু মূল্য হতে হবে'},context);const photo=d.photoDataUrl!==undefined?d.photoDataUrl:x.photo_url;const r=await repository.queryNamed('capitalService.js:shareUpdate',[d.memberId===undefined?x.member_id:d.memberId,d.shareholderName??x.shareholder_name,d.shareholderPhone??x.shareholder_phone,d.shareholderEmail??x.shareholder_email,d.shareUnits??Number(x.share_units),d.issuePricePerShare??Number(x.issue_price_per_share),d.investedAmount??Number(x.invested_amount),d.acquisitionDate??x.acquisition_date,d.status??x.status,d.notes??x.notes,photo,context.auth.user_id,context.params.id,context.auth.organization_id],{});return serviceJson(context,{shareId:r.rows[0].id});}
async function delete_share_id_10(context){const r=await repository.queryNamed('capitalService.js:shareDelete',[context.params.id,context.auth.organization_id],{});if(!r.rowCount)return serviceResponse(404,{error:'Share profile not found'},context);return serviceResponse(204,null,context);}
async function put_share_market_value_11(context){const p=z.object({marketValue:z.coerce.number().min(0)}).strict().safeParse(context.body);if(!p.success)return serviceResponse(400,{error:'Invalid market value'},context);const r=await repository.queryNamed('capitalService.js:shareMarketValueUpsert',[context.auth.organization_id,JSON.stringify({marketValue:p.data.marketValue}),context.auth.user_id],{});return serviceJson(context,{marketValue:p.data.marketValue});}

module.exports = { get_summary_1, get_entries_2, post_entries_3, delete_entries_id_4, computeCapitalSummary, get_shares_summary_5, get_shares_6, get_share_id_7, post_shares_8, put_share_id_9, delete_share_id_10, put_share_market_value_11 };
