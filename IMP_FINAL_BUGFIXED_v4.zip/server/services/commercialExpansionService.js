'use strict';
const { z } = require('zod');
const repository = require('../repositories');
const { serviceJson, serviceResponse } = require('./serviceResult');
const { isOrganizationWide, assertBranchAccess } = require('../application/accessScope');
const paymentsService = require('./paymentsService');
const { calculateLoanProduct } = require('./loanProductCalculator');

const productSchema = z.object({
  code: z.string().trim().min(2).max(80), name: z.string().trim().min(2).max(160),
  productType: z.string().trim().min(2).max(40).default('flat'),
  interestMethod: z.string().trim().min(2).max(40).default('flat'), interestRate: z.coerce.number().min(0),
  minAmount: z.coerce.number().min(0).default(0), maxAmount: z.coerce.number().min(0).nullable().optional(),
  minInstallments: z.coerce.number().int().min(1).default(1), maxInstallments: z.coerce.number().int().min(1).nullable().optional(),
  frequency: z.string().trim().min(2).max(30).default('monthly'), graceDays: z.coerce.number().int().min(0).default(0),
  penaltyRate: z.coerce.number().min(0).default(0), penaltyType: z.enum(['percent','fixed']).default('percent'),
  metadata: z.record(z.string(), z.any()).default({})
}).strict();
const adjustmentSchema = z.object({ loanId:z.string().uuid(), adjustmentType:z.enum(['penalty','waiver','reschedule','write_off','partial_payment']), amount:z.coerce.number().min(0).default(0), effectiveDate:z.string().regex(/^\d{4}-\d{2}-\d{2}$/), reason:z.string().trim().min(2).max(2000), metadata:z.record(z.string(),z.any()).default({}) }).strict();
const notificationSchema = z.object({ memberId:z.string().uuid().optional(), channel:z.enum(['sms','whatsapp']), recipient:z.string().trim().min(3).max(100), templateCode:z.string().trim().min(2).max(100), payload:z.record(z.string(),z.any()).default({}), scheduledAt:z.string().datetime().optional() }).strict();
const syncSchema = z.object({ events:z.array(z.object({clientEventId:z.string().min(1).max(120),eventType:z.string().min(1).max(60),entityType:z.string().min(1).max(60),entityId:z.string().uuid().optional(),payload:z.record(z.string(),z.any()).default({})}).strict()).max(500) }).strict();
const journalSchema = z.object({branchId:z.string().uuid().nullable().optional(),entryDate:z.string().regex(/^\d{4}-\d{2}-\d{2}$/),referenceType:z.string().max(60).optional(),referenceId:z.string().uuid().optional(),description:z.string().trim().min(2).max(500),lines:z.array(z.object({accountId:z.string().uuid(),debit:z.coerce.number().min(0).default(0),credit:z.coerce.number().min(0).default(0),description:z.string().max(500).optional()}).refine(x => (x.debit>0) !== (x.credit>0), 'Each line must have either debit or credit')).min(2)}).strict();

function org(ctx){return ctx.auth.organization_id;}
function branch(ctx, requested){ const b=isOrganizationWide(ctx.auth)?(requested||null):ctx.auth.branch_id; if(!isOrganizationWide(ctx.auth)&&!b) throw Object.assign(new Error('Branch assignment required'),{status:403}); if(b) assertBranchAccess(ctx.auth,b); return b; }
function money(n){return Number(Number(n||0).toFixed(2));}

async function get_field_route_1(ctx){
 const b=branch(ctx,ctx.query.branchId); const {rows}=await repository.queryNamed('commercialExpansion:fieldRoute',[org(ctx),b,ctx.query.date||null,ctx.query.q||null],{}); return serviceJson(ctx,{route:rows});
}
async function post_field_sync_2(ctx){
 const p=syncSchema.safeParse(ctx.body); if(!p.success)return serviceResponse(400,{error:'Invalid sync payload',details:p.error.issues},ctx);
 const results=[]; for(const e of p.data.events){ if(e.eventType==='collection.payment'){ if(!ctx.auth.permissions.includes('payment.create')){results.push({clientEventId:e.clientEventId,status:'rejected',error:'payment.create permission required'});continue;} const paymentContext={...ctx,body:e.payload,headers:{...(ctx.headers||{}),'Idempotency-Key':e.clientEventId}}; const paymentResult=await paymentsService.post_root_2(paymentContext); if(paymentResult?.status>=400){results.push({clientEventId:e.clientEventId,status:'rejected',error:paymentResult.body?.error||'Payment rejected'});continue;} } const r=await repository.queryNamed('commercialExpansion:syncInsert',[org(ctx),ctx.auth.branch_id||null,ctx.auth.user_id,e.clientEventId,e.eventType,e.entityType,e.entityId||null,JSON.stringify(e.payload)],{});results.push(r.rows[0]); } return serviceJson(ctx,{accepted:results});
}
async function get_field_sync_3(ctx){const {rows}=await repository.queryNamed('commercialExpansion:syncList',[org(ctx),ctx.auth.user_id,Number(ctx.query.limit||200)],{});return serviceJson(ctx,{events:rows});}

async function get_products_4(ctx){const {rows}=await repository.queryNamed('commercialExpansion:productsList',[org(ctx)],{});return serviceJson(ctx,{products:rows});}
async function post_product_5(ctx){const p=productSchema.safeParse(ctx.body);if(!p.success)return serviceResponse(400,{error:'Invalid loan product',details:p.error.issues},ctx);const d=p.data;const {rows}=await repository.queryNamed('commercialExpansion:productInsert',[org(ctx),d.code,d.name,d.productType,d.interestMethod,d.interestRate,d.minAmount,d.maxAmount??null,d.minInstallments,d.maxInstallments??null,d.frequency,d.graceDays,d.penaltyRate,d.penaltyType,JSON.stringify(d.metadata),ctx.auth.user_id],{});return serviceResponse(201,{product:rows[0]},ctx);}
async function post_adjustment_6(ctx){
 const idempotencyKey=String(ctx.headers?.['idempotency-key']||ctx.headers?.['Idempotency-Key']||ctx.headers?.['x-idempotency-key']||'').trim();
 if(!idempotencyKey||idempotencyKey.length>150)return serviceResponse(400,{error:'Idempotency-Key header is required for loan adjustments (max 150 characters)'},ctx);
 const p=adjustmentSchema.safeParse(ctx.body);if(!p.success)return serviceResponse(400,{error:'Invalid adjustment',details:p.error.issues},ctx);const d=p.data;
 if(['penalty','waiver','write_off','partial_payment'].includes(d.adjustmentType)&&!(d.amount>0))return serviceResponse(400,{error:'Amount must be greater than zero for this adjustment'},ctx);
 const metadata=d.metadata||{};
 if(d.adjustmentType==='reschedule'&&(!Number.isInteger(Number(metadata.days))||Number(metadata.days)<=0||Number(metadata.days)>3650))return serviceResponse(400,{error:'Reschedule requires metadata.days between 1 and 3650'},ctx);
 const tx=await repository.begin();
 try{await tx.begin();
   const loan=await tx.queryNamed('commercialExpansion:loanForAdjustment',[org(ctx),d.loanId],{});if(!loan.rows[0]){await tx.rollback();return serviceResponse(404,{error:'Loan not found'},ctx);}
   const l=loan.rows[0];if(!isOrganizationWide(ctx.auth))assertBranchAccess(ctx.auth,l.branch_id);if(!['disbursed','active'].includes(l.status)){await tx.rollback();return serviceResponse(409,{error:'Adjustments are only allowed on disbursed or active loans'},ctx);}
   const existing=await tx.queryNamed('commercialExpansion:adjustmentExistingByIdempotency',[org(ctx),idempotencyKey],{});
   if(existing.rows[0]){const prior=existing.rows[0];if(prior.loan_id!==d.loanId||prior.adjustment_type!==d.adjustmentType||Number(prior.amount)!==Number(d.amount)){await tx.rollback();return serviceResponse(409,{error:'Idempotency-Key was already used for a different adjustment'},ctx);}await tx.commit();return serviceResponse(200,{adjustment:prior,idempotent:true},ctx);}
   if(['waiver','write_off','partial_payment'].includes(d.adjustmentType)&&d.amount>Number(l.outstanding_amount)){await tx.rollback();return serviceResponse(409,{error:'Adjustment amount exceeds current loan outstanding balance'},ctx);}
   let payment=null;
   if(d.adjustmentType==='partial_payment'){
     const seq=await tx.queryNamed('paymentsService.js:15:175',[],{});const paymentNumber=`PAY-${d.effectiveDate.replace(/-/g,'')}-${String(seq.rows[0].n).padStart(8,'0')}`;
     const paymentDate=`${d.effectiveDate}T00:00:00.000Z`;
     const ins=await tx.queryNamed('paymentsService.js:16:176',[org(ctx),l.branch_id,l.member_id,d.loanId,paymentNumber,money(d.amount),paymentDate,'cash',null,null,null,null,d.reason,null,ctx.auth.user_id],{});payment=ins.rows[0];
     let remaining=money(d.amount);const schedules=await tx.queryNamed('paymentsService.js:20:177',[org(ctx),d.loanId],{});
     for(const sch of schedules.rows){if(remaining<=0)break;const a=money(Math.min(remaining,Number(sch.outstanding_amount)));if(a<=0)continue;remaining=money(remaining-a);await tx.queryNamed('paymentsService.js:22:178',[org(ctx),payment.id,d.loanId,sch.id,a],{});const paid=money(Number(sch.paid_amount)+a),out=money(Math.max(0,Number(sch.outstanding_amount)-a)),status=out===0?'paid':'partial';await tx.queryNamed('paymentsService.js:24:179',[paid,out,status,d.effectiveDate,sch.id,org(ctx)],{});}
     if(remaining>0){await tx.queryNamed('paymentsService.js:26:180',[org(ctx),payment.id,d.loanId,remaining],{});}
     const newOutstanding=money(Math.max(0,Number(l.outstanding_amount)-d.amount));await tx.queryNamed('paymentsService.js:28:181',[newOutstanding,d.loanId,org(ctx)]);
     const receiptSeq=await tx.queryNamed('paymentsService.js:29:182',[],{});const receiptNumber=`RCPT-${d.effectiveDate.replace(/-/g,'')}-${String(receiptSeq.rows[0].n).padStart(8,'0')}`;await tx.queryNamed('paymentsService.js:30:183',[org(ctx),payment.id,receiptNumber,ctx.auth.user_id],{});
   } else if(d.adjustmentType==='reschedule'){
     const days=Number(metadata.days);await tx.queryNamed('commercialExpansion:rescheduleInstallments',[days,org(ctx),d.loanId],{});await tx.queryNamed('commercialExpansion:rescheduleLoan',[days,org(ctx),d.loanId],{});
   } else {
     if(d.adjustmentType==='penalty'){
       await tx.queryNamed('commercialExpansion:loanPenaltyDelta',[d.amount,org(ctx),d.loanId],{});
       await tx.queryNamed('commercialExpansion:penaltyInstallmentInsert',[org(ctx),d.loanId,d.effectiveDate,money(d.amount)],{});
     }else if(['waiver','write_off'].includes(d.adjustmentType)){
       const schedules=await tx.queryNamed('commercialExpansion:adjustmentInstallments',[org(ctx),d.loanId],{});
       let remaining=money(d.amount);
       for(const sch of schedules.rows){
         if(remaining<=0) break;
         const waiver=money(Math.min(remaining,Number(sch.outstanding_amount)));
         if(waiver<=0) continue;
         const nextOutstanding=money(Math.max(0,Number(sch.outstanding_amount)-waiver));
         const nextStatus=nextOutstanding===0?'waived':(Number(sch.paid_amount)>0?'partial':sch.status);
         await tx.queryNamed('commercialExpansion:adjustmentInstallmentApply',[nextOutstanding,nextStatus,org(ctx),sch.id],{});
         remaining=money(remaining-waiver);
       }
       if(remaining>0) throw Object.assign(new Error('Adjustment amount exceeds outstanding installment balances'),{status:409});
       // A write-off should be distinguishable from a loan that was actually
       // fully repaid — otherwise it silently disappears into "completed"
       // and inflates that success metric / vanishes from portfolio-quality
       // reporting. A waiver (institution forgives the balance as settled)
       // keeps the existing "completed" semantics.
       if(d.adjustmentType==='write_off'){
         await tx.queryNamed('commercialExpansion:loanOutstandingDeltaWriteOff',[-d.amount,org(ctx),d.loanId],{});
       }else{
         await tx.queryNamed('commercialExpansion:loanOutstandingDelta',[-d.amount,org(ctx),d.loanId],{});
       }
     }
   }
   const a=await tx.queryNamed('commercialExpansion:adjustmentInsert',[org(ctx),l.branch_id,l.member_id,d.loanId,d.adjustmentType,d.amount,d.effectiveDate,d.reason,JSON.stringify({...metadata,paymentId:payment?.id||null}),idempotencyKey,ctx.auth.user_id],{});
   if(['penalty','waiver','write_off'].includes(d.adjustmentType)){
     await tx.queryNamed('commercialExpansion:ensureAdjustmentGlAccounts',[org(ctx)],{});
     const accountRows=await tx.queryNamed('commercialExpansion:adjustmentGlAccountIds',[org(ctx)],{});
     const accounts=Object.fromEntries(accountRows.rows.map(r=>[r.code,r.id]));
     let debitCode, creditCode, glAmount;
     if(d.adjustmentType==='penalty'){
       debitCode='1200'; creditCode='4100'; glAmount=d.amount;
     }else{
       // Loan Receivable (1200) is only ever debited for PRINCIPAL at
       // disbursement (see imp_post_loan_disbursement_gl) — interest owed
       // is never booked into it or recognized as income until actually
       // collected. Crediting 1200 for the FULL waiver/write-off amount
       // (principal + still-uncollected interest) drives it negative and
       // overstates the 5010 expense. Only the principal share of this
       // adjustment belongs in that entry; the interest share was never on
       // the books anywhere, so it needs no GL posting at all.
       debitCode='5010'; creditCode='1200';
       const loanPrincipal=Number(l.loan_amount??l.disbursed_amount??0);
       const loanInterest=Number(l.interest_amount??0);
       const loanTotal=Number(l.total_payable)>0?Number(l.total_payable):(loanPrincipal+loanInterest);
       let interestShare=loanTotal>0?money(d.amount*(loanInterest/loanTotal)):0;
       if(interestShare>d.amount) interestShare=d.amount;
       if(interestShare<0) interestShare=0;
       glAmount=money(Math.max(0,d.amount-interestShare));
     }
     if(glAmount>0){
       if(!accounts[debitCode]||!accounts[creditCode]) throw Object.assign(new Error('Required adjustment GL accounts are not configured'),{status:500});
       const j=await tx.queryNamed('commercialExpansion:journalInsert',[org(ctx),l.branch_id,d.effectiveDate,'loan_adjustment',a.rows[0].id,`${d.adjustmentType} ${l.id}`,ctx.auth.user_id],{});
       await tx.queryNamed('commercialExpansion:journalLineInsert',[j.rows[0].id,accounts[debitCode],glAmount,0,`${d.adjustmentType} receivable adjustment`],{});
       await tx.queryNamed('commercialExpansion:journalLineInsert',[j.rows[0].id,accounts[creditCode],0,glAmount,`${d.adjustmentType} offset`],{});
     }
   }
   await tx.queryNamed('commercialExpansion:audit',[org(ctx),ctx.auth.user_id,'loan.adjustment','loan',d.loanId,JSON.stringify({type:d.adjustmentType,amount:d.amount,paymentId:payment?.id||null,metadata})],{});
   await tx.commit();return serviceResponse(201,{adjustment:a.rows[0],payment:payment?{id:payment.id,paymentNumber:payment.payment_number,amount:Number(payment.amount)}:null},ctx);
 }catch(e){await tx.rollback();throw e;}finally{tx.release();}
}
async function get_adjustments_7(ctx){const b=branch(ctx,ctx.query.branchId); const {rows}=await repository.queryNamed('commercialExpansion:adjustments',[org(ctx),ctx.query.loanId||null,b],{});return serviceJson(ctx,{adjustments:rows});}

async function get_passbook_8(ctx){const b=branch(ctx,ctx.query.branchId); const {rows}=await repository.queryNamed('commercialExpansion:passbook',[org(ctx),ctx.params.memberId,b],{});if(!rows.length)return serviceResponse(404,{error:'Member not found or no passbook entries'},ctx);return serviceJson(ctx,{member:rows[0].member,entries:rows});}
async function post_notification_9(ctx){const p=notificationSchema.safeParse(ctx.body);if(!p.success)return serviceResponse(400,{error:'Invalid notification',details:p.error.issues},ctx);const d=p.data;if(!isOrganizationWide(ctx.auth)&&!d.memberId)return serviceResponse(403,{error:'Branch-scoped users must target a member'},ctx);if(d.memberId){const m=await repository.queryNamed('commercialExpansion:notificationMember',[org(ctx),d.memberId],{});if(!m.rows[0])return serviceResponse(404,{error:'Member not found'},ctx);if(!isOrganizationWide(ctx.auth))assertBranchAccess(ctx.auth,m.rows[0].branch_id);}const {rows}=await repository.queryNamed('commercialExpansion:notificationInsert',[org(ctx),d.memberId||null,d.channel,d.recipient,d.templateCode,JSON.stringify(d.payload),d.scheduledAt||new Date().toISOString(),ctx.auth.user_id],{});return serviceResponse(202,{notification:rows[0],provider:'outbox'},ctx);}
async function get_notifications_10(ctx){const b=branch(ctx,ctx.query.branchId);const {rows}=await repository.queryNamed('commercialExpansion:notifications',[org(ctx),Number(ctx.query.limit||100),b],{});return serviceJson(ctx,{notifications:rows});}

async function get_reports_11(ctx){const code=String(ctx.query.report||'summary');const b=branch(ctx,ctx.query.branchId);const map={summary:['commercialExpansion:operationalReport',[org(ctx),ctx.query.fromDate||null,ctx.query.toDate||null,b]],portfolio:['commercialExpansion:reportPortfolio',[org(ctx),b]],collection:['commercialExpansion:reportCollection',[org(ctx),ctx.query.fromDate||null,ctx.query.toDate||null,b]],overdue:['commercialExpansion:reportOverdue',[org(ctx),b]],branches:['commercialExpansion:reportBranches',[org(ctx),b]],collectors:['commercialExpansion:reportCollectors',[org(ctx),ctx.query.fromDate||null,ctx.query.toDate||null,b]],income_expense:['commercialExpansion:reportIncomeExpense',[org(ctx),b]]};if(!map[code])return serviceResponse(400,{error:'Unknown report code',available:Object.keys(map)},ctx);const [q,args]=map[code];const {rows}=await repository.queryNamed(q,args,{});return serviceJson(ctx,{reportCode:code,rows});}
async function get_mra_12(ctx){const b=branch(ctx,ctx.query.branchId); const {rows}=await repository.queryNamed('commercialExpansion:mraReport',[org(ctx),ctx.query.fromDate||null,ctx.query.toDate||null,b],{});return serviceJson(ctx,{report:rows[0]||{reportStandard:'MRA-oriented management report; regulatory submission format must be validated against current MRA templates'}});}
async function get_gl_accounts_13(ctx){const {rows}=await repository.queryNamed('commercialExpansion:glAccounts',[org(ctx)],{});return serviceJson(ctx,{accounts:rows});}
async function post_gl_journal_14(ctx){const p=journalSchema.safeParse(ctx.body);if(!p.success)return serviceResponse(400,{error:'Invalid journal',details:p.error.issues},ctx);const d=p.data;const debit=money(d.lines.reduce((s,x)=>s+x.debit,0)),credit=money(d.lines.reduce((s,x)=>s+x.credit,0));if(debit!==credit||debit<=0)return serviceResponse(400,{error:'Journal must balance: total debit must equal total credit'},ctx);const b=branch(ctx,d.branchId);const tx=await repository.begin();try{await tx.begin();const ownership=await tx.queryNamed('commercialExpansion:journalAccountsOwned',[org(ctx),d.lines.map(x=>x.accountId)],{});if(Number(ownership.rows[0]?.count||0)!==new Set(d.lines.map(x=>x.accountId)).size){await tx.rollback();return serviceResponse(400,{error:'One or more accounting accounts do not belong to this organization'},ctx);}const j=await tx.queryNamed('commercialExpansion:journalInsert',[org(ctx),b,d.entryDate,d.referenceType||null,d.referenceId||null,d.description,ctx.auth.user_id],{});for(const l of d.lines)await tx.queryNamed('commercialExpansion:journalLineInsert',[j.rows[0].id,l.accountId,l.debit,l.credit,l.description||null],{});await tx.commit();return serviceResponse(201,{journalId:j.rows[0].id,debit,credit},ctx);}catch(e){await tx.rollback();throw e;}finally{tx.release();}}
async function get_gl_summary_15(ctx){const b=branch(ctx,ctx.query.branchId); const {rows}=await repository.queryNamed('commercialExpansion:glSummary',[org(ctx),ctx.query.fromDate||null,ctx.query.toDate||null,b],{});return serviceJson(ctx,{accounts:rows});}
async function get_ops_16(ctx){const b=branch(ctx,ctx.query.branchId); const {rows}=await repository.queryNamed('commercialExpansion:ops',[org(ctx),b],{});return serviceJson(ctx,{monitoring:rows[0]||{}});}
async function calculate_product_17(ctx){
 const p=z.object({productId:z.string().uuid(),amount:z.coerce.number().positive(),installments:z.coerce.number().int().positive()}).safeParse(ctx.body);if(!p.success)return serviceResponse(400,{error:'Invalid calculation',details:p.error.issues},ctx);
 const {rows}=await repository.queryNamed('commercialExpansion:productGet',[org(ctx),p.data.productId],{});if(!rows[0])return serviceResponse(404,{error:'Product not found'},ctx);const x=rows[0];
 if(p.data.amount<x.min_amount||(x.max_amount!==null&&p.data.amount>x.max_amount))return serviceResponse(400,{error:'Amount is outside product limits'},ctx);if(p.data.installments<x.min_installments||(x.max_installments!==null&&p.data.installments>x.max_installments))return serviceResponse(400,{error:'Installment count is outside product limits'},ctx);
 try{return serviceJson(ctx,{product:x,calculation:calculateLoanProduct({amount:p.data.amount,installments:p.data.installments,interestRate:x.interest_rate,interestMethod:x.interest_method,frequency:x.frequency})});}catch(e){return serviceResponse(400,{error:e.message},ctx);}
}
module.exports={get_field_route_1,post_field_sync_2,get_field_sync_3,get_products_4,post_product_5,post_adjustment_6,get_adjustments_7,get_passbook_8,post_notification_9,get_notifications_10,get_reports_11,get_mra_12,get_gl_accounts_13,post_gl_journal_14,get_gl_summary_15,get_ops_16,calculate_product_17};
