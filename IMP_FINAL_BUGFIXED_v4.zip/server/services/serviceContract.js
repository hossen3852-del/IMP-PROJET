'use strict';

/**
 * Small common contract used by the production layers.
 * A service receives request-scoped context and delegates persistence to a
 * repository. Domain rules belong here rather than in browser code.
 */
function assertServiceContext(ctx) {
  if (!ctx || !ctx.auth || !ctx.auth.organization_id) {
    const error = new Error('Authenticated organization context is required');
    error.status = 401;
    throw error;
  }
  return ctx;
}

module.exports = { assertServiceContext };
