'use strict';

const { serviceResponse, serviceJson } = require('./serviceResult');


/**
 * Savings module (new — supports dashboard cards "মোট সঞ্চয়" and part of
 * "Current Balance" / "লোন").
 *
 * মোট সঞ্চয় = deposit + daily_deposit − withdrawal − installment_payment
 *
 * "installment_payment" is an internal transfer: a member's savings balance
 * pays down one of their own loans. It reduces this member's savings AND is
 * subtracted from that loan's outstanding balance in the Loan KPI — it is
 * never counted as fresh external collection.
 */

const { z } = require('zod');
const repository = require('../repositories');

const { isOrganizationWide, assertBranchAccess, enforceRequestedBranch } = require('../application/accessScope');

const TX_TYPES = ['deposit', 'daily_deposit', 'withdrawal', 'installment_payment'];

const createSchema = z.object({
  memberId: z.string().uuid(),
  transactionType: z.enum(TX_TYPES),
  amount: z.coerce.number().positive(),
  transactionDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'transactionDate must be YYYY-MM-DD'),
  loanId: z.string().uuid().nullable().optional(),
  branchId: z.string().uuid().nullable().optional(),
  description: z.string().trim().max(2000).optional().default('')
}).strict().superRefine((data, ctx) => {
  if (data.transactionType === 'installment_payment' && !data.loanId) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['loanId'], message: 'loanId is required for installment_payment transactions' });
  }
});

function money(v) { return Number(v); }

function toTx(r) {
  return {
    id: r.id,
    organizationId: r.organization_id,
    memberId: r.member_id,
    branchId: r.branch_id,
    loanId: r.loan_id,
    transactionType: r.transaction_type,
    amount: money(r.amount),
    transactionDate: r.transaction_date,
    description: r.description || '',
    createdBy: r.created_by,
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}

async function audit(tx, auth, action, entityId, metadata = {}) {
  await tx.queryNamed("savingsService.js:56:233", [auth.organization_id, auth.user_id, action, entityId, JSON.stringify(metadata)], {  });
}

/**
 * Org-wide (or single-member, if memberId given) savings summary — computed
 * live from PostgreSQL. Used by the "মোট সঞ্চয়" dashboard card and reused
 * by dashboard.js/capital.js for the Current Balance and Loan KPI figures.
 */
async function computeSavingsSummary(org, repo = repository, memberId = null, branchId = null) {
  const values = [org];
  if (branchId) values.push(branchId);
  if (memberId) {
    values.push(memberId);
  }
  const { rows } = await repo.queryNamed("savingsService.js:77:234", values, { hasBranch: Boolean(branchId), hasMember: Boolean(memberId) });
  const r = rows[0];
  const deposits = money(r.deposits);
  const dailyDeposits = money(r.daily_deposits);
  const withdrawals = money(r.withdrawals);
  const installmentPayments = money(r.installment_payments);
  return {
    deposits,
    dailyDeposits,
    withdrawals,
    installmentPayments,
    balance: deposits + dailyDeposits - withdrawals - installmentPayments
  };
}

;

;

;

;

module.exports.computeSavingsSummary = computeSavingsSummary;

async function get_summary_1(context) {
  context.cookies ||= [];

  try {
    const memberId = typeof context.query.memberId === 'string' && context.query.memberId ? context.query.memberId : null;
    const branchId = isOrganizationWide(context.auth) ? null : context.auth.branch_id;
    if (!isOrganizationWide(context.auth) && !branchId) return serviceResponse(403, { error: 'Your account is not assigned to a branch' }, context);
    const summary = await computeSavingsSummary(context.auth.organization_id, repository, memberId, branchId);
    return serviceJson(context, { summary });
  } catch (e) { throw e; }

}

async function get_transactions_2(context) {
  context.cookies ||= [];

  try {
    const org = context.auth.organization_id;
    const values = [org];
    const filters = [];
    if (!isOrganizationWide(context.auth)) {
      if (!context.auth.branch_id) filters.push('denyAll');
      else { values.push(context.auth.branch_id); filters.push('branchId'); }
    }
    if (typeof context.query.memberId === 'string' && context.query.memberId) { values.push(context.query.memberId); filters.push('memberId'); }
    if (typeof context.query.transactionType === 'string' && context.query.transactionType) { values.push(context.query.transactionType); filters.push('transactionType'); }
    if (typeof context.query.fromDate === 'string' && context.query.fromDate) { values.push(context.query.fromDate); filters.push('fromDate'); }
    if (typeof context.query.toDate === 'string' && context.query.toDate) { values.push(context.query.toDate); filters.push('toDate'); }

    const limit = Math.min(Math.max(parseInt(context.query.limit || '100', 10) || 100, 1), 500);
    const offset = Math.max(parseInt(context.query.offset || '0', 10) || 0, 0);
    values.push(limit, offset);

    const { rows } = await repository.queryNamed("savingsService.js:29:225", values, { filters });

    return serviceJson(context, { transactions: rows.map(toTx), pagination: { limit, offset, returned: rows.length } });
  } catch (e) { throw e; }

}

async function post_transactions_3(context) {
  context.cookies ||= [];

  const parsed = createSchema.safeParse(context.body);
  if (!parsed.success) return serviceResponse(400, { error: 'Invalid savings transaction', details: parsed.error.issues }, context);
  const data = parsed.data;
  const org = context.auth.organization_id;

  const tx = await repository.begin();
  try {
    await tx.begin();

    const member = await tx.queryNamed("savingsService.js:11:226", [data.memberId, org], {  });
    if (!member.rows[0]) {
      await tx.rollback();
      return serviceResponse(400, { error: 'Member does not belong to this organization' }, context);
    }
    const effectiveBranchId = isOrganizationWide(context.auth) ? (member.rows[0].branch_id || null) : context.auth.branch_id;
    if (data.branchId && String(data.branchId) !== String(member.rows[0].branch_id)) { await tx.rollback(); return serviceResponse(400, {error:'Transaction branch must match member branch'}, context); }
    if (!isOrganizationWide(context.auth) && (!effectiveBranchId || String(member.rows[0].branch_id) !== String(effectiveBranchId))) {
      await tx.rollback(); return serviceResponse(403, { error: 'Member is outside your branch' }, context);
    }

    if (effectiveBranchId) {
      const branch = await tx.queryNamed("savingsService.js:23:227", [effectiveBranchId, org], {  });
      if (!branch.rows[0]) {
        await tx.rollback();
        return serviceResponse(400, { error: 'Branch does not belong to this organization' }, context);
      }
    }

    let loanRow = null;
    if (data.loanId) {
      const loan = await tx.queryNamed("savingsService.js:31:228", [data.loanId, org, data.memberId], {  });
      if (!loan.rows[0]) {
        await tx.rollback();
        return serviceResponse(400, { error: 'Loan does not belong to this member/organization' }, context);
      }
      loanRow = loan.rows[0];
      if (data.transactionType === 'installment_payment' && !['disbursed', 'active'].includes(loanRow.status)) {
        await tx.rollback();
        return serviceResponse(409, { error: 'This loan is not active — it has no installment balance to pay from savings' }, context);
      }
    }

    if (data.transactionType === 'withdrawal' || data.transactionType === 'installment_payment') {
      const current = await computeSavingsSummary(org, tx, data.memberId, effectiveBranchId);
      if (current.balance < data.amount) {
        await tx.rollback();
        return serviceResponse(400, { error: 'Insufficient savings balance for this member', currentBalance: current.balance }, context);
      }
    }

    // An "installment_payment" savings transaction moves money out of the
    // member's savings balance and into one of their own loans. Recording
    // only the savings side (below) would leave the loan's own schedule
    // untouched — still showing the installment as due, and risking the
    // member being asked to pay it again on the next route sheet. So this
    // allocates the amount against that loan's outstanding installments
    // (oldest first) exactly like a normal collected payment does.
    if (data.transactionType === 'installment_payment') {
      const schedules = await tx.queryNamed("collectionsService.js:532:66", [org, data.loanId], {  });
      const totalOutstanding = schedules.rows.reduce((sum, s) => sum + Number(s.outstanding_amount), 0);
      if (data.amount > totalOutstanding + 0.009) {
        await tx.rollback();
        return serviceResponse(409, { error: 'Amount exceeds this loan\'s outstanding balance', outstanding: Math.round(totalOutstanding * 100) / 100 }, context);
      }

      const seq = await tx.queryNamed("collectionsService.js:444:64", [], {  });
      const paymentNumber = `PAY-${data.transactionDate.slice(0, 10).replace(/-/g, '')}-${String(seq.rows[0].n).padStart(8, '0')}`;

      const paymentIns = await tx.queryNamed("collectionsService.js:466:65", [
        org, loanRow.branch_id, data.memberId, data.loanId, paymentNumber, data.amount,
        data.transactionDate, 'other', context.auth.user_id,
        data.description ? `${data.description} (paid from savings)` : 'Paid from savings balance',
        null
      ], {  });
      const paymentId = paymentIns.rows[0].id;

      let remaining = data.amount;
      for (const s of schedules.rows) {
        if (remaining <= 0) break;
        const installmentOutstanding = Number(s.outstanding_amount);
        const a = Math.min(remaining, installmentOutstanding);
        if (a <= 0) continue;
        remaining = Number((remaining - a).toFixed(2));

        await tx.queryNamed("collectionsService.js:606:67", [org, paymentId, data.loanId, s.id, a], {  });

        const paid = Number(s.paid_amount) + a;
        const out = Math.max(0, installmentOutstanding - a);
        const st = out === 0 ? 'paid' : (paid > 0 ? 'partial' : s.status);
        await tx.queryNamed("collectionsService.js:659:68", [paid, out, st, data.transactionDate, s.id, org], {  });
      }
    }

    const { rows } = await tx.queryNamed("savingsService.js:49:229", [org, data.memberId, effectiveBranchId, data.loanId || null, data.transactionType, data.amount, data.transactionDate, data.description, context.auth.user_id], {  });

    await audit(tx, context.auth, 'savings_transaction.create', rows[0].id, { transactionType: data.transactionType, amount: data.amount, memberId: data.memberId });
    await tx.commit();
    return serviceResponse(201, { transaction: toTx(rows[0]) }, context);
  } catch (e) {
    await tx.rollback();
    throw e;
  } finally {
    tx.release();
  }

}

async function delete_transactions_id_4(context) {
  context.cookies ||= [];

  const tx = await repository.begin();
  try {
    await tx.begin();
    const org = context.auth.organization_id;
    const existing = await tx.queryNamed("savingsService.js:6:230", [context.params.id, org], {  });
    if (existing.rows[0]) {
      await tx.queryNamed("savingsService.js:11:231", [existing.rows[0].member_id, org], {  });
    }
    if (!existing.rows[0]) {
      await tx.rollback();
      return serviceResponse(404, { error: 'Savings transaction not found' }, context);
    }
    if (!isOrganizationWide(context.auth)) assertBranchAccess(context.auth, existing.rows[0].branch_id);
    await tx.queryNamed("savingsService.js:18:232", [context.params.id, org], {  });
    await audit(tx, context.auth, 'savings_transaction.delete', context.params.id, {
      transactionType: existing.rows[0].transaction_type,
      amount: money(existing.rows[0].amount),
      memberId: existing.rows[0].member_id
    });
    await tx.commit();
    return serviceResponse(204, null, context);
  } catch (e) {
    await tx.rollback();
    throw e;
  } finally {
    tx.release();
  }

}

module.exports = { get_summary_1, get_transactions_2, post_transactions_3, delete_transactions_id_4, computeSavingsSummary };
