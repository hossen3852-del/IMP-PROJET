
const { serviceResponse, serviceJson, setResponseCookie, clearResponseCookie } = require('./serviceResult');
const argon2 = require('argon2');
const crypto = require('node:crypto');
const { z } = require('zod');
const repository = require('../repositories');

const env = require('../config/env');
const { createSessionToken, hashSessionToken } = require('../utils/sessionToken');
const emailSchema = z.string().trim().email().max(254);
const passwordSchema = z.string().min(8).max(200);

const loginSchema = z.object({
  email: emailSchema,
  password: passwordSchema
});

const registerSchema = z.object({
  name: z.string().trim().min(2).max(200),
  organizationName: z.string().trim().min(2).max(200),
  companyCode: z.string().trim().regex(/^[A-Za-z0-9][A-Za-z0-9_-]{2,79}$/),
  companyType: z.string().trim().min(2).max(120),
  address: z.string().trim().min(2).max(1000),
  phone: z.string().trim().min(5).max(50),
  country: z.string().trim().min(2).max(120),
  currency: z.string().trim().regex(/^[A-Za-z]{3}$/).transform(v => v.toUpperCase()),
  workingDays: z.array(z.string().trim().min(2).max(30)).min(1).max(7),
  officeStartTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/),
  officeEndTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/),
  timezone: z.string().trim().min(1).max(80),
  email: emailSchema,
  password: passwordSchema
});

const resetRequestSchema = z.object({ email: emailSchema });
const resetPasswordSchema = z.object({
  token: z.string().trim().min(20).max(200),
  password: passwordSchema
});

const adminCredentialsSchema = z.object({
  currentPassword: passwordSchema,
  email: emailSchema.optional(),
  newPassword: passwordSchema.optional()
}).superRefine((value, ctx) => {
  if (!value.email && !value.newPassword) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['email'], message: 'Email or new password is required' });
  }
});

function normalizeEmail(email) {
  return email.trim().toLowerCase();
}

function publicUser(row) {
  return {
    id: row.id,
    userCode: row.user_code || null,
    name: row.name || '',
    email: row.email,
    role: row.role_code || row.role,
    roleId: row.role_id || null,
    permissions: Array.isArray(row.permissions) ? row.permissions : [],
    organizationId: row.organization_id,
    branchId: row.branch_id || null,
    status: row.active === false ? 'inactive' : 'active'
  };
}

function setSessionCookie(context, token) {
  setResponseCookie(context, env.cookieName, token, {
    httpOnly: true,
    secure: env.nodeEnv === 'production',
    sameSite: 'lax',
    maxAge: env.sessionTtlSeconds * 1000,
    path: '/'
  });
}

function clearSessionCookie(context) {
  clearResponseCookie(context, env.cookieName, {
    httpOnly: true,
    secure: env.nodeEnv === 'production',
    sameSite: 'lax',
    path: '/'
  });
}

async function createSession(tx, user) {
  const raw = createSessionToken();
  const hash = hashSessionToken(raw);
  await tx.queryNamed("authService.js:84:25", [crypto.randomUUID(), user.id, user.organization_id, hash, env.sessionTtlSeconds], {  });
  return raw;
}


async function sendPasswordResetEmail({ to, token }) {
  if (!env.emailWebhookUrl) {
    if (env.isProduction) throw new Error('Password reset email service is not configured');
    return;
  }
  const base = env.passwordResetBaseUrl || '';
  const link = `${base}${base.includes('?') ? '&' : '?'}token=${encodeURIComponent(token)}`;
  const response = await fetch(env.emailWebhookUrl, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      from: env.emailFrom,
      to,
      subject: 'IMP password reset',
      text: `Use this link to reset your IMP password: ${link}`,
      resetUrl: link
    })
  });
  if (!response.ok) throw new Error(`Password reset email delivery failed (${response.status})`);
}

;

;

;

;

;

;

;


async function post_register_1(context) {
  context.cookies ||= [];

  try {
    const parsed = registerSchema.safeParse(context.body);
    if (!parsed.success) return serviceResponse(400, { error: 'Invalid registration data' }, context);

    const data = parsed.data;
    const email = normalizeEmail(data.email);
    const tx = await repository.begin();

    try {
      await tx.begin();

      const duplicate = await tx.queryNamed("authService.js:13:1", [email], {  });
      if (duplicate.rows[0]) {
        await tx.rollback();
        return serviceResponse(409, { error: 'An account with this email already exists.' }, context);
      }

      const companyDuplicate = await tx.queryNamed("authService.js:22:2", [data.companyCode], {  });
      if (companyDuplicate.rows[0]) {
        await tx.rollback();
        return serviceResponse(409, { error: 'Company code already exists.' }, context);
      }

      const organization = await tx.queryNamed("authService.js:31:3", [data.organizationName, data.companyCode, data.companyType, data.address, data.phone, email, data.country, data.currency, JSON.stringify(data.workingDays), data.officeStartTime, data.officeEndTime, data.timezone], {  });

      const passwordHash = await argon2.hash(data.password, { type: argon2.argon2id });
      await tx.queryNamed("authService.js:39:4", [organization.rows[0].id], {  });
      await tx.queryNamed("authService.js:grant_v617", [organization.rows[0].id], {  });
      const roleResult = await tx.queryNamed("authService.js:40:5", [organization.rows[0].id], {  });
      if (!roleResult.rows[0]) throw new Error('Organization admin role is not configured');

      const userResult = await tx.queryNamed("authService.js:48:6", [organization.rows[0].id, `ADM-${crypto.randomUUID().replace(/-/g,'').slice(0,10).toUpperCase()}`, email, passwordHash, roleResult.rows[0].code, roleResult.rows[0].id, data.name], {  });

      const user = userResult.rows[0];
      const sessionToken = await createSession(tx, user);

      await tx.queryNamed("authService.js:58:7", [user.organization_id, user.id, JSON.stringify({ email: user.email })], {  });

      await tx.commit();
      const permissionsResult = await repository.queryNamed("authService.js:65:8", [user.role_id], {  });
      setSessionCookie(context, sessionToken);

      return serviceResponse(201, {
        user: publicUser({ ...user, permissions: permissionsResult.rows.map(row => row.code) }),
        organization: organization.rows[0]
      }, context);
    } catch (error) {
      await tx.rollback();
      throw error;
    } finally {
      tx.release();
    }
  } catch (error) {
    throw error;
  }

}

async function post_login_2(context) {
  context.cookies ||= [];

  try {
    const parsed = loginSchema.safeParse(context.body);
    if (!parsed.success) return serviceResponse(400, { error: 'Invalid credentials format' }, context);

    const email = normalizeEmail(parsed.data.email);
    const { password } = parsed.data;
    const { rows } = await repository.queryNamed("authService.js:8:9", [email], {  });
    const user = rows[0];

    if (!user || !user.active) return serviceResponse(401, { error: 'Invalid email or password' }, context);

    const valid = await argon2.verify(user.password_hash, password);
    if (!valid) return serviceResponse(401, { error: 'Invalid email or password' }, context);

    const tx = await repository.begin();
    try {
      await tx.begin();
      const sessionToken = await createSession(tx, user);
      await tx.queryNamed("authService.js:24:10", [user.id], {  });
      await tx.queryNamed("authService.js:28:11", [user.organization_id, user.id, JSON.stringify({ email: user.email })], {  });
      await tx.commit();
      const permissionsResult = await repository.queryNamed("authService.js:34:12", [user.role_id, user.organization_id], {  });
      setSessionCookie(context, sessionToken);
      const orgResult = await repository.queryNamed("authService.js:44:13", [user.organization_id, user.branch_id], {  });
      const orgRow = orgResult.rows[0] || {};
      return serviceJson(context, {
        user: publicUser({
          ...user,
          permissions: permissionsResult.rows.map(row => row.code)
        }),
        organization: {
          id: orgRow.id || user.organization_id,
          name: orgRow.name || '',
          status: orgRow.status || 'active',
          branch: orgRow.branch_id ? { id: orgRow.branch_id, name: orgRow.branch_name || '' } : null
        }
      });
    } catch (error) {
      await tx.rollback();
      throw error;
    } finally {
      tx.release();
    }
  } catch (error) {
    throw error;
  }

}

async function get_me_3(context) {
  context.cookies ||= [];

  try {
    const { rows } = await repository.queryNamed("authService.js:3:14", [context.auth.user_id], {  });
    if (!rows[0] || !rows[0].active || rows[0].organization_status !== 'active') {
      return serviceResponse(401, { error: 'Authentication required' }, context);
    }
    const user = { ...publicUser({ ...rows[0], permissions: context.auth.permissions }), roleName: rows[0].role_name || rows[0].role_code || '' };
    return serviceJson(context, { user, organization: {
      id: rows[0].organization_id,
      name: rows[0].organization_name,
      status: rows[0].organization_status,
      branch: rows[0].branch_id ? { id: rows[0].branch_id, name: rows[0].branch_name || '' } : null
    }});
  } catch (error) {
    throw error;
  }

}

async function post_logout_4(context) {
  context.cookies ||= [];

  try {
    const token = context.cookies?.[env.cookieName];
    if (token) {
      await repository.queryNamed("authService.js:5:15", [hashSessionToken(token)], {  });
    }
    clearSessionCookie(context);
    return serviceResponse(204, null, context);
  } catch (error) {
    throw error;
  }

}

async function post_logout_all_5(context) {
  context.cookies ||= [];

  try {
    await repository.queryNamed("authService.js:3:16", [context.auth.user_id], {  });
    clearSessionCookie(context);
    return serviceResponse(204, null, context);
  } catch (error) {
    throw error;
  }

}

async function put_admin_credentials_8(context) {
  context.cookies ||= [];

  try {
    if (!context.auth || context.auth.role_code !== 'organization_admin' || context.auth.role_is_system === true) {
      return serviceResponse(403, { error: 'Only the Organization Admin can change these credentials.' }, context);
    }

    const parsed = adminCredentialsSchema.safeParse(context.body);
    if (!parsed.success) return serviceResponse(400, { error: 'Enter the current password and at least one new credential.' }, context);

    const currentPassword = parsed.data.currentPassword;
    const nextEmail = parsed.data.email ? normalizeEmail(parsed.data.email) : null;
    const nextPassword = parsed.data.newPassword || null;

    const tx = await repository.begin();
    try {
      await tx.begin();
      const current = await tx.queryNamed('authService.js:admin_credentials_user', [context.auth.user_id, context.auth.organization_id], {});
      const user = current.rows[0];
      if (!user || !user.active || user.role_code !== 'organization_admin') {
        await tx.rollback();
        return serviceResponse(403, { error: 'Organization Admin account is required.' }, context);
      }

      const valid = await argon2.verify(user.password_hash, currentPassword);
      if (!valid) {
        await tx.rollback();
        return serviceResponse(401, { error: 'Current password is incorrect.' }, context);
      }

      if (nextEmail && nextEmail !== normalizeEmail(user.email)) {
        const duplicate = await tx.queryNamed('authService.js:admin_credentials_duplicate_email', [nextEmail, user.id], {});
        if (duplicate.rows[0]) {
          await tx.rollback();
          return serviceResponse(409, { error: 'This Gmail/email is already in use.' }, context);
        }
      }

      const passwordHash = nextPassword ? await argon2.hash(nextPassword, { type: argon2.argon2id }) : null;
      const updated = await tx.queryNamed('authService.js:admin_credentials_update', [nextEmail || user.email, passwordHash, user.id], {});
      const updatedUser = updated.rows[0];

      await tx.queryNamed('authService.js:admin_credentials_revoke_sessions', [user.id], {});
      const sessionToken = await createSession(tx, { id: user.id, organization_id: user.organization_id });

      const changed = [];
      if (nextEmail && nextEmail !== normalizeEmail(user.email)) changed.push('email');
      if (nextPassword) changed.push('password');
      await tx.queryNamed('authService.js:admin_credentials_audit', [user.organization_id, user.id, JSON.stringify({ changed })], {});
      await tx.commit();
      setSessionCookie(context, sessionToken);

      return serviceJson(context, {
        success: true,
        message: 'Organization Admin login credentials updated successfully.',
        user: { id: updatedUser.id, email: updatedUser.email }
      });
    } catch (error) {
      await tx.rollback();
      throw error;
    } finally {
      tx.release();
    }
  } catch (error) {
    throw error;
  }

}

async function post_password_reset_request_6(context) {
  context.cookies ||= [];

  try {
    const parsed = resetRequestSchema.safeParse(context.body);
    if (!parsed.success) return serviceResponse(400, { error: 'Invalid email' }, context);

    const email = normalizeEmail(parsed.data.email);
    const { rows } = await repository.queryNamed("authService.js:7:17", [email], {  });

    let devToken = null;
    if (rows[0]) {
      const rawToken = createSessionToken();
      const tokenHash = hashSessionToken(rawToken);
      await repository.queryNamed("authService.js:16:18", [rows[0].id], {  });
      await repository.queryNamed("authService.js:21:19", [rows[0].id, tokenHash], {  });

      try {
        await sendPasswordResetEmail({ to: rows[0].email, token: rawToken });
      } catch (mailError) {
        // Never reveal whether the email exists. Log failure and still return
        // the generic success response (token remains valid for confirm if mail later works).
        console.error('[IMP] password reset mail failed:', mailError && mailError.message ? mailError.message : mailError);
      }
      if (env.nodeEnv !== 'production') devToken = rawToken;
      console.info('[IMP] Password reset requested for user:', rows[0].id);
      if (devToken) console.info('[IMP] DEV reset token:', devToken);
    }

    const response = {
      success: true,
      message: 'If the account exists, a password reset link has been created.'
    };
    if (devToken) response.devToken = devToken;
    return serviceJson(context, response);
  } catch (error) {
    throw error;
  }

}

async function post_password_reset_confirm_7(context) {
  context.cookies ||= [];

  try {
    const parsed = resetPasswordSchema.safeParse(context.body);
    if (!parsed.success) return serviceResponse(400, { error: 'Invalid password reset data' }, context);

    const { token, password } = parsed.data;
    const tokenHash = hashSessionToken(token);
    const tx = await repository.begin();

    try {
      await tx.begin();
      const { rows } = await tx.queryNamed("authService.js:12:20", [tokenHash], {  });
      if (!rows[0]) {
        await tx.rollback();
        return serviceResponse(400, { error: 'Invalid or expired reset token' }, context);
      }

      const passwordHash = await argon2.hash(password, { type: argon2.argon2id });
      await tx.queryNamed("authService.js:26:21", [passwordHash, rows[0].user_id], {  });
      await tx.queryNamed("authService.js:30:22", [rows[0].id], {  });
      await tx.queryNamed("authService.js:34:23", [rows[0].user_id], {  });
      await tx.queryNamed("authService.js:38:24", [rows[0].organization_id, rows[0].user_id], {  });
      await tx.commit();
      clearSessionCookie(context);
      return serviceJson(context, { success: true });
    } catch (error) {
      await tx.rollback();
      throw error;
    } finally {
      tx.release();
    }
  } catch (error) {
    throw error;
  }

}

module.exports = { post_register_1, post_login_2, get_me_3, post_logout_4, post_logout_all_5, put_admin_credentials_8, post_password_reset_request_6, post_password_reset_confirm_7 };
