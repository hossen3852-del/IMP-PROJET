
const { serviceResponse, serviceJson } = require('./serviceResult');
const { z } = require('zod');
const repository = require('../repositories');
const { isOrganizationWide, assertBranchAccess } = require('../application/accessScope');
// ============================================================
// CONSTANTS
// ============================================================

const STATUSES = [
  "draft",
  "pending",
  "approved",
  "disbursed",
  "active",
  "completed",
  "cancelled",
  "rejected",
];

const TRANSITIONS = Object.freeze({
  draft: ["pending", "cancelled"],
  pending: ["approved", "rejected", "cancelled"],
  approved: ["disbursed", "cancelled"],
  disbursed: ["active"],
  active: ["completed", "cancelled"],
  completed: [],
  cancelled: [],
  rejected: [],
});

// ============================================================
// GLOBAL AUTH / TENANT / BRANCH ACCESS
// ============================================================

;

// ============================================================
// CREATE SCHEMA
// ============================================================

const createSchema = z
  .object({
    memberId: z.string().uuid(),

    renewalOfLoanId: z.string().uuid().nullable().optional(),
    loanSourceType: z.enum(['new','previous_loan']).optional().default('new'),
    legacyPaidAmount: z.coerce.number().min(0).optional().default(0),
    legacyPaidInstallments: z.coerce.number().int().min(0).optional().default(0),

    branchId: z.string().uuid().nullable().optional(),

    loanType: z.string().trim().min(1).max(100),

    loanPurpose: z.string().trim().max(5000).optional().default(""),

    loanAmount: z.coerce.number().positive(),

    interestRate: z.coerce.number().min(0).max(1000),

    numberOfInstallments: z.coerce.number().int().positive().max(10000),

    installmentAmount: z.coerce.number().positive(),

    savingsAmount: z.coerce.number().min(0).default(0),

    depositAmount: z.coerce.number().min(0).default(0),

    installmentFrequency: z.enum(["daily", "weekly", "biweekly", "monthly"]),

    startDate: z.string().date(),

    firstInstallmentDate: z.string().date().nullable().optional(),

    applicationDate: z.string().datetime().nullable().optional(),
  })
  .strict();

// ============================================================
// UPDATE SCHEMA
// ============================================================

const updateSchema = z
  .object({
    loanType: z.string().trim().min(1).max(100).optional(),

    loanPurpose: z.string().trim().max(5000).optional(),

    loanAmount: z.coerce.number().positive().optional(),

    interestRate: z.coerce.number().min(0).max(1000).optional(),

    numberOfInstallments: z.coerce
      .number()
      .int()
      .positive()
      .max(10000)
      .optional(),

    installmentAmount: z.coerce.number().positive().optional(),

    installmentFrequency: z.enum(["daily", "weekly", "biweekly", "monthly"]).optional(),

    startDate: z.string().date().optional(),

    firstInstallmentDate: z.string().date().nullable().optional(),

    branchId: z.string().uuid().nullable().optional(),
  })
  .strict();


// ============================================================
// CONVERT DATABASE ROW → API OBJECT
// ============================================================

function toLoan(row) {
  if (!row) {
    return null;
  }

  return {
    id: row.id,

    loanId: row.id,

    organizationId: row.organization_id,

    branchId: row.branch_id,

    memberId: row.member_id,

    renewalOfLoanId: row.renewal_of_loan_id || null,
    loanSourceType: row.loan_source_type || 'new',
    legacyPaidAmount: Number(row.legacy_original_paid_amount || 0),
    legacyPaidInstallments: Number(row.legacy_original_paid_installments || 0),

    loanNumber: row.loan_number,

    loanType: row.loan_type,

    loanPurpose: row.loan_purpose || "",

    loanAmount: Number(row.loan_amount || 0),

    interestRate: Number(row.interest_rate || 0),

    interestAmount: Number(row.interest_amount || 0),

    totalPayable: Number(row.total_payable || 0),

    installmentAmount: Number(row.installment_amount || 0),

    savingsAmount: Number(row.savings_amount || 0),

    depositAmount: Number(row.deposit_amount || 0),

    insuranceRate: 2,

    insuranceAmount: Number(row.loan_amount || 0) * 0.02,

    numberOfInstallments: Number(row.number_of_installments || 0),

    installmentCount: Number(row.number_of_installments || 0),

    installmentFrequency: row.installment_frequency,

    repaymentFrequency: row.installment_frequency,

    startDate: row.start_date,

    firstInstallmentDate: row.first_installment_date,

    applicationDate: row.application_date,

    approvalDate: row.approval_date,

    disbursedAt: row.disbursed_at,

    disbursedAmount: Number(row.disbursed_amount || 0),

    outstandingAmount: Number(row.outstanding_amount ?? row.total_payable ?? 0),

    status: row.status,

    createdBy: row.created_by,

    approvedBy: row.approved_by,

    createdAt: row.created_at,

    updatedAt: row.updated_at,

    memberCode: row.member_code || "",

    memberName: row.member_name || "",
  };
}

// ============================================================
// SERVER-SIDE LOAN CALCULATION
// ============================================================

function calculateLoanValues(loanAmount, interestRate, numberOfInstallments, manualInstallmentAmount) {
  const amount = Number(loanAmount);

  const rate = Number(interestRate);

  const count = Number(numberOfInstallments);
  const manualInstallment = Number(manualInstallmentAmount);

  if (!Number.isFinite(amount) || amount <= 0) {
    throw new Error("Loan amount must be greater than zero");
  }

  if (!Number.isFinite(rate) || rate < 0) {
    throw new Error("Interest rate cannot be negative");
  }

  if (!Number.isInteger(count) || count <= 0) {
    throw new Error("Number of installments must be greater than zero");
  }

  // ----------------------------------------------------------
  // Interest Amount
  // loanAmount × interestRate ÷ 100
  // ----------------------------------------------------------

  const interestAmount = Math.round(((amount * rate) / 100) * 100) / 100;

  // ----------------------------------------------------------
  // Total Payable
  // loanAmount + interestAmount
  // ----------------------------------------------------------

  const totalPayable = Math.round((amount + interestAmount) * 100) / 100;

  // ----------------------------------------------------------
  // Installment Amount
  // ----------------------------------------------------------
  // This is intentionally MANUAL. The collector/loan officer
  // decides the recurring installment amount; the final scheduled
  // installment may be adjusted by the scheduler to reconcile the
  // calculated total payable.

  if (!Number.isFinite(manualInstallment) || manualInstallment <= 0) {
    throw new Error("Installment amount must be entered manually");
  }

  if (manualInstallment > totalPayable + 0.01) {
    throw new Error("Installment amount cannot exceed total payable");
  }

  // The disbursement scheduler charges `manualInstallment` for every
  // installment except the last (which absorbs the remainder against
  // totalPayable). If manualInstallment × (count - 1) already exceeds
  // totalPayable, the last installment would be clamped to 0 while the
  // borrower is still billed more than totalPayable across the earlier
  // installments — reject this combination up front instead of letting a
  // broken schedule get generated at disbursement time.
  if (count > 1 && manualInstallment * (count - 1) > totalPayable + 0.01) {
    throw new Error(
      "Installment amount is too high for the number of installments — it would overcollect before the schedule finishes. Lower the installment amount or reduce the number of installments."
    );
  }

  const installmentAmount = Math.round(manualInstallment * 100) / 100;

  const totalInstallmentRepayment = totalPayable;

  return {
    loanAmount: amount,

    interestRate: rate,

    interestAmount: interestAmount,

    totalPayable: totalPayable,

    installmentAmount: installmentAmount,

    totalInstallmentRepayment: totalInstallmentRepayment,
  };
}


// ============================================================
// INSTALLMENT DATE HELPER
// ============================================================
function loanAddPeriod(date, frequency, n, skipFriday = true) {
  const [y,m,d]=String(date).slice(0,10).split('-').map(Number);
  const dt=new Date(Date.UTC(y,m-1,d));
  const advancePastFriday = () => { if (skipFriday && dt.getUTCDay() === 5) dt.setUTCDate(dt.getUTCDate()+1); };
  if(frequency==='daily'){
    let left=Math.max(0,Number(n)||0);
    while(left>0){ dt.setUTCDate(dt.getUTCDate()+1); if(dt.getUTCDay()!==5) left--; }
    advancePastFriday();
    return dt.toISOString().slice(0,10);
  }
  if(frequency==='weekly'||frequency==='biweekly'){
    dt.setUTCDate(dt.getUTCDate()+n*(frequency==='weekly'?7:14));
    advancePastFriday();
    return dt.toISOString().slice(0,10);
  }
  const target=m-1+n,ty=y+Math.floor(target/12),tm=((target%12)+12)%12,last=new Date(Date.UTC(ty,tm+1,0)).getUTCDate();
  const out=new Date(Date.UTC(ty,tm,Math.min(d,last)));
  if(skipFriday && out.getUTCDay()===5) out.setUTCDate(out.getUTCDate()+1);
  return out.toISOString().slice(0,10);
}

// ============================================================
// ASSERT BRANCH
// ============================================================

async function assertBranch(tx, organizationId, branchId) {
  if (!branchId) {
    return;
  }

  const { rows } = await tx.queryNamed("loansService.js:293:122", [branchId, organizationId], {  });

  if (!rows[0]) {
    const e = new Error(
      "Branch not found or does not belong to this organization",
    );

    e.status = 400;

    throw e;
  }
}

// ============================================================
// ASSERT MEMBER
// ============================================================

async function assertMember(tx, organizationId, memberId) {
  const { rows } = await tx.queryNamed("loansService.js:320:123", [memberId, organizationId], {  });

  if (!rows[0]) {
    const e = new Error(
      "Member not found or does not belong to this organization",
    );

    e.status = 400;

    throw e;
  }

  return rows[0];
}

// ============================================================
// AUDIT LOG
// ============================================================

async function writeAudit(tx, auth, action, id, metadata = {}) {
  await tx.queryNamed("loansService.js:349:124", [auth.organization_id, auth.user_id, action, id, JSON.stringify(metadata)], {  });
}

// ============================================================
// GET ALL LOANS
// ============================================================

;

// ============================================================
// CREATE LOAN
// ============================================================

;

// ============================================================
// GET SINGLE LOAN
// ============================================================

;

// ============================================================
// UPDATE LOAN
// ============================================================

;

// ============================================================
// APPROVE
// ============================================================

;

// ============================================================
// DISBURSE
// ============================================================

;

// ============================================================
// CHANGE STATUS
// ============================================================

;

// ============================================================
// LOAN STATUS TRANSITION
// ============================================================

async function transition(context, target, auditAction, options = {}) {
  const org = context.auth.organization_id;

  const tx = await repository.begin();

  try {
    await tx.begin();

    const current = await tx.queryNamed("loansService.js:426:125", [context.params.id, org], {  });

    if (!current.rows[0]) {
      await tx.rollback();

      return serviceResponse(404, {
        error: "Loan not found",
      }, context);
    }

    const from = current.rows[0].status;

    if (!TRANSITIONS[from].includes(target)) {
      await tx.rollback();

      return serviceResponse(409, {
        error: `Invalid loan transition: ${from} -> ${target}`,
      }, context);
    }

    const values = [target, context.params.id, org];
    if (target === "approved") values.push(context.auth.user_id);
    await tx.queryNamed("loansService.js:483:126", values, { target });

    if (target === "disbursed") {
      const loanRow = await tx.queryNamed("loansService.js:486:127", [context.params.id, org], {  });
      const lr = loanRow.rows[0];
      if (!lr) throw new Error("Loan not found after disbursement update");

      // Insurance is a fixed business rule: Loan Amount × 2%.
      const insurance = Math.round((Number(lr.loan_amount || 0) * 0.02) * 100) / 100;
      if (insurance > 0) {
        const ins = await tx.queryNamed("loansService.js:493:128", [
          org, lr.member_id, lr.branch_id, context.params.id, insurance,
          `Loan disbursement insurance (2%) — ${context.params.id}`,
          context.auth.user_id
        ], {  });
        await tx.queryNamed("loansService.js:500:129", [
          org, context.auth.user_id, ins.rows[0].id,
          JSON.stringify({ memberId: lr.member_id, loanId: context.params.id, amount: insurance, rate: 2, source: 'loan_disbursement' })
        ], {  });
      }

      // Optional one-time opening deposit entered on Add Loan.
      const openingDeposit = Number(lr.deposit_amount || 0);
      if (openingDeposit > 0) {
        await tx.queryNamed("loansService.js:disbursement:openingDeposit", [
          org, lr.member_id, lr.branch_id, context.params.id, openingDeposit,
          `Opening deposit at loan disbursement — ${context.params.id}`,
          context.auth.user_id
        ], {});
      }

      // Generate the installment schedule automatically on disbursement.
      const existingSchedule = await tx.queryNamed("installmentsService.js:11:98", [context.params.id, org], {});
      if (!existingSchedule.rows[0]) {
        const full = await tx.queryNamed("loansService.js:disbursement:loanSchedule", [context.params.id, org], {});
        const loan = full.rows[0];
        const count = Number(loan.number_of_installments);
        const total = Number(loan.total_payable);
        const base = Number(loan.installment_amount);
        const firstDate = loan.first_installment_date || loan.start_date;
        const scheduleCfgResult = await tx.queryNamed("loansService.js:disbursement:loanScheduleConfig", [org], {});
        const scheduleCfg = scheduleCfgResult.rows[0]?.setting_value || {};
        const skipFriday = scheduleCfg.skipFriday !== false;
        if (count > 0 && base > 0 && firstDate) {
          for (let n = 1; n <= count; n++) {
            const amount = n === count
              ? Math.max(0, Math.round((total - base * (count - 1)) * 100) / 100)
              : base;
            await tx.queryNamed("installmentsService.js:18:99", [
              org, loan.id, n,
              loanAddPeriod(firstDate, loan.installment_frequency, n - 1, skipFriday),
              amount
            ], {});
          }
        }
      }
    }

    await writeAudit(tx, context.auth, auditAction, context.params.id, {
      from,
      to: target,
      insuranceAmount: target === "disbursed"
        ? Math.round((Number(current.rows[0].loan_amount || 0) * 0.02) * 100) / 100
        : 0,
    });

    const loan = await tx.queryNamed("loansService.js:513:130", [context.params.id, org], {});

    await tx.commit();

    return serviceJson(context, {
      loan: toLoan(loan.rows[0]),
    });
  } catch (e) {
    await tx.rollback();

    throw e;
  } finally {
    tx.release();
  }
}

// ============================================================
// DELETE LOAN
// ============================================================

;

// ============================================================
// EXPORT
// ============================================================


async function post_legacy_import_9(context) {
  const parsed=createSchema.safeParse(context.body||{});
  if(!parsed.success) return serviceResponse(400,{error:'Invalid previous loan data',details:parsed.error.flatten()},context);
  const d=parsed.data;
  if(d.loanSourceType!=='previous_loan') return serviceResponse(400,{error:'loanSourceType must be previous_loan'},context);
  const org=context.auth.organization_id, tx=await repository.begin();
  try{
    await tx.begin();
    const memberQ=await tx.queryNamed('loansService.js:legacyImportMember',[d.memberId,org],{});
    const member=memberQ.rows[0];
    if(!member) { await tx.rollback(); return serviceResponse(404,{error:'Previous borrower not found'},context); }
    if(member.member_origin!=='previous_borrower') { await tx.rollback(); return serviceResponse(409,{error:'Selected member is not marked as a previous borrower'},context); }
    const effectiveBranchId=isOrganizationWide(context.auth)?(d.branchId||member.branch_id):context.auth.branch_id;
    if(!effectiveBranchId) { await tx.rollback(); return serviceResponse(403,{error:'Your account is not assigned to a branch'},context); }
    if(String(effectiveBranchId)!==String(member.branch_id)){await tx.rollback();return serviceResponse(400,{error:'Loan branch must match member branch'},context);}
    await assertBranch(tx,org,effectiveBranchId); assertBranchAccess(context.auth,effectiveBranchId);
    const calc=calculateLoanValues(d.loanAmount,d.interestRate,d.numberOfInstallments,d.installmentAmount);
    const paid=Math.min(Number(d.legacyPaidAmount||0),Number(calc.totalPayable));
    const paidInstallments=Math.min(Number(d.legacyPaidInstallments||0),Number(d.numberOfInstallments));
    const r=await tx.queryNamed('loansService.js:legacyLoanInsert',[org,effectiveBranchId,d.memberId,paid,paidInstallments,d.loanType,d.loanPurpose,calc.loanAmount,calc.interestRate,calc.interestAmount,calc.totalPayable,calc.installmentAmount,d.savingsAmount,d.depositAmount,d.numberOfInstallments,d.installmentFrequency,d.startDate,d.firstInstallmentDate||d.startDate,d.applicationDate||null,d.applicationDate||new Date().toISOString(),d.applicationDate||new Date().toISOString(),calc.loanAmount,Math.max(0,calc.totalPayable-paid),context.auth.user_id],{});
    const loanId=r.rows[0].id;
    const scheduleCfg=(await tx.queryNamed('loansService.js:disbursement:loanScheduleConfig',[org],{})).rows[0]?.setting_value||{};
    const skipFriday=scheduleCfg.skipFriday!==false;
    for(let n=1;n<=d.numberOfInstallments;n++){
      const amount=n===d.numberOfInstallments?Math.max(0,Math.round((calc.totalPayable-d.installmentAmount*(d.numberOfInstallments-1))*100)/100):d.installmentAmount;
      await tx.queryNamed('installmentsService.js:18:99',[org,loanId,n,loanAddPeriod(d.firstInstallmentDate||d.startDate,d.installmentFrequency,n-1,skipFriday),amount],{});
    }
    // Apply imported historical payment to the generated schedule, making total collection and outstanding balance consistent.
    if(paid>0){
      const pay=await tx.queryNamed('loansService.js:legacyPaymentInsert',[org,effectiveBranchId,d.memberId,loanId,paid,d.startDate,context.auth.user_id,'Imported previous-loan payment balance'],{});
      let rem=paid;
      const schedules=(await tx.queryNamed('loansService.js:legacySchedule',[org,loanId],{})).rows;
      for(const sch of schedules){if(rem<=0)break;const a=Math.min(rem,Number(sch.outstanding_amount));if(a<=0)continue;rem=Number((rem-a).toFixed(2));await tx.queryNamed('loansService.js:legacyPaymentAllocation',[org,pay.rows[0].id,loanId,sch.id,a],{});const nextPaid=Number(sch.paid_amount)+a;const nextOut=Math.max(0,Number(sch.outstanding_amount)-a);await tx.queryNamed('loansService.js:legacyInstallmentUpdate',[nextPaid,nextOut,nextOut<=0.009?'paid':'partial',d.startDate,sch.id,org],{});}
    }
    if(Number(member.legacy_savings_balance||0)>0){
      await tx.queryNamed('loansService.js:legacySavingsInsert',[org,d.memberId,effectiveBranchId,member.legacy_savings_balance,d.startDate,context.auth.user_id],{});
    }
    await tx.queryNamed('loansService.js:legacyLoanBalance',[Math.max(0,calc.totalPayable-paid),loanId,org],{});
    const updated=await tx.queryNamed('loansService.js:513:130',[loanId,org],{});
    await writeAudit(tx,context.auth,'LOAN_LEGACY_IMPORTED',loanId,{paidAmount:paid,paidInstallments,memberOrigin:'previous_borrower'});
    await tx.commit();
    return serviceResponse(201,{loan:toLoan(updated.rows[0]),importedPaidAmount:paid,importedSavingsBalance:Number(member.legacy_savings_balance||0)},context);
  }catch(e){await tx.rollback();throw e;}finally{tx.release();}
}

async function guard_loans(context) {
  context.cookies ||= [];

  if (isOrganizationWide(context.auth) || !context.params.id) {
    return null;
  }

  try {
    const { rows } = await repository.queryNamed("loansService.js:7:112", [context.params.id, context.auth.organization_id], {  });

    if (!rows[0]) {
      return serviceResponse(404, {
        error: "Loan not found",
      }, context);
    }

    if (
      !context.auth.branch_id ||
      String(rows[0].branch_id) !== String(context.auth.branch_id)
    ) {
      return serviceResponse(403, {
        error: "Branch access denied",
      }, context);
    }

    return null;
  } catch (e) {
    throw e;
  }

}

async function get_root_1(context) {
  context.cookies ||= [];

    try {
      const org = context.auth.organization_id;

      const q = typeof context.query.q === "string" ? context.query.q.trim() : "";

      const status =
        typeof context.query.status === "string" ? context.query.status : "";

      const branchId =
        typeof context.query.branch_id === "string" ? context.query.branch_id : "";

      const memberId =
        typeof context.query.member_id === "string" ? context.query.member_id : "";

      const limit = Math.min(
        Math.max(Number.parseInt(context.query.limit || "100", 10) || 100, 1),
        500,
      );

      const offset = Math.max(
        Number.parseInt(context.query.offset || "0", 10) || 0,
        0,
      );

      const values = [org];
      const filters = [];
      if (q) { values.push(`%${q}%`); filters.push('search'); }
      if (status) {
        if (!STATUSES.includes(status)) return serviceResponse(400, { error: "Invalid loan status" }, context);
        values.push(status); filters.push('status');
      }
      if (branchId) { values.push(branchId); filters.push('branchId'); }
      if (!isOrganizationWide(context.auth)) {
        if (!context.auth.branch_id) filters.push('denyAll');
        else { values.push(context.auth.branch_id); filters.push('scopedBranchId'); }
      }
      if (memberId) { values.push(memberId); filters.push('memberId'); }
      values.push(limit, offset);
      const { rows } = await repository.queryNamed("loansService.js:79:113", values, { filters });

      return serviceJson(context, {
        loans: rows.map(toLoan),

        pagination: {
          limit,
          offset,
          returned: rows.length,
        },
      });
    } catch (e) {
      throw e;
    }
  
}

async function post_root_2(context) {
  context.cookies ||= [];

    const parsed = createSchema.safeParse(context.body);

    if (!parsed.success) {
      return serviceResponse(400, {
        error: "Invalid loan data",
        details: parsed.error.flatten(),
      }, context);
    }

    const d = parsed.data;

    const org = context.auth.organization_id;

    // --------------------------------------------------------
    // IDEMPOTENCY (prevent double-create from double-submit / retry)
    // --------------------------------------------------------
    // The actual duplicate-prevention lookup now happens inside the
    // transaction below, with a row lock, backed by the DB-level unique
    // index loans_org_idempotency_idx(organization_id, idempotency_key).
    // This closes the race window: two concurrent requests with the same
    // key can no longer both create a loan (the second INSERT will hit the
    // unique constraint and is caught below).
    const rawIdem = context.headers && (
      context.headers['idempotency-key'] ||
      context.headers['x-idempotency-key']
    );
    const idempotencyKey = typeof rawIdem === 'string' ? rawIdem.trim().slice(0, 150) : '';

    // --------------------------------------------------------
    // SERVER-SIDE CALCULATION
    // --------------------------------------------------------

    let calculated;

    try {
      calculated = calculateLoanValues(
        d.loanAmount,
        d.interestRate,
        d.numberOfInstallments,
        d.installmentAmount,
      );
    } catch (e) {
      return serviceResponse(400, {
        error: e.message,
      }, context);
    }

    const {
      loanAmount,
      interestRate,
      interestAmount,
      totalPayable,
      installmentAmount,
    } = calculated;

    const tx = await repository.begin();

    try {
      await tx.begin();

      if (idempotencyKey) {
        const existing = await tx.queryNamed("loansService.js:idem:lookupRow", [org, idempotencyKey], {});
        if (existing.rows[0]) {
          await tx.commit();
          return serviceResponse(200, { loan: toLoan(existing.rows[0]), idempotent: true }, context);
        }
      }

      // ------------------------------------------------------
      // MEMBER VALIDATION
      // ------------------------------------------------------

      const member = await assertMember(tx, org, d.memberId);

      if (d.renewalOfLoanId) { const prior=await tx.queryNamed("loansService.js:renewalCheck",[d.renewalOfLoanId,org],{}); if(!prior.rows[0]||String(prior.rows[0].member_id)!==String(d.memberId)){await tx.rollback();return serviceResponse(400,{error:"Renewal loan must belong to the same member"},context);} }

      // ------------------------------------------------------
      // BRANCH VALIDATION
      // ------------------------------------------------------

      if (isOrganizationWide(context.auth) && d.branchId) {
        await assertBranch(tx, org, d.branchId);
      }

      const effectiveBranchId = isOrganizationWide(context.auth)
        ? d.branchId
        : context.auth.branch_id;

      if (!effectiveBranchId) {
        await tx.rollback();

        return serviceResponse(403, {
          error: "Your account is not assigned to a branch",
        }, context);
      }

      if (String(effectiveBranchId) !== String(member.branch_id)) {
        await tx.rollback();

        return serviceResponse(400, {
          error: "Loan branch must match member branch",
        }, context);
      }

      await assertBranch(tx, org, effectiveBranchId);

      assertBranchAccess(context.auth, effectiveBranchId);

      // ------------------------------------------------------
      // INSERT LOAN
      // ------------------------------------------------------

      const { rows } = await tx.queryNamed("loansService.js:88:114", [
          org,

          effectiveBranchId,

          d.memberId,

          d.renewalOfLoanId || null,
          d.loanSourceType,
          d.loanSourceType === 'previous_loan' ? d.legacyPaidAmount : 0,
          d.loanSourceType === 'previous_loan' ? d.legacyPaidInstallments : 0,

          d.loanType,

          d.loanPurpose,

          loanAmount,

          interestRate,

          interestAmount,

          totalPayable,

          installmentAmount,

          d.savingsAmount,

          d.depositAmount,

          d.numberOfInstallments,

          d.installmentFrequency,

          d.startDate,

          d.firstInstallmentDate || null,

          d.applicationDate || null,

          context.auth.user_id,

          idempotencyKey || null,
        ], {  });

      const loanId = rows[0].id;

      await writeAudit(tx, context.auth, "LOAN_CREATED", loanId, {
        loan_number: "generated",
        loan_amount: loanAmount,
        interest_rate: interestRate,
        interest_amount: interestAmount,
        total_payable: totalPayable,
        installment_amount: installmentAmount,
        idempotencyKey: idempotencyKey || null,
      });

      const result = await tx.queryNamed("loansService.js:189:115", [loanId, org], {});

      await tx.commit();

      return serviceResponse(201, {
        loan: toLoan(result.rows[0]),
      }, context);
    } catch (e) {
      await tx.rollback();

      if (e.code === '23505' && idempotencyKey) {
        return serviceResponse(409, { error: 'Idempotency key already used' }, context);
      }

      throw e;
    } finally {
      tx.release();
    }
  
}

async function get_id_3(context) {
  context.cookies ||= [];

    try {
      const { rows } = await repository.queryNamed("loansService.js:3:116", [context.params.id, context.auth.organization_id], {});

      if (!rows[0]) {
        return serviceResponse(404, {
          error: "Loan not found",
        }, context);
      }

      return serviceJson(context, {
        loan: toLoan(rows[0]),
      });
    } catch (e) {
      throw e;
    }
  
}

async function patch_id_4(context) {
  context.cookies ||= [];

    const parsed = updateSchema.safeParse(context.body);

    if (!parsed.success) {
      return serviceResponse(400, {
        error: "Invalid loan update",
        details: parsed.error.flatten(),
      }, context);
    }

    const d = parsed.data;

    const org = context.auth.organization_id;

    const tx = await repository.begin();

    try {
      await tx.begin();

      // ------------------------------------------------------
      // GET CURRENT LOAN
      // ------------------------------------------------------

      const current = await tx.queryNamed("loansService.js:24:117", [context.params.id, org], {});

      if (!current.rows[0]) {
        await tx.rollback();

        return serviceResponse(404, {
          error: "Loan not found",
        }, context);
      }

      const row = current.rows[0];

      // ------------------------------------------------------
      // ONLY DRAFT / PENDING CAN BE EDITED
      // ------------------------------------------------------

      if (!["draft", "pending"].includes(row.status)) {
        await tx.rollback();

        return serviceResponse(409, {
          error: "Only draft or pending loans can be edited",
        }, context);
      }

      // ------------------------------------------------------
      // EFFECTIVE BRANCH
      // ------------------------------------------------------

      const effectiveBranchId = isOrganizationWide(context.auth)
        ? d.branchId === undefined
          ? row.branch_id
          : d.branchId
        : context.auth.branch_id;

      if (!effectiveBranchId) {
        await tx.rollback();

        return serviceResponse(403, {
          error: "Your account is not assigned to a branch",
        }, context);
      }

      assertBranchAccess(context.auth, effectiveBranchId);

      await assertBranch(tx, org, effectiveBranchId);

      // ------------------------------------------------------
      // EXISTING / NEW VALUES
      // ------------------------------------------------------

      const amount = d.loanAmount ?? Number(row.loan_amount);

      const rate = d.interestRate ?? Number(row.interest_rate || 0);

      const count =
        d.numberOfInstallments ?? Number(row.number_of_installments);

      const manualInstallmentAmount =
        d.installmentAmount ?? Number(row.installment_amount);

      // ------------------------------------------------------
      // RECALCULATE EVERYTHING
      // ------------------------------------------------------

      const calculated = calculateLoanValues(amount, rate, count, manualInstallmentAmount);

      const { interestAmount, totalPayable, installmentAmount } = calculated;

      // ------------------------------------------------------
      // UPDATE LOAN
      // ------------------------------------------------------

      const { rows } = await tx.queryNamed("loansService.js:109:118", [
          d.loanType ?? null,

          d.loanPurpose ?? null,

          amount,

          rate,

          interestAmount,

          totalPayable,

          installmentAmount,

          count,

          d.installmentFrequency ?? null,

          d.startDate ?? null,

          d.firstInstallmentDate === undefined
            ? row.first_installment_date
            : d.firstInstallmentDate,

          effectiveBranchId,

          context.params.id,

          org,
        ], {  });

      await writeAudit(tx, context.auth, "LOAN_UPDATED", context.params.id, {
        fields: Object.keys(d),

        loan_amount: amount,

        interest_rate: rate,

        interest_amount: interestAmount,

        total_payable: totalPayable,

        installment_amount: installmentAmount,
      });

      // ------------------------------------------------------
      // GET UPDATED LOAN
      // ------------------------------------------------------

      const result = await tx.queryNamed("loansService.js:222:119", [rows[0].id, org], {});

      await tx.commit();

      return serviceJson(context, {
        loan: toLoan(result.rows[0]),
      });
    } catch (e) {
      await tx.rollback();

      throw e;
    } finally {
      tx.release();
    }
  
}

async function post_id_approve_5(context) {
  context.cookies ||= [];
return (transition(context, "approved", "LOAN_APPROVED"));
}

async function post_id_disburse_6(context) {
  context.cookies ||= [];

    const parsed = z.object({ insuranceAmount: z.coerce.number().min(0).max(100000000).optional().default(0) }).strict().safeParse(context.body || {});
    if (!parsed.success) return serviceResponse(400, { error: "Invalid insurance amount" }, context);
    return transition(context, "disbursed", "LOAN_DISBURSED", { insuranceAmount: parsed.data.insuranceAmount });
  
}

async function post_id_status_7(context) {
  context.cookies ||= [];

    const parsed = z
      .object({
        status: z.enum(STATUSES),
      })
      .strict()
      .safeParse(context.body);

    if (!parsed.success) {
      return serviceResponse(400, {
        error: "Invalid status",
      }, context);
    }

    return transition(
      context,
      parsed.data.status,
      "LOAN_STATUS_CHANGED",
    );
  
}

async function delete_id_8(context) {
  context.cookies ||= [];

    try {
      const tx = await repository.begin();

      try {
        await tx.begin();

        const current = await tx.queryNamed("loansService.js:8:120", [context.params.id, context.auth.organization_id], {  });

        if (!current.rows[0]) {
          await tx.rollback();

          return serviceResponse(404, {
            error: "Loan not found",
          }, context);
        }

        if (
          !["draft", "rejected", "cancelled"].includes(current.rows[0].status)
        ) {
          await tx.rollback();

          return serviceResponse(409, {
            error: "Only draft, rejected, or cancelled loans can be deleted",
          }, context);
        }

        await tx.queryNamed("loansService.js:40:121", [context.params.id, context.auth.organization_id], {  });

        await writeAudit(tx, context.auth, "LOAN_DELETED", context.params.id, {});

        await tx.commit();

        return serviceResponse(204, null, context);
      } catch (e) {
        await tx.rollback();

        throw e;
      } finally {
        tx.release();
      }
    } catch (e) {
      throw e;
    }
  
}

module.exports = { get_root_1, post_root_2, get_id_3, patch_id_4, post_id_approve_5, post_id_disburse_6, post_id_status_7, delete_id_8, post_legacy_import_9, guard_loans };
