'use strict';

const { serviceResponse, serviceJson } = require('./serviceResult');


const argon2 = require('argon2');
const crypto = require('node:crypto');
const { z } = require('zod');
const repository = require('../repositories');

const { isOrganizationWide, assertBranchAccess, enforceRequestedBranch } = require('../application/accessScope');

const createSchema = z.object({
  name: z.string().trim().min(2).max(200),
  email: z.string().trim().email().max(254),
  password: z.string().min(8).max(200),
  roleCode: z.string().trim().regex(/^[a-z][a-z0-9_]{1,79}$/),
  branchId: z.string().uuid().nullable().optional()
}).strict();

const updateSchema = z.object({
  name: z.string().trim().min(2).max(200).optional(),
  email: z.string().trim().email().max(254).optional(),
  password: z.string().min(8).max(200).optional(),
  roleCode: z.string().trim().regex(/^[a-z][a-z0-9_]{1,79}$/).optional(),
  branchId: z.string().uuid().nullable().optional(),
  active: z.boolean().optional()
}).strict();

function email(v) { return v.trim().toLowerCase(); }
function canManageRole(auth, roleCode) {
  if (isOrganizationWide(auth)) return roleCode !== 'super_admin';
  return !['super_admin', 'organization_admin'].includes(roleCode);
}
function scopedFilters(auth, values) {
  const filters = [];
  if (!isOrganizationWide(auth)) {
    if (!auth.branch_id) filters.push('denyAll');
    else { values.push(auth.branch_id); filters.push('branchId'); }
  }
  return filters;
}

;

;

;

;


async function get_root_1(context) {
  context.cookies ||= [];

  try {
    const values = [context.auth.organization_id];
    const filters = scopedFilters(context.auth, values);
    const { rows } = await repository.queryNamed("usersService.js:5:239", values, { filters });
    return serviceJson(context, { users: rows.map(r => ({
      id:r.id,userCode:r.user_code,name:r.full_name,email:r.email,active:r.active,
      branchId:r.branch_id,roleCode:r.role_code,roleName:r.role_name,branchName:r.branch_name || null,
      createdAt:r.created_at,updatedAt:r.updated_at
    })) });
  } catch (e) { throw e; }

}

async function post_root_2(context) {
  context.cookies ||= [];

  const parsed = createSchema.safeParse(context.body);
  if (!parsed.success) return serviceResponse(400, { error:'Invalid user data', details:parsed.error.issues }, context);
  const d=parsed.data, org=context.auth.organization_id, tx=await repository.begin();
  try {
    await tx.begin();
    if (!canManageRole(context.auth,d.roleCode)) { await tx.rollback(); return serviceResponse(403, {error:'You cannot assign this role'}, context); }
    const role=await tx.queryNamed("usersService.js:8:240", [d.roleCode,org], {  });
    if (!role.rows[0] || role.rows[0].is_system) { await tx.rollback(); return serviceResponse(400, {error:'Role is not available for organization users'}, context); }
    const branchId = isOrganizationWide(context.auth) ? (d.branchId || null) : context.auth.branch_id;
    if (!isOrganizationWide(context.auth) && !branchId) { await tx.rollback(); return serviceResponse(403, {error:'Your account is not assigned to a branch'}, context); }
    if (branchId) {
      const b=await tx.queryNamed("usersService.js:13:241", [branchId,org], {  });
      if (!b.rows[0]) { await tx.rollback(); return serviceResponse(400, {error:'Invalid branch'}, context); }
      if (!isOrganizationWide(context.auth)) assertBranchAccess(context.auth,branchId);
    }
    const dup=await tx.queryNamed("usersService.js:17:242", [email(d.email)], {  });
    if (dup.rows[0]) { await tx.rollback(); return serviceResponse(409, {error:'Email already exists'}, context); }
    const passwordHash=await argon2.hash(d.password,{type:argon2.argon2id});
    const userCode=`USR-${crypto.randomUUID().replace(/-/g,'').slice(0,10).toUpperCase()}`;
    const {rows}=await tx.queryNamed("usersService.js:21:243", [org,branchId,userCode,email(d.email),passwordHash,role.rows[0].code,role.rows[0].id,d.name,context.auth.user_id], {  });
    await tx.queryNamed("usersService.js:27:244", [org,context.auth.user_id,rows[0].id,JSON.stringify({role:d.roleCode,branch_id:branchId})], {  });
    await tx.commit();
    return serviceResponse(201, {user:{...rows[0],userCode:rows[0].user_code,name:rows[0].full_name,branchId:rows[0].branch_id}}, context);
  } catch(e){await tx.rollback();throw e;} finally{tx.release();}

}

async function patch_id_3(context) {
  context.cookies ||= [];

  const parsed=updateSchema.safeParse(context.body); if(!parsed.success)return serviceResponse(400, {error:'Invalid user update',details:parsed.error.issues}, context);
  const d=parsed.data,org=context.auth.organization_id,tx=await repository.begin();
  try{
    await tx.begin();
    const current=await tx.queryNamed("usersService.js:6:245", [context.params.id,org], {  });
    if(!current.rows[0]){await tx.rollback();return serviceResponse(404, {error:'User not found'}, context);}
    const u=current.rows[0];
    if(!isOrganizationWide(context.auth)) assertBranchAccess(context.auth,u.branch_id);
    if(u.id===context.auth.user_id && d.active===false){await tx.rollback();return serviceResponse(400, {error:'You cannot deactivate your own account'}, context);}
    const nextRole=d.roleCode||u.role_code;
    if(!canManageRole(context.auth,nextRole)){await tx.rollback();return serviceResponse(403, {error:'You cannot assign this role'}, context);}
    const role=await tx.queryNamed("usersService.js:13:246", [nextRole,org], {  });
    if(!role.rows[0]){await tx.rollback();return serviceResponse(400, {error:'Invalid organization role'}, context);}
    const branchId=isOrganizationWide(context.auth)?(d.branchId===undefined?u.branch_id:d.branchId):context.auth.branch_id;
    if(!branchId && nextRole!=='organization_admin'){await tx.rollback();return serviceResponse(400, {error:'Non-admin users must have a branch'}, context);}
    if(branchId){const b=await tx.queryNamed("usersService.js:17:247", [branchId,org], {  });if(!b.rows[0]){await tx.rollback();return serviceResponse(400, {error:'Invalid branch'}, context);}}
    const nextEmail=d.email?email(d.email):u.email;
    if(nextEmail!==u.email){const dup=await tx.queryNamed("usersService.js:19:248", [nextEmail,u.id], {  });if(dup.rows[0]){await tx.rollback();return serviceResponse(409, {error:'Email already exists'}, context);}}
    const passwordHash=d.password?await argon2.hash(d.password,{type:argon2.argon2id}):u.password_hash;
    const {rows}=await tx.queryNamed("usersService.js:21:249", [d.name||u.full_name,nextEmail,passwordHash,role.rows[0].code,role.rows[0].id,branchId,d.active===undefined?u.active:d.active,u.id,org], {  });
    // An admin-initiated password change must end the target user's existing
    // sessions (the settings page promises this); otherwise a stolen session
    // would survive the reset. The caller's own session is left alone.
    if (d.password && u.id !== context.auth.user_id) {
      await tx.queryNamed("authService.js:admin_credentials_revoke_sessions", [u.id], {});
    }
    await tx.queryNamed("usersService.js:22:250", [org,context.auth.user_id,u.id,JSON.stringify({fields:Object.keys(d),role:role.rows[0].code,branch_id:branchId})], {  });
    await tx.commit();
    return serviceJson(context, {user:{...rows[0],userCode:rows[0].user_code,name:rows[0].full_name,branchId:rows[0].branch_id}});
  }catch(e){await tx.rollback();throw e;}finally{tx.release();}

}

async function delete_id_4(context) {
  context.cookies ||= [];

  const tx=await repository.begin();
  try{await tx.begin();const org=context.auth.organization_id;const q=await tx.queryNamed("usersService.js:3:251", [context.params.id,org], {  });if(!q.rows[0]){await tx.rollback();return serviceResponse(404, {error:'User not found'}, context);}if(q.rows[0].id===context.auth.user_id){await tx.rollback();return serviceResponse(400, {error:'You cannot deactivate yourself'}, context);}if(!isOrganizationWide(context.auth))assertBranchAccess(context.auth,q.rows[0].branch_id);await tx.queryNamed("usersService.js:3:252", [context.params.id,org], {  });await tx.queryNamed("usersService.js:3:253", [org,context.auth.user_id,context.params.id], {  });await tx.commit();return serviceResponse(204, null, context);}catch(e){await tx.rollback();throw e;}finally{tx.release();}

}

module.exports = { get_root_1, post_root_2, patch_id_3, delete_id_4 };
