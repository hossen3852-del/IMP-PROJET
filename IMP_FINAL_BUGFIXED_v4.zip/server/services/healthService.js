'use strict';

const repository = require('../repositories');
const { serviceResponse } = require('./serviceResult');

async function health(context) {
  return serviceResponse(200, { status: 'ok', database: await repository.health() }, context);
}

module.exports = { health };
