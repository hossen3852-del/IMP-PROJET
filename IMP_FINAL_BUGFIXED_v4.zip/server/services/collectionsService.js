'use strict';

const { serviceResponse, serviceJson } = require('./serviceResult');


/**
 * 11.P.16 — Daily Collection (Field Officer route sheet).
 *
 * GET  /collections/route-sheet
 * POST /collections/daily
 */

const { z } = require('zod');
const repository = require('../repositories');


const { isOrganizationWide, assertBranchAccess, enforceRequestedBranch } = require('../application/accessScope');


// ============================================================
// Helpers
// ============================================================

function money(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return 0;
  return Number(n.toFixed(2));
}


/**
 * Validate YYYY-MM-DD as a real calendar date.
 *
 * Prevents:
 * 2026-99-99
 * 2026-02-31
 * invalid Date -> Invalid time value
 */
function getValidCollectionDate(value) {
  // IMP is Bangladesh-focused. Never let the database/server host timezone
  // decide what "today" means for daily collection.
  const dhakaParts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Dhaka',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(new Date());

  const dhaka = Object.fromEntries(
    dhakaParts
      .filter(p => p.type !== 'literal')
      .map(p => [p.type, p.value])
  );

  const fallback =
    `${dhaka.year}-${dhaka.month}-${dhaka.day}`;

  if (typeof value !== 'string') {
    return fallback;
  }

  const raw = value.trim();

  if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
    return fallback;
  }

  const [year, month, day] = raw.split('-').map(Number);

  const test = new Date(
    Date.UTC(year, month - 1, day)
  );

  if (
    !Number.isFinite(test.getTime()) ||
    test.getUTCFullYear() !== year ||
    test.getUTCMonth() !== month - 1 ||
    test.getUTCDate() !== day
  ) {
    return fallback;
  }

  return raw;
}


// ============================================================
// Daily Collection Settings
// ============================================================

const COLLECTION_SETTING_KEY =
  'daily_collection_config';

const PAYMENT_METHODS = [
  'cash',
  'bkash',
  'nagad',
  'rocket',
  'bank_transfer',
  'cheque',
  'other'
];

const DEFAULT_COLLECTION_CONFIG = {
  collectionTypes: {
    installment: true,
    savings: true,
  },

  defaultPaymentMethod: 'cash',

  showOverdueHint: true,

  allowBranchOverride: false,

  requireNoteOnAdvance: false,

  allowAdvance: true,

  autoIncludeInactiveMembers: false
};


const collectionConfigSchema = z.object({

  collectionTypes: z.object({
    installment: z.boolean(),
    savings: z.boolean(),
  }),

  defaultPaymentMethod:
    z.enum(PAYMENT_METHODS),

  showOverdueHint:
    z.boolean(),

  allowBranchOverride:
    z.boolean(),

  requireNoteOnAdvance:
    z.boolean(),

  allowAdvance:
    z.boolean(),

  autoIncludeInactiveMembers:
    z.boolean()

}).strict();


// ============================================================
// GET CONFIG
// ============================================================

;


// ============================================================
// UPDATE CONFIG
// ============================================================

;


// ============================================================
// Load Configuration
// ============================================================

async function loadCollectionConfig(org) {

  const { rows } =
    await repository.queryNamed("collectionsService.js:165:61", [
        org,
        COLLECTION_SETTING_KEY
      ], {  });

  if (!rows[0]) return DEFAULT_COLLECTION_CONFIG;

  const stored = rows[0].setting_value || {};
  return {
    ...DEFAULT_COLLECTION_CONFIG,
    ...stored,
    collectionTypes: {
      ...DEFAULT_COLLECTION_CONFIG.collectionTypes,
      ...(stored.collectionTypes || {})
    }
  };
}


// ============================================================
// GET ROUTE SHEET
// ============================================================

;


// ============================================================
// DAILY COLLECTION SCHEMA
// ============================================================

const entrySchema =
  z.object({
    memberId: z.string().uuid(),
    loanId: z.string().uuid().nullable().optional(),
    installmentAmount: z.coerce.number().min(0).optional().default(0),
    savingsAmount: z.coerce.number().min(0).optional().default(0),
    paymentMethod: z.enum(PAYMENT_METHODS).optional().default('cash'),
    notes: z.string().trim().max(2000).optional().default(''),
    // paid = collected (default); baki = arrears / did not pay
    status: z.enum(['paid', 'baki']).optional().default('paid'),
    // Client-generated, stable across retries of the same logical entry —
    // lets the server dedupe a mobile network retry or a double-tap so it
    // never posts the same installment/savings amount twice.
    idempotencyKey: z.string().trim().max(150).optional().default('')
  })
  .strict()
  .superRefine((d, ctx) => {
    if (d.installmentAmount > 0 && !d.loanId) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['loanId'],
        message: 'loanId is required when installmentAmount > 0'
      });
    }
    // Baki entries may have all amounts zero (just status tracking).
    // Paid entries still need at least one positive amount.
    if (
      d.status !== 'baki' &&
      d.installmentAmount <= 0 &&
      d.savingsAmount <= 0
    ) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['installmentAmount'],
        message: 'At least one collection amount must be > 0'
      });
    }
  });


// ============================================================
// DAILY SCHEMA
// ============================================================

const dailySchema =
  z.object({
    date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    branchId: z.string().uuid().nullable().optional(),
    // daily | weekly | monthly — server enforces once-per-day per branch+frequency
    frequency: z.enum(['daily','weekly','monthly']).optional().default('monthly'),
    dailyExpense: z.coerce.number().min(0).optional().default(0),
    dailyExpenseIdempotencyKey: z.string().trim().max(150).optional().default(''),
    entries: z.array(entrySchema).max(500)
  })
  .strict();


// ============================================================
// COLLECT INSTALLMENT
// ============================================================

async function collectInstallment(
  tx,
  org,
  auth,
  memberId,
  loanId,
  amount,
  dateISO,
  method,
  notes,
  requireNoteOnAdvance,
  allowAdvance,
  idempotencyKey
) {

  // Idempotent replay: if this exact entry was already posted (retry after a
  // dropped response, or a double-tap before the row disabled itself), return
  // the payment that was already created instead of creating a duplicate.
  if (idempotencyKey) {
    const dup = await tx.queryNamed("collectionsService.js:idem:paymentLookup", [org, idempotencyKey], {  });
    if (dup.rows[0]) {
      return {
        paymentId: dup.rows[0].id,
        paymentNumber: dup.rows[0].payment_number,
        idempotent: true
      };
    }
  }

  const loanQ =
    await tx.queryNamed("collectionsService.js:271:62", [
        loanId,
        org
      ], {  });


  const loan =
    loanQ.rows[0];


  if (!loan) {

    throw Object.assign(
      new Error('Loan not found'),
      {
        httpStatus: 404
      }
    );

  }


  if (
    loan.member_id !== memberId
  ) {

    throw Object.assign(
      new Error(
        'Loan does not belong to this member'
      ),
      {
        httpStatus: 400
      }
    );

  }


  if (
    !isOrganizationWide(auth)
  ) {

    assertBranchAccess(
      auth,
      loan.branch_id
    );

  }


  if (
    ![
      'disbursed',
      'active'
    ].includes(loan.status)
  ) {

    throw Object.assign(
      new Error(
        'Payments can only be posted to disbursed or active loans'
      ),
      {
        httpStatus: 409
      }
    );

  }


  const outstanding =
    Number(
      loan.outstanding_amount
    );


  // Note: the outstanding-balance check lives further below, with a small
  // floating-point tolerance (`amount > outstanding + 0.009`). Keeping only
  // that one check avoids a tolerance-free check here silently rejecting a
  // payment that exactly matches outstanding due to rounding — and this
  // check was unreachable dead code anyway, since it always ran first.

  // ==========================================================
  // IMPORTANT:
  // i.outstanding_amount is explicitly qualified.
  // ==========================================================

  const dueQ =
    await tx.queryNamed("collectionsService.js:385:63", [
        org,
        loanId,
        dateISO
      ], {  });


  const dueToday =
    Number(
      dueQ.rows[0].due_today
    );

  // Daily collection may post beyond the currently due balance only when
  // advance collection is explicitly enabled. The total can never exceed
  // the loan's remaining outstanding balance. FIFO allocation below then
  // applies the excess to the next unpaid installments in due-date order.
  const isAdvance = amount > dueToday + 0.009;

  if (amount > outstanding + 0.009) {
    throw Object.assign(
      new Error(
        `Installment payment exceeds the loan outstanding balance (${money(outstanding)})`
      ),
      { httpStatus: 409 }
    );
  }

  if (isAdvance && !allowAdvance) {
    throw Object.assign(
      new Error(
        'Advance installment collection is disabled in Settings → দৈনিক কালেকশন'
      ),
      { httpStatus: 409 }
    );
  }

  if (
    requireNoteOnAdvance &&
    isAdvance &&
    !notes.trim()
  ) {

    throw Object.assign(
      new Error(
        'This amount is an advance beyond what is due today — a note is required (see Settings → দৈনিক কালেকশন)'
      ),
      {
        httpStatus: 400
      }
    );

  }


  // ==========================================================
  // PAYMENT NUMBER
  // ==========================================================

  const seq =
    await tx.queryNamed("collectionsService.js:444:64", [], {  });


  const paymentNumber =
    `PAY-${dateISO
      .slice(0, 10)
      .replace(/-/g, '')}-${String(
        seq.rows[0].n
      ).padStart(8, '0')}`;


  // ==========================================================
  // PAYMENT
  // ==========================================================

  const ins =
    await tx.queryNamed("collectionsService.js:466:65", [
        org,
        loan.branch_id,
        memberId,
        loanId,
        paymentNumber,
        amount,
        // Plain YYYY-MM-DD — SQL stores noon Asia/Dhaka so date grouping
        // in Payments UI Daily Collection never shifts by timezone.
        String(dateISO).slice(0, 10),
        method,
        auth.user_id,
        notes || null,
        idempotencyKey || null
      ], {  });


  const payment =
    ins.rows[0];


  let remaining =
    amount;


  // ==========================================================
  // INSTALLMENT SCHEDULE
  // ==========================================================

  const schedules =
    await tx.queryNamed("collectionsService.js:532:66", [
        org,
        loanId
      ], {  });


  // ==========================================================
  // FIFO ALLOCATION
  // ==========================================================

  for (
    const s of schedules.rows
  ) {

    if (
      remaining <= 0
    ) {
      break;
    }


    const installmentOutstanding =
      Number(
        s.outstanding_amount
      );


    const a =
      Math.min(
        remaining,
        installmentOutstanding
      );


    if (a <= 0) {
      continue;
    }


    remaining =
      money(
        remaining - a
      );


    await tx.queryNamed("collectionsService.js:606:67", [
        org,
        payment.id,
        loanId,
        s.id,
        a
      ], {  });


    const paid =
      Number(s.paid_amount) + a;


    const out =
      Math.max(
        0,
        installmentOutstanding - a
      );


    const st =
      out === 0
        ? 'paid'
        : paid > 0
          ? 'partial'
          : s.status;


    await tx.queryNamed("collectionsService.js:659:68", [
        paid,
        out,
        st,
        dateISO,
        s.id,
        org
      ], {  });

  }


  // ==========================================================
  // ADVANCE
  // ==========================================================

  if (
    remaining > 0
  ) {

    await tx.queryNamed("collectionsService.js:704:69", [
        org,
        payment.id,
        loanId,
        remaining
      ], {  });

  }


  // ==========================================================
  // UPDATE LOAN
  // ==========================================================

  const newOutstanding =
    Math.max(
      0,
      outstanding - amount
    );


  await tx.queryNamed("collectionsService.js:750:70", [
      newOutstanding,
      loanId,
      org
    ], {  });


  // ==========================================================
  // RECEIPT
  // ==========================================================

  const rseq =
    await tx.queryNamed("collectionsService.js:783:71", [], {  });


  const receiptNumber =
    `RCP-${dateISO
      .slice(0, 10)
      .replace(/-/g, '')}-${String(
        rseq.rows[0].n
      ).padStart(8, '0')}`;


  await tx.queryNamed("collectionsService.js:800:72", [
      org,
      payment.id,
      receiptNumber,
      auth.user_id
    ], {  });


  // ==========================================================
  // AUDIT
  // ==========================================================

  await tx.queryNamed("collectionsService.js:833:73", [
      org,
      auth.user_id,
      payment.id,
      JSON.stringify({
        amount,
        payment_number:
          payment.payment_number,
        source:
          'daily_collection'
      })
    ], {  });


  return {
    paymentId:
      payment.id,

    paymentNumber:
      payment.payment_number
  };

}


// ============================================================
// COLLECT SAVINGS
// ============================================================

async function collectSavings(
  tx,
  org,
  auth,
  memberId,
  branchId,
  loanId,
  amount,
  dateISO,
  notes,
  idempotencyKey
) {

  if (idempotencyKey) {
    const dup = await tx.queryNamed("collectionsService.js:idem:savingsLookup", [org, idempotencyKey], {  });
    if (dup.rows[0]) {
      return {
        savingsTransactionId: dup.rows[0].id,
        idempotent: true
      };
    }
  }

  const {
    rows
  } = await tx.queryNamed("collectionsService.js:899:74", [
      org,
      memberId,
      branchId || null,
      loanId || null,
      amount,
      dateISO,
      notes || null,
      auth.user_id,
      idempotencyKey || null
    ], {  });


  await tx.queryNamed("collectionsService.js:942:75", [
      org,
      auth.user_id,
      rows[0].id,
      JSON.stringify({
        transactionType:
          'daily_deposit',
        amount,
        memberId,
        source:
          'daily_collection'
      })
    ], {  });


  return {
    savingsTransactionId:
      rows[0].id
  };

}


// ============================================================
// COLLECT INSURANCE
// ============================================================

// ============================================================
// COLLECT ADMISSION FEE
// ============================================================

// ============================================================
// POST DAILY COLLECTION
// ============================================================

;


// ============================================================
// EXPORT
// ============================================================

async function get_config_1(context) {
  context.cookies ||= [];


    try {

      const { rows } = await repository.queryNamed("collectionsService.js:5:49", [
          context.auth.organization_id,
          COLLECTION_SETTING_KEY
        ], {  });

      return serviceJson(context, {
        config:
          rows[0]
            ? rows[0].setting_value
            : DEFAULT_COLLECTION_CONFIG
      });

    } catch (e) {
      throw e;
    }

  
}

async function put_config_2(context) {
  context.cookies ||= [];


    const parsed =
      collectionConfigSchema.safeParse(context.body);

    if (!parsed.success) {

      return serviceResponse(400, {
        error: 'Invalid daily collection config',
        details: parsed.error.issues
      }, context);

    }

    const org = context.auth.organization_id;

    const tx =
      await repository.begin();

    try {

      await tx.begin();

      const { rows } =
        await tx.queryNamed("collectionsService.js:25:50", [
            org,
            COLLECTION_SETTING_KEY,
            JSON.stringify(parsed.data),
            context.auth.user_id
          ], {  });

      await tx.queryNamed("collectionsService.js:63:51", [
          org,
          context.auth.user_id,
          JSON.stringify(parsed.data)
        ], {  });

      await tx.commit();

      return serviceJson(context, {
        config: rows[0].setting_value
      });

    } catch (e) {

      await tx.rollback();

      throw e;

    } finally {

      tx.release();

    }

  
}

async function get_route_sheet_3(context) {
  context.cookies ||= [];


    try {

      const org =
        context.auth.organization_id;

      const config =
        await loadCollectionConfig(org);


      // --------------------------------------------------------
      // Safe date
      // --------------------------------------------------------

      const date =
        getValidCollectionDate(
          context.query.date
        );


      // --------------------------------------------------------
      // Branch scope
      // --------------------------------------------------------

      const requestedBranchId =
        typeof context.query.branchId === 'string' &&
        context.query.branchId.trim()
          ? context.query.branchId.trim()
          : null;


      let branchId = null;


      if (isOrganizationWide(context.auth)) {

        branchId =
          requestedBranchId || null;

      } else {

        if (!context.auth.branch_id) {

          return serviceResponse(403, {
            error:
              'Your account is not assigned to a branch'
          }, context);

        }

        if (requestedBranchId) {

          assertBranchAccess(
            context.auth,
            requestedBranchId
          );

        }

        branchId =
          context.auth.branch_id;

      }


      // --------------------------------------------------------
      // Search
      // --------------------------------------------------------

      const q =
        typeof context.query.q === 'string'
          ? context.query.q.trim()
          : '';


      // ========================================================
      // MEMBER QUERY
      //
      // IMPORTANT:
      // date is NOT added to this values array.
      //
      // This fixes:
      // "bind message supplies 2 parameters,
      //  but prepared statement requires 1"
      // ========================================================

      const values = [org];
      const filters = [];
      if (!config.autoIncludeInactiveMembers) filters.push('activeOnly');
      if (branchId) { values.push(branchId); filters.push('branchId'); }
      if (q) { values.push(`%${q}%`); filters.push('search'); }
      const { rows: members } = await repository.queryNamed("collectionsService.js:134:52", values, { filters });

      // --------------------------------------------------------
      // No members
      // --------------------------------------------------------

      if (!members.length) {

        return serviceJson(context, {
          date,
          branchId,
          config,
          members: []
        });

      }


      const memberIds =
        members.map(
          m => m.id
        );


      // ========================================================
      // LOANS
      // ========================================================

      const {
        rows: loanRows
      } = await repository.queryNamed("collectionsService.js:181:53", [
          org,
          date,
          memberIds
        ], {  });


      // ========================================================
      // SAVINGS
      // ========================================================

      const {
        rows: savingsRows
      } = await repository.queryNamed("collectionsService.js:236:54", [
          org,
          memberIds
        ], {  });


      // ========================================================
      // INSURANCE
      // ========================================================

      const {
        rows: insuranceRows
      } = await repository.queryNamed("collectionsService.js:293:55", [
          org,
          memberIds
        ], {  });


      // ========================================================
      // MAP DATA
      // ========================================================

      const loansByMember =
        new Map();


      for (const l of loanRows) {

        const list =
          loansByMember.get(
            l.member_id
          ) || [];


        // Daily collection must expose the CURRENT collectible amount.
        // `due_today` is the remaining outstanding amount for all unpaid
        // installments due on/before the selected collection date.  This is
        // what the frontend must prefill; the scheduled installment amount
        // is retained separately for display/debugging only.
        list.push({
          loanId: l.loan_id,
          loanNumber: l.loan_number,
          outstandingAmount: money(l.outstanding_amount),
          installmentAmount: money(l.due_today),
          scheduledInstallmentAmount: money(l.scheduled_installment_amount),
          savingsAmount: money(l.default_savings_amount),
          depositAmount: money(l.opening_deposit_amount),
          dueTodayAmount: money(l.due_today),
          overdueAmount: money(l.overdue_amount),
          dueOnDateAmount: money(l.due_on_date),
          installmentFrequency: l.installment_frequency || 'monthly'
        });


        loansByMember.set(
          l.member_id,
          list
        );

      }


      const savingsByMember =
        new Map(
          savingsRows.map(
            r => [
              r.member_id,
              money(r.balance)
            ]
          )
        );


      const insuranceByMember =
        new Map(
          insuranceRows.map(
            r => [
              r.member_id,
              money(r.balance)
            ]
          )
        );


      // ========================================================
      // FINAL RESULT
      // ========================================================

      const result =
        members.map(
          m => ({

            memberId:
              m.id,

            memberCode:
              m.member_code,

            fullName:
              m.full_name,

            phone:
              m.phone || '',

            branchId:
              m.branch_id,

            loans:
              loansByMember.get(
                m.id
              ) || [],

            savingsBalance:
              savingsByMember.get(
                m.id
              ) || 0,

            insuranceBalance:
              insuranceByMember.get(
                m.id
              ) || 0

          })
        );


      
    let submittedFrequencies = [];
    try {
      const branchKeyRs = branchId ? String(branchId) : '';
      const fq = await repository.queryNamed("collectionsService.js:freq:list", [
        org, date, branchKeyRs || null
      ], {});
      submittedFrequencies = (fq.rows || []).map(r => ({
        frequency: r.frequency,
        names: (() => { try { return JSON.parse(r.names || '[]'); } catch(_) { return []; } })()
      }));
    } catch (_) {}

return serviceJson(context, {
      submittedFrequencies,

        date,

        branchId,

        config,

        members:
          result

      });

    } catch (e) {

      throw e;

    }

  
}

async function post_daily_4(context) {
  context.cookies ||= [];


    const parsed =
      dailySchema.safeParse(
        context.body
      );


    if (!parsed.success) {

      return serviceResponse(400, {

        error:
          'Invalid daily collection data',

        details:
          parsed.error.issues

      }, context);

    }


    const {
      branchId: requestedBranchId,
      entries,
      dailyExpense = 0,
      dailyExpenseIdempotencyKey = ''
    } = parsed.data;

    // parsed.data.date only guarantees YYYY-MM-DD *shape* (regex) — it does
    // not guarantee a real calendar date (e.g. 2026-02-31 would pass). Run
    // it through the same check get_route_sheet_3 already uses so a value
    // like that can't reach payment/receipt numbers or a DATE column below.
    const date = getValidCollectionDate(parsed.data.date);


    const org =
      context.auth.organization_id;


    const config =
      await loadCollectionConfig(
        org
      );


    let branchId;


    try {

      branchId =
        isOrganizationWide(context.auth)
          ? (
              requestedBranchId ||
              null
            )
          : enforceRequestedBranch(
              context.auth,
              requestedBranchId ||
              context.auth.branch_id
            );

    } catch (e) {

      return serviceResponse(e.status || 403, {
        error:
          e.message
      }, context);

    }


    if (
      !isOrganizationWide(context.auth) &&
      !context.auth.branch_id
    ) {

      return serviceResponse(403, {
        error:
          'Your account is not assigned to a branch'
      }, context);

    }


    if (branchId) {

      const b =
        await repository.queryNamed("collectionsService.js:85:56", [
            branchId,
            org
          ], {  });


      if (!b.rows[0]) {

        return serviceResponse(400, {
          error:
            'Invalid branch'
        }, context);

      }

    }



    // ========================================================
    // Once-per-day-per-frequency lock (server-side)
    // ========================================================
    const frequency = String(parsed.data.frequency || 'monthly').toLowerCase();
    const branchKey = branchId ? String(branchId) : '';
    let collectionLockId = null;
    try {
      const reserved = await repository.queryNamed("collectionsService.js:freq:reserve", [
        org, branchKey, date, frequency, context.auth.user_id
      ], {});
      if (!reserved.rows[0]) {
        const closed = await repository.queryNamed("collectionsService.js:freq:lookup", [
          org, date, branchKey, frequency
        ], {});
        return serviceResponse(409, {
          error: `আজকের জন্য ${frequency} কিস্তির কালেকশন ইতিমধ্যে জমা দেওয়া হয়েছে অথবা প্রক্রিয়াধীন আছে।`,
          code: 'FREQUENCY_ALREADY_SUBMITTED',
          frequency,
          date,
          submittedAt: closed.rows[0]?.created_at || null
        }, context);
      }
      collectionLockId = reserved.rows[0].id;
    } catch (e) {
      console.warn('[IMP] daily-collection lock reservation failed:', e.message);
      return serviceResponse(503, { error: 'Unable to verify daily collection status. Please try again.' }, context);
    }


    const results = [];


    const summary = {

      totalInstallment:
        0,

      totalSavings:
        0,

      successCount:
        0,

      failureCount:
        0

    };


    // ========================================================
    // Process each entry independently
    // ========================================================

    for (
      const entry of entries
    ) {

      const tx =
        await repository.begin();


      const entryResult = {

        memberId:
          entry.memberId,

        loanId:
          entry.loanId ||
          null,

        success:
          false

      };


      try {

        // Baki-only entry: track status, no money movement
        if (
          entry.status === 'baki' &&
          Number(entry.installmentAmount || 0) <= 0 &&
          Number(entry.savingsAmount || 0) <= 0
        ) {
          await tx.begin();

          const member =
            await tx.queryNamed("collectionsService.js:234:58", [
                entry.memberId,
                org
              ], {  });

          if (!member.rows[0]) {
            throw Object.assign(
              new Error('Member not found in this organization'),
              { httpStatus: 400 }
            );
          }

          const memberBranch = member.rows[0].branch_id;

          if (!isOrganizationWide(context.auth)) {
            assertBranchAccess(context.auth, memberBranch);
          }

          if (
            branchId &&
            String(branchId) !== String(memberBranch)
          ) {
            throw Object.assign(
              new Error('Member does not belong to the selected branch'),
              { httpStatus: 403 }
            );
          }

          await tx.queryNamed("collectionsService.js:169:57", [org, context.auth.user_id, entry.memberId, JSON.stringify({
              date,
              loanId: entry.loanId || null,
              notes: entry.notes || '',
              status: 'baki'
            })], {  });
          await tx.commit();
          entryResult.success = true;
          entryResult.status = 'baki';
          summary.successCount += 1;
          results.push(entryResult);
          continue;
        }

        // ------------------------------------------------------
        // Settings checks
        // ------------------------------------------------------

        if (
          entry.installmentAmount > 0 &&
          !config.collectionTypes.installment
        ) {

          throw Object.assign(
            new Error(
              'Loan installment collection is disabled in Settings → দৈনিক কালেকশন'
            ),
            {
              httpStatus:
                400
            }
          );

        }


        if (
          entry.savingsAmount > 0 &&
          !config.collectionTypes.savings
        ) {

          throw Object.assign(
            new Error(
              'Savings collection is disabled in Settings → দৈনিক কালেকশন'
            ),
            {
              httpStatus:
                400
            }
          );

        }

        await tx.begin();


        // ------------------------------------------------------
        // Member validation
        // ------------------------------------------------------

        const member =
          await tx.queryNamed("collectionsService.js:234:58", [
              entry.memberId,
              org
            ], {  });


        if (!member.rows[0]) {

          throw Object.assign(
            new Error(
              'Member not found in this organization'
            ),
            {
              httpStatus:
                400
            }
          );

        }


        const memberBranch =
          member.rows[0].branch_id;


        if (!isOrganizationWide(context.auth)) {
          assertBranchAccess(context.auth, memberBranch);
        }


        if (
          branchId &&
          String(branchId) !==
          String(memberBranch)
        ) {

          throw Object.assign(
            new Error(
              'Member does not belong to the selected branch'
            ),
            {
              httpStatus:
                403
            }
          );

        }


        // Track this entry's contribution locally. It is only added to the
        // batch-wide `summary` totals after the transaction actually commits
        // — adding it earlier let a later failure within the SAME entry
        // (e.g. installment succeeds, savings then throws) roll the DB write
        // back while the already-incremented summary numbers stayed, so a
        // fully-failed batch could still report a nonzero totalCollected.
        let entryInstallmentAmount = 0;
        let entrySavingsAmount = 0;

        // ------------------------------------------------------
        // Installment
        // ------------------------------------------------------

        if (
          entry.installmentAmount > 0
        ) {

          const r =
            await collectInstallment(
              tx,
              org,
              context.auth,
              entry.memberId,
              entry.loanId,
              money(
                entry.installmentAmount
              ),
              date,
              entry.paymentMethod,
              entry.notes,
              config.requireNoteOnAdvance,
              config.allowAdvance,
              entry.idempotencyKey ? `${entry.idempotencyKey}:installment` : null
            );


          Object.assign(
            entryResult,
            r
          );


          entryInstallmentAmount =
            entry.installmentAmount;

        }


        // ------------------------------------------------------
        // Savings
        // ------------------------------------------------------

        if (
          entry.savingsAmount > 0
        ) {

          const r =
            await collectSavings(
              tx,
              org,
              context.auth,
              entry.memberId,
              memberBranch,
              entry.loanId,
              money(
                entry.savingsAmount
              ),
              date,
              entry.notes,
              entry.idempotencyKey ? `${entry.idempotencyKey}:savings` : null
            );


          Object.assign(
            entryResult,
            r
          );


          entrySavingsAmount =
            entry.savingsAmount;

        }


        // ------------------------------------------------------
        await tx.commit();


        entryResult.success =
          true;


        summary.successCount +=
          1;

        summary.totalInstallment =
          money(
            summary.totalInstallment +
            entryInstallmentAmount
          );

        summary.totalSavings =
          money(
            summary.totalSavings +
            entrySavingsAmount
          );


      } catch (e) {

        await tx.rollback();


        // Discard any partial fields (e.g. a paymentId from a step of this
        // entry that succeeded before a later step in the same transaction
        // threw and rolled everything back) — only the identifying fields
        // and the error should survive a failed entry.
        results.push({
          memberId: entry.memberId,
          loanId: entry.loanId || null,
          success: false,
          error: e.message || 'Unable to record this entry'
        });


        summary.failureCount +=
          1;


        continue;


      } finally {

        tx.release();

      }


      results.push(
        entryResult
      );

    }


    // Release the reserved lock now if nothing in this batch succeeded, so
    // a genuine retry isn't blocked — done here, before any further
    // (unguarded) queries below, so it still runs even if one of those
    // later steps throws.
    if (summary.successCount === 0 && collectionLockId) {
      try {
        await repository.queryNamed("collectionsService.js:freq:release", [collectionLockId, org], {});
      } catch (e) {
        console.warn('[IMP] daily-collection lock release failed:', e.message);
      }
    }

    // ========================================================
    // SUMMARY
    // ========================================================

    summary.totalCollected =
      money(
        summary.totalInstallment +
        summary.totalSavings
      );
    summary.dailyExpense = money(dailyExpense || 0);
    summary.netCollection = money(
      summary.totalCollected - summary.dailyExpense
    );

    // Record daily expense only when at least one collection entry succeeded.
    // Avoid posting expense against a fully failed collection batch.
    const attemptedExpenseSave = Number(dailyExpense) > 0 && summary.successCount > 0;
    let dailyExpenseSaved = Number(dailyExpense) <= 0;
    if (attemptedExpenseSave) {
      try {
        if (dailyExpenseIdempotencyKey) {
          const dup = await repository.queryNamed("collectionsService.js:idem:expenseLookup", [org, dailyExpenseIdempotencyKey], {  });
          if (dup.rows[0]) { dailyExpenseSaved = true; }
        }
        if (!dailyExpenseSaved) {
          await repository.queryNamed("collectionsService.js:438:59", [
              org,
              branchId || null,
              dailyExpense,
              date,
              'Daily collection field expense',
              context.auth.user_id,
              dailyExpenseIdempotencyKey || null
            ], {  });
          dailyExpenseSaved = true;
        }
      } catch (expErr) {
        console.error('[IMP] daily expense insert failed:', expErr.message);
        dailyExpenseSaved = false;
      }
    }
    summary.dailyExpenseSaved = dailyExpenseSaved;
    if (!dailyExpenseSaved) {
      summary.dailyExpenseWarning = Number(dailyExpense) > 0 && summary.successCount === 0
        // No entry succeeded at all — the expense was intentionally never
        // attempted (see the guard above), so the message must not claim
        // collections succeeded.
        ? 'দৈনিক খরচ সংরক্ষণ করা হয়নি — কারণ এই ব্যাচের কোনো কালেকশন এন্ট্রিই সফল হয়নি। ব্যয়টি পরে আলাদাভাবে যোগ করুন।'
        : 'দৈনিক খরচ সংরক্ষণ করা যায়নি — কালেকশন এন্ট্রিগুলো সফল হয়েছে, কিন্তু ব্যয় রেকর্ডটি পুনরায় দিতে হবে।';
    }

    await repository.queryNamed("collectionsService.js:463:60", [
        org,
        context.auth.user_id,

        JSON.stringify({

          date,

          branchId,

          entryCount:
            entries.length,

          ...summary

        })
      ], {  });


    // The lock row reserved at the very start of this request is what now
    // closes this date+branch+frequency against further submissions when
    // at least one entry succeeded (already released above otherwise).

    return serviceResponse(summary.failureCount > 0 &&
      summary.successCount === 0
        ? 400
        : 201, {

      date,

      branchId,

      frequency,

      frequencyClosed: summary.successCount > 0,

      results,

      summary

    }, context);

  
}

module.exports = { get_config_1, put_config_2, get_route_sheet_3, post_daily_4 };
