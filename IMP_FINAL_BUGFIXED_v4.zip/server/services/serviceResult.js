'use strict';

/**
 * Transport-neutral application result.
 * Services return data + outcome metadata; Express stays in controllers.
 */
function serviceResponse(status = 200, body = null, context = null, meta = {}) {
  const cookies = Array.isArray(context?.cookiesOut) ? context.cookiesOut.slice() : [];
  return Object.freeze({
    kind: 'application-result',
    status,
    body,
    cookies,
    ...meta
  });
}

function serviceJson(context, body, status = 200) {
  return serviceResponse(status, body, context);
}

function setResponseCookie(context, name, value, options = {}) {
  if (!context) throw new TypeError('context is required');
  context.cookiesOut ||= [];
  context.cookiesOut.push({ op: 'set', name, value, options: { ...options } });
}

function clearResponseCookie(context, name, options = {}) {
  if (!context) throw new TypeError('context is required');
  context.cookiesOut ||= [];
  context.cookiesOut.push({ op: 'clear', name, options: { ...options } });
}

module.exports = {
  serviceResponse,
  serviceJson,
  setResponseCookie,
  clearResponseCookie
};
