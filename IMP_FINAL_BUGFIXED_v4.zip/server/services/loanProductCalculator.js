'use strict';
function money(n){return Number(Number(n).toFixed(2));}
function periodsPerYear(frequency){switch(String(frequency||'monthly').toLowerCase()){case 'daily':return 365;case 'weekly':return 52;case 'biweekly':return 26;case 'quarterly':return 4;case 'yearly':case 'annual':return 1;default:return 12;}}
function roundSchedule(rows,totalPrincipal,totalInterest){
  if(!rows.length)return rows;
  const rounded=rows.map(r=>({...r,interest:money(r.interest),principal:money(r.principal),payment:money(r.payment),balance:money(r.balance)}));
  const last=rounded[rounded.length-1];
  const priorPrincipal=money(rounded.slice(0,-1).reduce((s,r)=>s+r.principal,0));
  const priorInterest=money(rounded.slice(0,-1).reduce((s,r)=>s+r.interest,0));
  const priorPayments=money(rounded.slice(0,-1).reduce((s,r)=>s+r.payment,0));
  last.interest=money(totalInterest-priorInterest);
  last.payment=money(totalPrincipal+totalInterest-priorPayments);
  last.principal=money(last.payment-last.interest);
  last.balance=0;
  return rounded;
}
function calculateLoanProduct({amount,installments,interestRate,interestMethod,frequency}){
  amount=Number(amount);installments=Number(installments);const rate=Number(interestRate||0);const method=String(interestMethod||'flat').toLowerCase();
  if(!(amount>0)||!(installments>0)||rate<0)throw new Error('Invalid loan calculation inputs');
  const ppy=periodsPerYear(frequency); const periodicRate=rate/100/ppy;
  let schedule=[];
  if(method==='flat'||method==='simple'||method==='fixed_interest'){
    const interest=money(amount*rate/100), total=money(amount+interest), basePrincipal=amount/installments, baseInterest=interest/installments;
    let balance=total;
    for(let i=1;i<=installments;i++){const principal=i===installments?money(amount-basePrincipal*(installments-1)):money(basePrincipal);const interestPart=i===installments?money(interest-baseInterest*(installments-1)):money(baseInterest);const payment=money(principal+interestPart);balance=money(Math.max(0,balance-payment));schedule.push({installment:i,principal,interest:interestPart,payment,balance});}
    schedule=roundSchedule(schedule,amount,interest);
    return {method,principal:money(amount),interest,totalPayable:total,installmentAmount:money(total/installments),schedule};
  }
  if(['reducing_balance','reducing','declining_balance','amortized','emi'].includes(method)){
    const payment=periodicRate===0?amount/installments:amount*periodicRate/(1-Math.pow(1+periodicRate,-installments));
    let balance=amount,totalInterest=0;
    for(let i=1;i<=installments;i++){const interestPart=balance*periodicRate;const principal=Math.min(balance,payment-interestPart);const actual=principal+interestPart;balance=Math.max(0,balance-principal);totalInterest+=interestPart;schedule.push({installment:i,principal,interest:interestPart,payment:actual,balance});}
    const roundedInterest=money(totalInterest);const total=money(amount+roundedInterest);schedule=roundSchedule(schedule,amount,roundedInterest);return {method,principal:money(amount),interest:roundedInterest,totalPayable:total,installmentAmount:money(total/installments),schedule};
  }
  if(method==='compound'){
    const total=money(amount*Math.pow(1+rate/100,installments/ppy));const interest=money(total-amount);const payment=total/installments;let balance=total;
    for(let i=1;i<=installments;i++){const interestPart=interest/installments;const principalPart=payment-interestPart;balance=money(Math.max(0,balance-payment));schedule.push({installment:i,principal:principalPart,interest:interestPart,payment,balance});}
    schedule=roundSchedule(schedule,amount,interest);
    return {method,principal:money(amount),interest,totalPayable:total,installmentAmount:money(total/installments),schedule};
  }
  throw new Error(`Unsupported interest method: ${interestMethod}`);
}
module.exports={calculateLoanProduct,periodsPerYear};
