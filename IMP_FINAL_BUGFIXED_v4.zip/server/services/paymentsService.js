'use strict';

const { serviceResponse, serviceJson } = require('./serviceResult');


const { z } = require('zod');
const repository = require('../repositories');

const { isOrganizationWide, assertBranchAccess, enforceRequestedBranch } = require('../application/accessScope');


;
const METHODS = ['cash','bkash','nagad','rocket','bank_transfer','cheque','other'];
const STATUSES = ['posted','cancelled','reversed'];
const createSchema = z.object({
  memberId: z.string().uuid(), loanId: z.string().uuid(), amount: z.coerce.number().positive(),
  paymentDate: z.string().datetime(), paymentMethod: z.enum(METHODS),
  transactionReference: z.string().trim().max(255).optional().default(''),
  bankName: z.string().trim().max(200).optional().default(''),
  bankAccount: z.string().trim().max(100).optional().default(''),
  collectorId: z.string().uuid().nullable().optional(), notes: z.string().trim().max(5000).optional().default(''),
  allowAdvance: z.boolean().optional().default(false)
}).strict();

const cancelSchema = z.object({ reason: z.string().trim().max(1000).optional().default('Administrative cancellation') }).strict();

function money(v) { return Number(v); }
function toPayment(r) {
  const source = r.source || (r.from_daily_collection ? 'daily_collection' : 'manual');
  return { id:r.id, paymentId:r.id, organizationId:r.organization_id, branchId:r.branch_id, memberId:r.member_id,
    loanId:r.loan_id, paymentNumber:r.payment_number, amount:money(r.amount), paymentDate:r.payment_date,
    paymentMethod:r.payment_method, transactionReference:r.transaction_reference || '', bankName:r.bank_name || '',
    bankAccount:r.bank_account || '', collectorId:r.collector_id, notes:r.notes || '', status:r.status,
    source,
    idempotencyKey:r.idempotency_key, createdBy:r.created_by, createdAt:r.created_at, updatedAt:r.updated_at };
}
function toAllocation(r) { return { id:r.id, allocationId:r.id, organizationId:r.organization_id, paymentId:r.payment_id,
  loanId:r.loan_id, installmentId:r.installment_id, allocationType:r.allocation_type, amount:money(r.amount), status:r.status,
  createdAt:r.created_at, cancelledAt:r.cancelled_at, reversedAt:r.reversed_at }; }

async function audit(tx, auth, action, entityId, metadata={}) {
  await tx.queryNamed("paymentsService.js:39:201", [auth.organization_id,auth.user_id,action,entityId,JSON.stringify(metadata)], {  });
}
async function loadPayment(tx,id,org,lock=false) {
  const r=await tx.queryNamed("paymentsService.js:44:202", [id,org], { lock: Boolean(lock) });
  return r.rows[0] || null;
}

;

;

/**
 * 11.P.17 — Payment Dashboard / Reports data source.
 * Replaces the legacy js/payments/paymentCollectionReport.js +
 * paymentReportService.js, which computed everything from a
 * `localStorage` payments list that the real payment flow never writes
 * to (payments are created here, server-side, in Postgres). Same filters,
 * same aggregate shapes the existing dashboard/report render functions
 * already expect — only the data source changes.
 */
;

/**
 * Data-integrity check: does each payment's amount match the sum of its
 * active allocations? Mirrors the rules the old tx-only
 * paymentReconciliation.js applied, now run against the real ledger.
 */
;


;
;

;

async function changeStatus(context,target,permission,auditAction,reason){
  if(!context.auth)return serviceResponse(401, {error:'Authentication required'}, context); if(!context.auth.permissions.includes(permission))return serviceResponse(403, {error:'Forbidden'}, context);
  const org=context.auth.organization_id,tx=await repository.begin(); try{await tx.begin();const p=await loadPayment(tx,context.params.id,org,true);if(!p){await tx.rollback();return serviceResponse(404, {error:'Payment not found'}, context);}if(p.status!=='posted'){await tx.rollback();return serviceResponse(409, {error:`Only posted payments can be ${target}`}, context);}
    const alloc=await tx.queryNamed("paymentsService.js:78:203", [org,p.id], {  });
    for(const a of alloc.rows){if(a.installment_id){const s=await tx.queryNamed("paymentsService.js:79:204", [a.installment_id,org], {  });if(s.rows[0]){const paid=Math.max(0,Number(s.rows[0].paid_amount)-Number(a.amount)),out=Math.min(Number(s.rows[0].installment_amount),Number(s.rows[0].outstanding_amount)+Number(a.amount));const st=paid===0?'pending':out===0?'paid':'partial';await tx.queryNamed("paymentsService.js:79:205", [paid,out,st,a.installment_id,org], {  });}}
      await tx.queryNamed("paymentsService.js:80:206", [target,a.id,org], { target: target });}
    const loan=await tx.queryNamed("paymentsService.js:81:207", [p.loan_id,org], {  });
    await tx.queryNamed("paymentsService.js:82:208", [Number(p.amount),p.loan_id,org], {  });
    await tx.queryNamed("paymentsService.js:83:209", [target,p.id,org], {  });
    await tx.queryNamed("paymentsService.js:84:210", [p.id,org], {  });
    await audit(tx,context.auth,auditAction,p.id,{amount:Number(p.amount),reason:reason||'',previousStatus:'posted',newStatus:target});await tx.commit();return serviceJson(context, {payment:toPayment({...p,status:target})});
  }catch(e){await tx.rollback();throw e;}finally{tx.release();}
}
;
;
;



async function guard_payments(context) {
  context.cookies ||= [];

  if (isOrganizationWide(context.auth) || !context.params.id) return null;
  try {
    const {rows}=await repository.queryNamed("paymentsService.js:4:170", [context.params.id,context.auth.organization_id], {  });
    if(!rows[0]) return serviceResponse(404, {error:'Payment not found'}, context);
    if(!context.auth.branch_id || String(rows[0].branch_id)!==String(context.auth.branch_id)) return serviceResponse(403, {error:'Branch access denied'}, context);
    return null;
  }catch(e){throw e;}

}

const PAYMENT_LIST_FILTER_FIELDS = [
  ['member_id', 'memberId'],
  ['loan_id', 'loanId'],
  ['payment_method', 'paymentMethod'],
  ['status', 'status'],
  ['collector_id', 'collectorId'],
  ['source', 'source']
];

async function get_root_1(context) {
  context.cookies ||= [];

  try {
    const org=context.auth.organization_id, values=[org], filters=[];
    if (!isOrganizationWide(context.auth)) { if (!context.auth.branch_id) filters.push('denyAll'); else { values.push(context.auth.branch_id); filters.push('branchId'); } }
    for(const [db,key] of PAYMENT_LIST_FILTER_FIELDS){ const v=context.query[key]; if(typeof v==='string'&&v){ values.push(v); filters.push(key==='memberId'?'memberId':key==='loanId'?'loanId':key==='paymentMethod'?'paymentMethod':key==='collectorId'?'collectorId':key==='source'?'source':'status'); } }
    if(typeof context.query.fromDate==='string'&&context.query.fromDate){values.push(context.query.fromDate);filters.push('fromTimestamp');}
    if(typeof context.query.toDate==='string'&&context.query.toDate){values.push(context.query.toDate);filters.push('toDate');}
    const limit=Math.min(Math.max(parseInt(context.query.limit||'100',10)||100,1),500), offset=Math.max(parseInt(context.query.offset||'0',10)||0,0); values.push(limit,offset);
    const {rows}=await repository.queryNamed("paymentsService.js:11:171", values, { filters });
    return serviceJson(context, {payments:rows.map(toPayment),pagination:{limit,offset,returned:rows.length}});
  }catch(e){throw e;}

}

async function post_root_2(context) {
  context.cookies ||= [];

  const parsed=createSchema.safeParse(context.body); if(!parsed.success)return serviceResponse(400, {error:'Invalid payment data'}, context);
  const d=parsed.data, org=context.auth.organization_id, idem=(context.headers?.['idempotency-key'] || context.headers?.['Idempotency-Key'] || '').trim().slice(0,150), tx=await repository.begin();
  try {
    await tx.begin();
    if(idem){ const existing=await tx.queryNamed("paymentsService.js:6:172", [org,idem], {}); if(existing.rows[0]){await tx.commit();return serviceResponse(200, {payment:toPayment(existing.rows[0]),idempotent:true}, context);} }
    const loanQ=await tx.queryNamed("paymentsService.js:7:173", [d.loanId,org], {  });
    const loan=loanQ.rows[0]; if(!loan){await tx.rollback();return serviceResponse(404, {error:'Loan not found'}, context);}
    if(!['disbursed','active'].includes(loan.status)){await tx.rollback();return serviceResponse(409, {error:'Payments can only be posted to disbursed or active loans'}, context);}
    if(loan.member_id!==d.memberId){await tx.rollback();return serviceResponse(400, {error:'Member does not belong to loan'}, context);}
    if(!isOrganizationWide(context.auth)) assertBranchAccess(context.auth, loan.branch_id);
    if(d.collectorId){const u=await tx.queryNamed("paymentsService.js:12:174", [d.collectorId,org], {  });if(!u.rows[0]){await tx.rollback();return serviceResponse(400, {error:'Collector not found in organization'}, context);}if(!isOrganizationWide(context.auth))assertBranchAccess(context.auth,u.rows[0].branch_id);}
    const outstanding=Number(loan.outstanding_amount), amount=Number(d.amount.toFixed(2));
    if(amount>outstanding && !d.allowAdvance){await tx.rollback();return serviceResponse(409, {error:'Payment exceeds loan outstanding balance'}, context);}
    const seq=await tx.queryNamed("paymentsService.js:15:175", [], {  }); const paymentNumber=`PAY-${new Date().toISOString().slice(0,10).replace(/-/g,'')}-${String(seq.rows[0].n).padStart(8,'0')}`;
    const ins=await tx.queryNamed("paymentsService.js:16:176", [org,loan.branch_id,d.memberId,d.loanId,paymentNumber,amount,d.paymentDate,d.paymentMethod,d.transactionReference||null,d.bankName||null,d.bankAccount||null,d.collectorId||null,d.notes||null,idem||null,context.auth.user_id], {});
    const payment=ins.rows[0]; let remaining=amount; const allocations=[];
    const schedules=await tx.queryNamed("paymentsService.js:20:177", [org,d.loanId], {  });
    for(const s of schedules.rows){ if(remaining<=0)break; const a=Math.min(remaining,Number(s.outstanding_amount)); if(a<=0)continue; remaining=Number((remaining-a).toFixed(2));
      const ar=await tx.queryNamed("paymentsService.js:22:178", [org,payment.id,d.loanId,s.id,a], {  }); allocations.push(ar.rows[0]);
      const paid=Number(s.paid_amount)+a, out=Math.max(0,Number(s.outstanding_amount)-a), st=out===0?'paid':paid>0?'partial':s.status;
      await tx.queryNamed("paymentsService.js:24:179", [paid,out,st,d.paymentDate.slice(0,10),s.id,org], {  });
    }
    if(remaining>0){if(!d.allowAdvance){await tx.rollback();return serviceResponse(409,{error:'Payment allocation resulted in leftover amount. Enable allowAdvance or reduce payment amount.',remaining:Number(remaining.toFixed(2))},context);}const ar=await tx.queryNamed("paymentsService.js:26:180", [org,payment.id,d.loanId,remaining], {  });allocations.push(ar.rows[0]);remaining=0;}
    const newOutstanding=Math.max(0,outstanding-amount);
    await tx.queryNamed("paymentsService.js:28:181", [newOutstanding,d.loanId,org], {  });
    const rseq=await tx.queryNamed("paymentsService.js:29:182", [], {  }); const receiptNumber=`RCP-${new Date().toISOString().slice(0,10).replace(/-/g,'')}-${String(rseq.rows[0].n).padStart(8,'0')}`;
    await tx.queryNamed("paymentsService.js:30:183", [org,payment.id,receiptNumber,context.auth.user_id], {  });
    await audit(tx,context.auth,'PAYMENT_CREATED',payment.id,{amount,payment_number:paymentNumber,allocation_count:allocations.length});
    await tx.commit(); return serviceResponse(201, {payment:toPayment(payment),allocations:allocations.map(toAllocation),receiptNumber}, context);
  }catch(e){await tx.rollback();if(e.code==='23505'&&idem)return serviceResponse(409, {error:'Idempotency key already used'}, context);throw e;}finally{tx.release();}

}

async function get_collection_report_3(context) {
  context.cookies ||= [];

  try {
    const org = context.auth.organization_id;
    const values = [org];
    const filters = [];
    if (!isOrganizationWide(context.auth)) { if (!context.auth.branch_id) filters.push('denyAll'); else { values.push(context.auth.branch_id); filters.push('branchId'); } }
    if (context.query.fromDate) { values.push(context.query.fromDate); filters.push('fromDate'); }
    if (context.query.toDate) { values.push(context.query.toDate); filters.push('toDate'); }
    if (context.query.memberId) { values.push(context.query.memberId); filters.push('memberId'); }
    if (context.query.loanId) { values.push(context.query.loanId); filters.push('loanId'); }
    if (context.query.collectorId) { values.push(context.query.collectorId); filters.push('collectorId'); }
    if (context.query.paymentMethod) { values.push(context.query.paymentMethod); filters.push('paymentMethod'); }
    if (context.query.branchId) { values.push(context.query.branchId); filters.push('branchId'); }
    if (context.query.status) { values.push(context.query.status); filters.push('status'); }
    if (context.query.source) { values.push(context.query.source); filters.push('source'); }

    const branchForOverdue = (!isOrganizationWide(context.auth) && context.auth.branch_id)
      ? context.auth.branch_id
      : (context.query.branchId || null);
    const overdueValues = branchForOverdue ? [org, branchForOverdue] : [org];
    const [summaryQ, allocQ, byMethodQ, byCollectorQ, byMemberQ, byLoanQ, dailyQ, monthlyQ, paymentsQ, overdueQ] = await Promise.all([
      repository.queryNamed("paymentsService.js:18:184", values, { filters }),
      repository.queryNamed("paymentsService.js:23:185", values, { filters }),
      repository.queryNamed("paymentsService.js:27:186", values, { filters }),
      repository.queryNamed("paymentsService.js:29:187", values, { filters }),
      repository.queryNamed("paymentsService.js:34:188", values, { filters }),
      repository.queryNamed("paymentsService.js:38:189", values, { filters }),
      repository.queryNamed("paymentsService.js:41:190", values, { filters }),
      repository.queryNamed("paymentsService.js:43:191", values, { filters }),
      repository.queryNamed("paymentsService.js:45:192", values, { filters }),
      repository.queryNamed("paymentsService.js:overdueMembers", overdueValues, { hasBranch: Boolean(branchForOverdue) })
    ]);

    const s = summaryQ.rows[0], a = allocQ.rows[0];
    const installmentAmount = money(a.installment_amount), advanceAmount = money(a.advance_amount);
    return serviceJson(context, {
      summary: {
        paymentCount: Number(s.payment_count), postedAmount: money(s.posted_amount),
        cancelledAmount: money(s.cancelled_amount), averagePayment: money(s.average_payment),
        installmentAmount, advanceAmount, allocatedAmount: money(installmentAmount + advanceAmount)
      },
      payments: paymentsQ.rows.map(r => ({ id:r.id, paymentDate:r.payment_date, amount:money(r.amount), status:r.status, source: r.from_daily_collection ? 'daily_collection' : (r.source||'manual'), paymentMethod:r.payment_method, memberId:r.member_id, loanId:r.loan_id, collectorId:r.collector_id })),
      byMethod: byMethodQ.rows.map(r => ({ name:r.name, count:Number(r.count), amount:money(r.amount) })),
      byCollector: byCollectorQ.rows.map(r => ({ collectorId:r.collector_id, collectorName:r.collector_name||'', count:Number(r.count), amount:money(r.amount), cash:money(r.cash), digital:money(r.digital) })),
      byMember: byMemberQ.rows.map(r => ({ memberId:r.member_id, memberName:r.member_name||'', memberCode:r.member_code||'', count:Number(r.count), amount:money(r.amount), lastPaymentDate:r.last_payment_date })),
      byLoan: byLoanQ.rows.map(r => ({ loanId:r.loan_id, loanNumber:r.loan_number||'', memberId:r.member_id, memberName:r.member_name||'', count:Number(r.count), amount:money(r.amount) })),
      daily: dailyQ.rows.map(r => ({ date:r.date, count:Number(r.count), amount:money(r.amount), dailyCollectionCount:Number(r.daily_collection_count||0), dailyCollectionAmount:money(r.daily_collection_amount||0) })),
      monthly: monthlyQ.rows.map(r => ({ month:r.month, count:Number(r.count), amount:money(r.amount) })),
      arrearsMembers: (overdueQ.rows||[]).map(r => ({
        memberId: r.member_id,
        memberCode: r.member_code||'',
        memberName: r.member_name||'',
        overdueAmount: money(r.overdue_amount),
        lastPaymentDate: r.last_payment_date||null,
        isBaki: true
      })),
      paidMemberCount: new Set((paymentsQ.rows||[]).map(r => String(r.member_id))).size,
      bakiMemberCount: (overdueQ.rows||[]).length
    });
  } catch (e) { throw e; }

}

async function get_reconciliation_4(context) {
  context.cookies ||= [];

  try {
    const org = context.auth.organization_id;
    const values = [org];
    const filters = [];
    if (!isOrganizationWide(context.auth)) { if (!context.auth.branch_id) filters.push('denyAll'); else { values.push(context.auth.branch_id); filters.push('branchId'); } }
    if (context.query.fromDate) { values.push(context.query.fromDate); filters.push('fromDate'); }
    if (context.query.toDate) { values.push(context.query.toDate); filters.push('toDate'); }
    if (context.query.memberId) { values.push(context.query.memberId); filters.push('memberId'); }
    if (context.query.loanId) { values.push(context.query.loanId); filters.push('loanId'); }
    if (context.query.status) { values.push(context.query.status); filters.push('status'); }
    const limit = Math.min(Math.max(parseInt(context.query.limit || '500', 10) || 500, 1), 2000);
    const { rows } = await repository.queryNamed("paymentsService.js:14:193", values, { filters, limit });

    const results = rows.map(r => {
      const paymentAmount = money(r.amount), allocatedAmount = money(r.allocated_amount);
      const difference = money(paymentAmount - allocatedAmount);
      const issues = [];
      if (Math.abs(difference) > 0.01) issues.push('Payment amount and allocation amount do not match.');
      if (r.status === 'posted' && Number(r.allocation_count) === 0) issues.push('Posted payment has no allocation record.');
      if (r.status !== 'posted' && Number(r.allocation_count) > 0) issues.push('Cancelled/reversed payment still has active allocation records.');
      if (Number(r.non_positive) > 0) issues.push('One or more allocations have an invalid (non-positive) amount.');
      if (Number(r.bad_installment) > 0) issues.push('An installment allocation is missing its installment reference.');
      if (Number(r.bad_advance) > 0) issues.push('An advance allocation should not reference an installment.');
      return { paymentId:r.id, memberId:r.member_id, loanId:r.loan_id, paymentStatus:r.status, paymentAmount, allocatedAmount,
        difference, allocationCount:Number(r.allocation_count), status: issues.length ? 'mismatch' : 'matched', issues };
    });
    const mismatches = results.filter(r => r.status === 'mismatch');
    return serviceJson(context, { results, summary: { total: results.length, matchedCount: results.length - mismatches.length,
      mismatchCount: mismatches.length, totalDifference: money(mismatches.reduce((t, r) => t + r.difference, 0)) } });
  } catch (e) { throw e; }

}

async function get_id_5(context) {
  context.cookies ||= [];
try{const tx = await repository.begin();try{const p=await loadPayment(tx,context.params.id,context.auth.organization_id);if(!p)return serviceResponse(404, {error:'Payment not found'}, context);const a=await tx.queryNamed("paymentsService.js:1:194", [context.auth.organization_id,p.id], {  });const r=await tx.queryNamed("paymentsService.js:1:195", [context.auth.organization_id,p.id], {  });return serviceJson(context, {payment:toPayment(p),allocations:a.rows.map(toAllocation),receipt:r.rows[0]||null});}finally{tx.release();}}catch(e){throw e;}
}

async function get_id_allocations_6(context) {
  context.cookies ||= [];
try{const {rows}=await repository.queryNamed("paymentsService.js:1:196", [context.auth.organization_id,context.params.id], {  });return serviceJson(context, {allocations:rows.map(toAllocation)});}catch(e){throw e;}
}

async function get_id_audit_7(context) {
  context.cookies ||= [];

  try {
    const org=context.auth.organization_id;
    const {rows:paymentRows}=await repository.queryNamed("paymentsService.js:4:197", [context.params.id,org], {  });
    if(!paymentRows[0]) return serviceResponse(404, {error:'Payment not found'}, context);
    const {rows}=await repository.queryNamed("paymentsService.js:6:198", [org,context.params.id], {  });
    return serviceJson(context, {audits:rows.map(r=>({id:r.id,action:r.action,previousStatus:r.metadata?.previousStatus||null,newStatus:r.metadata?.newStatus||null,amount:Number(r.metadata?.amount||0),reason:r.metadata?.reason||'',performedBy:r.user_name||r.user_id||'-',performedAt:r.created_at,metadata:r.metadata||{}}))});
  }catch(e){throw e;}

}

async function post_id_cancel_8(context) {
  context.cookies ||= [];
const p=cancelSchema.safeParse(context.body||{});if(!p.success)return serviceResponse(400, {error:'Invalid cancellation data'}, context);return changeStatus(context,'cancelled','payment.cancel','PAYMENT_CANCELLED',p.data.reason);
}

async function post_id_reverse_9(context) {
  context.cookies ||= [];
const p=cancelSchema.safeParse(context.body||{});if(!p.success)return serviceResponse(400, {error:'Invalid reversal data'}, context);return changeStatus(context,'reversed','payment.reverse','PAYMENT_REVERSED',p.data.reason);
}

async function get_id_receipt_10(context) {
  context.cookies ||= [];

  try {
    const org=context.auth.organization_id, tx = await repository.begin();
    try {
      const q=await tx.queryNamed("paymentsService.js:5:199", [org,context.params.id], {  });
      if(!q.rows[0]) return serviceResponse(404, {error:'Receipt not found'}, context);
      const r=q.rows[0], a=await tx.queryNamed("paymentsService.js:7:200", [org,context.params.id], {  });
      return serviceJson(context, {receipt:{receiptNumber:r.receipt_number,status:r.status,issuedAt:r.issued_at,issuedBy:r.issued_by,paymentId:r.payment_id,paymentNumber:r.payment_number,amount:Number(r.amount),paymentDate:r.payment_date,paymentMethod:r.payment_method,transactionReference:r.transaction_reference||'',bankName:r.bank_name||'',bankAccount:r.bank_account||'',collectorId:r.collector_id,notes:r.notes||'',memberId:r.member_id,loanId:r.loan_id,allocations:a.rows.map(toAllocation)}});
    } finally { tx.release(); }
  } catch(e){throw e;}

}

module.exports = { get_root_1, post_root_2, get_collection_report_3, get_reconciliation_4, get_id_5, get_id_allocations_6, get_id_audit_7, post_id_cancel_8, post_id_reverse_9, get_id_receipt_10, guard_payments, changeStatus };
