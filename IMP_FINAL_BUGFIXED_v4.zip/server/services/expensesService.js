'use strict';

const { serviceResponse, serviceJson } = require('./serviceResult');


/**
 * Expense module (new — supports dashboard cards "মোট খরচ" and the
 * "ডেইলি খরচ" subtraction inside "আজকের কালেকশন").
 *
 * মোট খরচ = office + travel + equipment + daily/other
 * though not named in the original card list).
 */

const { z } = require('zod');
const repository = require('../repositories');

const { isOrganizationWide, assertBranchAccess, enforceRequestedBranch } = require('../application/accessScope');

const CATEGORIES = ['office', 'travel', 'equipment', 'other'];

const createSchema = z.object({
  category: z.enum(CATEGORIES),
  amount: z.coerce.number().positive(),
  expenseDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'expenseDate must be YYYY-MM-DD'),
  branchId: z.string().uuid().nullable().optional(),
  description: z.string().trim().max(2000).optional().default('')
}).strict();

function money(v) { return Number(v); }

function toExpense(r) {
  return {
    id: r.id,
    organizationId: r.organization_id,
    branchId: r.branch_id,
    category: r.category,
    amount: money(r.amount),
    expenseDate: r.expense_date,
    description: r.description || '',
    createdBy: r.created_by,
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}

async function audit(tx, auth, action, entityId, metadata = {}) {
  await tx.queryNamed("expensesService.js:44:92", [auth.organization_id, auth.user_id, action, entityId, JSON.stringify(metadata)], {  });
}

/**
 * Live-computed expense totals — by category (for মোট খরচ) and for a given
 * date (for the "ডেইলি খরচ" term inside আজকের কালেকশন, computed here as the
 * sum across ALL categories for that date).
 */
async function computeExpenseSummary(org, repo = repository, onDate = null, branchId = null) {
  const values = branchId ? [org, branchId] : [org];
  const byCategory = await repo.queryNamed("expensesService.js:59:93", values, { hasBranch: Boolean(branchId) });
  const r = byCategory.rows[0];
  const office = money(r.office);
  const travel = money(r.travel);
  const equipment = money(r.equipment);
  const other = money(r.other);

  let todayTotal = 0;
  if (onDate) {
    const today = await repo.queryNamed("expensesService.js:77:94", branchId ? [org, onDate, branchId] : [org, onDate], { branchId: branchId });
    todayTotal = money(today.rows[0].total);
  }

  return {
    office,
    travel,
    equipment,
    other,
    total: office + travel + equipment + other, // মোট খরচ = office + travel + equipment + daily (other)
    totalOnDate: todayTotal
  };
}

;

;

;

;

module.exports.computeExpenseSummary = computeExpenseSummary;

async function get_summary_1(context) {
  context.cookies ||= [];

  try {
    const onDate = typeof context.query.date === 'string' && context.query.date ? context.query.date : null;
    const branchId = isOrganizationWide(context.auth) ? null : context.auth.branch_id;
    if (!isOrganizationWide(context.auth) && !branchId) return serviceResponse(403, { error: 'Your account is not assigned to a branch' }, context);
    const summary = await computeExpenseSummary(context.auth.organization_id, repository, onDate, branchId);
    return serviceJson(context, { summary });
  } catch (e) { throw e; }

}

async function get_entries_2(context) {
  context.cookies ||= [];

  try {
    const org = context.auth.organization_id;
    const values = [org];
    const filters = [];
    if (!isOrganizationWide(context.auth)) {
      if (!context.auth.branch_id) filters.push('denyAll');
      else { values.push(context.auth.branch_id); filters.push('branchId'); }
    }
    if (typeof context.query.category === 'string' && context.query.category) { values.push(context.query.category); filters.push('category'); }
    if (typeof context.query.fromDate === 'string' && context.query.fromDate) { values.push(context.query.fromDate); filters.push('fromDate'); }
    if (typeof context.query.toDate === 'string' && context.query.toDate) { values.push(context.query.toDate); filters.push('toDate'); }

    const limit = Math.min(Math.max(parseInt(context.query.limit || '100', 10) || 100, 1), 500);
    const offset = Math.max(parseInt(context.query.offset || '0', 10) || 0, 0);
    values.push(limit, offset);

    const { rows } = await repository.queryNamed("expensesService.js:25:87", values, { filters });

    return serviceJson(context, { entries: rows.map(toExpense), pagination: { limit, offset, returned: rows.length } });
  } catch (e) { throw e; }

}

async function post_entries_3(context) {
  context.cookies ||= [];

  const parsed = createSchema.safeParse(context.body);
  if (!parsed.success) return serviceResponse(400, { error: 'Invalid expense entry', details: parsed.error.issues }, context);
  const data = parsed.data;
  const org = context.auth.organization_id;

  const tx = await repository.begin();
  try {
    await tx.begin();

    const effectiveBranchId = isOrganizationWide(context.auth) ? (data.branchId || null) : context.auth.branch_id;
    if (!isOrganizationWide(context.auth) && !effectiveBranchId) { await tx.rollback(); return serviceResponse(403, {error:'Your account is not assigned to a branch'}, context); }
    if (effectiveBranchId) {
      assertBranchAccess(context.auth, effectiveBranchId);
      const branch = await tx.queryNamed("expensesService.js:15:88", [effectiveBranchId, org], {  });
      if (!branch.rows[0]) {
        await tx.rollback();
        return serviceResponse(400, { error: 'Branch does not belong to this organization' }, context);
      }
    }

    const { rows } = await tx.queryNamed("expensesService.js:22:89", [org, effectiveBranchId, data.category, data.amount, data.expenseDate, data.description, context.auth.user_id], {  });

    await audit(tx, context.auth, 'expense_entry.create', rows[0].id, { category: data.category, amount: data.amount });
    await tx.commit();
    return serviceResponse(201, { entry: toExpense(rows[0]) }, context);
  } catch (e) {
    await tx.rollback();
    throw e;
  } finally {
    tx.release();
  }

}

async function delete_entries_id_4(context) {
  context.cookies ||= [];

  const tx = await repository.begin();
  try {
    await tx.begin();
    const org = context.auth.organization_id;
    const existing = await tx.queryNamed("expensesService.js:6:90", [context.params.id, org], {  });
    if (!existing.rows[0]) {
      await tx.rollback();
      return serviceResponse(404, { error: 'Expense entry not found' }, context);
    }
    if (!isOrganizationWide(context.auth)) assertBranchAccess(context.auth, existing.rows[0].branch_id);
    await tx.queryNamed("expensesService.js:15:91", [context.params.id, org], {  });
    await audit(tx, context.auth, 'expense_entry.delete', context.params.id, { category: existing.rows[0].category, amount: money(existing.rows[0].amount) });
    await tx.commit();
    return serviceResponse(204, null, context);
  } catch (e) {
    await tx.rollback();
    throw e;
  } finally {
    tx.release();
  }

}

module.exports = { get_summary_1, get_entries_2, post_entries_3, delete_entries_id_4, computeExpenseSummary };
