'use strict';

const { serviceResponse, serviceJson } = require('./serviceResult');


const { z } = require('zod');
const repository = require('../repositories');

const { isOrganizationWide, assertBranchAccess, enforceRequestedBranch } = require('../application/accessScope');

const updateSchema = z.object({
  name: z.string().trim().min(2).max(200).optional(),
  phone: z.string().trim().max(50).nullable().optional(),
  email: z.string().trim().email().max(254).nullable().optional(),
  address: z.string().trim().max(5000).nullable().optional(),
  companyType: z.string().trim().min(2).max(120).optional(),
  country: z.string().trim().max(120).optional(),
  currency: z.string().trim().regex(/^[A-Za-z]{3}$/).transform(v => v.toUpperCase()).optional(),
  workingDays: z.array(z.string().trim().min(2).max(30)).min(1).max(7).optional(),
  officeStartTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/).optional(),
  officeEndTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/).optional(),
  timezone: z.string().trim().max(80).optional()
}).strict();

function cleanNullable(value) {
  if (value === undefined) return undefined;
  if (value === null || value === '') return null;
  return value;
}

;


;

;


async function get_root_1(context) {
  context.cookies ||= [];

  try {
    const { rows } = await repository.queryNamed("organizationService.js:3:165", [context.auth.organization_id], {  });
    if (!rows[0]) return serviceResponse(404, { error: 'Organization not found' }, context);
    return serviceJson(context, { organization: rows[0] });
  } catch (error) { throw error; }

}

async function get_dashboard_summary_2(context) {
  context.cookies ||= [];

  try {
    const branchId = isOrganizationWide(context.auth) ? null : context.auth.branch_id;
    if (!isOrganizationWide(context.auth) && !branchId) return serviceResponse(403, {error:'Your account is not assigned to a branch'}, context);
    const { rows } = await repository.queryNamed("organizationService.js:5:166", branchId ? [context.auth.organization_id, branchId] : [context.auth.organization_id], { branchId: branchId });
    if (!rows[0]) return serviceResponse(404, { error: 'Organization not found' }, context);

    return serviceJson(context, {
      summary: {
        organization: {
          id: rows[0].id,
          name: rows[0].name,
          status: rows[0].status
        },
        branchCount: rows[0].branch_count,
        userCount: rows[0].user_count,
        memberCount: rows[0].member_count
      }
    });
  } catch (error) {
    throw error;
  }

}

async function patch_root_3(context) {
  context.cookies ||= [];

  try {
    const parsed = updateSchema.safeParse(context.body);
    if (!parsed.success) return serviceResponse(400, { error: 'Invalid organization data' }, context);
    const data = parsed.data;
    if (data.email !== undefined) data.email = cleanNullable(data.email);
    if (data.phone !== undefined) data.phone = cleanNullable(data.phone);
    if (data.address !== undefined) data.address = cleanNullable(data.address);
    if (data.companyType !== undefined) data.companyType = data.companyType.trim();
    if (data.country !== undefined) data.country = data.country.trim();
    if (data.timezone !== undefined) data.timezone = data.timezone.trim();
    if (data.name !== undefined) data.name = data.name.trim();

    const tx = await repository.begin();
    try {
      await tx.begin();
      const current = await tx.queryNamed("organizationService.js:17:167", [context.auth.organization_id], {  });
      if (!current.rows[0]) {
        await tx.rollback();
        return serviceResponse(404, { error: 'Organization not found' }, context);
      }

      const o = current.rows[0];
      const next = {
        name: data.name !== undefined ? data.name : o.name,
        // status is intentionally NOT settable here — an organization must
        // never be able to suspend/deactivate itself through its own
        // self-service update, since every session (including the admin's
        // own) requires status='active' on every subsequent request. That
        // is a platform-level action with no self-service undo.
        status: o.status,
        phone: data.phone !== undefined ? data.phone : o.phone,
        email: data.email !== undefined ? data.email : o.email,
        address: data.address !== undefined ? data.address : o.address,
        companyType: data.companyType !== undefined ? data.companyType : o.company_type,
        country: data.country !== undefined ? data.country : o.country,
        currency: data.currency !== undefined ? data.currency : o.currency,
        workingDays: data.workingDays !== undefined ? data.workingDays : o.working_days,
        officeStartTime: data.officeStartTime !== undefined ? data.officeStartTime : o.office_start_time,
        officeEndTime: data.officeEndTime !== undefined ? data.officeEndTime : o.office_end_time,
        timezone: data.timezone !== undefined ? data.timezone : o.timezone
      };

      if (!next.name) {
        await tx.rollback();
        return serviceResponse(400, { error: 'Organization name is required' }, context);
      }

      const result = await tx.queryNamed("organizationService.js:47:168", [next.name, next.status, next.phone, next.email, next.address, next.companyType, next.country, next.currency, JSON.stringify(next.workingDays || []), next.officeStartTime || null, next.officeEndTime || null, next.timezone, context.auth.organization_id], {  });

      await tx.queryNamed("organizationService.js:54:169", [context.auth.organization_id, context.auth.user_id, JSON.stringify({ fields: Object.keys(data) })], {  });
      await tx.commit();
      return serviceJson(context, { organization: result.rows[0] });
    } catch (error) {
      await tx.rollback();
      throw error;
    } finally { tx.release(); }
  } catch (error) { throw error; }

}

module.exports = { get_root_1, get_dashboard_summary_2, patch_root_3 };
