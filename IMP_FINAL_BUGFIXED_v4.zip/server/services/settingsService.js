'use strict';

const { serviceResponse, serviceJson } = require('./serviceResult');


/**
 * Unified Organization Settings API
 * All UI/config settings are org-scoped and stored in organization_settings.
 * Keys: loan_ui_config, payment_ui_config, member_registration_ui
 * (dashboard_config remains available via /api/dashboard/config as well)
 */

const { z } = require('zod');
const repository = require('../repositories');

const ALLOWED_KEYS = new Set([
  'loan_ui_config',
  'payment_ui_config',
  'member_registration_ui',
  'dashboard_config',
  'daily_collection_config',
  'loan_schedule_config',
  'user_ui_visibility',
  'share_capital_config'
]);

const DEFAULTS = {
  loan_ui_config: {
    formFields: {
      loanType: true, loanPurpose: true, loanAmount: true, interestAmount: true,
      numberOfInstallments: true, installmentFrequency: true, startDate: true,
      firstInstallmentDate: true, branchId: true
    },
    defaults: { installmentFrequency: 'daily', interestRateHint: true },
    weeklyOffDay:5, skipFriday:true, allowAdvance:true, allowFullSettlement:true, renewalMode:'new_loan',
    listColumns: {
      loanNumber: true, memberName: true, loanAmount: true,
      outstanding: true, status: true, branch: true
    },
    dashboardCards: { totalLoans: true, totalDisbursed: true, totalOutstanding: true, activeLoans: true }
  },
  loan_schedule_config: { defaultFrequency:'daily', weeklyOffDay:5, skipFriday:true, allowAdvance:true, allowFullSettlement:true, renewalMode:'new_loan' },
  user_ui_visibility: {},
  share_capital_config: { marketValue: 0 },
  payment_ui_config: {
    methods: { cash: true, bkash: true, nagad: true, rocket: true, bank_transfer: true, cheque: true, other: true },
    requireReferenceFor: ['bkash', 'nagad', 'rocket', 'bank_transfer', 'cheque'],
    allowAdvanceDefault: true,
    listColumns: { paymentNumber: true, memberName: true, amount: true, method: true, date: true, status: true }
  },
  member_registration_ui: {
    layout: 'two-column',
    memberPhotoVisible: true,
    memberPhotoRequired: false,
    nomineeVisible: true,
    nomineePhotoVisible: true,
    nomineePhotoRequired: false,
    nomineeRequired: true,
    memberFields: {
      fullName: true, fatherName: true, motherName: true, spouseName: true,
      dateOfBirth: true, gender: true, nid: true, mobile: true, email: true,
      occupation: true, monthlyIncome: true, sourceOfIncome: true, address: true
    },
    nomineeFields: { name: true, relation: true, nid: true, mobile: true, address: true }
  }
};

function deepMerge(base, override) {
  if (!override || typeof override !== 'object' || Array.isArray(override)) return base;
  const out = { ...base };
  for (const [k, v] of Object.entries(override)) {
    if (v && typeof v === 'object' && !Array.isArray(v) && base[k] && typeof base[k] === 'object') {
      out[k] = deepMerge(base[k], v);
    } else {
      out[k] = v;
    }
  }
  return out;
}

const putSchema = z.object({
  value: z.record(z.string(), z.any())
}).strict();

;

;

function canUpdateSettings(context) {
  if (!context.auth) return serviceResponse(401, { error: 'Authentication required' }, context);
  const key = String(context.params.key || '');
  const perms = context.auth.permissions || [];
  if (perms.includes('settings.update')) return null;
  if (key === 'dashboard_config' && perms.includes('dashboard.customize')) return null;
  return serviceResponse(403, { error: 'Forbidden' }, context);
}

;


async function get_root_1(context) {
  context.cookies ||= [];

  try {
    const org = context.auth.organization_id;
    const { rows } = await repository.queryNamed("settingsService.js:4:235", [org, Array.from(ALLOWED_KEYS)], {  });
    const map = {};
    for (const key of ALLOWED_KEYS) {
      map[key] = DEFAULTS[key] ? { ...DEFAULTS[key] } : null;
    }
    for (const row of rows) {
      const def = DEFAULTS[row.setting_key];
      map[row.setting_key] = def ? deepMerge(def, row.setting_value) : row.setting_value;
    }
    return serviceJson(context, { settings: map });
  } catch (e) { throw e; }

}

async function get_key_2(context) {
  context.cookies ||= [];

  try {
    const key = String(context.params.key || '');
    if (!ALLOWED_KEYS.has(key)) return serviceResponse(400, { error: 'Unknown settings key' }, context);
    const org = context.auth.organization_id;
    const { rows } = await repository.queryNamed("settingsService.js:6:236", [org, key], {  });
    const def = DEFAULTS[key] || {};
    const value = rows[0] ? deepMerge(def, rows[0].setting_value) : def;
    return serviceJson(context, { key, value, updatedAt: rows[0]?.updated_at || null });
  } catch (e) { throw e; }

}

async function put_key_3(context) {
  context.cookies ||= [];

  try {
    const key = String(context.params.key || '');
    if (!ALLOWED_KEYS.has(key)) return serviceResponse(400, { error: 'Unknown settings key' }, context);
    const parsed = putSchema.safeParse(context.body);
    if (!parsed.success) return serviceResponse(400, { error: 'Invalid settings payload' }, context);

    const org = context.auth.organization_id;
    const def = DEFAULTS[key] || {};
    const merged = deepMerge(def, parsed.data.value);
    const tx = await repository.begin();
    try {
      await tx.begin();
      const { rows } = await tx.queryNamed("settingsService.js:14:237", [org, key, JSON.stringify(merged), context.auth.user_id], {  });
      await tx.queryNamed("settingsService.js:22:238", [org, context.auth.user_id, `settings.${key}.update`, JSON.stringify({ key })], {  });
      await tx.commit();
      return serviceJson(context, { key, value: rows[0].setting_value, updatedAt: rows[0].updated_at });
    } catch (e) {
      await tx.rollback();
      throw e;
    } finally {
      tx.release();
    }
  } catch (e) { throw e; }

}


const UI_VISIBILITY_LEGACY_KEYS=['organization.view#0','branch.view#1','user.view#2','member.view#3','loan.view#4','loan.view#5','payment.view#6','collection.create#7','capital.view#8','savings.view#9','expense.view#10','settings.view#11','dashboard.customize#12'];
const UI_VISIBILITY_STABLE_KEYS=['organization','branches','users','members','loans','installments','payments','daily_collection','capital','savings','expenses','settings','dashboard_customize'];
function normalizeUiVisibility(value){
  if(!Array.isArray(value)) return [];
  return value.map(key=>{const i=UI_VISIBILITY_LEGACY_KEYS.indexOf(key);return i>=0?UI_VISIBILITY_STABLE_KEYS[i]:key;}).filter((v,i,a)=>a.indexOf(v)===i);
}
async function get_user_ui_visibility_4(context){
  const r=await repository.queryNamed('settingsService.js:userUiVisibility',[context.auth.organization_id],{});
  const raw=r.rows[0]?.setting_value||{};
  const visibility=Object.fromEntries(Object.entries(raw).map(([id,value])=>[id,normalizeUiVisibility(value)]));
  // Every authenticated tenant user may read only their own UI visibility.
  // Organization admins with ui.visibility.manage may read the full organization map.
  if((context.auth.permissions||[]).includes('ui.visibility.manage')) return serviceJson(context,{visibility});
  const userId=context.auth.user_id;
  // No saved custom visibility must not mean "hide everything".
  // When the user has no custom visibility record, return an empty map so
  // the frontend keeps normal RBAC as the source of truth.
  if(!Object.prototype.hasOwnProperty.call(visibility,userId)){
    return serviceJson(context,{visibility:{}});
  }
  return serviceJson(context,{visibility:{[userId]:visibility[userId]}});
}
async function put_user_ui_visibility_5(context){if(!(context.auth.permissions||[]).includes('ui.visibility.manage'))return serviceResponse(403,{error:'Forbidden'},context);const schema=z.object({userId:z.string().uuid(),modules:z.array(z.string().min(1).max(80)).max(100)}).strict();const p=schema.safeParse(context.body);if(!p.success)return serviceResponse(400,{error:'Invalid user UI visibility payload'},context);const current=(await repository.queryNamed('settingsService.js:userUiVisibility',[context.auth.organization_id],{})).rows[0]?.setting_value||{};current[p.data.userId]=p.data.modules;const r=await repository.queryNamed('settingsService.js:userUiVisibilityUpsert',[context.auth.organization_id,JSON.stringify(current),context.auth.user_id],{});return serviceJson(context,{visibility:r.rows[0].setting_value});}

module.exports = { get_root_1, get_key_2, put_key_3, canUpdateSettings, get_user_ui_visibility_4, put_user_ui_visibility_5 };
