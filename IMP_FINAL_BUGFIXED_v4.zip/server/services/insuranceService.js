'use strict';

const { serviceResponse, serviceJson } = require('./serviceResult');


/**
 * 11.P.16 — Member-wise Insurance ledger.
 *
 * মোট বীমা (member-level) = premium − claim, for one member or org-wide.
 * This is additive with the existing organization-level capital_entries
 * ('insurance','insurance_new','insurance_claim') rows used for manual/
 * backdated adjustments — see server/routes/capital.js, which sums both
 * sources into the dashboard "মোট বীমা" KPI.
 */

const { z } = require('zod');
const repository = require('../repositories');

const { isOrganizationWide, assertBranchAccess, enforceRequestedBranch } = require('../application/accessScope');

const TX_TYPES = ['claim'];

const createSchema = z.object({
  memberId: z.string().uuid(),
  transactionType: z.enum(TX_TYPES),
  amount: z.coerce.number().positive(),
  transactionDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'transactionDate must be YYYY-MM-DD'),
  loanId: z.string().uuid().nullable().optional(),
  branchId: z.string().uuid().nullable().optional(),
  description: z.string().trim().max(2000).optional().default('')
}).strict();

function money(v) { return Number(v); }

function toTx(r) {
  return {
    id: r.id,
    organizationId: r.organization_id,
    memberId: r.member_id,
    branchId: r.branch_id,
    loanId: r.loan_id,
    transactionType: r.transaction_type,
    amount: money(r.amount),
    transactionDate: r.transaction_date,
    description: r.description || '',
    createdBy: r.created_by,
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}

async function audit(tx, auth, action, entityId, metadata = {}) {
  await tx.queryNamed("insuranceService.js:50:110", [auth.organization_id, auth.user_id, action, entityId, JSON.stringify(metadata)], {  });
}

/**
 * Org-wide (or single-member, if memberId given) insurance summary —
 * computed live from PostgreSQL.
 */
async function computeInsuranceSummary(org, repo = repository, memberId = null, branchId = null) {
  const values = [org];
  if (branchId) values.push(branchId);
  if (memberId) {
    values.push(memberId);
  }
  const { rows } = await repo.queryNamed("insuranceService.js:70:111", values, { hasBranch: Boolean(branchId), hasMember: Boolean(memberId) });
  const r = rows[0];
  const premiums = money(r.premiums);
  const claims = money(r.claims);
  return { premiums, claims, balance: premiums - claims };
}

;

;

;

;

module.exports.computeInsuranceSummary = computeInsuranceSummary;

async function get_summary_1(context) {
  context.cookies ||= [];

  try {
    const memberId = typeof context.query.memberId === 'string' && context.query.memberId ? context.query.memberId : null;
    const branchId = isOrganizationWide(context.auth) ? null : context.auth.branch_id;
    if (!isOrganizationWide(context.auth) && !branchId) return serviceResponse(403, { error: 'Your account is not assigned to a branch' }, context);
    const summary = await computeInsuranceSummary(context.auth.organization_id, repository, memberId, branchId);
    return serviceJson(context, { summary });
  } catch (e) { throw e; }

}

async function get_transactions_2(context) {
  context.cookies ||= [];

  try {
    const org = context.auth.organization_id;
    const values = [org];
    const filters = [];
    if (!isOrganizationWide(context.auth)) {
      if (!context.auth.branch_id) filters.push('denyAll');
      else { values.push(context.auth.branch_id); filters.push('branchId'); }
    }
    if (typeof context.query.memberId === 'string' && context.query.memberId) { values.push(context.query.memberId); filters.push('memberId'); }
    if (typeof context.query.transactionType === 'string' && context.query.transactionType) { values.push(context.query.transactionType); filters.push('transactionType'); }
    if (typeof context.query.fromDate === 'string' && context.query.fromDate) { values.push(context.query.fromDate); filters.push('fromDate'); }
    if (typeof context.query.toDate === 'string' && context.query.toDate) { values.push(context.query.toDate); filters.push('toDate'); }

    const limit = Math.min(Math.max(parseInt(context.query.limit || '100', 10) || 100, 1), 500);
    const offset = Math.max(parseInt(context.query.offset || '0', 10) || 0, 0);
    values.push(limit, offset);

    const { rows } = await repository.queryNamed("insuranceService.js:29:103", values, { filters });

    return serviceJson(context, { transactions: rows.map(toTx), pagination: { limit, offset, returned: rows.length } });
  } catch (e) { throw e; }

}

async function post_transactions_3(context) {
  context.cookies ||= [];

  const parsed = createSchema.safeParse(context.body);
  if (!parsed.success) return serviceResponse(400, { error: 'Invalid insurance transaction', details: parsed.error.issues }, context);
  const data = parsed.data;
  const org = context.auth.organization_id;

  const tx = await repository.begin();
  try {
    await tx.begin();

    const member = await tx.queryNamed("insuranceService.js:11:104", [data.memberId, org], {  });
    if (!member.rows[0]) {
      await tx.rollback();
      return serviceResponse(400, { error: 'Member does not belong to this organization' }, context);
    }
    if (!isOrganizationWide(context.auth) && (!context.auth.branch_id || String(member.rows[0].branch_id) !== String(context.auth.branch_id))) {
      await tx.rollback(); return serviceResponse(403, { error: 'Member is outside your branch' }, context);
    }

    if (data.loanId) {
      const loan = await tx.queryNamed("insuranceService.js:21:105", [data.loanId, org, data.memberId], {  });
      if (!loan.rows[0]) {
        await tx.rollback();
        return serviceResponse(400, { error: 'Loan does not belong to this member/organization' }, context);
      }
    }

    if (data.transactionType === 'claim') {
      const current = await computeInsuranceSummary(org, tx, data.memberId, isOrganizationWide(context.auth) ? null : context.auth.branch_id);
      if (current.balance < data.amount) {
        await tx.rollback();
        return serviceResponse(400, { error: 'Claim exceeds member insurance balance', currentBalance: current.balance }, context);
      }
    }

    const branchId = isOrganizationWide(context.auth) ? (member.rows[0].branch_id || null) : context.auth.branch_id;
    if (data.branchId && String(data.branchId) !== String(member.rows[0].branch_id)) { await tx.rollback(); return serviceResponse(400, {error:'Transaction branch must match member branch'}, context); }
    if (branchId) { const b = await tx.queryNamed("insuranceService.js:41:106", [branchId, org], {  }); if (!b.rows[0]) { await tx.rollback(); return serviceResponse(400, {error:'Invalid branch'}, context); } }

    const { rows } = await tx.queryNamed("insuranceService.js:43:107", [org, data.memberId, branchId, data.loanId || null, data.transactionType, data.amount, data.transactionDate, data.description, context.auth.user_id], {  });

    await audit(tx, context.auth, 'insurance_transaction.create', rows[0].id, { transactionType: data.transactionType, amount: data.amount, memberId: data.memberId });
    await tx.commit();
    return serviceResponse(201, { transaction: toTx(rows[0]) }, context);
  } catch (e) {
    await tx.rollback();
    throw e;
  } finally {
    tx.release();
  }

}

async function delete_transactions_id_4(context) {
  context.cookies ||= [];

  const tx = await repository.begin();
  try {
    await tx.begin();
    const org = context.auth.organization_id;
    const existing = await tx.queryNamed("insuranceService.js:6:108", [context.params.id, org], {  });
    if (!existing.rows[0]) {
      await tx.rollback();
      return serviceResponse(404, { error: 'Insurance transaction not found' }, context);
    }
    if (!isOrganizationWide(context.auth)) assertBranchAccess(context.auth, existing.rows[0].branch_id);
    await tx.queryNamed("insuranceService.js:15:109", [context.params.id, org], {  });
    await audit(tx, context.auth, 'insurance_transaction.delete', context.params.id, {});
    await tx.commit();
    return serviceResponse(204, null, context);
  } catch (e) {
    await tx.rollback();
    throw e;
  } finally {
    tx.release();
  }

}

module.exports = { get_summary_1, get_transactions_2, post_transactions_3, delete_transactions_id_4, computeInsuranceSummary };
