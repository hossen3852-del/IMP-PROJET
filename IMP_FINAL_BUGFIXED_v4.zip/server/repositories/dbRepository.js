'use strict';

// Compatibility facade. Raw pool/query/connect are intentionally not exposed.
module.exports = require('./index');
