'use strict';

const repository = require('./index');

async function findSessionContext(tokenHash) {
  return repository.queryNamed('middleware.auth:session', [tokenHash]);
}

async function findRolePermissions(roleId, organizationId) {
  return repository.queryNamed('middleware.auth:permissions', [roleId, organizationId]);
}

module.exports = Object.freeze({ findSessionContext, findRolePermissions });
