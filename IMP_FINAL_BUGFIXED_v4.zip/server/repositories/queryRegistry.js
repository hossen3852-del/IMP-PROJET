'use strict';

const BRANCH_COLUMNS = "id,organization_id,branch_code,name,phone,address,manager_name,status,created_by,created_at,updated_at";
const LOAN_COLUMNS = "l.renewal_of_loan_id AS renewal_of_loan_id,\n  l.loan_source_type,\n  l.legacy_original_paid_amount,\n  l.legacy_original_paid_installments,\n  l.id,\n  l.organization_id,\n  l.branch_id,\n  l.member_id,\n  l.loan_number,\n  l.loan_type,\n  l.loan_purpose,\n  l.loan_amount,\n  l.interest_rate,\n  l.interest_amount,\n  l.total_payable,\n  l.installment_amount,\n  l.savings_amount,\n  l.deposit_amount,\n  l.number_of_installments,\n  l.installment_frequency,\n  l.start_date,\n  l.first_installment_date,\n  l.application_date,\n  l.approval_date,\n  l.disbursed_at,\n  l.disbursed_amount,\n  l.outstanding_amount,\n  l.status,\n  l.created_by,\n  l.approved_by,\n  l.created_at,\n  l.updated_at,\n  m.member_code,\n  m.full_name AS member_name";
const MEMBER_COLUMNS = "m.id,m.organization_id,m.branch_id,m.member_code,m.full_name,m.email,m.phone,\n  m.address,m.nid_or_passport,m.status,m.personal_info,m.financial,m.family,\n  m.photo_data,m.photo_mime,m.photo_path,m.member_origin,m.legacy_current_installments_paid,m.legacy_current_installment_amount,m.legacy_savings_balance,m.created_by,m.updated_by,m.created_at,m.updated_at";
const MEMBER_RETURNING_COLUMNS = MEMBER_COLUMNS.replace(/m\./g, '');
const MEMBER_LIST_COLUMNS = `m.id,m.organization_id,m.branch_id,m.member_code,m.full_name,m.email,m.phone,m.address,m.nid_or_passport,m.status,m.personal_info,m.financial,m.family,m.member_origin,m.legacy_current_installments_paid,m.legacy_current_installment_amount,m.legacy_savings_balance,m.photo_path,(m.photo_path IS NOT NULL OR m.photo_data IS NOT NULL) AS has_photo,m.created_by,m.updated_by,m.created_at,m.updated_at,\n  n.id AS nominee_id,n.name AS nominee_name,n.relation AS nominee_relation,n.mobile AS nominee_mobile,n.nid AS nominee_nid,n.address AS nominee_address,(n.photo_path IS NOT NULL OR n.photo_data IS NOT NULL) AS nominee_has_photo,n.photo_path AS nominee_photo_path`;
const ROLE_COLUMNS = "r.id,r.organization_id,r.code,r.name,r.description,\n  r.is_system,r.is_protected,r.created_by,r.created_at,r.updated_at";
const PAYMENT_COLUMNS = "p.id,p.organization_id,p.branch_id,p.member_id,p.loan_id,p.payment_number,p.amount,p.payment_date,p.payment_method,\n p.transaction_reference,p.bank_name,p.bank_account,p.collector_id,p.notes,p.status,p.idempotency_key,p.created_by,p.created_at,p.updated_at";
const PAYMENT_RETURNING_COLUMNS = PAYMENT_COLUMNS.replace(/p\./g, "");
const INSTALLMENT_COLUMNS = "id,organization_id,loan_id,installment_number,due_date,installment_amount,paid_amount,outstanding_amount,status,paid_date,created_at,updated_at";

const STATIC_FILTER_KEYS = new Set(['denyAll', 'activeOnly']);
function countParams(filters = []) {
  return filters.reduce((n, f) => {
    const key = typeof f === 'string' ? f : f?.key;
    return n + (STATIC_FILTER_KEYS.has(key) ? 0 : 1);
  }, 0);
}
function renderFilters(filters = [], definitions = {}, start = 2) {
  let p = start; const clauses = [];
  for (const raw of filters) {
    const key = typeof raw === 'string' ? raw : raw.key; const def = definitions[key];
    if (!def) throw new Error('Unknown repository filter: ' + key);
    if (typeof def === 'string') { clauses.push(def); continue; }
    if (def.static) { clauses.push(def.static); continue; }
    clauses.push(def(p)); p += 1;
  }
  return clauses;
}
const PAYMENT_FILTERS = Object.freeze({
  branchId: p => `p.branch_id=$${p}`, scopedBranchId: p => `p.branch_id=$${p}`,
  fromDate: p => `(p.payment_date AT TIME ZONE 'Asia/Dhaka')::date >= $${p}::date`, toDate: p => `(p.payment_date AT TIME ZONE 'Asia/Dhaka')::date <= $${p}::date`,
  fromTimestamp: p => `p.payment_date >= $${p}::timestamptz`, memberId: p => `p.member_id=$${p}`,
  loanId: p => `p.loan_id=$${p}`, collectorId: p => `p.collector_id=$${p}`, paymentMethod: p => `p.payment_method=$${p}`,
  status: p => `p.status=$${p}`, source: p => `EXISTS (SELECT 1 FROM audit_logs a WHERE a.organization_id=p.organization_id AND a.entity_type='payment' AND a.entity_id=p.id AND a.action='PAYMENT_CREATED' AND (a.metadata->>'source')=$${p})`, denyAll: { static: '1=0' }
});
function renderPaymentFilters(filters = []) { return renderFilters(filters, PAYMENT_FILTERS, 2).join(' AND '); }

const queries = {
"authService.js:12:20": ({  }) => (`SELECT pr.id,pr.user_id,u.organization_id,u.email
         FROM password_resets pr
         JOIN users u ON u.id=pr.user_id
         WHERE pr.token_hash=$1 AND pr.used_at IS NULL AND pr.expires_at>NOW() AND u.active=TRUE
         FOR UPDATE`),
"authService.js:13:1": ({  }) => ('SELECT id FROM users WHERE lower(email)=lower($1) LIMIT 1'),
"authService.js:admin_credentials_user": ({  }) => (`SELECT u.id,u.organization_id,u.email,u.password_hash,u.active,r.code AS role_code,r.is_system AS role_is_system
       FROM users u JOIN roles r ON r.id=u.role_id
       WHERE u.id=$1 AND u.organization_id=$2 LIMIT 1`),
"authService.js:admin_credentials_duplicate_email": ({  }) => ('SELECT id FROM users WHERE lower(email)=lower($1) AND id<>$2 LIMIT 1'),
"authService.js:admin_credentials_update": ({  }) => (`UPDATE users
       SET email=$1, password_hash=COALESCE($2,password_hash), updated_at=NOW()
       WHERE id=$3
       RETURNING id,email`),
"authService.js:admin_credentials_revoke_sessions": ({  }) => ('UPDATE sessions SET revoked_at=NOW() WHERE user_id=$1 AND revoked_at IS NULL'),
"authService.js:admin_credentials_audit": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
       VALUES($1,$2,'auth.admin_credentials_update','user',$2,$3::jsonb)`),

"authService.js:16:18": ({  }) => (`UPDATE password_resets SET used_at=NOW()
         WHERE user_id=$1 AND used_at IS NULL`),
"authService.js:21:19": ({  }) => (`INSERT INTO password_resets(user_id,token_hash,expires_at)
         VALUES($1,$2,NOW()+INTERVAL '15 minutes')`),
"authService.js:22:2": ({  }) => ('SELECT id FROM organizations WHERE lower(company_code)=lower($1) LIMIT 1'),
"authService.js:24:10": ({  }) => (`UPDATE users SET updated_at=NOW() WHERE id=$1`),
"authService.js:26:21": ({  }) => ('UPDATE users SET password_hash=$1,updated_at=NOW() WHERE id=$2'),
"authService.js:28:11": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
         VALUES($1,$2,'auth.login','user',$2,$3::jsonb)`),
"authService.js:30:22": ({  }) => ('UPDATE password_resets SET used_at=NOW() WHERE id=$1'),
"authService.js:31:3": ({  }) => (`INSERT INTO organizations(name,company_code,company_type,address,phone,email,country,currency,working_days,office_start_time,office_end_time,timezone,status)
         VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9::jsonb,$10::time,$11::time,$12,'active')
         RETURNING id,name,status,company_code,company_type,address,phone,email,country,currency,working_days,office_start_time,office_end_time,timezone`),
"authService.js:34:12": ({  }) => (`SELECT p.code
         FROM role_permissions rp
         JOIN permissions p ON p.id=rp.permission_id
         JOIN roles r ON r.id=rp.role_id
         WHERE r.id=$1 AND (r.is_system=TRUE OR r.organization_id=$2)
         ORDER BY p.code`),
"authService.js:34:23": ({  }) => ('UPDATE sessions SET revoked_at=NOW() WHERE user_id=$1 AND revoked_at IS NULL'),
"authService.js:38:24": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
         VALUES($1,$2,'auth.password_reset','user',$2,'{}'::jsonb)`),
"authService.js:39:4": ({  }) => ('SELECT create_default_org_rbac($1)'),
"authService.js:3:14": ({  }) => (`SELECT u.id,u.organization_id,u.branch_id,u.email,u.role,u.role_id,u.active,u.user_code,u.full_name AS name,
              r.code AS role_code,r.name AS role_name,
              o.name AS organization_name,o.status AS organization_status,
              b.name AS branch_name
       FROM users u
       JOIN organizations o ON o.id=u.organization_id
       JOIN roles r ON r.id=u.role_id
       LEFT JOIN branches b ON b.id=u.branch_id AND b.organization_id=u.organization_id
       WHERE u.id=$1
         AND ((r.is_system=TRUE AND r.organization_id IS NULL)
              OR (r.is_system=FALSE AND r.organization_id=u.organization_id))`),
"authService.js:3:16": ({  }) => ('UPDATE sessions SET revoked_at=NOW() WHERE user_id=$1 AND revoked_at IS NULL'),
"authService.js:grant_v617": ({}) => (`SELECT grant_v617_permissions($1)`),
"authService.js:40:5": ({  }) => (`SELECT id,code FROM roles
         WHERE code='organization_admin' AND organization_id=$1 AND is_system=FALSE
         LIMIT 1`),
"authService.js:44:13": ({  }) => (`SELECT o.id, o.name, o.status, b.id AS branch_id, b.name AS branch_name
         FROM organizations o
         LEFT JOIN branches b ON b.id=$2 AND b.organization_id=o.id
         WHERE o.id=$1`),
"authService.js:48:6": ({  }) => (`INSERT INTO users(organization_id,user_code,email,password_hash,role,role_id,active,full_name)
         VALUES($1,$2,$3,$4,$5,$6,TRUE,$7)
         RETURNING id,organization_id,user_code,email,role,role_id,active,full_name AS name,branch_id`),
"authService.js:58:7": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
         VALUES($1,$2,'auth.register','user',$2,$3::jsonb)`),
"authService.js:5:15": ({  }) => ('UPDATE sessions SET revoked_at=NOW() WHERE token_hash=$1 AND revoked_at IS NULL'),
"authService.js:65:8": ({  }) => (`SELECT p.code
         FROM role_permissions rp
         JOIN permissions p ON p.id=rp.permission_id
         WHERE rp.role_id=$1 ORDER BY p.code`),
"authService.js:7:17": ({  }) => ('SELECT id,email,organization_id FROM users WHERE lower(email)=lower($1) AND active=TRUE LIMIT 1'),
"authService.js:84:25": ({  }) => (`INSERT INTO sessions(id,user_id,organization_id,token_hash,expires_at)
     VALUES($1,$2,$3,$4,NOW()+($5 * INTERVAL '1 second'))`),
"authService.js:8:9": ({  }) => (`SELECT id,organization_id,branch_id,email,password_hash,role,role_id,active,full_name AS name
       FROM users WHERE lower(email)=lower($1) LIMIT 1`),
"branchesService.js:13:36": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
         VALUES($1,$2,'branch.deactivate','branch',$3,'{}'::jsonb)`),
  "branchesService.js:18:29": ({}) => (`INSERT INTO branches(organization_id,branch_code,name,phone,address,manager_name,status,created_by) VALUES($1,$2,$3,$4,$5,$6,'active',$7) RETURNING ${BRANCH_COLUMNS}`),
"branchesService.js:23:30": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
         VALUES($1,$2,'branch.create','branch',$3,$4::jsonb)`),
"branchesService.js:23:32": ({  }) => (`SELECT id FROM branches WHERE organization_id=$1 AND lower(name)=lower($2) AND id<>$3 LIMIT 1`),
  "branchesService.js:29:33": ({}) => (`UPDATE branches SET name=$1,phone=$2,address=$3,manager_name=$4,status=$5,updated_at=NOW() WHERE organization_id=$6 AND id=$7 RETURNING ${BRANCH_COLUMNS}`),
"branchesService.js:29:37": ({  }) => ('SELECT 1 FROM branches WHERE organization_id=$1 AND branch_code=$2'),
"branchesService.js:34:34": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
         VALUES($1,$2,'branch.update','branch',$3,$4::jsonb)`),
  "branchesService.js:3:26": ({ orgWide = true }) => (`SELECT ${BRANCH_COLUMNS} FROM branches WHERE organization_id=$1${orgWide ? '' : ' AND id=$2'} ORDER BY name ASC`),
  "branchesService.js:3:27": ({ orgWide = true }) => (`SELECT ${BRANCH_COLUMNS} FROM branches WHERE organization_id=$1 AND id=$2${orgWide ? '' : ' AND id=$3'}`),
  "branchesService.js:6:35": ({}) => (`UPDATE branches SET status='inactive',updated_at=NOW() WHERE organization_id=$1 AND id=$2 AND status<>'inactive' RETURNING ${BRANCH_COLUMNS}`),
"branchesService.js:9:28": ({  }) => (`SELECT id FROM branches WHERE organization_id=$1 AND lower(name)=lower($2) LIMIT 1`),
  "branchesService.js:9:31": ({}) => (`SELECT ${BRANCH_COLUMNS} FROM branches WHERE organization_id=$1 AND id=$2 FOR UPDATE`),
"capitalService.js:111:48": ({ branchId }) => (`SELECT
       COALESCE(SUM(amount) FILTER (WHERE transaction_type = 'premium'), 0) AS premiums,
       COALESCE(SUM(amount) FILTER (WHERE transaction_type = 'claim'), 0) AS claims
     FROM member_insurance_transactions
     WHERE organization_id = $1${branchId ? ' AND branch_id = $2' : ''}`),
"capitalService.js:15:39": ({  }) => (`SELECT id FROM branches WHERE id=$1 AND organization_id=$2`),
"capitalService.js:15:42": ({  }) => (`DELETE FROM capital_entries WHERE id=$1 AND organization_id=$2`),
  "capitalService.js:25:38": ({ filters = [] }) => { const n=countParams(filters); const extra=renderFilters(filters,{branchId:p=>`branch_id=$${p}`,entryType:p=>`entry_type=$${p}`,fromDate:p=>`entry_date >= $${p}::date`,toDate:p=>`entry_date <= $${p}::date`,denyAll:{static:'1=0'}}).map(x=>' AND '+x).join(''); return `SELECT id,organization_id,branch_id,entry_type,amount,entry_date,description,created_by,created_at,updated_at FROM capital_entries WHERE organization_id=$1${extra} ORDER BY entry_date DESC, created_at DESC LIMIT $${n+2} OFFSET $${n+3}` },
"capitalService.js:25:40": ({  }) => (`INSERT INTO capital_entries(organization_id,branch_id,entry_type,amount,entry_date,description,created_by)
       VALUES($1,$2,$3,$4,$5,$6,$7)
       RETURNING id,organization_id,branch_id,entry_type,amount,entry_date,description,created_by,created_at,updated_at`),
"capitalService.js:58:43": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
     VALUES($1,$2,$3,'capital_entry',$4,$5::jsonb)`),
"capitalService.js:6:41": ({  }) => (`SELECT id,entry_type,amount,branch_id FROM capital_entries WHERE id=$1 AND organization_id=$2 FOR UPDATE`),
  "capitalService.js:72:44": ({ hasBranch = false }) => (`SELECT COALESCE(SUM(amount) FILTER (WHERE entry_type='capital_in'),0) AS capital_in,COALESCE(SUM(amount) FILTER (WHERE entry_type='admission_fee'),0) AS admission_fee,COALESCE(SUM(amount) FILTER (WHERE entry_type='capital_withdrawal'),0) AS capital_withdrawal,COALESCE(SUM(amount) FILTER (WHERE entry_type='capital_adjustment'),0) AS capital_adjustment FROM capital_entries WHERE organization_id=$1${hasBranch ? ' AND branch_id=$2' : ''}`),
"capitalService.js:83:45": ({ branchId }) => (`SELECT COALESCE(SUM(amount), 0) AS total
     FROM payments
     WHERE organization_id = $1 AND status = 'posted'${branchId ? ' AND branch_id = $2' : ''}`),
"capitalService.js:90:46": ({ branchId }) => (`SELECT COALESCE(SUM(disbursed_amount), 0) AS total
     FROM loans
     WHERE organization_id = $1 AND disbursed_at IS NOT NULL${branchId ? ' AND branch_id = $2' : ''}`),
"capitalService.js:97:47": ({ branchId }) => (`SELECT
       COALESCE(SUM(amount) FILTER (WHERE transaction_type = 'deposit'), 0) AS deposits,
       COALESCE(SUM(amount) FILTER (WHERE transaction_type = 'daily_deposit'), 0) AS daily_deposits,
       COALESCE(SUM(amount) FILTER (WHERE transaction_type = 'withdrawal'), 0) AS withdrawals,
       COALESCE(SUM(amount) FILTER (WHERE transaction_type = 'installment_payment'), 0) AS installment_payments
     FROM savings_transactions
     WHERE organization_id = $1${branchId ? ' AND branch_id = $2' : ''}`),
  "collectionsService.js:134:52": ({ filters = [] }) => { const extra=renderFilters(filters,{activeOnly:{static:`m.status='active'`},branchId:p=>`m.branch_id=$${p}`,search:p=>`(m.member_code ILIKE $${p} OR m.full_name ILIKE $${p} OR m.phone ILIKE $${p})`,denyAll:{static:'1=0'}}).map(x=>' AND '+x).join(''); return `SELECT m.id,m.member_code,m.full_name,m.phone,m.branch_id FROM members m WHERE m.organization_id=$1${extra} ORDER BY m.full_name` },
"collectionsService.js:165:61": ({  }) => (`
      SELECT setting_value
      FROM organization_settings
      WHERE organization_id=$1
        AND setting_key=$2
      `),
"collectionsService.js:169:57": ({  }) => (`INSERT INTO audit_logs (organization_id, user_id, action, entity_type, entity_id, metadata)
             VALUES ($1, $2, 'DAILY_COLLECTION_BAKI', 'member', $3, $4::jsonb)`),
"collectionsService.js:181:53": ({  }) => (`
        SELECT
          l.id AS loan_id,
          l.member_id,
          l.loan_number,
          l.outstanding_amount,
          l.installment_amount AS scheduled_installment_amount,
          l.savings_amount AS default_savings_amount,
          l.deposit_amount AS opening_deposit_amount,
          l.installment_frequency,

          COALESCE(due.due_today, 0) AS due_today,
          COALESCE(due.overdue_amount, 0) AS overdue_amount,
          COALESCE(due.due_on_date, 0) AS due_on_date

        FROM loans l

        LEFT JOIN LATERAL
        (
          SELECT
            COALESCE(SUM(i.outstanding_amount), 0) AS due_today,
            COALESCE(SUM(i.outstanding_amount) FILTER (WHERE i.due_date < $2::date), 0) AS overdue_amount,
            COALESCE(SUM(i.outstanding_amount) FILTER (WHERE i.due_date = $2::date), 0) AS due_on_date
          FROM installments i
          WHERE i.loan_id = l.id
            AND i.organization_id = l.organization_id
            AND i.status NOT IN ('paid', 'waived', 'cancelled')
            AND i.due_date <= $2::date
        ) due ON TRUE

        WHERE l.organization_id=$1

          AND l.member_id =
              ANY($3::uuid[])

          AND l.status IN
              (
                'disbursed',
                'active'
              )

        ORDER BY l.created_at
        `),
"collectionsService.js:234:58": ({  }) => (`
            SELECT
              id,
              branch_id

            FROM members

            WHERE id=$1
              AND organization_id=$2

            FOR UPDATE
            `),
"collectionsService.js:236:54": ({  }) => (`
        SELECT
          member_id,

          COALESCE(
            SUM(amount)
            FILTER
            (
              WHERE transaction_type
                IN
                (
                  'deposit',
                  'daily_deposit'
                )
            ),
            0
          )

          -

          COALESCE(
            SUM(amount)
            FILTER
            (
              WHERE transaction_type
                IN
                (
                  'withdrawal',
                  'installment_payment'
                )
            ),
            0
          ) AS balance

        FROM savings_transactions

        WHERE organization_id=$1

          AND member_id =
              ANY($2::uuid[])

        GROUP BY member_id
        `),
"collectionsService.js:25:50": ({  }) => (`
          INSERT INTO organization_settings
          (
            organization_id,
            setting_key,
            setting_value,
            updated_by
          )
          VALUES
          (
            $1,
            $2,
            $3::jsonb,
            $4
          )

          ON CONFLICT
          (
            organization_id,
            setting_key
          )

          DO UPDATE SET
            setting_value=EXCLUDED.setting_value,
            updated_by=EXCLUDED.updated_by,
            updated_at=NOW()

          RETURNING setting_value
          `),
"collectionsService.js:271:62": ({  }) => (`
      SELECT
        l.id,
        l.branch_id,
        l.member_id,
        l.outstanding_amount,
        l.status

      FROM loans l

      WHERE l.id=$1
        AND l.organization_id=$2

      FOR UPDATE
      `),
"collectionsService.js:293:55": ({  }) => (`
        SELECT
          member_id,

          COALESCE(
            SUM(amount)
            FILTER
            (
              WHERE transaction_type='premium'
            ),
            0
          )

          -

          COALESCE(
            SUM(amount)
            FILTER
            (
              WHERE transaction_type='claim'
            ),
            0
          ) AS balance

        FROM member_insurance_transactions

        WHERE organization_id=$1

          AND member_id =
              ANY($2::uuid[])

        GROUP BY member_id
        `),
"collectionsService.js:385:63": ({  }) => (`
      SELECT
        COALESCE(
          SUM(i.outstanding_amount),
          0
        ) AS due_today

      FROM installments i

      WHERE i.organization_id=$1
        AND i.loan_id=$2

        AND i.status NOT IN
            (
              'paid',
              'waived',
              'cancelled'
            )

        AND i.due_date <= $3::date
      `),
"collectionsService.js:438:59": ({  }) => (`INSERT INTO expense_entries
             (organization_id, branch_id, category, amount, expense_date, description, created_by, idempotency_key)
           VALUES ($1, $2, 'other', $3, $4::date, $5, $6, $7)`),
"collectionsService.js:idem:expenseLookup": ({  }) => (`SELECT id FROM expense_entries WHERE organization_id=$1 AND idempotency_key=$2 LIMIT 1`),
"collectionsService.js:444:64": ({  }) => (`
      SELECT nextval(
        'payment_number_seq'
      ) AS n
      `),
"collectionsService.js:463:60": ({  }) => (`
      INSERT INTO audit_logs
      (
        organization_id,
        user_id,
        action,
        entity_type,
        entity_id,
        metadata
      )

      VALUES
      (
        $1,
        $2,
        'DAILY_COLLECTION_SUBMITTED',
        'collection',
        $2,
        $3::jsonb
      )
      `),
"collectionsService.js:466:65": ({  }) => (`
      INSERT INTO payments
      (
        organization_id,
        branch_id,
        member_id,
        loan_id,
        payment_number,
        amount,
        payment_date,
        payment_method,
        collector_id,
        notes,
        idempotency_key,
        status,
        created_by
      )

      VALUES
      (
        $1,
        $2,
        $3,
        $4,
        $5,
        $6,
        ($7::date + TIME '12:00') AT TIME ZONE 'Asia/Dhaka',
        $8,
        $9,
        $10,
        $11,
        'posted',
        $9
      )

      RETURNING
        id,
        payment_number
      `),

"collectionsService.js:freq:lookup": ({  }) => (`SELECT id, created_at FROM daily_collection_locks WHERE organization_id=$1 AND collection_date=$2 AND branch_key=$3 AND frequency=$4 LIMIT 1`),
"collectionsService.js:freq:reserve": ({  }) => (`INSERT INTO daily_collection_locks(organization_id,branch_key,collection_date,frequency,created_by) VALUES($1,$2,$3,$4,$5) ON CONFLICT(organization_id,branch_key,collection_date,frequency) DO NOTHING RETURNING id`),
"collectionsService.js:freq:release": ({  }) => (`DELETE FROM daily_collection_locks WHERE id=$1 AND organization_id=$2`),
"collectionsService.js:freq:list": ({  }) => (`SELECT DISTINCT metadata->>'frequency' AS frequency, COALESCE(metadata->'names', '[]'::jsonb)::text AS names FROM audit_logs WHERE organization_id=$1 AND action='DAILY_COLLECTION_FREQUENCY_CLOSED' AND entity_type='daily_collection' AND (metadata->>'date')=$2 AND COALESCE(metadata->>'branchId','')=COALESCE($3::text,'')`),
"loansService.js:idem:lookupRow": ({  }) => (`SELECT ${LOAN_COLUMNS} FROM loans l JOIN members m ON m.id=l.member_id AND m.organization_id=l.organization_id WHERE l.organization_id=$1 AND l.idempotency_key=$2 FOR UPDATE`),
"collectionsService.js:idem:paymentLookup": ({  }) => (`SELECT id, payment_number FROM payments WHERE organization_id=$1 AND idempotency_key=$2 LIMIT 1`),
"collectionsService.js:532:66": ({  }) => (`
      SELECT
        id,
        outstanding_amount,
        paid_amount,
        status

      FROM installments

      WHERE organization_id=$1
        AND loan_id=$2

        AND status NOT IN
            (
              'paid',
              'waived',
              'cancelled'
            )

        AND outstanding_amount > 0

      ORDER BY
        due_date,
        installment_number

      FOR UPDATE
      `),
"collectionsService.js:5:49": ({  }) => (`
        SELECT setting_value
        FROM organization_settings
        WHERE organization_id=$1
          AND setting_key=$2
        `),
"collectionsService.js:606:67": ({  }) => (`
      INSERT INTO payment_allocations
      (
        organization_id,
        payment_id,
        loan_id,
        installment_id,
        allocation_type,
        amount,
        status
      )

      VALUES
      (
        $1,
        $2,
        $3,
        $4,
        'installment',
        $5,
        'active'
      )
      `),
"collectionsService.js:63:51": ({  }) => (`
        INSERT INTO audit_logs
        (
          organization_id,
          user_id,
          action,
          entity_type,
          entity_id,
          metadata
        )

        VALUES
        (
          $1,
          $2,
          'daily_collection_config.update',
          'organization_settings',
          $1,
          $3::jsonb
        )
        `),
"collectionsService.js:659:68": ({  }) => (`
      UPDATE installments

      SET
        paid_amount=$1,
        outstanding_amount=$2,
        status=$3,

        paid_date=
          CASE
            WHEN $3::varchar='paid'
            THEN COALESCE(
              paid_date,
              $4::date
            )
            ELSE paid_date
          END,

        updated_at=NOW()

      WHERE id=$5
        AND organization_id=$6
      `),
"collectionsService.js:704:69": ({  }) => (`
      INSERT INTO payment_allocations
      (
        organization_id,
        payment_id,
        loan_id,
        installment_id,
        allocation_type,
        amount,
        status
      )

      VALUES
      (
        $1,
        $2,
        $3,
        NULL,
        'advance',
        $4,
        'active'
      )
      `),
"collectionsService.js:750:70": ({  }) => (`
    UPDATE loans

    SET
      outstanding_amount=$1,

      status=
        CASE
          WHEN $1::numeric=0
            AND status IN ('disbursed','active')
          THEN 'completed'
          ELSE status
        END,

      updated_at=NOW()

    WHERE id=$2
      AND organization_id=$3
    `),
"collectionsService.js:783:71": ({  }) => (`
      SELECT nextval(
        'receipt_number_seq'
      ) AS n
      `),
"collectionsService.js:800:72": ({  }) => (`
    INSERT INTO payment_receipts
    (
      organization_id,
      payment_id,
      receipt_number,
      status,
      issued_by
    )

    VALUES
    (
      $1,
      $2,
      $3,
      'active',
      $4
    )
    `),
"collectionsService.js:833:73": ({  }) => (`
    INSERT INTO audit_logs
    (
      organization_id,
      user_id,
      action,
      entity_type,
      entity_id,
      metadata
    )

    VALUES
    (
      $1,
      $2,
      'PAYMENT_CREATED',
      'payment',
      $3,
      $4::jsonb
    )
    `),
"collectionsService.js:85:56": ({  }) => (`
          SELECT 1
          FROM branches

          WHERE id=$1
            AND organization_id=$2
            AND status<>'inactive'
          `),
"collectionsService.js:899:74": ({  }) => (`
    INSERT INTO savings_transactions
    (
      organization_id,
      member_id,
      branch_id,
      loan_id,
      transaction_type,
      amount,
      transaction_date,
      description,
      created_by,
      idempotency_key
    )

    VALUES
    (
      $1,
      $2,
      $3,
      $4,
      'daily_deposit',
      $5,
      $6,
      $7,
      $8,
      $9
    )

    RETURNING id
    `),
"collectionsService.js:idem:savingsLookup": ({  }) => (`SELECT id FROM savings_transactions WHERE organization_id=$1 AND idempotency_key=$2 LIMIT 1`),
"collectionsService.js:942:75": ({  }) => (`
    INSERT INTO audit_logs
    (
      organization_id,
      user_id,
      action,
      entity_type,
      entity_id,
      metadata
    )

    VALUES
    (
      $1,
      $2,
      'savings_transaction.create',
      'savings_transaction',
      $3,
      $4::jsonb
    )
    `),
"dashboardService.js:11:76": ({ branchId }) => (`SELECT o.id, o.name, o.status,
                (SELECT COUNT(*)::int FROM branches WHERE organization_id=$1 AND status='active'${branchId ? ' AND id=$2' : ''}) AS branch_count,
                (SELECT COUNT(*)::int FROM users WHERE organization_id=$1 AND active=TRUE${branchId ? ' AND branch_id=$2' : ''}) AS user_count
         FROM organizations o WHERE o.id=$1`),
"dashboardService.js:17:86": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
       VALUES($1,$2,'dashboard_config.update','organization_settings',$1,$3::jsonb)`),
  "dashboardService.js:18:77": ({ hasBranch = false }) => (`SELECT COUNT(*)::int AS total FROM members WHERE organization_id=$1 AND status <> 'inactive'${hasBranch ? ' AND branch_id=$2' : ''}`),
  "dashboardService.js:22:78": ({ hasBranch = false }) => (`SELECT COUNT(*) FILTER (WHERE status IN ('draft','pending','approved','disbursed','active'))::int AS active_count,COALESCE(SUM(loan_amount) FILTER (WHERE status IN ('draft','pending','approved','disbursed','active')),0) AS active_amount,COUNT(*) FILTER (WHERE status='completed')::int AS closed_count,COUNT(*) FILTER (WHERE status='written_off')::int AS written_off_count,COUNT(*) FILTER (WHERE status='cancelled')::int AS cancelled_count FROM loans WHERE organization_id=$1${hasBranch ? ' AND branch_id=$2' : ''}`),
  "dashboardService.js:31:79": ({ hasBranch = false }) => (`SELECT COALESCE(SUM(interest_amount) FILTER (WHERE disbursed_at IS NOT NULL),0) AS total FROM loans WHERE organization_id=$1${hasBranch ? ' AND branch_id=$2' : ''}`),
  "dashboardService.js:36:80": ({ hasBranch = false }) => (`SELECT COALESCE(SUM(i.outstanding_amount) FILTER (WHERE i.status IN ('pending','partial','overdue')),0) AS total_due,COUNT(*) FILTER (WHERE i.status='overdue' OR (i.status IN ('pending','partial') AND i.due_date < CURRENT_DATE))::int AS overdue_count,COALESCE(SUM(i.outstanding_amount) FILTER (WHERE i.status='overdue' OR (i.status IN ('pending','partial') AND i.due_date < CURRENT_DATE)),0) AS overdue_amount FROM installments AS i WHERE i.organization_id=$1${hasBranch ? ' AND EXISTS (SELECT 1 FROM loans AS l WHERE l.id=i.loan_id AND l.organization_id=i.organization_id AND l.branch_id=$2)' : ''}`),
"dashboardService.js:3:84": ({  }) => (`SELECT setting_value FROM organization_settings WHERE organization_id=$1 AND setting_key=$2`),
  "dashboardService.js:46:81": ({ hasBranch = false }) => (`SELECT COALESCE(SUM(amount),0) AS total FROM payments WHERE organization_id=$1 AND status='posted' AND payment_date::date=$2::date${hasBranch ? ' AND branch_id=$3' : ''}`),
  "dashboardService.js:51:82": ({ hasBranch = false }) => (`SELECT COALESCE(SUM(disbursed_amount),0) AS total FROM loans WHERE organization_id=$1 AND disbursed_at::date=$2::date${hasBranch ? ' AND branch_id=$3' : ''}`),
  "dashboardService.js:59:83": ({ hasBranch = false }) => (`SELECT COALESCE(SUM(amount) FILTER (WHERE transaction_type IN ('deposit','daily_deposit')),0) AS total FROM savings_transactions WHERE organization_id=$1 AND transaction_date=$2::date${hasBranch ? ' AND branch_id=$3' : ''}`),
"dashboardService.js:9:85": ({  }) => (`INSERT INTO organization_settings(organization_id, setting_key, setting_value, updated_by)
       VALUES($1,$2,$3::jsonb,$4)
       ON CONFLICT (organization_id, setting_key)
       DO UPDATE SET setting_value=EXCLUDED.setting_value, updated_by=EXCLUDED.updated_by, updated_at=NOW()
       RETURNING setting_value`),
"expensesService.js:15:88": ({  }) => (`SELECT id FROM branches WHERE id=$1 AND organization_id=$2`),
"expensesService.js:15:91": ({  }) => (`DELETE FROM expense_entries WHERE id=$1 AND organization_id=$2`),
"expensesService.js:22:89": ({  }) => (`INSERT INTO expense_entries(organization_id,branch_id,category,amount,expense_date,description,created_by)
       VALUES($1,$2,$3,$4,$5,$6,$7)
       RETURNING id,organization_id,branch_id,category,amount,expense_date,description,created_by,created_at,updated_at`),
  "expensesService.js:25:87": ({ filters = [] }) => { const n=countParams(filters); const extra=renderFilters(filters,{branchId:p=>`branch_id=$${p}`,category:p=>`category=$${p}`,fromDate:p=>`expense_date >= $${p}::date`,toDate:p=>`expense_date <= $${p}::date`,denyAll:{static:'1=0'}}).map(x=>' AND '+x).join(''); return `SELECT id,organization_id,branch_id,category,amount,expense_date,description,created_by,created_at,updated_at FROM expense_entries WHERE organization_id=$1${extra} ORDER BY expense_date DESC, created_at DESC LIMIT $${n+2} OFFSET $${n+3}` },
"expensesService.js:44:92": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
     VALUES($1,$2,$3,'expense_entry',$4,$5::jsonb)`),
  "expensesService.js:59:93": ({ hasBranch = false }) => (`SELECT COALESCE(SUM(amount) FILTER (WHERE category='office'),0) AS office,COALESCE(SUM(amount) FILTER (WHERE category='travel'),0) AS travel,COALESCE(SUM(amount) FILTER (WHERE category='equipment'),0) AS equipment,COALESCE(SUM(amount) FILTER (WHERE category='other'),0) AS other FROM expense_entries WHERE organization_id=$1${hasBranch ? ' AND branch_id=$2' : ''}`),
"expensesService.js:6:90": ({  }) => (`SELECT id,category,amount,branch_id FROM expense_entries WHERE id=$1 AND organization_id=$2 FOR UPDATE`),
  "expensesService.js:77:94": ({ hasBranch = false }) => (`SELECT COALESCE(SUM(amount),0) AS total FROM expense_entries WHERE organization_id=$1 AND expense_date=$2::date${hasBranch ? ' AND branch_id=$3' : ''}`),
"installmentsService.js:11:98": ({  }) => ('SELECT id FROM installments WHERE loan_id=$1 AND organization_id=$2 LIMIT 1'),
  "installmentsService.js:13:101": ({}) => (`UPDATE installments SET status=$1,paid_date=$2,updated_at=NOW() WHERE id=$3 AND organization_id=$4 RETURNING ${INSTALLMENT_COLUMNS}`),
  "installmentsService.js:14:95": ({ hasLoanId = false }) => { const loanClause=hasLoanId ? ' AND i.loan_id=$2' : ''; const limitParam=hasLoanId ? '$3' : '$2'; const cols=INSTALLMENT_COLUMNS.split(',').map(c=>`i.${c}`).join(','); return `SELECT ${cols} FROM installments i JOIN loans l ON l.id=i.loan_id AND l.organization_id=i.organization_id WHERE i.organization_id=$1${loanClause} ORDER BY i.due_date ASC, i.installment_number ASC LIMIT ${limitParam}` },
  "installmentsService.js:18:99": ({}) => (`INSERT INTO installments(organization_id,loan_id,installment_number,due_date,installment_amount,paid_amount,outstanding_amount,status) VALUES($1,$2,$3,$4,$5,0,$5,'pending') RETURNING ${INSTALLMENT_COLUMNS}`),
"installmentsService.js:3:96": ({ select }) => (`SELECT ${select} FROM installments i WHERE i.id=$1 AND i.organization_id=$2`),
"installmentsService.js:51:102": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata) VALUES($1,$2,$3,'installment',$4,$5::jsonb)`),
  "installmentsService.js:7:100": ({}) => (`SELECT ${INSTALLMENT_COLUMNS} FROM installments WHERE id=$1 AND organization_id=$2`),
"installmentsService.js:7:97": ({  }) => (`SELECT id,organization_id,member_id,status,loan_amount,interest_amount,total_payable,installment_amount,number_of_installments,installment_frequency,first_installment_date,start_date FROM loans WHERE id=$1 AND organization_id=$2 FOR UPDATE`),
"insuranceService.js:11:104": ({  }) => (`SELECT id, branch_id FROM members WHERE id=$1 AND organization_id=$2 FOR UPDATE`),
"insuranceService.js:15:109": ({  }) => (`DELETE FROM member_insurance_transactions WHERE id=$1 AND organization_id=$2`),
"insuranceService.js:21:105": ({  }) => (`SELECT id FROM loans WHERE id=$1 AND organization_id=$2 AND member_id=$3`),
  "insuranceService.js:29:103": ({ filters = [] }) => { const n=countParams(filters); const extra=renderFilters(filters,{branchId:p=>`branch_id=$${p}`,memberId:p=>`member_id=$${p}`,transactionType:p=>`transaction_type=$${p}`,fromDate:p=>`transaction_date >= $${p}::date`,toDate:p=>`transaction_date <= $${p}::date`,denyAll:{static:'1=0'}}).map(x=>' AND '+x).join(''); return `SELECT id,organization_id,member_id,branch_id,loan_id,transaction_type,amount,transaction_date,description,created_by,created_at,updated_at FROM member_insurance_transactions WHERE organization_id=$1${extra} ORDER BY transaction_date DESC, created_at DESC LIMIT $${n+2} OFFSET $${n+3}` },
"insuranceService.js:41:106": ({  }) => (`SELECT 1 FROM branches WHERE id=$1 AND organization_id=$2`),
"insuranceService.js:43:107": ({  }) => (`INSERT INTO member_insurance_transactions(organization_id,member_id,branch_id,loan_id,transaction_type,amount,transaction_date,description,created_by)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)
       RETURNING id,organization_id,member_id,branch_id,loan_id,transaction_type,amount,transaction_date,description,created_by,created_at,updated_at`),
"insuranceService.js:50:110": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
     VALUES($1,$2,$3,'insurance_transaction',$4,$5::jsonb)`),
"insuranceService.js:6:108": ({  }) => (`SELECT id,branch_id FROM member_insurance_transactions WHERE id=$1 AND organization_id=$2 FOR UPDATE`),
  "insuranceService.js:70:111": ({ hasBranch = false, hasMember = false }) => (`SELECT COALESCE(SUM(amount) FILTER (WHERE transaction_type='premium'),0) AS premiums,COALESCE(SUM(amount) FILTER (WHERE transaction_type='claim'),0) AS claims FROM member_insurance_transactions WHERE organization_id=$1${hasBranch ? ' AND branch_id=$2' : ''}${hasMember ? ` AND member_id=$${hasBranch ? 3 : 2}` : ''}`),
"loansService.js:109:118": ({  }) => (`
          UPDATE loans

          SET

            loan_type =
              COALESCE(
                $1,
                loan_type
              ),

            loan_purpose =
              COALESCE(
                $2,
                loan_purpose
              ),

            loan_amount =
              $3,

            interest_rate =
              $4,

            interest_amount =
              $5,

            total_payable =
              $6,

            installment_amount =
              $7,

            number_of_installments =
              $8,

            installment_frequency =
              COALESCE(
                $9,
                installment_frequency
              ),

            start_date =
              COALESCE(
                $10,
                start_date
              ),

            first_installment_date =
              $11,

            branch_id =
              $12,

            updated_at =
              NOW()

          WHERE id = $13
            AND organization_id = $14

          RETURNING id
          `),
  "loansService.js:189:115": ({}) => (`SELECT ${LOAN_COLUMNS} FROM loans l JOIN members m ON m.id=l.member_id AND m.organization_id=l.organization_id WHERE l.id=$1 AND l.organization_id=$2`),
  "loansService.js:222:119": ({}) => (`SELECT ${LOAN_COLUMNS} FROM loans l JOIN members m ON m.id=l.member_id AND m.organization_id=l.organization_id WHERE l.id=$1 AND l.organization_id=$2`),
  "loansService.js:24:117": ({}) => (`SELECT ${LOAN_COLUMNS} FROM loans l JOIN members m ON m.id=l.member_id AND m.organization_id=l.organization_id WHERE l.id=$1 AND l.organization_id=$2 FOR UPDATE`),
"loansService.js:293:122": ({  }) => (`
      SELECT 1
      FROM branches
      WHERE id = $1
        AND organization_id = $2
        AND status = 'active'
      `),
"loansService.js:320:123": ({  }) => (`
      SELECT id, branch_id
      FROM members
      WHERE id = $1
        AND organization_id = $2
        AND status <> 'inactive'
      `),
"loansService.js:349:124": ({  }) => (`
    INSERT INTO audit_logs(
      organization_id,
      user_id,
      action,
      entity_type,
      entity_id,
      metadata
    )
    VALUES(
      $1,
      $2,
      $3,
      'loan',
      $4,
      $5::jsonb
    )
    `),
  "loansService.js:renewalCheck": ({}) => (`SELECT id,member_id,status FROM loans WHERE id=$1 AND organization_id=$2`),
"membersService.js:legacyBorrowers": ({ hasBranch = false }) => (`SELECT ${MEMBER_LIST_COLUMNS} FROM members m LEFT JOIN member_nominees n ON n.member_id=m.id AND n.organization_id=m.organization_id WHERE m.organization_id=$1 AND m.member_origin='previous_borrower' AND m.status <> 'inactive'${hasBranch ? ' AND m.branch_id=$2' : ''} ORDER BY m.created_at DESC LIMIT ${hasBranch ? '$3' : '$2'}`),
"loansService.js:legacyImportMember": ({}) => (`SELECT id,branch_id,member_origin,legacy_current_installments_paid,legacy_current_installment_amount,legacy_savings_balance FROM members WHERE id=$1 AND organization_id=$2 AND status <> 'inactive' FOR UPDATE`),
"loansService.js:legacyLoanInsert": ({}) => (`INSERT INTO loans(organization_id,branch_id,member_id,renewal_of_loan_id,loan_source_type,legacy_original_paid_amount,legacy_original_paid_installments,loan_number,loan_type,loan_purpose,loan_amount,interest_rate,interest_amount,total_payable,installment_amount,savings_amount,deposit_amount,number_of_installments,installment_frequency,start_date,first_installment_date,application_date,approval_date,disbursed_at,disbursed_amount,outstanding_amount,status,created_by,approved_by,created_at,updated_at) VALUES($1,$2,$3,NULL,'previous_loan',$4,$5,'LEGACY-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,12)),$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,'active',$24,$24,NOW(),NOW()) RETURNING id`),
"loansService.js:legacyLoanByMember": ({}) => (`SELECT ${LOAN_COLUMNS} FROM loans l JOIN members m ON m.id=l.member_id AND m.organization_id=l.organization_id WHERE l.organization_id=$1 AND l.member_id=$2 AND l.loan_source_type='previous_loan' ORDER BY l.created_at DESC LIMIT 50`),
"loansService.js:legacySchedule": ({}) => (`SELECT id,installment_number,installment_amount,paid_amount,outstanding_amount,status FROM installments WHERE organization_id=$1 AND loan_id=$2 ORDER BY installment_number FOR UPDATE`),
"loansService.js:legacyPaymentInsert": ({}) => (`INSERT INTO payments(organization_id,branch_id,member_id,loan_id,payment_number,amount,payment_date,payment_method,collector_id,notes,status,created_by) VALUES($1,$2,$3,$4,'LEGACY-PAY-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,16)),$5,$6,'cash',$7,$8,'posted',$7) RETURNING ${PAYMENT_RETURNING_COLUMNS}`),
"loansService.js:legacyPaymentAllocation": ({}) => (`INSERT INTO payment_allocations(organization_id,payment_id,loan_id,installment_id,allocation_type,amount) VALUES($1,$2,$3,$4,'installment',$5) RETURNING id`),
"loansService.js:legacyInstallmentUpdate": ({}) => (`UPDATE installments SET paid_amount=$1,outstanding_amount=$2,status=$3,paid_date=CASE WHEN $2=0 THEN $4::date ELSE paid_date END,updated_at=NOW() WHERE id=$5 AND organization_id=$6`),
"loansService.js:legacySavingsInsert": ({}) => (`INSERT INTO savings_transactions(organization_id,member_id,branch_id,transaction_type,amount,transaction_date,description,created_by) VALUES($1,$2,$3,'deposit',$4,$5,'Imported previous-member savings balance',$6) RETURNING id`),
"loansService.js:legacyLoanBalance": ({}) => (`UPDATE loans SET outstanding_amount=$1,status=CASE WHEN $1<=0.009 THEN 'completed' ELSE 'active' END,updated_at=NOW() WHERE id=$2 AND organization_id=$3 RETURNING id,organization_id,branch_id,member_id,renewal_of_loan_id,loan_source_type,legacy_original_paid_amount,legacy_original_paid_installments,loan_number,loan_type,loan_purpose,loan_amount,interest_rate,interest_amount,total_payable,installment_amount,savings_amount,deposit_amount,number_of_installments,installment_frequency,start_date,first_installment_date,application_date,approval_date,disbursed_at,disbursed_amount,outstanding_amount,status,created_by,approved_by,created_at,updated_at`),
"capitalService.js:shareList": ({}) => (`SELECT s.*,m.member_code,m.full_name AS member_name FROM capital_share_profiles s LEFT JOIN members m ON m.id=s.member_id AND m.organization_id=s.organization_id WHERE s.organization_id=$1 ORDER BY s.status DESC,s.shareholder_name ASC LIMIT $2 OFFSET $3`),
"capitalService.js:shareOne": ({}) => (`SELECT s.*,m.member_code,m.full_name AS member_name FROM capital_share_profiles s LEFT JOIN members m ON m.id=s.member_id AND m.organization_id=s.organization_id WHERE s.id=$1 AND s.organization_id=$2`),
"capitalService.js:shareInsert": ({}) => (`INSERT INTO capital_share_profiles(organization_id,member_id,shareholder_name,shareholder_phone,shareholder_email,share_units,issue_price_per_share,invested_amount,acquisition_date,status,notes,photo_url,created_by,updated_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$13) RETURNING id`),
"capitalService.js:shareUpdate": ({}) => (`UPDATE capital_share_profiles SET member_id=$1,shareholder_name=$2,shareholder_phone=$3,shareholder_email=$4,share_units=$5,issue_price_per_share=$6,invested_amount=$7,acquisition_date=$8,status=$9,notes=$10,photo_url=COALESCE($11,photo_url),updated_by=$12,updated_at=NOW() WHERE id=$13 AND organization_id=$14 RETURNING id`),
"capitalService.js:shareDelete": ({}) => (`DELETE FROM capital_share_profiles WHERE id=$1 AND organization_id=$2`),
"capitalService.js:shareTotals": ({}) => (`SELECT COALESCE(SUM(share_units) FILTER (WHERE status='active'),0) AS total_units,COALESCE(SUM(invested_amount) FILTER (WHERE status='active'),0) AS invested_capital FROM capital_share_profiles WHERE organization_id=$1`),
"capitalService.js:shareMarketValue": ({}) => (`SELECT setting_value->>'marketValue' AS market_value FROM organization_settings WHERE organization_id=$1 AND setting_key='share_capital_config' LIMIT 1`),
"capitalService.js:shareMarketValueUpsert": ({}) => (`INSERT INTO organization_settings(organization_id,setting_key,setting_value,updated_by) VALUES($1,'share_capital_config',$2::jsonb,$3) ON CONFLICT(organization_id,setting_key) DO UPDATE SET setting_value=EXCLUDED.setting_value,updated_by=EXCLUDED.updated_by,updated_at=NOW() RETURNING setting_value`),
"settingsService.js:userUiVisibility": ({}) => (`SELECT setting_value FROM organization_settings WHERE organization_id=$1 AND setting_key='user_ui_visibility' LIMIT 1`),
"settingsService.js:userUiVisibilityUpsert": ({}) => (`INSERT INTO organization_settings(organization_id,setting_key,setting_value,updated_by) VALUES($1,'user_ui_visibility',$2::jsonb,$3) ON CONFLICT(organization_id,setting_key) DO UPDATE SET setting_value=EXCLUDED.setting_value,updated_by=EXCLUDED.updated_by,updated_at=NOW() RETURNING setting_value,updated_at`),
"loansService.js:3:116": ({}) => (`SELECT ${LOAN_COLUMNS} FROM loans l JOIN members m ON m.id=l.member_id AND m.organization_id=l.organization_id WHERE l.id=$1 AND l.organization_id=$2`),
"loansService.js:40:121": ({  }) => (`
          DELETE FROM loans
          WHERE id = $1
            AND organization_id = $2
          `),
"loansService.js:426:125": ({  }) => (`
        SELECT status
        FROM loans
        WHERE id = $1
          AND organization_id = $2
        FOR UPDATE
        `),
  "loansService.js:483:126": ({ target }) => { const updates=['status=$1','updated_at=NOW()']; if(target==='approved') updates.unshift('approval_date=NOW(),approved_by=$4'); if(target==='disbursed') updates.unshift('disbursed_at=NOW(),disbursed_amount=loan_amount,outstanding_amount=total_payable'); return `UPDATE loans SET ${updates.join(',')} WHERE id=$2 AND organization_id=$3 RETURNING id`; },
"loansService.js:disbursement:openingDeposit": ({  }) => (`INSERT INTO savings_transactions
  (organization_id,member_id,branch_id,loan_id,transaction_type,amount,transaction_date,description,created_by)
  VALUES($1,$2,$3,$4,'deposit',$5,CURRENT_DATE,$6,$7)
  RETURNING id`),
"loansService.js:disbursement:loanScheduleConfig": ({}) => (`SELECT setting_value FROM organization_settings WHERE organization_id=$1 AND setting_key='loan_schedule_config' LIMIT 1`),
"loansService.js:disbursement:loanSchedule": ({  }) => (`SELECT id,number_of_installments,total_payable,installment_amount,installment_frequency,first_installment_date,start_date FROM loans WHERE id=$1 AND organization_id=$2 FOR UPDATE`),
"loansService.js:486:127": ({  }) => (`SELECT member_id, branch_id, loan_amount, deposit_amount FROM loans WHERE id=$1 AND organization_id=$2 FOR UPDATE`),
"loansService.js:493:128": ({  }) => (`INSERT INTO member_insurance_transactions
          (organization_id,member_id,branch_id,loan_id,transaction_type,amount,transaction_date,description,created_by)
         VALUES($1,$2,$3,$4,'premium',$5,CURRENT_DATE,$6,$7)
         RETURNING id`),
"loansService.js:500:129": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
         VALUES($1,$2,'insurance_transaction.create','insurance_transaction',$3,$4::jsonb)`),
  "loansService.js:513:130": ({}) => (`SELECT ${LOAN_COLUMNS} FROM loans l JOIN members m ON m.id=l.member_id AND m.organization_id=l.organization_id WHERE l.id=$1 AND l.organization_id=$2`),
  "loansService.js:79:113": ({ filters = [] }) => { const n=countParams(filters); const extra=renderFilters(filters,{search:p=>`(l.loan_number ILIKE $${p} OR l.loan_type ILIKE $${p} OR m.member_code ILIKE $${p} OR m.full_name ILIKE $${p})`,status:p=>`l.status=$${p}`,branchId:p=>`l.branch_id=$${p}`,scopedBranchId:p=>`l.branch_id=$${p}`,memberId:p=>`l.member_id=$${p}`,denyAll:{static:'1=0'}}).map(x=>' AND '+x).join(''); return `SELECT ${LOAN_COLUMNS} FROM loans l JOIN members m ON m.id=l.member_id AND m.organization_id=l.organization_id WHERE l.organization_id=$1${extra}${filters.includes('status') ? '' : " AND l.status IN ('draft','pending','approved','disbursed','active')"} ORDER BY l.created_at DESC LIMIT $${n+2} OFFSET $${n+3}` },
"loansService.js:7:112": ({  }) => (`
        SELECT branch_id
        FROM loans
        WHERE id = $1
          AND organization_id = $2
        `),
"loansService.js:88:114": ({  }) => (`
          INSERT INTO loans(
            organization_id,
            branch_id,
            member_id,
            renewal_of_loan_id,
            loan_source_type,
            legacy_original_paid_amount,
            legacy_original_paid_installments,
            loan_number,
            loan_type,
            loan_purpose,
            loan_amount,
            interest_rate,
            interest_amount,
            total_payable,
            installment_amount,
            savings_amount,
            deposit_amount,
            number_of_installments,
            installment_frequency,
            start_date,
            first_installment_date,
            application_date,
            status,
            created_by,
            idempotency_key,
            updated_at
          )

                    VALUES(
            $1,
            $2,
            $3,
            $4,
            $5,
            $6,
            $7,
            'LOAN-' ||
              upper(
                substr(
                  replace(gen_random_uuid()::text,'-',''),
                  1,
                  12
                )
              ),
            $8,
            $9,
            $10,
            $11,
            $12,
            $13,
            $14,
            $15,
            $16,
            $17,
            $18,
            $19,
            $20,
            COALESCE($21::timestamptz,NOW()),
            'pending',
            $22,
            $23,
            NOW()
          )

          RETURNING id
          `),
"loansService.js:8:120": ({  }) => (`
            SELECT status

            FROM loans

            WHERE id = $1
              AND organization_id = $2

            FOR UPDATE
            `),
"membersService.js:10:148": ({  }) => (`INSERT INTO member_nominees(organization_id,member_id,name,relation,mobile,nid,address)
         VALUES($1,$2,$3,$4,$5,$6,$7)
         ON CONFLICT(organization_id,member_id) DO UPDATE SET
           name=EXCLUDED.name, relation=EXCLUDED.relation, mobile=EXCLUDED.mobile,
           nid=EXCLUDED.nid, address=EXCLUDED.address, updated_at=NOW()
         RETURNING id,name,relation,mobile,nid,address,created_at,updated_at`),
"membersService.js:10:153": ({  }) => (`INSERT INTO member_activities(organization_id,member_id,activity_type,description,metadata,created_by)
       SELECT $1, id, $2, $3, $4::jsonb, $5 FROM members WHERE id=$6 AND organization_id=$1
       RETURNING id,activity_type,description,metadata,created_by,created_at`),
"membersService.js:11:157": ({  }) => ('SELECT financial FROM members WHERE id=$1 AND organization_id=$2'),
"membersService.js:131:159": ({  }) => ('SELECT 1 FROM branches WHERE id=$1 AND organization_id=$2 AND status=\'active\''),
"membersService.js:delete:activeLoan": ({  }) => (`SELECT id,status,outstanding_amount FROM loans WHERE member_id=$1 AND organization_id=$2 AND status NOT IN ('completed','cancelled','rejected') AND (status IN ('draft','pending','approved') OR outstanding_amount > 0.009) LIMIT 1`),
  "membersService.js:143:160": ({}) => (`SELECT ${MEMBER_COLUMNS} FROM members m WHERE m.id=$1 AND m.organization_id=$2`),
"membersService.js:14:133": ({  }) => (`SELECT id, status FROM members WHERE organization_id=$1 AND nid_or_passport=$2 LIMIT 1`),
"membersService.js:14:158": ({  }) => ('UPDATE members SET financial=$1::jsonb, updated_by=$2, updated_at=NOW() WHERE id=$3 AND organization_id=$4 RETURNING financial'),
"membersService.js:150:161": ({  }) => (`SELECT id,name,relation,mobile,nid,address,photo_data,photo_mime,photo_path,created_at,updated_at FROM member_nominees WHERE member_id=$1 AND organization_id=$2`),
"membersService.js:152:162": ({  }) => (`SELECT id,document_type,name,reference,storage_key,description,uploaded_by,uploaded_at FROM member_documents WHERE member_id=$1 AND organization_id=$2 ORDER BY uploaded_at DESC`),
"membersService.js:154:163": ({  }) => (`SELECT id,activity_type,description,metadata,created_by,created_at FROM member_activities WHERE member_id=$1 AND organization_id=$2 ORDER BY created_at DESC`),
"membersService.js:161:164": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
     VALUES($1,$2,$3,'member',$4,$5::jsonb)`),
  "membersService.js:16:132": ({ filters = [] }) => { const n=countParams(filters); const extra=renderFilters(filters,{search:p=>`(m.member_code ILIKE $${p} OR m.full_name ILIKE $${p} OR m.phone ILIKE $${p} OR m.nid_or_passport ILIKE $${p})`,status:p=>`m.status=$${p}`,branchId:p=>`m.branch_id=$${p}`,scopedBranchId:p=>`m.branch_id=$${p}`,denyAll:{static:'1=0'}}).map(x=>' AND '+x).join(''); return `SELECT ${MEMBER_LIST_COLUMNS},EXISTS (SELECT 1 FROM loans l WHERE l.member_id=m.id AND l.organization_id=m.organization_id AND l.status IN ('disbursed','active','approved','pending','draft')) AS has_blocking_loan FROM members m LEFT JOIN member_nominees n ON n.member_id=m.id AND n.organization_id=m.organization_id WHERE m.organization_id=$1${extra} ORDER BY m.created_at DESC LIMIT $${n+2} OFFSET $${n+3}` },
"membersService.js:17:143": ({  }) => (`SELECT id, status FROM members WHERE organization_id=$1 AND nid_or_passport=$2 AND id != $3 LIMIT 1`),
"membersService.js:24:134": ({  }) => ('SELECT pg_advisory_xact_lock(hashtext($1::text))'),
"membersService.js:25:135": ({  }) => (`SELECT COALESCE(MAX(NULLIF(regexp_replace(member_code, '^.*-', ''), '')::int), 0) AS mx
         FROM members WHERE organization_id=$1 AND member_code ~ '^MEM-'`),
  "membersService.js:31:144": ({}) => (`UPDATE members SET branch_id=$1,full_name=$2,email=$3,phone=$4,address=$5,nid_or_passport=$6,status=COALESCE($7,status),personal_info=$8::jsonb,financial=$9::jsonb,updated_by=$10,updated_at=NOW() WHERE id=$11 AND organization_id=$12 RETURNING ${MEMBER_RETURNING_COLUMNS}`),
  "membersService.js:34:136": ({}) => (`INSERT INTO members(organization_id,branch_id,member_code,full_name,email,phone,address,nid_or_passport,member_origin,legacy_current_installments_paid,legacy_current_installment_amount,legacy_savings_balance,personal_info,financial,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13::jsonb,$14::jsonb,$15) RETURNING ${MEMBER_RETURNING_COLUMNS}`),
"membersService.js:3:141": ({  }) => (`SELECT photo_path,photo_data,photo_mime FROM members WHERE id=$1 AND organization_id=$2`),
"membersService.js:3:142": ({  }) => (`SELECT photo_path,photo_data,photo_mime FROM member_nominees WHERE member_id=$1 AND organization_id=$2`),
"membersService.js:3:146": ({  }) => (`SELECT id,name,relation,mobile,nid,address,photo_data,photo_mime,photo_path,created_at,updated_at FROM member_nominees WHERE member_id=$1 AND organization_id=$2`),
"membersService.js:3:149": ({  }) => (`SELECT id,document_type,name,reference,storage_key,description,uploaded_by,uploaded_at FROM member_documents WHERE member_id=$1 AND organization_id=$2 ORDER BY uploaded_at DESC`),
"membersService.js:3:151": ({  }) => (`DELETE FROM member_documents WHERE id=$1 AND member_id=$2 AND organization_id=$3`),
"membersService.js:3:152": ({  }) => (`SELECT id,activity_type,description,metadata,created_by,created_at FROM member_activities WHERE member_id=$1 AND organization_id=$2 ORDER BY created_at DESC`),
"membersService.js:3:154": ({  }) => ('SELECT family FROM members WHERE id=$1 AND organization_id=$2'),
"membersService.js:3:156": ({  }) => ('SELECT financial FROM members WHERE id=$1 AND organization_id=$2'),
"membersService.js:44:137": ({  }) => ('UPDATE members SET photo_path=$1, photo_data=NULL, photo_mime=NULL WHERE id=$2 AND organization_id=$3'),
"membersService.js:4:131": ({  }) => (`SELECT branch_id FROM members WHERE id=$1 AND organization_id=$2`),
"membersService.js:54:138": ({  }) => (`INSERT INTO capital_entries
            (organization_id, branch_id, entry_type, amount, entry_date, description, created_by)
           VALUES ($1, $2, 'admission_fee', $3, CURRENT_DATE, $4, $5)
           RETURNING id`),
"membersService.js:5:155": ({  }) => (`UPDATE members SET family=$1::jsonb, updated_by=$2, updated_at=NOW() WHERE id=$3 AND organization_id=$4 RETURNING family`),
"membersService.js:61:139": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
           VALUES($1,$2,'admission_fee.create','capital_entry',$3,$4::jsonb)`),
"membersService.js:6:145": ({  }) => (`UPDATE members SET status='inactive',updated_by=$1,updated_at=NOW() WHERE id=$2 AND organization_id=$3 RETURNING id`),
"membersService.js:6:150": ({  }) => (`INSERT INTO member_documents(organization_id,member_id,document_type,name,reference,storage_key,description,uploaded_by)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8)
       RETURNING id,document_type,name,reference,storage_key,description,uploaded_by,uploaded_at`),
"membersService.js:73:140": ({  }) => (`INSERT INTO member_nominees(organization_id,member_id,name,relation,mobile,nid,address,photo_path,photo_data,photo_mime)
          VALUES($1,$2,$3,$4,$5,$6,$7,$8,NULL,NULL)
          ON CONFLICT(organization_id,member_id) DO UPDATE SET name=EXCLUDED.name,relation=EXCLUDED.relation,mobile=EXCLUDED.mobile,nid=EXCLUDED.nid,address=EXCLUDED.address,photo_path=COALESCE(EXCLUDED.photo_path, member_nominees.photo_path),photo_data=NULL,photo_mime=NULL`),
"membersService.js:8:147": ({  }) => ('SELECT id FROM members WHERE id=$1 AND organization_id=$2'),
  "middleware.auth:permissions": ({}) => (`SELECT p.code FROM role_permissions rp JOIN permissions p ON p.id=rp.permission_id JOIN roles r ON r.id=rp.role_id WHERE r.id=$1 AND (r.is_system=TRUE OR r.organization_id=$2) ORDER BY p.code`),
  "middleware.auth:session": ({}) => (`SELECT s.id AS session_id,s.user_id,s.organization_id,u.branch_id,u.email,u.role,u.role_id,u.active,u.full_name AS name,r.code AS role_code,r.name AS role_name,r.organization_id AS role_organization_id,r.is_system AS role_is_system,r.is_protected AS role_is_protected FROM sessions s JOIN users u ON u.id=s.user_id JOIN organizations o ON o.id=s.organization_id JOIN roles r ON r.id=u.role_id WHERE s.token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at>NOW() AND u.active=TRUE AND o.status='active' AND ((r.is_system=TRUE AND r.organization_id IS NULL) OR (r.is_system=FALSE AND r.organization_id=s.organization_id)) LIMIT 1`),
"organizationService.js:17:167": ({  }) => (`SELECT id,name,status,company_type,phone,email,address,country,currency,working_days,office_start_time,office_end_time,timezone FROM organizations WHERE id=$1 FOR UPDATE`),
"organizationService.js:3:165": ({  }) => (`SELECT id,name,status,company_code,company_type,phone,email,address,country,currency,working_days,office_start_time,office_end_time,timezone,created_at,updated_at
       FROM organizations WHERE id=$1`),
"organizationService.js:47:168": ({  }) => (`UPDATE organizations SET name=$1,status=$2,phone=$3,email=$4,address=$5,company_type=$6,country=$7,currency=$8,working_days=$9::jsonb,office_start_time=$10::time,office_end_time=$11::time,timezone=$12,updated_at=NOW()
         WHERE id=$13
         RETURNING id,name,status,company_code,company_type,phone,email,address,country,currency,working_days,office_start_time,office_end_time,timezone,created_at,updated_at`),
"organizationService.js:54:169": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
         VALUES($1,$2,'organization.update','organization',$1,$3::jsonb)`),
"organizationService.js:5:166": ({ branchId }) => (`SELECT
         o.id,
         o.name,
         o.status,
         (SELECT COUNT(*)::int
            FROM branches
           WHERE organization_id=$1 AND status='active'${branchId ? ' AND id=$2' : ''}) AS branch_count,
         (SELECT COUNT(*)::int
            FROM users
           WHERE organization_id=$1 AND active=TRUE${branchId ? ' AND branch_id=$2' : ''}) AS user_count,
         (SELECT COUNT(*)::int
            FROM members
           WHERE organization_id=$1 AND status <> 'inactive'${branchId ? ' AND branch_id=$2' : ''}) AS member_count
       FROM organizations o
       WHERE o.id=$1`),
  "paymentsService.js:11:171": ({ filters = [] }) => { const n=countParams(filters); const extra=renderPaymentFilters(filters); return `SELECT ${PAYMENT_COLUMNS},m.member_code,m.full_name AS member_name,EXISTS (SELECT 1 FROM audit_logs a WHERE a.organization_id=p.organization_id AND a.entity_type='payment' AND a.entity_id=p.id AND a.action='PAYMENT_CREATED' AND (a.metadata->>'source')='daily_collection') AS from_daily_collection FROM payments p JOIN members m ON m.id=p.member_id AND m.organization_id=p.organization_id WHERE p.organization_id=$1${extra ? ' AND '+extra : ''} ORDER BY p.payment_date DESC,p.created_at DESC LIMIT $${n+2} OFFSET $${n+3}` },
"paymentsService.js:12:174": ({  }) => ('SELECT id,branch_id FROM users WHERE id=$1 AND organization_id=$2 AND active=TRUE'),
  "paymentsService.js:14:193": ({ filters = [], limit = 500 }) => { const w=renderPaymentFilters(filters); return `SELECT p.id,p.member_id,p.loan_id,p.status,p.amount,COALESCE(alloc.total,0) AS allocated_amount,COALESCE(alloc.count,0) AS allocation_count,COALESCE(alloc.bad_installment,0) AS bad_installment,COALESCE(alloc.bad_advance,0) AS bad_advance,COALESCE(alloc.non_positive,0) AS non_positive FROM payments p LEFT JOIN LATERAL (SELECT SUM(amount) AS total,COUNT(*) AS count,COUNT(*) FILTER (WHERE allocation_type='installment' AND installment_id IS NULL) AS bad_installment,COUNT(*) FILTER (WHERE allocation_type='advance' AND installment_id IS NOT NULL) AS bad_advance,COUNT(*) FILTER (WHERE amount<=0) AS non_positive FROM payment_allocations WHERE payment_id=p.id AND organization_id=p.organization_id AND status='active') alloc ON TRUE WHERE p.organization_id=$1${w ? ' AND '+w : ''} ORDER BY p.payment_date DESC LIMIT ${Number(limit)}` },
"paymentsService.js:15:175": ({  }) => (`SELECT nextval('payment_number_seq') AS n`),
  "paymentsService.js:16:176": ({}) => (`INSERT INTO payments(organization_id,branch_id,member_id,loan_id,payment_number,amount,payment_date,payment_method,transaction_reference,bank_name,bank_account,collector_id,notes,status,idempotency_key,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,'posted',$14,$15) RETURNING ${PAYMENT_RETURNING_COLUMNS}`),
  "paymentsService.js:18:184": ({ filters = [] }) => { const w=renderPaymentFilters(filters); return `SELECT COUNT(*) FILTER (WHERE p.status='posted') AS payment_count,COALESCE(SUM(p.amount) FILTER (WHERE p.status='posted'),0) AS posted_amount,COALESCE(SUM(p.amount) FILTER (WHERE p.status IN ('cancelled','reversed')),0) AS cancelled_amount,COALESCE(AVG(p.amount) FILTER (WHERE p.status='posted'),0) AS average_payment FROM payments p WHERE p.organization_id=$1${w ? ' AND '+w : ''}` },
"paymentsService.js:1:194": ({  }) => (`SELECT * FROM payment_allocations WHERE organization_id=$1 AND payment_id=$2 ORDER BY created_at`),
"paymentsService.js:1:195": ({  }) => (`SELECT receipt_number,status,issued_at,issued_by FROM payment_receipts WHERE organization_id=$1 AND payment_id=$2`),
"paymentsService.js:1:196": ({  }) => (`SELECT * FROM payment_allocations WHERE organization_id=$1 AND payment_id=$2 ORDER BY created_at`),
"paymentsService.js:20:177": ({  }) => (`SELECT id,installment_amount,paid_amount,outstanding_amount,status FROM installments WHERE organization_id=$1 AND loan_id=$2 AND status NOT IN ('paid','waived','cancelled') AND outstanding_amount>0 ORDER BY due_date,installment_number FOR UPDATE`),
"paymentsService.js:22:178": ({  }) => (`INSERT INTO payment_allocations(organization_id,payment_id,loan_id,installment_id,allocation_type,amount,status) VALUES($1,$2,$3,$4,'installment',$5,'active') RETURNING *`),
  "paymentsService.js:23:185": ({ filters = [] }) => { const w=renderPaymentFilters(filters); return `SELECT COALESCE(SUM(pa.amount) FILTER (WHERE pa.allocation_type='installment' AND pa.status='active'),0) AS installment_amount,COALESCE(SUM(pa.amount) FILTER (WHERE pa.allocation_type='advance' AND pa.status='active'),0) AS advance_amount FROM payment_allocations pa JOIN payments p ON p.id=pa.payment_id AND p.organization_id=pa.organization_id WHERE p.organization_id=$1${w ? ' AND '+w : ''}` },
"paymentsService.js:24:179": ({  }) => (`UPDATE installments SET paid_amount=$1,outstanding_amount=$2,status=$3,paid_date=CASE WHEN $3::varchar='paid' THEN COALESCE(paid_date,$4::date) ELSE paid_date END,updated_at=NOW() WHERE id=$5 AND organization_id=$6`),
"paymentsService.js:26:180": ({  }) => (`INSERT INTO payment_allocations(organization_id,payment_id,loan_id,installment_id,allocation_type,amount,status) VALUES($1,$2,$3,NULL,'advance',$4,'active') RETURNING *`),
  "paymentsService.js:27:186": ({ filters = [] }) => { const w=renderPaymentFilters(filters); return `SELECT p.payment_method AS name,COUNT(*)::int AS count,COALESCE(SUM(p.amount),0) AS amount FROM payments p WHERE p.organization_id=$1 AND p.status='posted'${w ? ' AND '+w : ''} GROUP BY p.payment_method ORDER BY amount DESC` },
"paymentsService.js:28:181": ({  }) => (`UPDATE loans SET outstanding_amount=$1,status=CASE WHEN $1::numeric=0 AND status IN ('disbursed','active') THEN 'completed' ELSE status END,updated_at=NOW() WHERE id=$2 AND organization_id=$3`),
"paymentsService.js:29:182": ({  }) => (`SELECT nextval('receipt_number_seq') AS n`),
  "paymentsService.js:29:187": ({ filters = [] }) => { const w=renderPaymentFilters(filters); return `SELECT p.collector_id,u.full_name AS collector_name,COUNT(*)::int AS count,COALESCE(SUM(p.amount),0) AS amount,COALESCE(SUM(p.amount) FILTER (WHERE p.payment_method='cash'),0) AS cash,COALESCE(SUM(p.amount) FILTER (WHERE p.payment_method<>'cash'),0) AS digital FROM payments p LEFT JOIN users u ON u.id=p.collector_id AND u.organization_id=p.organization_id WHERE p.organization_id=$1 AND p.status='posted'${w ? ' AND '+w : ''} GROUP BY p.collector_id,u.full_name ORDER BY amount DESC NULLS LAST` },
"paymentsService.js:30:183": ({  }) => (`INSERT INTO payment_receipts(organization_id,payment_id,receipt_number,status,issued_by) VALUES($1,$2,$3,'active',$4)`),
  "paymentsService.js:34:188": ({ filters = [] }) => { const w=renderPaymentFilters(filters); return `SELECT p.member_id,m.member_code,m.full_name AS member_name,COUNT(*)::int AS count,COALESCE(SUM(p.amount),0) AS amount,MAX(p.payment_date) AS last_payment_date FROM payments p JOIN members m ON m.id=p.member_id AND m.organization_id=p.organization_id WHERE p.organization_id=$1 AND p.status='posted'${w ? ' AND '+w : ''} GROUP BY p.member_id,m.member_code,m.full_name ORDER BY amount DESC` },
  "paymentsService.js:38:189": ({ filters = [] }) => { const w=renderPaymentFilters(filters); return `SELECT p.loan_id,l.loan_number,p.member_id,m.full_name AS member_name,COUNT(*)::int AS count,COALESCE(SUM(p.amount),0) AS amount FROM payments p JOIN loans l ON l.id=p.loan_id AND l.organization_id=p.organization_id JOIN members m ON m.id=p.member_id AND m.organization_id=p.organization_id WHERE p.organization_id=$1 AND p.status='posted'${w ? ' AND '+w : ''} GROUP BY p.loan_id,l.loan_number,p.member_id,m.full_name ORDER BY amount DESC` },
"paymentsService.js:39:201": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata) VALUES($1,$2,$3,'payment',$4,$5::jsonb)`),
  "paymentsService.js:overdueMembers": ({ hasBranch = false }) => (`SELECT m.id AS member_id,m.member_code,m.full_name AS member_name,COALESCE(SUM(i.outstanding_amount),0) AS overdue_amount,MAX(p.payment_date) AS last_payment_date FROM members m JOIN loans l ON l.member_id=m.id AND l.organization_id=m.organization_id AND l.status IN ('disbursed','active') JOIN installments i ON i.loan_id=l.id AND i.organization_id=l.organization_id AND i.status IN ('pending','partial','overdue') AND i.outstanding_amount>0 AND i.due_date < (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Dhaka')::date LEFT JOIN LATERAL (SELECT MAX(payment_date) AS payment_date FROM payments WHERE organization_id=m.organization_id AND member_id=m.id AND status='posted') p ON TRUE WHERE m.organization_id=$1 AND m.status<>'inactive'${hasBranch ? ' AND m.branch_id=$2' : ''} GROUP BY m.id,m.member_code,m.full_name HAVING COALESCE(SUM(i.outstanding_amount),0)>0 ORDER BY overdue_amount DESC LIMIT 500`),
"paymentsService.js:41:190": ({ filters = [] }) => { const w=renderPaymentFilters(filters); const statusAlready=(filters||[]).includes('status'); const posted=statusAlready?'':" AND p.status='posted'"; return `SELECT (p.payment_date AT TIME ZONE 'Asia/Dhaka')::date AS date,COUNT(*)::int AS count,COALESCE(SUM(p.amount),0) AS amount,COUNT(*) FILTER (WHERE EXISTS (SELECT 1 FROM audit_logs a WHERE a.organization_id=p.organization_id AND a.entity_type='payment' AND a.entity_id=p.id AND a.action IN ('PAYMENT_CREATED','payment.create') AND COALESCE(a.metadata->>'source','')='daily_collection'))::int AS daily_collection_count,COALESCE(SUM(p.amount) FILTER (WHERE EXISTS (SELECT 1 FROM audit_logs a WHERE a.organization_id=p.organization_id AND a.entity_type='payment' AND a.entity_id=p.id AND a.action IN ('PAYMENT_CREATED','payment.create') AND COALESCE(a.metadata->>'source','')='daily_collection')),0) AS daily_collection_amount FROM payments p WHERE p.organization_id=$1${w ? ' AND '+w : ''}${posted} GROUP BY (p.payment_date AT TIME ZONE 'Asia/Dhaka')::date ORDER BY date DESC` },

  "paymentsService.js:43:191": ({ filters = [] }) => { const w=renderPaymentFilters(filters); const statusAlready = (filters||[]).includes('status'); const posted = statusAlready ? '' : " AND p.status='posted'"; return `SELECT to_char(date_trunc('month',(p.payment_date AT TIME ZONE 'Asia/Dhaka')),'YYYY-MM') AS month,COUNT(*)::int AS count,COALESCE(SUM(p.amount),0) AS amount FROM payments p WHERE p.organization_id=$1${w ? ' AND '+w : ''}${posted} GROUP BY date_trunc('month',(p.payment_date AT TIME ZONE 'Asia/Dhaka')) ORDER BY month DESC` },
  "paymentsService.js:44:202": ({ lock = false }) => (`SELECT ${PAYMENT_COLUMNS} FROM payments p WHERE p.id=$1 AND p.organization_id=$2${lock ? ' FOR UPDATE' : ''}`),
  "paymentsService.js:45:192": ({ filters = [] }) => { const w=renderPaymentFilters(filters); const statusAlready=(filters||[]).includes('status'); const posted=statusAlready?'':" AND p.status='posted'"; return `SELECT p.id,p.member_id,p.loan_id,p.payment_number,p.amount,p.payment_date,p.payment_method,p.status,p.collector_id,EXISTS (SELECT 1 FROM audit_logs a WHERE a.organization_id=p.organization_id AND a.entity_type='payment' AND a.entity_id=p.id AND a.action IN ('PAYMENT_CREATED','payment.create') AND COALESCE(a.metadata->>'source','')='daily_collection') AS from_daily_collection FROM payments p WHERE p.organization_id=$1${w ? ' AND '+w : ''}${posted} ORDER BY p.payment_date DESC LIMIT 2000` },
"paymentsService.js:4:170": ({  }) => (`SELECT branch_id FROM payments WHERE id=$1 AND organization_id=$2`),
"paymentsService.js:4:197": ({  }) => (`SELECT id,branch_id FROM payments WHERE id=$1 AND organization_id=$2`),
"paymentsService.js:5:199": ({  }) => (`SELECT pr.receipt_number,pr.status,pr.issued_at,pr.issued_by,p.id AS payment_id,p.payment_number,p.amount,p.payment_date,p.payment_method,p.transaction_reference,p.bank_name,p.bank_account,p.collector_id,p.notes,p.member_id,p.loan_id FROM payment_receipts pr JOIN payments p ON p.id=pr.payment_id AND p.organization_id=pr.organization_id WHERE pr.organization_id=$1 AND pr.payment_id=$2`),
  "paymentsService.js:6:172": ({}) => (`SELECT ${PAYMENT_COLUMNS} FROM payments p WHERE p.organization_id=$1 AND p.idempotency_key=$2 FOR UPDATE`),
"paymentsService.js:6:198": ({  }) => (`SELECT a.id,a.action,a.metadata,a.created_at,a.user_id,u.full_name AS user_name FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id WHERE a.organization_id=$1 AND a.entity_type='payment' AND a.entity_id=$2 ORDER BY a.created_at DESC`),
"paymentsService.js:78:203": ({  }) => (`SELECT * FROM payment_allocations WHERE organization_id=$1 AND payment_id=$2 AND status='active' FOR UPDATE`),
"paymentsService.js:79:204": ({  }) => (`SELECT paid_amount,outstanding_amount,installment_amount,status FROM installments WHERE id=$1 AND organization_id=$2 FOR UPDATE`),
"paymentsService.js:79:205": ({  }) => (`UPDATE installments SET paid_amount=$1,outstanding_amount=$2,status=$3,paid_date=CASE WHEN $3::varchar='paid' THEN paid_date ELSE NULL END,updated_at=NOW() WHERE id=$4 AND organization_id=$5`),
"paymentsService.js:7:173": ({  }) => (`SELECT l.id,l.organization_id,l.branch_id,l.member_id,l.total_payable,l.outstanding_amount,l.status FROM loans l WHERE l.id=$1 AND l.organization_id=$2 FOR UPDATE`),
"paymentsService.js:7:200": ({  }) => (`SELECT id,installment_id,allocation_type,amount,status FROM payment_allocations WHERE organization_id=$1 AND payment_id=$2 ORDER BY created_at`),
"paymentsService.js:80:206": ({ target }) => (`UPDATE payment_allocations SET status=$1,${target==='cancelled'?'cancelled_at':'reversed_at'}=NOW() WHERE id=$2 AND organization_id=$3`),
"paymentsService.js:81:207": ({  }) => (`SELECT total_payable FROM loans WHERE id=$1 AND organization_id=$2 FOR UPDATE`),
"paymentsService.js:82:208": ({  }) => (`UPDATE loans SET outstanding_amount=LEAST(total_payable,outstanding_amount+$1),status=CASE WHEN status='completed' THEN 'active' ELSE status END,updated_at=NOW() WHERE id=$2 AND organization_id=$3`),
"paymentsService.js:83:209": ({  }) => (`UPDATE payments SET status=$1,updated_at=NOW() WHERE id=$2 AND organization_id=$3`),
"paymentsService.js:84:210": ({  }) => (`UPDATE payment_receipts SET status='void' WHERE payment_id=$1 AND organization_id=$2`),
"rbacService.js:13:217": ({  }) => (`SELECT COUNT(*)::int AS count FROM users WHERE role_id=$1 AND active=TRUE`),
  "rbacService.js:17:214": ({}) => (`INSERT INTO roles(organization_id,code,name,description,is_system,is_protected,created_by) VALUES($1,$2,$3,$4,FALSE,FALSE,$5) RETURNING ${ROLE_COLUMNS}`),
"rbacService.js:17:220": ({  }) => (`SELECT id,code FROM permissions WHERE code = ANY($1::varchar[])`),
  "rbacService.js:18:216": ({}) => (`UPDATE roles SET name=$1,description=$2,updated_at=NOW() WHERE id=$3 RETURNING ${ROLE_COLUMNS}`),
"rbacService.js:20:218": ({  }) => (`DELETE FROM roles WHERE id=$1`),
"rbacService.js:25:221": ({  }) => (`DELETE FROM role_permissions WHERE role_id=$1`),
"rbacService.js:27:222": ({  }) => (`INSERT INTO role_permissions(role,permission_id,role_id)
           VALUES($1,$2,$3)`),
  "rbacService.js:30:223": ({}) => (`SELECT ${ROLE_COLUMNS} FROM roles r WHERE r.id=$1`),
"rbacService.js:3:211": ({  }) => (`SELECT id,code FROM permissions ORDER BY code`),
  "rbacService.js:3:212": ({}) => (`SELECT ${ROLE_COLUMNS} FROM roles r WHERE (r.is_system=TRUE AND $2=TRUE) OR (r.is_system=FALSE AND r.organization_id=$1) ORDER BY r.is_system DESC,r.name ASC`),
"rbacService.js:44:224": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
     VALUES($1,$2,$3,'role',$4,$5::jsonb)`),
"rbacService.js:7:215": ({  }) => (`SELECT p.id,p.code
         FROM role_permissions rp JOIN permissions p ON p.id=rp.permission_id
         WHERE rp.role_id=$1 ORDER BY p.code`),
"rbacService.js:7:219": ({  }) => (`SELECT p.id,p.code FROM role_permissions rp
         JOIN permissions p ON p.id=rp.permission_id
         WHERE rp.role_id=$1 ORDER BY p.code`),
"rbacService.js:9:213": ({  }) => (`SELECT 1 FROM roles WHERE organization_id=$1 AND code=$2 LIMIT 1`),
  "repository:health": ({}) => ('SELECT 1 AS ok'),
"savingsService.js:11:226": ({  }) => (`SELECT id,branch_id FROM members WHERE id=$1 AND organization_id=$2 FOR UPDATE`),
"savingsService.js:11:231": ({  }) => (`SELECT id FROM members WHERE id=$1 AND organization_id=$2 FOR UPDATE`),
"savingsService.js:18:232": ({  }) => (`DELETE FROM savings_transactions WHERE id=$1 AND organization_id=$2`),
"savingsService.js:23:227": ({  }) => (`SELECT id FROM branches WHERE id=$1 AND organization_id=$2`),
  "savingsService.js:29:225": ({ filters = [] }) => { const n=countParams(filters); const extra=renderFilters(filters,{branchId:p=>`branch_id=$${p}`,memberId:p=>`member_id=$${p}`,transactionType:p=>`transaction_type=$${p}`,fromDate:p=>`transaction_date >= $${p}::date`,toDate:p=>`transaction_date <= $${p}::date`,denyAll:{static:'1=0'}}).map(x=>' AND '+x).join(''); return `SELECT id,organization_id,member_id,branch_id,loan_id,transaction_type,amount,transaction_date,description,created_by,created_at,updated_at FROM savings_transactions WHERE organization_id=$1${extra} ORDER BY transaction_date DESC, created_at DESC LIMIT $${n+2} OFFSET $${n+3}` },
"savingsService.js:31:228": ({  }) => (`SELECT id, branch_id, status FROM loans WHERE id=$1 AND organization_id=$2 AND member_id=$3`),
"savingsService.js:49:229": ({  }) => (`INSERT INTO savings_transactions(organization_id,member_id,branch_id,loan_id,transaction_type,amount,transaction_date,description,created_by)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)
       RETURNING id,organization_id,member_id,branch_id,loan_id,transaction_type,amount,transaction_date,description,created_by,created_at,updated_at`),
"savingsService.js:56:233": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
     VALUES($1,$2,$3,'savings_transaction',$4,$5::jsonb)`),
"savingsService.js:6:230": ({  }) => (`SELECT id,transaction_type,amount,member_id,branch_id FROM savings_transactions WHERE id=$1 AND organization_id=$2 FOR UPDATE`),
  "savingsService.js:77:234": ({ hasBranch = false, hasMember = false }) => (`SELECT COALESCE(SUM(amount) FILTER (WHERE transaction_type='deposit'),0) AS deposits,COALESCE(SUM(amount) FILTER (WHERE transaction_type='daily_deposit'),0) AS daily_deposits,COALESCE(SUM(amount) FILTER (WHERE transaction_type='withdrawal'),0) AS withdrawals,COALESCE(SUM(amount) FILTER (WHERE transaction_type='installment_payment'),0) AS installment_payments FROM savings_transactions WHERE organization_id=$1${hasBranch ? ' AND branch_id=$2' : ''}${hasMember ? ` AND member_id=$${hasBranch ? 3 : 2}` : ''}`),
"settingsService.js:14:237": ({  }) => (`INSERT INTO organization_settings(organization_id, setting_key, setting_value, updated_by)
         VALUES($1,$2,$3::jsonb,$4)
         ON CONFLICT (organization_id, setting_key)
         DO UPDATE SET setting_value=EXCLUDED.setting_value, updated_by=EXCLUDED.updated_by, updated_at=NOW()
         RETURNING setting_value, updated_at`),
"settingsService.js:22:238": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata)
         VALUES($1,$2,$3,'organization_settings',$1,$4::jsonb)`),
"settingsService.js:4:235": ({  }) => (`SELECT setting_key, setting_value, updated_at FROM organization_settings
       WHERE organization_id=$1 AND setting_key = ANY($2::text[])`),
"settingsService.js:6:236": ({  }) => (`SELECT setting_value, updated_at FROM organization_settings WHERE organization_id=$1 AND setting_key=$2`),
"usersService.js:13:241": ({  }) => (`SELECT 1 FROM branches WHERE id=$1 AND organization_id=$2 AND status<>'inactive'`),
"usersService.js:13:246": ({  }) => (`SELECT id,code,is_system,is_protected FROM roles WHERE code=$1 AND is_system=FALSE AND organization_id=$2`),
"usersService.js:17:242": ({  }) => (`SELECT 1 FROM users WHERE lower(email)=lower($1)`),
"usersService.js:17:247": ({  }) => (`SELECT 1 FROM branches WHERE id=$1 AND organization_id=$2 AND status<>'inactive'`),
"usersService.js:19:248": ({  }) => (`SELECT 1 FROM users WHERE lower(email)=lower($1) AND id<>$2`),
"usersService.js:21:243": ({  }) => (`INSERT INTO users(organization_id,branch_id,user_code,email,password_hash,role,role_id,active,full_name,created_by)
       VALUES($1,$2,$3,$4,$5,$6,$7,TRUE,$8,$9)
       RETURNING id,user_code,email,full_name,branch_id,role_id,active,created_at`),
"usersService.js:21:249": ({  }) => (`UPDATE users SET full_name=$1,email=$2,password_hash=$3,role=$4,role_id=$5,branch_id=$6,active=$7,updated_at=NOW() WHERE id=$8 AND organization_id=$9 RETURNING id,user_code,email,full_name,branch_id,role_id,active,updated_at`),
"usersService.js:22:250": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata) VALUES($1,$2,'USER_UPDATED','user',$3,$4::jsonb)`),
"usersService.js:27:244": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata) VALUES($1,$2,'USER_CREATED','user',$3,$4::jsonb)`),
"usersService.js:3:251": ({  }) => (`SELECT id,branch_id FROM users WHERE id=$1 AND organization_id=$2 FOR UPDATE`),
"usersService.js:3:252": ({  }) => (`UPDATE users SET active=FALSE,updated_at=NOW() WHERE id=$1 AND organization_id=$2`),
"usersService.js:3:253": ({  }) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id) VALUES($1,$2,'USER_DEACTIVATED','user',$3)`),
  "usersService.js:5:239": ({ filters = [] }) => { const extra=renderFilters(filters,{branchId:p=>`u.branch_id=$${p}`,denyAll:{static:'1=0'}}).map(x=>' AND '+x).join(''); return `SELECT u.id,u.user_code,u.full_name,u.email,u.active,u.branch_id,u.role_id,u.created_at,u.updated_at,r.code AS role_code,r.name AS role_name,b.name AS branch_name FROM users u JOIN roles r ON r.id=u.role_id LEFT JOIN branches b ON b.id=u.branch_id AND b.organization_id=u.organization_id WHERE u.organization_id=$1${extra} ORDER BY u.created_at DESC` },
"usersService.js:6:245": ({  }) => (`SELECT u.*,r.code AS role_code,r.is_system,r.is_protected FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=$1 AND u.organization_id=$2 FOR UPDATE`),
"usersService.js:8:240": ({  }) => (`SELECT id,code,is_system,is_protected FROM roles WHERE id IS NOT NULL AND code=$1 AND ((is_system=FALSE AND organization_id=$2) OR (is_system=TRUE AND organization_id IS NULL))`),

  "commercialExpansion:fieldRoute": ({}) => (`SELECT m.id AS member_id,m.member_code,m.full_name,m.phone,l.id AS loan_id,l.loan_number,COALESCE(i.due_amount,0) AS due_amount,COALESCE(i.due_date,CURRENT_DATE) AS due_date FROM members m JOIN loans l ON l.member_id=m.id AND l.organization_id=m.organization_id AND l.status IN ('disbursed','active') LEFT JOIN LATERAL (SELECT SUM(i.outstanding_amount) AS due_amount,MIN(i.due_date) AS due_date FROM installments i WHERE i.organization_id=m.organization_id AND i.loan_id=l.id AND i.status IN ('pending','partial','overdue') AND i.outstanding_amount>0 AND i.due_date <= COALESCE($3::date,CURRENT_DATE)) i ON TRUE WHERE m.organization_id=$1 AND m.status<>'inactive' AND ($2::uuid IS NULL OR m.branch_id=$2) AND ($4::text IS NULL OR $4='' OR m.member_code ILIKE '%'||$4||'%' OR m.full_name ILIKE '%'||$4||'%' OR m.phone ILIKE '%'||$4||'%') ORDER BY m.full_name LIMIT 500`),
  "commercialExpansion:syncInsert": ({}) => (`INSERT INTO field_sync_events(organization_id,branch_id,user_id,client_event_id,event_type,entity_type,entity_id,payload,status) VALUES($1,$2,$3,$4,$5,$6,$7,$8::jsonb,'accepted') ON CONFLICT(organization_id,user_id,client_event_id) DO UPDATE SET status='duplicate' RETURNING *`),
  "commercialExpansion:syncList": ({}) => (`SELECT * FROM field_sync_events WHERE organization_id=$1 AND user_id=$2 ORDER BY created_at DESC LIMIT $3`),
  "commercialExpansion:productsList": ({}) => (`SELECT * FROM loan_products WHERE organization_id=$1 ORDER BY created_at DESC`),
  "commercialExpansion:productInsert": ({}) => (`INSERT INTO loan_products(organization_id,code,name,product_type,interest_method,interest_rate,min_amount,max_amount,min_installments,max_installments,frequency,grace_days,penalty_rate,penalty_type,metadata,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15::jsonb,$16) RETURNING *`),
  "commercialExpansion:productGet": ({}) => (`SELECT * FROM loan_products WHERE organization_id=$1 AND id=$2 AND active=TRUE`),
  "commercialExpansion:loanForAdjustment": ({}) => (`SELECT id,organization_id,branch_id,member_id,status,outstanding_amount,total_payable,loan_amount,interest_amount,disbursed_amount,first_installment_date FROM loans WHERE organization_id=$1 AND id=$2 FOR UPDATE`),
  "commercialExpansion:adjustmentExistingByIdempotency": ({}) => (`SELECT * FROM loan_adjustments WHERE organization_id=$1 AND idempotency_key=$2 FOR UPDATE`),
  "commercialExpansion:adjustmentInsert": ({}) => (`INSERT INTO loan_adjustments(organization_id,branch_id,member_id,loan_id,adjustment_type,amount,effective_date,reason,metadata,idempotency_key,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9::jsonb,$10,$11) RETURNING *`),
  "commercialExpansion:loanOutstandingDelta": ({}) => (`UPDATE loans SET outstanding_amount=GREATEST(0,outstanding_amount+$1),status=CASE WHEN GREATEST(0,outstanding_amount+$1)=0 THEN 'completed' WHEN status='completed' THEN 'active' ELSE status END,updated_at=NOW() WHERE organization_id=$2 AND id=$3`),
  "commercialExpansion:loanOutstandingDeltaWriteOff": ({}) => (`UPDATE loans SET outstanding_amount=GREATEST(0,outstanding_amount+$1),status=CASE WHEN GREATEST(0,outstanding_amount+$1)=0 THEN 'written_off' WHEN status IN ('completed','written_off') THEN 'active' ELSE status END,updated_at=NOW() WHERE organization_id=$2 AND id=$3`),
  "commercialExpansion:loanPenaltyDelta": ({}) => (`UPDATE loans SET total_payable=total_payable+$1,outstanding_amount=outstanding_amount+$1,status=CASE WHEN status='completed' THEN 'active' ELSE status END,updated_at=NOW() WHERE organization_id=$2 AND id=$3 RETURNING id,total_payable,outstanding_amount`),
  "commercialExpansion:adjustmentInstallments": ({}) => (`SELECT id,installment_amount,paid_amount,outstanding_amount,status FROM installments WHERE organization_id=$1 AND loan_id=$2 AND status NOT IN ('paid','waived','cancelled') AND outstanding_amount>0 ORDER BY due_date,installment_number FOR UPDATE`),
  "commercialExpansion:adjustmentInstallmentApply": ({}) => (`UPDATE installments SET outstanding_amount=$1,status=$2,updated_at=NOW() WHERE organization_id=$3 AND id=$4 RETURNING id,outstanding_amount,status`),
  "commercialExpansion:ensureAdjustmentGlAccounts": ({}) => (`INSERT INTO accounting_accounts(organization_id,code,name,account_type) VALUES ($1,'1200','Loan Receivable','asset'),($1,'4100','Penalty Income','income'),($1,'5010','Loan Waiver / Write-off Expense','expense') ON CONFLICT(organization_id,code) DO NOTHING RETURNING id,code`),
  "commercialExpansion:adjustmentGlAccountIds": ({}) => (`SELECT id,code FROM accounting_accounts WHERE organization_id=$1 AND code IN ('1200','4100','5010')`),
  "commercialExpansion:penaltyInstallmentInsert": ({}) => (`INSERT INTO installments(organization_id,loan_id,installment_number,due_date,installment_amount,paid_amount,outstanding_amount,status) SELECT $1,$2,COALESCE(MAX(installment_number),0)+1,$3::date,$4,0,$4,'pending' FROM installments WHERE organization_id=$1 AND loan_id=$2 RETURNING *`),
  "commercialExpansion:rescheduleInstallments": ({}) => (`UPDATE installments SET due_date=due_date+($1::int),updated_at=NOW() WHERE organization_id=$2 AND loan_id=$3 AND status IN ('pending','partial','overdue') RETURNING id,installment_number,due_date`),
  "commercialExpansion:rescheduleLoan": ({}) => (`UPDATE loans SET first_installment_date=CASE WHEN first_installment_date IS NULL THEN NULL ELSE first_installment_date+($1::int) END,updated_at=NOW() WHERE organization_id=$2 AND id=$3`),
  "commercialExpansion:audit": ({}) => (`INSERT INTO audit_logs(organization_id,user_id,action,entity_type,entity_id,metadata) VALUES($1,$2,$3,$4,$5,$6::jsonb)`),
  "commercialExpansion:adjustments": ({}) => (`SELECT * FROM loan_adjustments WHERE organization_id=$1 AND ($2::uuid IS NULL OR loan_id=$2) AND ($3::uuid IS NULL OR branch_id=$3) ORDER BY effective_date DESC,created_at DESC LIMIT 500`),
  "commercialExpansion:passbook": ({}) => (`SELECT m.id AS member_id,m.member_code,m.full_name,'payment' AS entry_type,p.payment_date::date AS entry_date,p.payment_number AS reference,p.amount,p.payment_method AS description FROM members m JOIN payments p ON p.member_id=m.id AND p.organization_id=m.organization_id WHERE m.organization_id=$1 AND m.id=$2 AND p.status='posted' AND ($3::uuid IS NULL OR m.branch_id=$3) AND ($3::uuid IS NULL OR p.branch_id=$3) ORDER BY p.payment_date DESC LIMIT 500`),
  "commercialExpansion:notificationMember": ({}) => (`SELECT id,branch_id FROM members WHERE organization_id=$1 AND id=$2 AND status='active'`),
  "commercialExpansion:notificationInsert": ({}) => (`INSERT INTO notification_outbox(organization_id,member_id,channel,recipient,template_code,payload,scheduled_at,created_by) VALUES($1,$2,$3,$4,$5,$6::jsonb,$7,$8) RETURNING *`),
  "commercialExpansion:notifications": ({}) => (`SELECT n.* FROM notification_outbox n LEFT JOIN members m ON m.id=n.member_id AND m.organization_id=n.organization_id WHERE n.organization_id=$1 AND ($3::uuid IS NULL OR m.branch_id=$3) ORDER BY n.created_at DESC LIMIT $2`),
  "commercialExpansion:notificationsClaim": ({}) => (`WITH candidates AS (SELECT id FROM notification_outbox WHERE ((status='queued' AND scheduled_at <= $1) OR (status='processing' AND updated_at <= NOW() - INTERVAL '15 minutes')) ORDER BY scheduled_at,id FOR UPDATE SKIP LOCKED LIMIT $2) UPDATE notification_outbox n SET status='processing',updated_at=NOW() FROM candidates c WHERE n.id=c.id RETURNING n.*`),
  "commercialExpansion:notificationsPending": ({}) => (`SELECT * FROM notification_outbox WHERE status='queued' AND scheduled_at <= $1 ORDER BY scheduled_at LIMIT $2`),
  "commercialExpansion:notificationMark": ({}) => (`UPDATE notification_outbox SET status=$2,last_error=$3,sent_at=$4,provider_message_id=$5,attempts=attempts+1,updated_at=NOW() WHERE id=$1 AND status='processing' RETURNING id`),
  "commercialExpansion:operationalReport": ({}) => (`SELECT (SELECT COUNT(*)::int FROM members m WHERE m.organization_id=$1 AND ($4::uuid IS NULL OR m.branch_id=$4)) AS member_count,(SELECT COUNT(*)::int FROM loans l WHERE l.organization_id=$1 AND ($4::uuid IS NULL OR l.branch_id=$4)) AS loan_count,(SELECT COALESCE(SUM(l.outstanding_amount),0) FROM loans l WHERE l.organization_id=$1 AND ($4::uuid IS NULL OR l.branch_id=$4)) AS outstanding_amount,(SELECT COALESCE(SUM(p.amount),0) FROM payments p WHERE p.organization_id=$1 AND p.status='posted' AND ($2::date IS NULL OR p.payment_date::date >= $2::date) AND ($3::date IS NULL OR p.payment_date::date <= $3::date) AND ($4::uuid IS NULL OR p.branch_id=$4)) AS collected_amount`),
  "commercialExpansion:reportPortfolio": ({}) => (`SELECT l.id,l.loan_number,l.member_id,m.member_code,m.full_name,l.loan_amount,l.total_payable,l.outstanding_amount,l.status,l.branch_id FROM loans l JOIN members m ON m.id=l.member_id AND m.organization_id=l.organization_id WHERE l.organization_id=$1 AND ($2::uuid IS NULL OR l.branch_id=$2) ORDER BY l.created_at DESC LIMIT 2000`),
  "commercialExpansion:reportCollection": ({}) => (`SELECT p.payment_date::date AS date,COUNT(*)::int AS count,COALESCE(SUM(p.amount),0) AS amount FROM payments p WHERE p.organization_id=$1 AND p.status='posted' AND ($2::date IS NULL OR p.payment_date::date >= $2::date) AND ($3::date IS NULL OR p.payment_date::date <= $3::date) AND ($4::uuid IS NULL OR p.branch_id=$4) GROUP BY p.payment_date::date ORDER BY date DESC`),
  "commercialExpansion:reportOverdue": ({}) => (`SELECT l.id,l.loan_number,m.member_code,m.full_name,COALESCE(SUM(i.outstanding_amount),0) AS overdue_amount,MIN(i.due_date) AS oldest_due_date FROM loans l JOIN members m ON m.id=l.member_id AND m.organization_id=l.organization_id JOIN installments i ON i.loan_id=l.id AND i.organization_id=l.organization_id WHERE l.organization_id=$1 AND i.status IN ('pending','partial','overdue') AND i.due_date<CURRENT_DATE AND i.outstanding_amount>0 AND ($2::uuid IS NULL OR l.branch_id=$2) GROUP BY l.id,l.loan_number,m.member_code,m.full_name ORDER BY oldest_due_date LIMIT 2000`),
  "commercialExpansion:reportBranches": ({}) => (`SELECT b.id,b.name,b.branch_code,(SELECT COUNT(*)::int FROM members m WHERE m.organization_id=b.organization_id AND m.branch_id=b.id) AS members,(SELECT COUNT(*)::int FROM loans l WHERE l.organization_id=b.organization_id AND l.branch_id=b.id) AS loans,(SELECT COALESCE(SUM(l.outstanding_amount),0) FROM loans l WHERE l.organization_id=b.organization_id AND l.branch_id=b.id) AS outstanding FROM branches b WHERE b.organization_id=$1 AND ($2::uuid IS NULL OR b.id=$2) ORDER BY b.name`),
  "commercialExpansion:reportCollectors": ({}) => (`SELECT p.collector_id,u.full_name AS collector_name,COUNT(*)::int AS count,COALESCE(SUM(p.amount),0) AS amount FROM payments p LEFT JOIN users u ON u.id=p.collector_id AND u.organization_id=p.organization_id WHERE p.organization_id=$1 AND p.status='posted' AND ($2::date IS NULL OR p.payment_date::date >= $2::date) AND ($3::date IS NULL OR p.payment_date::date <= $3::date) AND ($4::uuid IS NULL OR p.branch_id=$4) GROUP BY p.collector_id,u.full_name ORDER BY amount DESC`),
  "commercialExpansion:reportIncomeExpense": ({}) => (`SELECT COALESCE((SELECT SUM(amount) FROM payments WHERE organization_id=$1 AND status='posted' AND ($2::uuid IS NULL OR branch_id=$2)),0) AS collection_income,COALESCE((SELECT SUM(amount) FROM expense_entries WHERE organization_id=$1 AND ($2::uuid IS NULL OR branch_id=$2)),0) AS expenses`),
  "commercialExpansion:mraReport": ({}) => (`SELECT $2::date AS from_date,$3::date AS to_date,(SELECT COUNT(*)::int FROM loans l WHERE l.organization_id=$1 AND l.status NOT IN ('draft','pending','approved','cancelled','rejected') AND ($4::uuid IS NULL OR l.branch_id=$4) AND ($2::date IS NULL OR COALESCE(l.disbursed_at::date,l.start_date)>=$2::date) AND ($3::date IS NULL OR COALESCE(l.disbursed_at::date,l.start_date)<=$3::date)) AS loan_count,(SELECT COALESCE(SUM(COALESCE(l.disbursed_amount,l.loan_amount)),0) FROM loans l WHERE l.organization_id=$1 AND l.status NOT IN ('draft','pending','approved','cancelled','rejected') AND ($4::uuid IS NULL OR l.branch_id=$4) AND ($2::date IS NULL OR COALESCE(l.disbursed_at::date,l.start_date)>=$2::date) AND ($3::date IS NULL OR COALESCE(l.disbursed_at::date,l.start_date)<=$3::date)) AS disbursed_amount,(SELECT COALESCE(SUM(l.outstanding_amount),0)+COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.organization_id=$1 AND p.status='posted' AND ($3::date IS NOT NULL AND p.payment_date::date>$3::date) AND EXISTS (SELECT 1 FROM loans lx WHERE lx.id=p.loan_id AND lx.organization_id=$1 AND ($4::uuid IS NULL OR lx.branch_id=$4) AND lx.status NOT IN ('draft','pending','approved','cancelled','rejected') AND ($3::date IS NULL OR COALESCE(lx.disbursed_at::date,lx.start_date)<=$3::date))),0)-COALESCE((SELECT SUM(la.amount) FROM loan_adjustments la WHERE la.organization_id=$1 AND la.adjustment_type='penalty' AND ($3::date IS NOT NULL AND la.effective_date>$3::date) AND ($4::uuid IS NULL OR la.branch_id=$4)),0)+COALESCE((SELECT SUM(la.amount) FROM loan_adjustments la WHERE la.organization_id=$1 AND la.adjustment_type IN ('waiver','write_off') AND ($3::date IS NOT NULL AND la.effective_date>$3::date) AND ($4::uuid IS NULL OR la.branch_id=$4)),0) FROM loans l WHERE l.organization_id=$1 AND l.status NOT IN ('draft','pending','approved','cancelled','rejected') AND ($4::uuid IS NULL OR l.branch_id=$4) AND ($3::date IS NULL OR COALESCE(l.disbursed_at::date,l.start_date)<=$3::date)) AS outstanding_amount,(SELECT COALESCE(SUM(p.amount),0) FROM payments p WHERE p.organization_id=$1 AND p.status='posted' AND ($2::date IS NULL OR p.payment_date::date >= $2::date) AND ($3::date IS NULL OR p.payment_date::date <= $3::date) AND ($4::uuid IS NULL OR p.branch_id=$4)) AS collected_amount,'MRA-oriented management report' AS report_standard`),
  "commercialExpansion:glAccounts": ({}) => (`SELECT * FROM accounting_accounts WHERE organization_id=$1 ORDER BY code`),
  "commercialExpansion:journalInsert": ({}) => (`INSERT INTO accounting_journal_entries(organization_id,branch_id,entry_date,reference_type,reference_id,description,posted_by) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *`),
  "commercialExpansion:journalLineInsert": ({}) => (`INSERT INTO accounting_journal_lines(journal_id,account_id,debit,credit,description) VALUES($1,$2,$3,$4,$5)`),
  "commercialExpansion:journalAccountsOwned": ({}) => (`SELECT COUNT(*)::int AS count FROM accounting_accounts WHERE organization_id=$1 AND id = ANY($2::uuid[])`),
  "commercialExpansion:glSummary": ({}) => (`SELECT a.id,a.code,a.name,a.account_type,COALESCE(x.debit,0) AS debit,COALESCE(x.credit,0) AS credit,COALESCE(x.balance,0) AS balance FROM accounting_accounts a LEFT JOIN (SELECT l.account_id,SUM(l.debit) AS debit,SUM(l.credit) AS credit,SUM(l.debit-l.credit) AS balance FROM accounting_journal_lines l JOIN accounting_journal_entries j ON j.id=l.journal_id WHERE j.organization_id=$1 AND ($2::date IS NULL OR j.entry_date>=$2::date) AND ($3::date IS NULL OR j.entry_date<=$3::date) AND ($4::uuid IS NULL OR j.branch_id=$4) GROUP BY l.account_id) x ON x.account_id=a.id WHERE a.organization_id=$1 GROUP BY a.id,a.code,a.name,a.account_type,x.debit,x.credit,x.balance ORDER BY a.code`),
  "commercialExpansion:ops": ({}) => (`SELECT (SELECT COUNT(*) FROM field_sync_events WHERE organization_id=$1 AND ($2::uuid IS NULL OR branch_id=$2)) AS sync_events,(SELECT COUNT(*) FROM notification_outbox n LEFT JOIN members m ON m.id=n.member_id AND m.organization_id=n.organization_id WHERE n.organization_id=$1 AND n.status='queued' AND ($2::uuid IS NULL OR m.branch_id=$2)) AS queued_notifications,(SELECT COUNT(*) FROM loans WHERE organization_id=$1 AND status IN ('disbursed','active') AND ($2::uuid IS NULL OR branch_id=$2)) AS active_loans,(SELECT COALESCE(SUM(outstanding_amount),0) FROM loans WHERE organization_id=$1 AND status IN ('disbursed','active') AND ($2::uuid IS NULL OR branch_id=$2)) AS outstanding_amount`),
};

module.exports = Object.freeze(queries);
