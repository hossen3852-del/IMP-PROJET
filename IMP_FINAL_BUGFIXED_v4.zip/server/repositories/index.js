'use strict';

const db = require('../config/db');
const queries = require('./queryRegistry');

function sqlFor(name, vars = {}) {
  const builder = queries[name];
  if (typeof builder !== 'function') throw new Error(`Unknown repository query: ${name}`);
  const sql = builder(vars);
  if (typeof sql !== 'string' || !sql.trim()) throw new Error(`Empty repository SQL: ${name}`);
  return sql;
}

async function queryNamed(name, params = [], vars = {}) {
  return db.query(sqlFor(name, vars), params);
}

async function begin() {
  const client = await db.connect();
  let closed = false;
  let begun = false;
  const tx = {
    async begin() {
      if (!begun) { await client.query('BEGIN'); begun = true; }
    },
    queryNamed(name, params = [], vars = {}) {
      return client.query(sqlFor(name, vars), params);
    },
    async commit() {
      if (closed) return;
      await client.query('COMMIT');
      closed = true;
    },
    async rollback() {
      if (closed) return;
      try { await client.query('ROLLBACK'); } finally { closed = true; }
    },
    release() {
      if (!closed) {
        try { client.release(); } finally { closed = true; }
        return;
      }
      client.release();
    }
  };
  return tx;
}

async function withTransaction(work) {
  const tx = await begin();
  try {
    await tx.begin();
    const result = await work(tx);
    await tx.commit();
    return result;
  } catch (error) {
    try { await tx.rollback(); } catch (_) {}
    throw error;
  } finally {
    tx.release();
  }
}

async function health() {
  const { rows } = await queryNamed('repository:health');
  return Number(rows[0]?.ok) === 1;
}

module.exports = Object.freeze({ queryNamed, begin, withTransaction, health, sqlFor });
