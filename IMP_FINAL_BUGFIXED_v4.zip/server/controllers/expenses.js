'use strict';

const service = require('../services/expensesService.js');
const { handler, serviceMiddleware } = require('./controller');

const get_summary_1 = handler(service.get_summary_1);
const get_entries_2 = handler(service.get_entries_2);
const post_entries_3 = handler(service.post_entries_3);
const delete_entries_id_4 = handler(service.delete_entries_id_4);

module.exports = Object.freeze({
  get_summary_1,
  get_entries_2,
  post_entries_3,
  delete_entries_id_4,
});
