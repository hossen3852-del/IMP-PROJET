'use strict';

const service = require('../services/loansService.js');
const { handler, serviceMiddleware } = require('./controller');

const get_root_1 = handler(service.get_root_1);
const post_root_2 = handler(service.post_root_2);
const get_id_3 = handler(service.get_id_3);
const patch_id_4 = handler(service.patch_id_4);
const post_id_approve_5 = handler(service.post_id_approve_5);
const post_id_disburse_6 = handler(service.post_id_disburse_6);
const post_id_status_7 = handler(service.post_id_status_7);
const delete_id_8 = handler(service.delete_id_8);
const post_legacy_import_9 = handler(service.post_legacy_import_9);
const guard_loans = serviceMiddleware(service.guard_loans);

module.exports = Object.freeze({
  get_root_1,
  post_root_2,
  get_id_3,
  patch_id_4,
  post_id_approve_5,
  post_id_disburse_6,
  post_id_status_7,
  delete_id_8,
  post_legacy_import_9,
  guard_loans,
});
