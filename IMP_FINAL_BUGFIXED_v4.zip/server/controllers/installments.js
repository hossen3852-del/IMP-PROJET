'use strict';

const service = require('../services/installmentsService.js');
const { handler, serviceMiddleware } = require('./controller');

const get_root_1 = handler(service.get_root_1);
const get_id_2 = handler(service.get_id_2);
const post_generate_3 = handler(service.post_generate_3);
const patch_id_status_4 = handler(service.patch_id_status_4);

module.exports = Object.freeze({
  get_root_1,
  get_id_2,
  post_generate_3,
  patch_id_status_4,
});
