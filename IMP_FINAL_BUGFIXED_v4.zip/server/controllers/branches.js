'use strict';

const service = require('../services/branchesService.js');
const { handler, serviceMiddleware } = require('./controller');

const get_root_1 = handler(service.get_root_1);
const get_id_2 = handler(service.get_id_2);
const post_root_3 = handler(service.post_root_3);
const patch_id_4 = handler(service.patch_id_4);
const post_id_deactivate_5 = handler(service.post_id_deactivate_5);

module.exports = Object.freeze({
  get_root_1,
  get_id_2,
  post_root_3,
  patch_id_4,
  post_id_deactivate_5,
});
