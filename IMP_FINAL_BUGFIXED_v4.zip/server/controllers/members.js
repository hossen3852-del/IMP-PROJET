'use strict';

const service = require('../services/membersService.js');
const { handler, serviceMiddleware } = require('./controller');

const get_root_1 = handler(service.get_root_1);
const post_root_2 = handler(service.post_root_2);
const get_id_photo_3 = handler(service.get_id_photo_3);
const get_id_nominee_photo_4 = handler(service.get_id_nominee_photo_4);
const get_id_5 = handler(service.get_id_5);
const patch_id_6 = handler(service.patch_id_6);
const delete_id_7 = handler(service.delete_id_7);
const get_id_nominee_8 = handler(service.get_id_nominee_8);
const put_id_nominee_9 = handler(service.put_id_nominee_9);
const get_id_documents_10 = handler(service.get_id_documents_10);
const post_id_documents_11 = handler(service.post_id_documents_11);
const delete_id_documents_documentId_12 = handler(service.delete_id_documents_documentId_12);
const get_id_activities_13 = handler(service.get_id_activities_13);
const post_id_activities_14 = handler(service.post_id_activities_14);
const get_id_family_15 = handler(service.get_id_family_15);
const put_id_family_16 = handler(service.put_id_family_16);
const get_id_financial_17 = handler(service.get_id_financial_17);
const patch_id_financial_18 = handler(service.patch_id_financial_18);
const get_legacy_borrowers_19 = handler(service.get_legacy_borrowers_19);
const guard_members = serviceMiddleware(service.guard_members);

module.exports = Object.freeze({
  get_root_1,
  post_root_2,
  get_id_photo_3,
  get_id_nominee_photo_4,
  get_id_5,
  patch_id_6,
  delete_id_7,
  get_id_nominee_8,
  put_id_nominee_9,
  get_id_documents_10,
  post_id_documents_11,
  delete_id_documents_documentId_12,
  get_id_activities_13,
  post_id_activities_14,
  get_id_family_15,
  put_id_family_16,
  get_id_financial_17,
  patch_id_financial_18,
  get_legacy_borrowers_19,
  guard_members,
});
