'use strict';

const service = require('../services/settingsService.js');
const { handler, serviceMiddleware } = require('./controller');

const get_root_1 = handler(service.get_root_1);
const get_key_2 = handler(service.get_key_2);
const put_key_3 = handler(service.put_key_3);
const canUpdateSettings = serviceMiddleware(service.canUpdateSettings);
const get_user_ui_visibility_4 = handler(service.get_user_ui_visibility_4);
const put_user_ui_visibility_5 = handler(service.put_user_ui_visibility_5);

module.exports = Object.freeze({
  get_root_1,
  get_key_2,
  put_key_3,
  canUpdateSettings,
  get_user_ui_visibility_4,
  put_user_ui_visibility_5,
});
