'use strict';

const service = require('../services/dashboardService.js');
const { handler, serviceMiddleware } = require('./controller');

const get_summary_1 = handler(service.get_summary_1);
const get_config_2 = handler(service.get_config_2);
const put_config_3 = handler(service.put_config_3);

module.exports = Object.freeze({
  get_summary_1,
  get_config_2,
  put_config_3,
});
