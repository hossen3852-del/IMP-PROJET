'use strict';

const service = require('../services/insuranceService.js');
const { handler, serviceMiddleware } = require('./controller');

const get_summary_1 = handler(service.get_summary_1);
const get_transactions_2 = handler(service.get_transactions_2);
const post_transactions_3 = handler(service.post_transactions_3);
const delete_transactions_id_4 = handler(service.delete_transactions_id_4);

module.exports = Object.freeze({
  get_summary_1,
  get_transactions_2,
  post_transactions_3,
  delete_transactions_id_4,
});
