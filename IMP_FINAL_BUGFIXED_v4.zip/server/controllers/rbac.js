'use strict';

const service = require('../services/rbacService.js');
const { handler, serviceMiddleware } = require('./controller');

const get_permissions_1 = handler(service.get_permissions_1);
const get_roles_2 = handler(service.get_roles_2);
const post_roles_3 = handler(service.post_roles_3);
const get_roles_id_4 = handler(service.get_roles_id_4);
const patch_roles_id_5 = handler(service.patch_roles_id_5);
const delete_roles_id_6 = handler(service.delete_roles_id_6);
const get_roles_id_permissions_7 = handler(service.get_roles_id_permissions_7);
const put_roles_id_permissions_8 = handler(service.put_roles_id_permissions_8);

module.exports = Object.freeze({
  get_permissions_1,
  get_roles_2,
  post_roles_3,
  get_roles_id_4,
  patch_roles_id_5,
  delete_roles_id_6,
  get_roles_id_permissions_7,
  put_roles_id_permissions_8,
});
