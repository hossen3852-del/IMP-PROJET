'use strict';

const service = require('../services/authService.js');
const { handler, serviceMiddleware } = require('./controller');

const post_register_1 = handler(service.post_register_1);
const post_login_2 = handler(service.post_login_2);
const get_me_3 = handler(service.get_me_3);
const post_logout_4 = handler(service.post_logout_4);
const post_logout_all_5 = handler(service.post_logout_all_5);
const post_password_reset_request_6 = handler(service.post_password_reset_request_6);
const post_password_reset_confirm_7 = handler(service.post_password_reset_confirm_7);
const put_admin_credentials_8 = handler(service.put_admin_credentials_8);

module.exports = Object.freeze({
  post_register_1,
  post_login_2,
  get_me_3,
  post_logout_4,
  post_logout_all_5,
  post_password_reset_request_6,
  post_password_reset_confirm_7,
  put_admin_credentials_8,
});
