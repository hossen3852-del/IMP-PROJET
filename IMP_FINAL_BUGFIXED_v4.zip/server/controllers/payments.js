'use strict';

const service = require('../services/paymentsService.js');
const { handler, serviceMiddleware } = require('./controller');

const get_root_1 = handler(service.get_root_1);
const post_root_2 = handler(service.post_root_2);
const get_collection_report_3 = handler(service.get_collection_report_3);
const get_reconciliation_4 = handler(service.get_reconciliation_4);
const get_id_5 = handler(service.get_id_5);
const get_id_allocations_6 = handler(service.get_id_allocations_6);
const get_id_audit_7 = handler(service.get_id_audit_7);
const post_id_cancel_8 = handler(service.post_id_cancel_8);
const post_id_reverse_9 = handler(service.post_id_reverse_9);
const get_id_receipt_10 = handler(service.get_id_receipt_10);
const guard_payments = serviceMiddleware(service.guard_payments);

module.exports = Object.freeze({
  get_root_1,
  post_root_2,
  get_collection_report_3,
  get_reconciliation_4,
  get_id_5,
  get_id_allocations_6,
  get_id_audit_7,
  post_id_cancel_8,
  post_id_reverse_9,
  get_id_receipt_10,
  guard_payments,
});
