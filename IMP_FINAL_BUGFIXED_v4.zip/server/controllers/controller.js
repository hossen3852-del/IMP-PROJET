'use strict';

function toContext(req) {
  return {
    body: req.body || {},
    query: req.query || {},
    params: req.params || {},
    cookies: req.cookies || {},
    headers: req.headers || {},
    auth: req.auth || null
  };
}

function writeResult(res, result, next) {
  if (!result || result.kind !== 'application-result') return result;

  for (const cookie of result.cookies || []) {
    if (cookie.op === 'set') res.cookie(cookie.name, cookie.value, cookie.options || {});
    if (cookie.op === 'clear') res.clearCookie(cookie.name, cookie.options || {});
  }

  if (result.file) {
    return res.status(result.status || 200).sendFile(result.file, err => { if (err && next) next(err); });
  }

  if (result.contentType) res.set('Content-Type', result.contentType);
  if (result.status === 204) return res.status(204).end();
  // Legacy BYTEA-backed content (e.g. a photo read straight from the
  // database) arrives here as a raw Buffer. res.json() would serialize it
  // as {"type":"Buffer","data":[...]} instead of sending image bytes.
  if (Buffer.isBuffer(result.body)) return res.status(result.status || 200).send(result.body);
  return res.status(result.status || 200).json(result.body);
}

function handler(serviceHandler) {
  if (typeof serviceHandler !== 'function') throw new TypeError('service handler must be a function');
  return async function controllerHandler(req, res, next) {
    try {
      const result = await serviceHandler(toContext(req));
      return writeResult(res, result, next);
    } catch (error) {
      return next(error);
    }
  };
}

function serviceMiddleware(serviceHandler) {
  if (typeof serviceHandler !== 'function') throw new TypeError('service middleware must be a function');
  return async function serviceGuard(req, res, next) {
    try {
      const result = await serviceHandler(toContext(req));
      if (!result) return next();
      return writeResult(res, result, next);
    } catch (error) {
      return next(error);
    }
  };
}

module.exports = Object.freeze({ toContext, writeResult, handler, serviceMiddleware });
