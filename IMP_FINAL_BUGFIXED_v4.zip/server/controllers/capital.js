'use strict';

const service = require('../services/capitalService.js');
const { handler, serviceMiddleware } = require('./controller');

const get_summary_1 = handler(service.get_summary_1);
const get_entries_2 = handler(service.get_entries_2);
const post_entries_3 = handler(service.post_entries_3);
const delete_entries_id_4 = handler(service.delete_entries_id_4);
const get_shares_summary_5 = handler(service.get_shares_summary_5);
const get_shares_6 = handler(service.get_shares_6);
const get_share_id_7 = handler(service.get_share_id_7);
const post_shares_8 = handler(service.post_shares_8);
const put_share_id_9 = handler(service.put_share_id_9);
const delete_share_id_10 = handler(service.delete_share_id_10);
const put_share_market_value_11 = handler(service.put_share_market_value_11);

module.exports = Object.freeze({
  get_summary_1,
  get_entries_2,
  post_entries_3,
  delete_entries_id_4,
  get_shares_summary_5,
  get_shares_6,
  get_share_id_7,
  post_shares_8,
  put_share_id_9,
  delete_share_id_10,
  put_share_market_value_11,
});
