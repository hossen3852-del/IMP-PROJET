'use strict';

const service = require('../services/collectionsService.js');
const { handler, serviceMiddleware } = require('./controller');

const get_config_1 = handler(service.get_config_1);
const put_config_2 = handler(service.put_config_2);
const get_route_sheet_3 = handler(service.get_route_sheet_3);
const post_daily_4 = handler(service.post_daily_4);

module.exports = Object.freeze({
  get_config_1,
  put_config_2,
  get_route_sheet_3,
  post_daily_4,
});
