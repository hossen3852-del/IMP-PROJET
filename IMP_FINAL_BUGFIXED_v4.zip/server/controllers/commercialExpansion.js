'use strict';
const service=require('../services/commercialExpansionService.js');
const {handler}=require('./controller');
module.exports=Object.freeze({
 get_field_route_1:handler(service.get_field_route_1),post_field_sync_2:handler(service.post_field_sync_2),get_field_sync_3:handler(service.get_field_sync_3),
 get_products_4:handler(service.get_products_4),post_product_5:handler(service.post_product_5),post_adjustment_6:handler(service.post_adjustment_6),get_adjustments_7:handler(service.get_adjustments_7),
 get_passbook_8:handler(service.get_passbook_8),post_notification_9:handler(service.post_notification_9),get_notifications_10:handler(service.get_notifications_10),
 get_reports_11:handler(service.get_reports_11),get_mra_12:handler(service.get_mra_12),get_gl_accounts_13:handler(service.get_gl_accounts_13),post_gl_journal_14:handler(service.post_gl_journal_14),
 get_gl_summary_15:handler(service.get_gl_summary_15),get_ops_16:handler(service.get_ops_16),calculate_product_17:handler(service.calculate_product_17)
});
