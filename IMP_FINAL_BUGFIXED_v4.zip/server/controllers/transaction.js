'use strict';

const service = require('../services/transactionService.js');
const { handler, serviceMiddleware } = require('./controller');

module.exports = Object.freeze({});
