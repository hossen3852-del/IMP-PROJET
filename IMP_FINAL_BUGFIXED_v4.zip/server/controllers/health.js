'use strict';

const service = require('../services/healthService.js');
const { handler, serviceMiddleware } = require('./controller');

const health = handler(service.health);

module.exports = Object.freeze({ health });
