'use strict';

const service = require('../services/organizationService.js');
const { handler, serviceMiddleware } = require('./controller');

const get_root_1 = handler(service.get_root_1);
const get_dashboard_summary_2 = handler(service.get_dashboard_summary_2);
const patch_root_3 = handler(service.patch_root_3);

module.exports = Object.freeze({
  get_root_1,
  get_dashboard_summary_2,
  patch_root_3,
});
