'use strict';

const service = require('../services/usersService.js');
const { handler, serviceMiddleware } = require('./controller');

const get_root_1 = handler(service.get_root_1);
const post_root_2 = handler(service.post_root_2);
const patch_id_3 = handler(service.patch_id_3);
const delete_id_4 = handler(service.delete_id_4);

module.exports = Object.freeze({
  get_root_1,
  post_root_2,
  patch_id_3,
  delete_id_4,
});
