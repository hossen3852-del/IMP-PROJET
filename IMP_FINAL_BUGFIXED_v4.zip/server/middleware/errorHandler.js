'use strict';

module.exports = function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);
  const raw =
    (Number.isInteger(err.status) && err.status) ||
    (Number.isInteger(err.statusCode) && err.statusCode) ||
    (Number.isInteger(err.httpStatus) && err.httpStatus) ||
    500;
  const status = raw >= 400 && raw < 600 ? raw : 500;
  console.error('[IMP]', req.requestId || '-', err && err.message ? err.message : 'Unhandled error');
  res.status(status).json({
    error: process.env.NODE_ENV === 'production' ? (status === 500 ? 'Internal server error' : 'Request failed') : err.message,
    requestId: req.requestId || null
  });
};
