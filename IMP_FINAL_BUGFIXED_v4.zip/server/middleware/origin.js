const env = require('../config/env');

function requireSameOrigin(req, res, next) {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) return next();

  const origin = req.get('origin');
  if (!origin) return next();

  const allowed = String(env.corsOrigin)
    .split(',')
    .map(value => value.trim())
    .filter(Boolean);

  if (allowed.includes('*') || allowed.includes(origin)) return next();
  return res.status(403).json({ error: 'Cross-origin request rejected' });
}

module.exports = { requireSameOrigin };
