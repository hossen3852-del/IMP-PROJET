'use strict';

const authRepository = require('../repositories/authRepository');
const { hashSessionToken } = require('../utils/sessionToken');
const env = require('../config/env');

async function requireAuth(req, res, next) {
  try {
    const token = req.cookies?.[env.cookieName];
    if (!token) return res.status(401).json({ error: 'Authentication required' });

    const hash = hashSessionToken(token);
    const { rows } = await authRepository.findSessionContext(hash);

    if (!rows[0]) return res.status(401).json({ error: 'Invalid or expired session' });

    const permissionResult = await authRepository.findRolePermissions(rows[0].role_id, rows[0].organization_id);

    req.auth = {
      ...rows[0],
      permissions: permissionResult.rows.map(row => row.code)
    };
    next();
  } catch (e) {
    next(e);
  }
}

function requirePermission(permission) {
  return (req, res, next) => {
    if (!req.auth) return res.status(401).json({ error: 'Authentication required' });
    if (!permission || req.auth.permissions.includes(permission)) return next();
    return res.status(403).json({ error: 'Forbidden' });
  };
}

function requireAnyPermission(permissions) {
  return (req, res, next) => {
    if (!req.auth) return res.status(401).json({ error: 'Authentication required' });
    if (permissions.some(p => req.auth.permissions.includes(p))) return next();
    return res.status(403).json({ error: 'Forbidden' });
  };
}

module.exports = { requireAuth, requirePermission, requireAnyPermission };
