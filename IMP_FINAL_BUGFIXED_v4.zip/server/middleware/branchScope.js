'use strict';

/**
 * Branch-level authorization helpers.
 * Organization Admin and Super Admin are organization-wide.
 * Every other role is restricted to its assigned branch.
 */
const ORG_WIDE_ROLES = new Set(['organization_admin', 'super_admin']);

function isOrganizationWide(auth) {
  return !!auth && ORG_WIDE_ROLES.has(auth.role_code || auth.role);
}

function scopedBranchId(auth) {
  if (isOrganizationWide(auth)) return null;
  return auth?.branch_id || null;
}

function applyBranchFilter(where, values, auth, alias = '') {
  if (isOrganizationWide(auth)) return;
  if (!auth?.branch_id) {
    where.push('1=0');
    return;
  }
  values.push(auth.branch_id);
  const prefix = alias ? `${alias}.` : '';
  where.push(`${prefix}branch_id=$${values.length}`);
}

function assertBranchAccess(auth, branchId) {
  if (isOrganizationWide(auth)) return;
  if (!auth?.branch_id || String(auth.branch_id) !== String(branchId)) {
    const error = new Error('Branch access denied');
    error.status = 403;
    throw error;
  }
}

function enforceRequestedBranch(auth, requestedBranchId) {
  if (isOrganizationWide(auth)) return requestedBranchId || null;
  assertBranchAccess(auth, requestedBranchId);
  return auth.branch_id;
}

module.exports = { ORG_WIDE_ROLES, isOrganizationWide, scopedBranchId, applyBranchFilter, assertBranchAccess, enforceRequestedBranch };
