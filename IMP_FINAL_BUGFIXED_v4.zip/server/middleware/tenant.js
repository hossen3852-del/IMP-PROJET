'use strict';

/**
 * 11.P.6 — Tenant boundary helpers.
 *
 * req.auth.organization_id is the only tenant context accepted from the
 * authenticated server session. Client supplied organization_id values must
 * never replace it.
 */
function requireTenant(req, res, next) {
  if (!req.auth?.organization_id) return res.status(401).json({ error: 'Tenant context required' });
  return next();
}

function tenantId(req) {
  return req.auth?.organization_id || null;
}

function sameTenant(organizationId, req) {
  return Boolean(organizationId && req.auth?.organization_id &&
    String(organizationId) === String(req.auth.organization_id));
}

module.exports = { requireTenant, tenantId, sameTenant };
