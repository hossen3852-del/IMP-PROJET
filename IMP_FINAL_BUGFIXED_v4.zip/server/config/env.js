'use strict';

require('dotenv').config();

const nodeEnv = process.env.NODE_ENV || 'development';
const isProduction = nodeEnv === 'production';
const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) {
  throw new Error('Missing required environment variable: DATABASE_URL. Create .env from .env.example (or run .\SETUP_ENV.ps1 on Windows) and set DATABASE_URL before starting IMP.');
}

function positiveInt(name, fallback, max) {
  const value = Number(process.env[name] || fallback);
  if (!Number.isInteger(value) || value <= 0 || (max && value > max)) {
    throw new Error(`${name} must be a positive integer${max ? ` <= ${max}` : ''}`);
  }
  return value;
}

const corsOrigin = String(process.env.CORS_ORIGIN || (isProduction ? '' : 'http://localhost:5500'))
  .split(',').map(v => v.trim()).filter(Boolean);
if (isProduction && corsOrigin.length === 0) throw new Error('CORS_ORIGIN is required in production');
if (corsOrigin.includes('*') && isProduction) throw new Error('CORS_ORIGIN must not contain * in production');

const cookieName = process.env.COOKIE_NAME || (isProduction ? '__Host-imp_session' : 'imp_session');
if (isProduction && (!cookieName.startsWith('__Host-') || cookieName !== '__Host-imp_session')) {
  throw new Error('Production COOKIE_NAME must be __Host-imp_session');
}

const databaseSsl = String(process.env.DATABASE_SSL || (isProduction ? 'require' : 'disable')).toLowerCase();
if (!['require', 'prefer', 'disable', 'no-verify'].includes(databaseSsl)) {
  throw new Error('DATABASE_SSL must be require, prefer, disable, or no-verify');
}
if (isProduction && databaseSsl === 'disable') throw new Error('DATABASE_SSL=disable is not allowed in production');

module.exports = {
  nodeEnv,
  isProduction,
  port: positiveInt('PORT', 3000, 65535),
  databaseUrl,
  corsOrigin,
  sessionTtlSeconds: positiveInt('SESSION_TTL_SECONDS', 86400, 2592000),
  cookieName,
  trustProxy: process.env.TRUST_PROXY === '1',
  databaseSsl,
  bodyLimit: process.env.BODY_LIMIT || '1mb',
  requestTimeoutMs: positiveInt('REQUEST_TIMEOUT_MS', 30000, 120000),
  shutdownTimeoutMs: positiveInt('SHUTDOWN_TIMEOUT_MS', 10000, 60000),
  passwordResetBaseUrl: String(process.env.PASSWORD_RESET_BASE_URL || ''),
  emailWebhookUrl: String(process.env.EMAIL_WEBHOOK_URL || ''),
  emailFrom: String(process.env.EMAIL_FROM || 'no-reply@example.com')
};
