'use strict';

const { Pool, types } = require('pg');
const env = require('./env');

// Keep PostgreSQL DATE values as YYYY-MM-DD strings so host/server timezone
// never shifts collection/installment dates by one day.
types.setTypeParser(1082, (value) => value);

function buildSslConfig() {
  const mode = env.databaseSsl;
  if (mode === 'disable') return false;
  if (mode === 'no-verify') return { rejectUnauthorized: false };
  return { rejectUnauthorized: true };
}

const pool = new Pool({
  connectionString: env.databaseUrl,
  ssl: buildSslConfig(),
  max: Number(process.env.DB_POOL_MAX || 20),
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
  statement_timeout: Number(process.env.DB_STATEMENT_TIMEOUT_MS || 15000),
  query_timeout: Number(process.env.DB_QUERY_TIMEOUT_MS || 15000),
  application_name: 'imp-api'
});
pool.on('error', err => console.error('[IMP] PostgreSQL pool error:', err.message));
module.exports = pool;
