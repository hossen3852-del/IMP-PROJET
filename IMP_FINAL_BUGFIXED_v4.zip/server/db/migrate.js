'use strict';

const fs = require('node:fs/promises');
const path = require('node:path');
const pool = require('../config/db');

const MIGRATIONS_DIR = path.resolve(__dirname, '../../database/migrations');

async function migrate() {
  const client = await pool.connect();
  let locked = false;
  try {
    const lock = await client.query("SELECT pg_try_advisory_lock(hashtext('imp:database:migrations')) AS locked");
    locked = lock.rows[0].locked;
    if (!locked) throw new Error('Another migration process is already running');
    await client.query('CREATE EXTENSION IF NOT EXISTS pgcrypto');
    await client.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version VARCHAR(100) PRIMARY KEY,
        applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);

    const files = (await fs.readdir(MIGRATIONS_DIR))
      .filter((file) => file.endsWith('.sql'))
      .sort();

    for (const file of files) {
      const version = file.replace(/\.sql$/, '');
      const { rowCount } = await client.query(
        'SELECT 1 FROM schema_migrations WHERE version = $1',
        [version]
      );
      if (rowCount) continue;

      const sql = await fs.readFile(path.join(MIGRATIONS_DIR, file), 'utf8');
      await client.query('BEGIN');
      try {
        await client.query(sql);
        await client.query(
          `INSERT INTO schema_migrations(version) VALUES ($1)
           ON CONFLICT(version) DO NOTHING`,
          [version]
        );
        await client.query('COMMIT');
        console.log(`Applied migration: ${file}`);
      } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(`Migration failed: ${file}: ${error.message}`);
      }
    }
  } finally {
    if (locked) { try { await client.query("SELECT pg_advisory_unlock(hashtext('imp:database:migrations'))"); } catch {} }
    client.release();
    await pool.end();
  }
}

if (require.main === module) {
  migrate().catch((error) => {
    console.error(error);
    process.exitCode = 1;
  });
}

module.exports = { migrate, MIGRATIONS_DIR };
