'use strict';
const app = require('./app');
const env = require('./config/env');
const pool = require('./config/db');

const server = app.listen(env.port, () => console.log(`IMP API listening on port ${env.port}`));
server.requestTimeout = env.requestTimeoutMs;
server.headersTimeout = Math.min(env.requestTimeoutMs + 5000, 120000);
server.keepAliveTimeout = 5000;

let shuttingDown = false;
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`[IMP] ${signal} received; shutting down`);
  const timer = setTimeout(() => process.exit(1), env.shutdownTimeoutMs);
  timer.unref();
  server.close(async () => {
    try { await pool.end(); process.exit(0); }
    catch (error) { console.error('[IMP] Shutdown error:', error.message); process.exit(1); }
  });
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
