# Commercial Expansion Pack — Final Frozen Build

This build adds the requested ten commercial capability areas on top of the V5.2 pure layered API architecture.

## Included
1. **Mobile Field Officer App** — responsive field route page with authenticated API access.
2. **Offline-first Collection + Sync** — IndexedDB queue; collection payment events can sync through the existing payment transaction service using idempotency keys.
3. **SMS / WhatsApp notification layer** — tenant-scoped notification outbox and provider adapter boundary. Vendor credentials/adapters remain deployment configuration, not hard-coded.
4. **Digital Member Passbook** — tenant-scoped payment history endpoint.
5. **Advanced Loan Product Engine** — product rules, amount/installment limits, interest method, grace/penalty settings and server-side term calculation.
6. **Reschedule / Write-off / Penalty / Partial Payment** — controlled loan-adjustment ledger. Partial-payment collection continues to use the canonical Payment API; adjustment records provide the audit/business layer.
7. **MRA-oriented reporting** — management report endpoint containing active members, loan accounts, outstanding portfolio and collection metrics. It is intentionally labelled MRA-oriented, not a certified regulatory submission template.
8. **Full Accounting / GL integration foundation** — double-entry journal tables, balanced manual journals, automatic payment and loan-disbursement journal posting.
9. **Operational report engine** — summary, portfolio, collection, overdue, branch, collector and income/expense report codes.
10. **Production monitoring + backup + disaster recovery foundation** — authenticated monitoring endpoint, `pg_dump` backup script, deployment/restore runbook.

## Important deployment requirements
- Run `npm run db:migrate` against the target PostgreSQL database.
- Configure `DATABASE_URL` and normal production environment variables.
- For SMS/WhatsApp, configure an approved vendor adapter in `server/integrations/notificationProvider.js` and provider credentials via environment/secret management.
- Schedule `npm run notifications:process` through a worker/cron only after provider configuration.
- Schedule `npm run db:backup` and copy encrypted backups to separate durable storage.
- Test restore into a clean PostgreSQL instance before declaring disaster recovery complete.

## Financial safety
The existing Payment service remains the canonical posting path. Offline collection sync delegates `collection.payment` events to that service and uses the client event ID as an idempotency key. The GL migration automatically posts balanced journal entries for posted payments and loan disbursements.

## Regulatory note
The MRA report endpoint is a management/reporting foundation. Current Bangladesh Microcredit Regulatory Authority submission formats, schedules and validation rules must be verified against the applicable current MRA circular/template before regulatory filing.
