# 11.P.14.1 — Forgot Password + Secure Password Reset

Status: IMPLEMENTED — automated/static validation.

## Flow
Forgot Password → request reset → staging/local dev token → Reset Password → new Argon2id password → all existing sessions revoked → login.

## Security
- Reset token stored only as a SHA-256 hash.
- Token expires after 15 minutes.
- Previous unused tokens for the user are invalidated when a new request is created.
- Token is one-time via `used_at`.
- Reset revokes all existing sessions.
- Account existence is not disclosed in the response.
- Production does not return the raw token.

## Production email
The current build has no SMTP/email provider configured. In staging/local, the raw reset token is returned as `devToken` for testing. Before production go-live, a trusted email delivery provider must be integrated so production users receive a reset link; the raw token must never be returned in production responses.
