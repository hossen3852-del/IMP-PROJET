# IMP — Repaired Build

This build contains the audited IMP project plus the repaired canonical Core Storage layer for 11.3.1.

## Test
From this directory:
`node tests/storage.test.js`

See `IMP_AUDIT_AND_PRODUCTION_STATUS.md` for audit scope, results, and remaining production blockers.

Important: this is a production-candidate frontend build, not a fully production SaaS backend. The application still relies on browser storage and client-side authentication until the backend/security modules are completed.

## 2026-09-14 Loan workflow repair
- New loan creation now starts in `pending` status instead of `draft`, so the existing `loan.approve` action is immediately available.
- Lifecycle remains `pending -> approved -> disbursed -> active`; installment schedule generation remains after approval/disbursement.
