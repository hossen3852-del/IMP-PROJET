ALTER TABLE loans ADD COLUMN IF NOT EXISTS renewal_of_loan_id UUID REFERENCES loans(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS loans_renewal_of_idx ON loans(organization_id, renewal_of_loan_id);
INSERT INTO schema_migrations(version) VALUES ('030_v6_0_15_collection_loan_extensions') ON CONFLICT(version) DO NOTHING;
