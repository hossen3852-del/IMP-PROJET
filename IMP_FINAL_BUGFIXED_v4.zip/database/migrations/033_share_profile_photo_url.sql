-- V6.0.18 — shareholder profile photo support + validation hardening
ALTER TABLE capital_share_profiles
  ADD COLUMN IF NOT EXISTS photo_url TEXT;

COMMENT ON COLUMN capital_share_profiles.photo_url IS 'Optional shareholder photo (data URL or path)';
