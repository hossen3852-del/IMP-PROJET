-- 11.P.20 — Final idempotent repair for dashboard/capital/savings/expense RBAC
-- Repairs databases where 011/012/019 were already marked applied but
-- permission rows or grants are missing due to an incomplete/manual migration.

INSERT INTO permissions(code) VALUES
  ('capital.view'),
  ('capital.manage'),
  ('dashboard.customize'),
  ('savings.view'),
  ('savings.manage'),
  ('expense.view'),
  ('expense.manage')
ON CONFLICT (code) DO NOTHING;

-- Organization admin: full access.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'organization_admin'
  AND p.code IN (
    'capital.view','capital.manage','dashboard.customize',
    'savings.view','savings.manage','expense.view','expense.manage'
  )
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- Super admin: full access where the system role exists.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'super_admin'
  AND p.code IN (
    'capital.view','capital.manage','dashboard.customize',
    'savings.view','savings.manage','expense.view','expense.manage'
  )
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- Preserve the existing application RBAC policy for non-admin roles.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'branch_manager'
  AND p.code IN ('savings.view','savings.manage','expense.view')
ON CONFLICT (role_id, permission_id) DO NOTHING;

INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'accountant'
  AND p.code IN (
    'capital.view','savings.view','savings.manage',
    'expense.view','expense.manage'
  )
ON CONFLICT (role_id, permission_id) DO NOTHING;

INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code IN ('collector','field_officer')
  AND p.code IN ('savings.view','savings.manage','expense.view')
ON CONFLICT (role_id, permission_id) DO NOTHING;

INSERT INTO schema_migrations(version)
VALUES ('020_repair_dashboard_savings_expense_permissions_final')
ON CONFLICT (version) DO NOTHING;
