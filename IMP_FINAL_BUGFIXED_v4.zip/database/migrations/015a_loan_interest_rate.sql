-- ============================================================
-- 015 — Loan Interest Rate
-- ============================================================

ALTER TABLE loans
ADD COLUMN IF NOT EXISTS interest_rate
NUMERIC(10,4)
NOT NULL
DEFAULT 0
CHECK (interest_rate >= 0);


-- Existing loans:
-- interest_rate = interest_amount / loan_amount * 100

UPDATE loans
SET interest_rate =
    CASE
        WHEN loan_amount > 0
        THEN ROUND(
            (interest_amount / loan_amount) * 100,
            4
        )
        ELSE 0
    END
WHERE interest_rate = 0;


CREATE INDEX IF NOT EXISTS
loans_org_interest_rate_idx
ON loans(
    organization_id,
    interest_rate
);


INSERT INTO schema_migrations(version)
VALUES ('015a_loan_interest_rate')
ON CONFLICT(version)
DO NOTHING;