-- 11.P.9 — Installment API + Frontend Installment Cut-over
-- PostgreSQL/API is authoritative for installment schedules and status.

CREATE INDEX IF NOT EXISTS installments_org_loan_number_idx
  ON installments(organization_id,loan_id,installment_number);
CREATE INDEX IF NOT EXISTS installments_org_status_due_idx
  ON installments(organization_id,status,due_date);

-- Ensure the tenant-safe loan relationship created in 11.P.6 remains explicit.
ALTER TABLE installments DROP CONSTRAINT IF EXISTS installments_loan_org_fk;
ALTER TABLE installments
  ADD CONSTRAINT installments_loan_org_fk
  FOREIGN KEY (organization_id,loan_id)
  REFERENCES loans(organization_id,id) ON DELETE CASCADE;

INSERT INTO schema_migrations(version)
VALUES ('009_installment_api')
ON CONFLICT(version) DO NOTHING;
