-- 11.P.17 — Security hardening: company profile + user API + branch scope.

ALTER TABLE organizations
  ADD COLUMN IF NOT EXISTS company_code VARCHAR(80),
  ADD COLUMN IF NOT EXISTS company_type VARCHAR(120),
  ADD COLUMN IF NOT EXISTS country VARCHAR(120),
  ADD COLUMN IF NOT EXISTS currency VARCHAR(10) DEFAULT 'BDT',
  ADD COLUMN IF NOT EXISTS working_days JSONB DEFAULT '["Saturday","Sunday","Monday","Tuesday","Wednesday","Thursday"]'::jsonb,
  ADD COLUMN IF NOT EXISTS office_start_time TIME,
  ADD COLUMN IF NOT EXISTS office_end_time TIME,
  ADD COLUMN IF NOT EXISTS timezone VARCHAR(80) DEFAULT 'Asia/Dhaka';

CREATE UNIQUE INDEX IF NOT EXISTS organizations_company_code_uidx
  ON organizations(lower(company_code)) WHERE company_code IS NOT NULL;

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS user_code VARCHAR(40),
  ADD COLUMN IF NOT EXISTS created_by UUID REFERENCES users(id);

CREATE UNIQUE INDEX IF NOT EXISTS users_org_user_code_uidx
  ON users(organization_id,user_code) WHERE user_code IS NOT NULL;

-- Backfill safe display codes for existing users.
UPDATE users
SET user_code = 'USR-' || upper(substr(replace(id::text,'-',''),1,8))
WHERE user_code IS NULL OR user_code='';

ALTER TABLE organizations
  ADD CONSTRAINT organizations_company_code_format_ck
  CHECK (company_code IS NULL OR company_code ~ '^[A-Za-z0-9][A-Za-z0-9_-]{2,79}$');

INSERT INTO schema_migrations(version)
VALUES ('016_security_branch_scope')
ON CONFLICT(version) DO NOTHING;
