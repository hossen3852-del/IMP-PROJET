-- 11.P.4 — Organization + Branch API
-- Canonical API permissions and cross-tenant branch ownership constraints.

INSERT INTO permissions(code) VALUES
  ('organization.view'),
  ('organization.update'),
  ('branch.view'),
  ('branch.create'),
  ('branch.update')
ON CONFLICT(code) DO NOTHING;

INSERT INTO role_permissions(role, permission_id)
SELECT 'organization_admin', id FROM permissions
WHERE code IN ('organization.view','organization.update','branch.view','branch.create','branch.update')
ON CONFLICT DO NOTHING;

INSERT INTO role_permissions(role, permission_id)
SELECT 'super_admin', id FROM permissions
WHERE code IN ('organization.view','organization.update','branch.view','branch.create','branch.update')
ON CONFLICT DO NOTHING;

-- A branch is uniquely identified within its organization so dependent records
-- can use composite foreign keys to prevent cross-tenant relationships.
CREATE UNIQUE INDEX IF NOT EXISTS branches_org_id_id_uidx
  ON branches(organization_id,id);

ALTER TABLE users
  DROP CONSTRAINT IF EXISTS users_branch_org_fk;
ALTER TABLE users
  ADD CONSTRAINT users_branch_org_fk
  FOREIGN KEY (organization_id,branch_id)
  REFERENCES branches(organization_id,id)
  DEFERRABLE INITIALLY IMMEDIATE;

ALTER TABLE members
  DROP CONSTRAINT IF EXISTS members_branch_org_fk;
ALTER TABLE members
  ADD CONSTRAINT members_branch_org_fk
  FOREIGN KEY (organization_id,branch_id)
  REFERENCES branches(organization_id,id)
  DEFERRABLE INITIALLY IMMEDIATE;

ALTER TABLE loans
  DROP CONSTRAINT IF EXISTS loans_branch_org_fk;
ALTER TABLE loans
  ADD CONSTRAINT loans_branch_org_fk
  FOREIGN KEY (organization_id,branch_id)
  REFERENCES branches(organization_id,id)
  DEFERRABLE INITIALLY IMMEDIATE;

ALTER TABLE payments
  DROP CONSTRAINT IF EXISTS payments_branch_org_fk;
ALTER TABLE payments
  ADD CONSTRAINT payments_branch_org_fk
  FOREIGN KEY (organization_id,branch_id)
  REFERENCES branches(organization_id,id)
  DEFERRABLE INITIALLY IMMEDIATE;
