-- 11.P.15.3 — Member + Nominee Registration photos
ALTER TABLE members ADD COLUMN IF NOT EXISTS photo_data BYTEA;
ALTER TABLE members ADD COLUMN IF NOT EXISTS photo_mime VARCHAR(100);
ALTER TABLE member_nominees ADD COLUMN IF NOT EXISTS photo_data BYTEA;
ALTER TABLE member_nominees ADD COLUMN IF NOT EXISTS photo_mime VARCHAR(100);
INSERT INTO schema_migrations(version) VALUES ('013_member_nominee_registration') ON CONFLICT(version) DO NOTHING;
