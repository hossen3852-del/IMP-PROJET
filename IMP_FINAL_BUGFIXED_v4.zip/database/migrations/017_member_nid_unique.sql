-- 11.P.17 — Enforce unique NID/Passport per organization (non-empty values)
-- Soft: only for non-empty nid_or_passport. Existing duplicates (if any) must be cleaned before applying unique index.

CREATE UNIQUE INDEX IF NOT EXISTS members_org_nid_unique_idx
  ON members (organization_id, nid_or_passport)
  WHERE nid_or_passport IS NOT NULL AND btrim(nid_or_passport) <> '';

INSERT INTO schema_migrations(version)
VALUES ('017_member_nid_unique')
ON CONFLICT(version) DO NOTHING;
