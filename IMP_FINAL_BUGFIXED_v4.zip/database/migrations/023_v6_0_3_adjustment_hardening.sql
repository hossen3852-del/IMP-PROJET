-- V6.0.3 adjustment hardening.
-- Reschedule execution is applied to open installments by the application service.
-- Metadata retains the reschedule parameters and partial-payment payment id.
CREATE INDEX IF NOT EXISTS loan_adjustments_org_type_date_idx
  ON loan_adjustments(organization_id, adjustment_type, effective_date DESC);
INSERT INTO schema_migrations(version) VALUES ('023_v6_0_3_adjustment_hardening') ON CONFLICT(version) DO NOTHING;
