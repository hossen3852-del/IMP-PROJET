-- 034_payment_source_daily_collection
-- Tag payments created from Daily Collection so Payments UI Daily Collection
-- section and reports can attribute them correctly.

ALTER TABLE payments
  ADD COLUMN IF NOT EXISTS source VARCHAR(40) NOT NULL DEFAULT 'manual';

ALTER TABLE payments DROP CONSTRAINT IF EXISTS payments_source_check;
ALTER TABLE payments ADD CONSTRAINT payments_source_check
  CHECK (source IN ('manual', 'daily_collection', 'legacy', 'disbursement', 'other'));

CREATE INDEX IF NOT EXISTS payments_org_source_date_idx
  ON payments(organization_id, source, payment_date DESC)
  WHERE status = 'posted';

-- Backfill: any payment whose audit log says daily_collection
UPDATE payments p
SET source = 'daily_collection'
WHERE p.source = 'manual'
  AND EXISTS (
    SELECT 1 FROM audit_logs a
    WHERE a.organization_id = p.organization_id
      AND a.entity_type = 'payment'
      AND a.entity_id = p.id
      AND a.action = 'PAYMENT_CREATED'
      AND (a.metadata->>'source') = 'daily_collection'
  );

INSERT INTO schema_migrations(version)
VALUES ('034_payment_source_daily_collection')
ON CONFLICT(version) DO NOTHING;
