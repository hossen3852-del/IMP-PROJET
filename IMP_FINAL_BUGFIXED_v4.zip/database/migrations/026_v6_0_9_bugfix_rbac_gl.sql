-- V6.0.9 / V6.0.10 bugfix migration
-- 1) Expand create_default_org_rbac so NEW organizations receive commercial expansion permissions
-- 2) Backfill expansion permissions for existing organization roles
-- 3) Fix payment GL trigger: split principal vs interest so Loan Receivable (1200)
--    does not go negative and Interest Income (4000) is recognized
-- 4) Ensure default GL accounts for every organization

-- ============================================================
-- Permissions catalog (idempotent)
-- ============================================================
INSERT INTO permissions(code) VALUES
 ('field.sync'),('field.route.view'),
 ('notification.view'),('notification.send'),
 ('passbook.view'),
 ('loan.product.view'),('loan.product.manage'),('loan.adjustment.view'),('loan.adjustment.manage'),
 ('report.view'),('report.mra.view'),
 ('accounting.view'),('accounting.manage'),
 ('ops.view')
ON CONFLICT(code) DO NOTHING;

-- ============================================================
-- create_default_org_rbac — includes commercial expansion codes
-- ============================================================
CREATE OR REPLACE FUNCTION create_default_org_rbac(p_organization_id UUID)
RETURNS VOID
LANGUAGE plpgsql
AS $$
DECLARE
  role_record RECORD;
BEGIN
  INSERT INTO roles(organization_id,code,name,description,is_system,is_protected)
  VALUES
    (p_organization_id,'organization_admin','Organization Admin','Full organization administration',FALSE,TRUE),
    (p_organization_id,'branch_manager','Branch Manager','Branch-level operational management',FALSE,FALSE),
    (p_organization_id,'collector','Collector','Collection and payment operations',FALSE,FALSE),
    (p_organization_id,'accountant','Accountant','Financial and payment operations',FALSE,FALSE),
    (p_organization_id,'field_officer','Field Officer','Daily member visits: loan installment, savings and insurance collection',FALSE,FALSE),
    (p_organization_id,'viewer','Viewer','Read-only organization access',FALSE,FALSE)
  ON CONFLICT (organization_id,code) WHERE is_system=FALSE DO NOTHING;

  -- Default GL chart for the new organization
  INSERT INTO accounting_accounts(organization_id,code,name,account_type) VALUES
    (p_organization_id,'1000','Cash','asset'),
    (p_organization_id,'1010','Bank / Digital Wallet','asset'),
    (p_organization_id,'1200','Loan Receivable','asset'),
    (p_organization_id,'4000','Interest Income','income'),
    (p_organization_id,'4100','Penalty Income','income'),
    (p_organization_id,'5000','Operating Expense','expense'),
    (p_organization_id,'5010','Loan Write-off / Waiver Expense','expense')
  ON CONFLICT(organization_id,code) DO NOTHING;

  FOR role_record IN
    SELECT id,code FROM roles
    WHERE organization_id=p_organization_id AND is_system=FALSE
  LOOP
    INSERT INTO role_permissions(role,permission_id,role_id)
    SELECT role_record.code,p.id,role_record.id
    FROM permissions p
    WHERE p.code = ANY(
      CASE role_record.code
        WHEN 'organization_admin' THEN ARRAY[
          'dashboard.view','dashboard.customize',
          'organization.view','organization.update',
          'branch.view','branch.create','branch.update','branch.delete',
          'user.view','user.create','user.update','user.delete',
          'role.view','role.create','role.update','role.delete','role.manage',
          'permission.view','settings.view','settings.update',
          'member.view','member.create','member.update','member.delete',
          'member.status.update','member.financial.update',
          'member.document.upload','member.document.delete',
          'loan.view','loan.create','loan.update','loan.delete','loan.approve',
          'loan.status.update','loan.financial.update',
          'loan.payment.create','loan.payment.update','loan.payment.delete','loan.schedule.update',
          'payment.view','payment.create','payment.cancel','payment.reverse',
          'capital.view','capital.manage',
          'savings.view','savings.manage','expense.view','expense.manage',
          'insurance.view','insurance.manage','collection.create',
          'field.sync','field.route.view',
          'notification.view','notification.send',
          'passbook.view',
          'loan.product.view','loan.product.manage','loan.adjustment.view','loan.adjustment.manage',
          'report.view','report.mra.view',
          'accounting.view','accounting.manage',
          'ops.view'
        ]
        WHEN 'branch_manager' THEN ARRAY[
          'dashboard.view','branch.view','user.view','user.create','user.update',
          'settings.view','member.view','member.create','member.update',
          'member.status.update','member.financial.update','member.document.upload',
          'loan.view','loan.create','loan.update','loan.approve','loan.status.update',
          'loan.financial.update','loan.payment.create','loan.schedule.update',
          'savings.view','savings.manage','expense.view',
          'insurance.view','insurance.manage','collection.create',
          'field.sync','field.route.view',
          'passbook.view',
          'loan.product.view','loan.adjustment.view',
          'report.view','notification.view'
        ]
        WHEN 'collector' THEN ARRAY[
          'dashboard.view','member.view','loan.view','payment.view','payment.create',
          'loan.payment.create','savings.view','savings.manage',
          'insurance.view','insurance.manage','collection.create',
          'field.sync','field.route.view','passbook.view'
        ]
        WHEN 'field_officer' THEN ARRAY[
          'dashboard.view','member.view','loan.view','payment.view','payment.create',
          'loan.payment.create','savings.view','savings.manage',
          'insurance.view','insurance.manage','collection.create',
          'field.sync','field.route.view','passbook.view'
        ]
        WHEN 'accountant' THEN ARRAY[
          'dashboard.view','member.view','member.financial.update','loan.view',
          'loan.financial.update','payment.view','payment.create','loan.payment.create',
          'loan.payment.update','capital.view',
          'savings.view','savings.manage','expense.view','expense.manage',
          'insurance.view','insurance.manage',
          'passbook.view','loan.product.view','loan.adjustment.view','loan.adjustment.manage',
          'report.view','report.mra.view','accounting.view','accounting.manage'
        ]
        ELSE ARRAY[
          'dashboard.view','organization.view','branch.view','user.view',
          'member.view','loan.view','payment.view','passbook.view','report.view'
        ]
      END::VARCHAR[]
    )
    ON CONFLICT (role_id,permission_id) DO NOTHING;
  END LOOP;
END;
$$;

-- ============================================================
-- Backfill existing organizations (roles already created without expansion perms)
-- ============================================================
DO $$
DECLARE
  org_rec RECORD;
  role_rec RECORD;
BEGIN
  FOR org_rec IN SELECT id FROM organizations LOOP
    -- Ensure GL accounts exist
    INSERT INTO accounting_accounts(organization_id,code,name,account_type) VALUES
      (org_rec.id,'1000','Cash','asset'),
      (org_rec.id,'1010','Bank / Digital Wallet','asset'),
      (org_rec.id,'1200','Loan Receivable','asset'),
      (org_rec.id,'4000','Interest Income','income'),
      (org_rec.id,'4100','Penalty Income','income'),
      (org_rec.id,'5000','Operating Expense','expense'),
      (org_rec.id,'5010','Loan Write-off / Waiver Expense','expense')
    ON CONFLICT(organization_id,code) DO NOTHING;

    FOR role_rec IN
      SELECT id, code FROM roles
      WHERE organization_id = org_rec.id AND is_system = FALSE
    LOOP
      INSERT INTO role_permissions(role, permission_id, role_id)
      SELECT role_rec.code, p.id, role_rec.id
      FROM permissions p
      WHERE p.code = ANY(
        CASE role_rec.code
          WHEN 'organization_admin' THEN ARRAY[
            'field.sync','field.route.view','notification.view','notification.send',
            'passbook.view','loan.product.view','loan.product.manage',
            'loan.adjustment.view','loan.adjustment.manage',
            'report.view','report.mra.view','accounting.view','accounting.manage','ops.view'
          ]
          WHEN 'branch_manager' THEN ARRAY[
            'field.sync','field.route.view','passbook.view','loan.product.view',
            'loan.adjustment.view','report.view','notification.view'
          ]
          WHEN 'collector' THEN ARRAY[
            'field.sync','field.route.view','passbook.view'
          ]
          WHEN 'field_officer' THEN ARRAY[
            'field.sync','field.route.view','passbook.view'
          ]
          WHEN 'accountant' THEN ARRAY[
            'passbook.view','loan.product.view','loan.adjustment.view','loan.adjustment.manage',
            'report.view','report.mra.view','accounting.view','accounting.manage'
          ]
          ELSE ARRAY['passbook.view','report.view']
        END::VARCHAR[]
      )
      ON CONFLICT (role_id, permission_id) DO NOTHING;
    END LOOP;
  END LOOP;
END $$;

-- Super-admin system role expansion perms (idempotent)
INSERT INTO role_permissions(role,permission_id,role_id)
SELECT r.code,p.id,r.id FROM roles r CROSS JOIN permissions p
WHERE r.code='super_admin' AND r.is_system=TRUE
  AND p.code IN (
    'field.sync','field.route.view','notification.view','notification.send','passbook.view',
    'loan.product.view','loan.product.manage','loan.adjustment.view','loan.adjustment.manage',
    'report.view','report.mra.view','accounting.view','accounting.manage','ops.view'
  )
ON CONFLICT(role_id,permission_id) DO NOTHING;

-- ============================================================
-- GL: payment posting splits principal vs interest
-- Disbursement still posts only principal to receivable (correct).
-- Payment credits receivable for principal portion and interest income
-- for the interest portion, proportional to loan.interest_amount / total_payable.
-- ============================================================
CREATE OR REPLACE FUNCTION imp_post_payment_gl() RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
  debit_account UUID;
  receivable UUID;
  interest_income UUID;
  jid UUID;
  loan_principal NUMERIC(18,2);
  loan_interest NUMERIC(18,2);
  loan_total NUMERIC(18,2);
  principal_share NUMERIC(18,2);
  interest_share NUMERIC(18,2);
BEGIN
  PERFORM imp_ensure_gl(NEW.organization_id);

  SELECT id INTO receivable FROM accounting_accounts
    WHERE organization_id=NEW.organization_id AND code='1200';
  SELECT id INTO interest_income FROM accounting_accounts
    WHERE organization_id=NEW.organization_id AND code='4000';
  SELECT id INTO debit_account FROM accounting_accounts
    WHERE organization_id=NEW.organization_id
      AND code=CASE WHEN NEW.payment_method IN ('cash') THEN '1000' ELSE '1010' END;

  SELECT
    COALESCE(loan_amount, disbursed_amount, 0),
    COALESCE(interest_amount, 0),
    COALESCE(NULLIF(total_payable, 0), COALESCE(loan_amount, disbursed_amount, 0) + COALESCE(interest_amount, 0))
  INTO loan_principal, loan_interest, loan_total
  FROM loans
  WHERE id = NEW.loan_id AND organization_id = NEW.organization_id;

  IF loan_total IS NULL OR loan_total <= 0 THEN
    loan_total := NEW.amount;
    loan_principal := NEW.amount;
    loan_interest := 0;
  END IF;

  -- Proportional split; last residual goes to principal to avoid rounding drift
  interest_share := ROUND(NEW.amount * (loan_interest / loan_total), 2);
  IF interest_share > NEW.amount THEN
    interest_share := NEW.amount;
  END IF;
  IF interest_share < 0 THEN
    interest_share := 0;
  END IF;
  principal_share := ROUND(NEW.amount - interest_share, 2);

  INSERT INTO accounting_journal_entries(
    organization_id, branch_id, entry_date, reference_type, reference_id, description, posted_by
  ) VALUES (
    NEW.organization_id, NEW.branch_id, NEW.payment_date::date,
    'payment', NEW.id, 'Payment '||NEW.payment_number, NEW.created_by
  ) RETURNING id INTO jid;

  -- Debit cash / bank for full amount received
  INSERT INTO accounting_journal_lines(journal_id, account_id, debit, credit, description)
  VALUES (jid, debit_account, NEW.amount, 0, 'Payment received');

  -- Credit loan receivable for principal portion
  IF principal_share > 0 AND receivable IS NOT NULL THEN
    INSERT INTO accounting_journal_lines(journal_id, account_id, debit, credit, description)
    VALUES (jid, receivable, 0, principal_share, 'Loan principal reduction');
  END IF;

  -- Credit interest income for interest portion
  IF interest_share > 0 AND interest_income IS NOT NULL THEN
    INSERT INTO accounting_journal_lines(journal_id, account_id, debit, credit, description)
    VALUES (jid, interest_income, 0, interest_share, 'Interest income recognized');
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_payment_gl ON payments;
CREATE TRIGGER trg_payment_gl
  AFTER INSERT ON payments
  FOR EACH ROW
  WHEN (NEW.status = 'posted')
  EXECUTE FUNCTION imp_post_payment_gl();

-- Ensure write-off expense account exists via imp_ensure_gl
CREATE OR REPLACE FUNCTION imp_ensure_gl(p_org UUID) RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO accounting_accounts(organization_id,code,name,account_type) VALUES
    (p_org,'1000','Cash','asset'),
    (p_org,'1010','Bank / Digital Wallet','asset'),
    (p_org,'1200','Loan Receivable','asset'),
    (p_org,'4000','Interest Income','income'),
    (p_org,'4100','Penalty Income','income'),
    (p_org,'5000','Operating Expense','expense'),
    (p_org,'5010','Loan Write-off / Waiver Expense','expense')
  ON CONFLICT(organization_id,code) DO NOTHING;
END;
$$;

INSERT INTO schema_migrations(version) VALUES ('026_v6_0_9_bugfix_rbac_gl') ON CONFLICT(version) DO NOTHING;
