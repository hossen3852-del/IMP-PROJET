-- Bugfix: cancelling or reversing a payment (POST /payments/:id/cancel,
-- POST /payments/:id/reverse) correctly restores installment outstanding
-- amounts and the loan's outstanding balance, but never reversed the
-- General Ledger journal entries that trg_payment_gl posted on the
-- original INSERT. Cash/Bank and Interest Income stayed permanently
-- overstated and Loan Receivable permanently understated after any
-- cancellation/reversal.
--
-- This adds a companion trigger that, when a payment moves from 'posted'
-- to 'cancelled'/'reversed', finds the original journal entry (by
-- reference_type='payment', reference_id=payment id) and posts a mirror
-- entry with debit/credit swapped on every line — the standard accounting
-- practice of reversing via a new entry rather than editing history.

CREATE OR REPLACE FUNCTION imp_post_payment_reversal_gl() RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
  orig_jid UUID;
  jid UUID;
  line_count INT;
BEGIN
  IF NEW.status IN ('cancelled','reversed') AND OLD.status = 'posted' THEN
    SELECT id INTO orig_jid
      FROM accounting_journal_entries
      WHERE organization_id = NEW.organization_id
        AND reference_type = 'payment'
        AND reference_id = NEW.id
      ORDER BY posted_at ASC
      LIMIT 1;

    -- Nothing to reverse if no GL entry was ever posted for this payment
    -- (e.g. GL integration was added after this payment existed).
    IF orig_jid IS NULL THEN
      RETURN NEW;
    END IF;

    -- Idempotency guard: never post a second reversal for the same payment.
    PERFORM 1 FROM accounting_journal_entries
      WHERE organization_id = NEW.organization_id
        AND reference_type = 'payment_reversal'
        AND reference_id = NEW.id;
    IF FOUND THEN
      RETURN NEW;
    END IF;

    INSERT INTO accounting_journal_entries(
      organization_id, branch_id, entry_date, reference_type, reference_id, description, posted_by
    ) VALUES (
      NEW.organization_id, NEW.branch_id, CURRENT_DATE, 'payment_reversal', NEW.id,
      (CASE WHEN NEW.status = 'cancelled' THEN 'Payment cancellation reversal ' ELSE 'Payment reversal ' END) || NEW.payment_number,
      NEW.created_by
    ) RETURNING id INTO jid;

    INSERT INTO accounting_journal_lines(journal_id, account_id, debit, credit, description)
    SELECT jid, account_id, credit, debit, 'Reversal: ' || COALESCE(description, '')
    FROM accounting_journal_lines
    WHERE journal_id = orig_jid;

    GET DIAGNOSTICS line_count = ROW_COUNT;
    IF line_count = 0 THEN
      -- Original entry had no lines (shouldn't happen) — remove the empty
      -- header so we don't leave an orphaned journal entry behind.
      DELETE FROM accounting_journal_entries WHERE id = jid;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_payment_gl_reversal ON payments;
CREATE TRIGGER trg_payment_gl_reversal
  AFTER UPDATE OF status ON payments
  FOR EACH ROW
  WHEN (NEW.status IN ('cancelled','reversed') AND OLD.status = 'posted')
  EXECUTE FUNCTION imp_post_payment_reversal_gl();

INSERT INTO schema_migrations(version) VALUES ('036_payment_cancellation_gl_reversal')
ON CONFLICT(version) DO NOTHING;
