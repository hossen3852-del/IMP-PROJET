-- 11.P.6 — Tenant Isolation
-- Enforces organization ownership at the PostgreSQL relationship boundary.
-- Application authorization remains required; these constraints are the final
-- integrity layer against cross-tenant ID substitution.

-- Composite parent keys used by tenant-aware foreign keys.
CREATE UNIQUE INDEX IF NOT EXISTS organizations_id_uidx ON organizations(id);
CREATE UNIQUE INDEX IF NOT EXISTS users_org_id_uidx ON users(organization_id,id);
CREATE UNIQUE INDEX IF NOT EXISTS members_org_id_uidx ON members(organization_id,id);
CREATE UNIQUE INDEX IF NOT EXISTS loans_org_id_uidx ON loans(organization_id,id);
CREATE UNIQUE INDEX IF NOT EXISTS installments_org_id_uidx ON installments(organization_id,id);
CREATE UNIQUE INDEX IF NOT EXISTS payments_org_id_uidx ON payments(organization_id,id);
CREATE UNIQUE INDEX IF NOT EXISTS payment_allocations_org_id_uidx ON payment_allocations(organization_id,id);

-- A session's tenant must be the same tenant as its user.
ALTER TABLE sessions DROP CONSTRAINT IF EXISTS sessions_user_org_fk;
ALTER TABLE sessions
  ADD CONSTRAINT sessions_user_org_fk
  FOREIGN KEY (organization_id,user_id)
  REFERENCES users(organization_id,id)
  ON DELETE CASCADE;

-- A tenant user may only use a role belonging to that tenant, except for a
-- global system role. The trigger handles the intentional global-role case.
CREATE OR REPLACE FUNCTION enforce_user_role_tenant()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE role_org UUID; role_is_system BOOLEAN;
BEGIN
  IF NEW.role_id IS NULL THEN
    RAISE EXCEPTION 'users.role_id is required for tenant authorization';
  END IF;
  SELECT organization_id,is_system INTO role_org,role_is_system
  FROM roles WHERE id=NEW.role_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Assigned role does not exist';
  END IF;
  IF role_is_system IS DISTINCT FROM TRUE AND role_org IS DISTINCT FROM NEW.organization_id THEN
    RAISE EXCEPTION 'User role belongs to another organization';
  END IF;
  IF role_is_system = TRUE AND role_org IS NOT NULL THEN
    RAISE EXCEPTION 'System role must not have an organization';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS users_role_tenant_trg ON users;
CREATE TRIGGER users_role_tenant_trg
BEFORE INSERT OR UPDATE OF organization_id,role_id ON users
FOR EACH ROW EXECUTE FUNCTION enforce_user_role_tenant();

-- Branch ownership was established in 11.P.4. Extend the same guarantee to
-- every tenant-owned child relationship.
ALTER TABLE branches DROP CONSTRAINT IF EXISTS branches_created_by_org_fk;
ALTER TABLE branches
  ADD CONSTRAINT branches_created_by_org_fk
  FOREIGN KEY (organization_id,created_by)
  REFERENCES users(organization_id,id);

ALTER TABLE members DROP CONSTRAINT IF EXISTS members_created_by_org_fk;
ALTER TABLE members
  ADD CONSTRAINT members_created_by_org_fk
  FOREIGN KEY (organization_id,created_by)
  REFERENCES users(organization_id,id);
ALTER TABLE members DROP CONSTRAINT IF EXISTS members_updated_by_org_fk;
ALTER TABLE members
  ADD CONSTRAINT members_updated_by_org_fk
  FOREIGN KEY (organization_id,updated_by)
  REFERENCES users(organization_id,id);

ALTER TABLE member_nominees DROP CONSTRAINT IF EXISTS member_nominee_member_org_fk;
ALTER TABLE member_nominees
  ADD CONSTRAINT member_nominee_member_org_fk
  FOREIGN KEY (organization_id,member_id)
  REFERENCES members(organization_id,id) ON DELETE CASCADE;

ALTER TABLE member_documents DROP CONSTRAINT IF EXISTS member_document_member_org_fk;
ALTER TABLE member_documents
  ADD CONSTRAINT member_document_member_org_fk
  FOREIGN KEY (organization_id,member_id)
  REFERENCES members(organization_id,id) ON DELETE CASCADE;
ALTER TABLE member_documents DROP CONSTRAINT IF EXISTS member_documents_uploaded_by_org_fk;
ALTER TABLE member_documents
  ADD CONSTRAINT member_documents_uploaded_by_org_fk
  FOREIGN KEY (organization_id,uploaded_by)
  REFERENCES users(organization_id,id);

ALTER TABLE member_activities DROP CONSTRAINT IF EXISTS member_activity_member_org_fk;
ALTER TABLE member_activities
  ADD CONSTRAINT member_activity_member_org_fk
  FOREIGN KEY (organization_id,member_id)
  REFERENCES members(organization_id,id) ON DELETE CASCADE;
ALTER TABLE member_activities DROP CONSTRAINT IF EXISTS member_activities_created_by_org_fk;
ALTER TABLE member_activities
  ADD CONSTRAINT member_activities_created_by_org_fk
  FOREIGN KEY (organization_id,created_by)
  REFERENCES users(organization_id,id);

ALTER TABLE loans DROP CONSTRAINT IF EXISTS loans_member_org_fk;
ALTER TABLE loans
  ADD CONSTRAINT loans_member_org_fk
  FOREIGN KEY (organization_id,member_id)
  REFERENCES members(organization_id,id) ON DELETE RESTRICT;
ALTER TABLE loans DROP CONSTRAINT IF EXISTS loans_created_by_org_fk;
ALTER TABLE loans
  ADD CONSTRAINT loans_created_by_org_fk
  FOREIGN KEY (organization_id,created_by)
  REFERENCES users(organization_id,id);
ALTER TABLE loans DROP CONSTRAINT IF EXISTS loans_approved_by_org_fk;
ALTER TABLE loans
  ADD CONSTRAINT loans_approved_by_org_fk
  FOREIGN KEY (organization_id,approved_by)
  REFERENCES users(organization_id,id);

ALTER TABLE installments DROP CONSTRAINT IF EXISTS installments_loan_org_fk;
ALTER TABLE installments
  ADD CONSTRAINT installments_loan_org_fk
  FOREIGN KEY (organization_id,loan_id)
  REFERENCES loans(organization_id,id) ON DELETE CASCADE;

ALTER TABLE payments DROP CONSTRAINT IF EXISTS payments_member_org_fk;
ALTER TABLE payments
  ADD CONSTRAINT payments_member_org_fk
  FOREIGN KEY (organization_id,member_id)
  REFERENCES members(organization_id,id) ON DELETE RESTRICT;
ALTER TABLE payments DROP CONSTRAINT IF EXISTS payments_loan_org_fk;
ALTER TABLE payments
  ADD CONSTRAINT payments_loan_org_fk
  FOREIGN KEY (organization_id,loan_id)
  REFERENCES loans(organization_id,id) ON DELETE RESTRICT;
ALTER TABLE payments DROP CONSTRAINT IF EXISTS payments_collector_org_fk;
ALTER TABLE payments
  ADD CONSTRAINT payments_collector_org_fk
  FOREIGN KEY (organization_id,collector_id)
  REFERENCES users(organization_id,id);
ALTER TABLE payments DROP CONSTRAINT IF EXISTS payments_created_by_org_fk;
ALTER TABLE payments
  ADD CONSTRAINT payments_created_by_org_fk
  FOREIGN KEY (organization_id,created_by)
  REFERENCES users(organization_id,id);

ALTER TABLE payment_allocations DROP CONSTRAINT IF EXISTS payment_allocations_payment_org_fk;
ALTER TABLE payment_allocations
  ADD CONSTRAINT payment_allocations_payment_org_fk
  FOREIGN KEY (organization_id,payment_id)
  REFERENCES payments(organization_id,id) ON DELETE RESTRICT;
ALTER TABLE payment_allocations DROP CONSTRAINT IF EXISTS payment_allocations_loan_org_fk;
ALTER TABLE payment_allocations
  ADD CONSTRAINT payment_allocations_loan_org_fk
  FOREIGN KEY (organization_id,loan_id)
  REFERENCES loans(organization_id,id) ON DELETE RESTRICT;
ALTER TABLE payment_allocations DROP CONSTRAINT IF EXISTS payment_allocations_installment_org_fk;
ALTER TABLE payment_allocations
  ADD CONSTRAINT payment_allocations_installment_org_fk
  FOREIGN KEY (organization_id,installment_id)
  REFERENCES installments(organization_id,id) ON DELETE RESTRICT;
ALTER TABLE payment_allocations DROP CONSTRAINT IF EXISTS payment_allocations_adjustment_org_fk;
ALTER TABLE payment_allocations
  ADD CONSTRAINT payment_allocations_adjustment_org_fk
  FOREIGN KEY (organization_id,adjustment_for_allocation_id)
  REFERENCES payment_allocations(organization_id,id) ON DELETE RESTRICT;

ALTER TABLE payment_receipts DROP CONSTRAINT IF EXISTS payment_receipts_payment_org_fk;
ALTER TABLE payment_receipts
  ADD CONSTRAINT payment_receipts_payment_org_fk
  FOREIGN KEY (organization_id,payment_id)
  REFERENCES payments(organization_id,id) ON DELETE RESTRICT;
ALTER TABLE payment_receipts DROP CONSTRAINT IF EXISTS payment_receipts_issued_by_org_fk;
ALTER TABLE payment_receipts
  ADD CONSTRAINT payment_receipts_issued_by_org_fk
  FOREIGN KEY (organization_id,issued_by)
  REFERENCES users(organization_id,id);

ALTER TABLE organization_settings DROP CONSTRAINT IF EXISTS organization_settings_updated_by_org_fk;
ALTER TABLE organization_settings
  ADD CONSTRAINT organization_settings_updated_by_org_fk
  FOREIGN KEY (organization_id,updated_by)
  REFERENCES users(organization_id,id);

-- Tenant ownership is also validated for the authentication/session boundary.
CREATE INDEX IF NOT EXISTS audit_logs_org_user_time_idx
  ON audit_logs(organization_id,user_id,created_at DESC);

INSERT INTO schema_migrations(version)
VALUES ('006_tenant_isolation')
ON CONFLICT(version) DO NOTHING;
