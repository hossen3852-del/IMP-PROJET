-- 11.P.16 — Organization Settings API + disk-based photo storage
-- Additive only. Keeps photo_data BYTEA for backward compatibility;
-- new writes prefer photo_path on disk under /uploads.

ALTER TABLE members
  ADD COLUMN IF NOT EXISTS photo_path VARCHAR(500);

ALTER TABLE member_nominees
  ADD COLUMN IF NOT EXISTS photo_path VARCHAR(500);

-- Ensure known setting keys are documented (no schema change needed —
-- organization_settings already supports arbitrary setting_key + JSONB).
-- Canonical keys used by /api/settings:
--   loan_ui_config
--   payment_ui_config
--   member_registration_ui
--   dashboard_config (also via /api/dashboard/config)
--   daily_collection_config (also via collections)

INSERT INTO schema_migrations(version)
VALUES ('015b_settings_photo_storage')
ON CONFLICT(version) DO NOTHING;
