CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 11.P.2 — Canonical tenant-aware domain schema.
-- Money uses NUMERIC, never floating point.
-- Organization ownership is explicit on every tenant-owned root/entity table.

CREATE TABLE IF NOT EXISTS branches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  branch_code VARCHAR(50) NOT NULL,
  name VARCHAR(200) NOT NULL,
  phone VARCHAR(50),
  address TEXT,
  manager_name VARCHAR(200),
  status VARCHAR(30) NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(organization_id, branch_code),
  UNIQUE(organization_id, name)
);
CREATE INDEX IF NOT EXISTS branches_org_idx ON branches(organization_id);

ALTER TABLE users
  DROP CONSTRAINT IF EXISTS users_branch_id_fkey;
ALTER TABLE users
  ADD CONSTRAINT users_branch_id_fkey
  FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE SET NULL;

CREATE TABLE IF NOT EXISTS members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES branches(id) ON DELETE RESTRICT,
  member_code VARCHAR(80) NOT NULL,
  full_name VARCHAR(200) NOT NULL,
  email VARCHAR(254),
  phone VARCHAR(50),
  address TEXT,
  nid_or_passport VARCHAR(100),
  status VARCHAR(30) NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','inactive')),
  created_by UUID REFERENCES users(id),
  updated_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(organization_id, member_code)
);
CREATE INDEX IF NOT EXISTS members_org_idx ON members(organization_id);
CREATE INDEX IF NOT EXISTS members_org_branch_idx ON members(organization_id,branch_id);
CREATE INDEX IF NOT EXISTS members_org_phone_idx ON members(organization_id,phone);

CREATE TABLE IF NOT EXISTS member_nominees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  member_id UUID NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  name VARCHAR(200) NOT NULL,
  relation VARCHAR(100),
  mobile VARCHAR(50),
  nid VARCHAR(100),
  address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(organization_id,member_id)
);
CREATE INDEX IF NOT EXISTS member_nominees_org_idx ON member_nominees(organization_id);

CREATE TABLE IF NOT EXISTS member_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  member_id UUID NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  document_type VARCHAR(100) NOT NULL,
  name VARCHAR(255) NOT NULL,
  reference VARCHAR(255),
  storage_key TEXT,
  description TEXT,
  uploaded_by UUID REFERENCES users(id),
  uploaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS member_documents_org_member_idx ON member_documents(organization_id,member_id);

CREATE TABLE IF NOT EXISTS member_activities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  member_id UUID NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  activity_type VARCHAR(100) NOT NULL,
  description TEXT,
  metadata JSONB,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS member_activities_org_member_time_idx ON member_activities(organization_id,member_id,created_at DESC);

CREATE TABLE IF NOT EXISTS loans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES branches(id) ON DELETE RESTRICT,
  member_id UUID NOT NULL REFERENCES members(id) ON DELETE RESTRICT,
  loan_number VARCHAR(100) NOT NULL,
  loan_type VARCHAR(100) NOT NULL,
  loan_purpose TEXT,
  loan_amount NUMERIC(18,2) NOT NULL CHECK (loan_amount > 0),
  interest_amount NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (interest_amount >= 0),
  total_payable NUMERIC(18,2) NOT NULL CHECK (total_payable >= 0),
  installment_amount NUMERIC(18,2) NOT NULL CHECK (installment_amount > 0),
  number_of_installments INTEGER NOT NULL CHECK (number_of_installments > 0),
  installment_frequency VARCHAR(30) NOT NULL,
  start_date DATE NOT NULL,
  first_installment_date DATE,
  application_date TIMESTAMPTZ,
  approval_date TIMESTAMPTZ,
  disbursed_at TIMESTAMPTZ,
  status VARCHAR(30) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','pending','approved','disbursed','active','completed','cancelled','rejected')),
  created_by UUID REFERENCES users(id),
  approved_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(organization_id,loan_number)
);
CREATE INDEX IF NOT EXISTS loans_org_member_idx ON loans(organization_id,member_id);
CREATE INDEX IF NOT EXISTS loans_org_branch_idx ON loans(organization_id,branch_id);
CREATE INDEX IF NOT EXISTS loans_org_status_idx ON loans(organization_id,status);

CREATE TABLE IF NOT EXISTS installments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  loan_id UUID NOT NULL REFERENCES loans(id) ON DELETE CASCADE,
  installment_number INTEGER NOT NULL CHECK (installment_number > 0),
  due_date DATE NOT NULL,
  installment_amount NUMERIC(18,2) NOT NULL CHECK (installment_amount > 0),
  paid_amount NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (paid_amount >= 0),
  outstanding_amount NUMERIC(18,2) NOT NULL CHECK (outstanding_amount >= 0),
  status VARCHAR(30) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','partial','paid','overdue','waived','cancelled')),
  paid_date DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(organization_id,loan_id,installment_number)
);
CREATE INDEX IF NOT EXISTS installments_org_loan_idx ON installments(organization_id,loan_id);
CREATE INDEX IF NOT EXISTS installments_org_due_idx ON installments(organization_id,due_date,status);

CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES branches(id) ON DELETE RESTRICT,
  member_id UUID NOT NULL REFERENCES members(id) ON DELETE RESTRICT,
  loan_id UUID NOT NULL REFERENCES loans(id) ON DELETE RESTRICT,
  payment_number VARCHAR(100) NOT NULL,
  amount NUMERIC(18,2) NOT NULL CHECK (amount > 0),
  payment_date TIMESTAMPTZ NOT NULL,
  payment_method VARCHAR(30) NOT NULL CHECK (payment_method IN ('cash','bkash','nagad','rocket','bank_transfer','cheque','other')),
  transaction_reference VARCHAR(255),
  bank_name VARCHAR(200),
  bank_account VARCHAR(100),
  collector_id UUID REFERENCES users(id),
  notes TEXT,
  status VARCHAR(30) NOT NULL DEFAULT 'posted' CHECK (status IN ('posted','cancelled','reversed')),
  idempotency_key VARCHAR(150),
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(organization_id,payment_number)
);
CREATE UNIQUE INDEX IF NOT EXISTS payments_org_idempotency_idx
  ON payments(organization_id,idempotency_key)
  WHERE idempotency_key IS NOT NULL;
CREATE INDEX IF NOT EXISTS payments_org_member_date_idx ON payments(organization_id,member_id,payment_date DESC);
CREATE INDEX IF NOT EXISTS payments_org_loan_date_idx ON payments(organization_id,loan_id,payment_date DESC);

CREATE TABLE IF NOT EXISTS payment_allocations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  payment_id UUID NOT NULL REFERENCES payments(id) ON DELETE RESTRICT,
  loan_id UUID NOT NULL REFERENCES loans(id) ON DELETE RESTRICT,
  installment_id UUID REFERENCES installments(id) ON DELETE RESTRICT,
  allocation_type VARCHAR(30) NOT NULL CHECK (allocation_type IN ('installment','advance','adjustment')),
  amount NUMERIC(18,2) NOT NULL CHECK (amount > 0),
  adjustment_for_allocation_id UUID REFERENCES payment_allocations(id) ON DELETE RESTRICT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS payment_allocations_org_payment_idx ON payment_allocations(organization_id,payment_id);
CREATE INDEX IF NOT EXISTS payment_allocations_org_installment_idx ON payment_allocations(organization_id,installment_id);

CREATE TABLE IF NOT EXISTS payment_receipts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  payment_id UUID NOT NULL REFERENCES payments(id) ON DELETE RESTRICT,
  receipt_number VARCHAR(100) NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'active' CHECK (status IN ('active','void')),
  issued_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  issued_by UUID REFERENCES users(id),
  UNIQUE(organization_id,receipt_number),
  UNIQUE(organization_id,payment_id)
);
CREATE INDEX IF NOT EXISTS payment_receipts_org_payment_idx ON payment_receipts(organization_id,payment_id);

CREATE TABLE IF NOT EXISTS organization_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  setting_key VARCHAR(150) NOT NULL,
  setting_value JSONB NOT NULL,
  updated_by UUID REFERENCES users(id),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(organization_id,setting_key)
);

CREATE TABLE IF NOT EXISTS password_resets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS password_resets_active_idx ON password_resets(token_hash,expires_at) WHERE used_at IS NULL;

-- Cross-table tenant integrity: child organization_id must match its parent.
-- PostgreSQL CHECK constraints cannot reference other rows, so these are enforced
-- in the application transaction layer in 11.P.6 and additionally by triggers there.

INSERT INTO schema_migrations(version)
VALUES ('002_core_domain')
ON CONFLICT(version) DO NOTHING;
