-- IMP V1 — Single Organization / Manual Loan Terms / Savings Defaults
-- The application no longer permits public organization registration.
-- The existing organization/user records remain the authoritative company.
ALTER TABLE loans
  ADD COLUMN IF NOT EXISTS savings_amount NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (savings_amount >= 0),
  ADD COLUMN IF NOT EXISTS deposit_amount NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (deposit_amount >= 0);

INSERT INTO schema_migrations(version)
VALUES ('028_single_org_manual_loan_savings')
ON CONFLICT(version) DO NOTHING;
