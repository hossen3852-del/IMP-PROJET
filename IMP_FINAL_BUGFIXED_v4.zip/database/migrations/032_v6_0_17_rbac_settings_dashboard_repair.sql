-- V6.0.17 final RBAC repair: guarantee core settings/dashboard permissions
-- for organization administrators and super administrators, even when older
-- migrations were already marked applied or roles were created earlier.

INSERT INTO permissions(code) VALUES
  ('settings.view'),
  ('settings.update'),
  ('dashboard.view'),
  ('dashboard.customize')
ON CONFLICT(code) DO NOTHING;

INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'organization_admin'
  AND p.code IN ('settings.view','settings.update','dashboard.view','dashboard.customize')
ON CONFLICT (role_id, permission_id) DO NOTHING;

INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'super_admin'
  AND p.code IN ('settings.view','settings.update','dashboard.view','dashboard.customize')
ON CONFLICT (role_id, permission_id) DO NOTHING;

INSERT INTO schema_migrations(version)
VALUES ('032_v6_0_17_rbac_settings_dashboard_repair')
ON CONFLICT(version) DO NOTHING;
