-- Automatic double-entry posting for core loan cash movements.
CREATE OR REPLACE FUNCTION imp_ensure_gl(p_org UUID) RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
 INSERT INTO accounting_accounts(organization_id,code,name,account_type) VALUES
 (p_org,'1000','Cash','asset'),(p_org,'1010','Bank / Digital Wallet','asset'),(p_org,'1200','Loan Receivable','asset'),
 (p_org,'4000','Interest Income','income'),(p_org,'4100','Penalty Income','income'),(p_org,'5000','Operating Expense','expense')
 ON CONFLICT(organization_id,code) DO NOTHING;
END; $$;

CREATE OR REPLACE FUNCTION imp_post_payment_gl() RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE debit_account UUID; receivable UUID; jid UUID;
BEGIN
 PERFORM imp_ensure_gl(NEW.organization_id);
 SELECT id INTO receivable FROM accounting_accounts WHERE organization_id=NEW.organization_id AND code='1200';
 SELECT id INTO debit_account FROM accounting_accounts WHERE organization_id=NEW.organization_id AND code=CASE WHEN NEW.payment_method IN ('cash') THEN '1000' ELSE '1010' END;
 INSERT INTO accounting_journal_entries(organization_id,branch_id,entry_date,reference_type,reference_id,description,posted_by)
 VALUES(NEW.organization_id,NEW.branch_id,NEW.payment_date::date,'payment',NEW.id,'Payment '||NEW.payment_number,NEW.created_by) RETURNING id INTO jid;
 INSERT INTO accounting_journal_lines(journal_id,account_id,debit,credit,description) VALUES(jid,debit_account,NEW.amount,0,'Payment received');
 INSERT INTO accounting_journal_lines(journal_id,account_id,debit,credit,description) VALUES(jid,receivable,0,NEW.amount,'Loan receivable reduction');
 RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS trg_payment_gl ON payments;
CREATE TRIGGER trg_payment_gl AFTER INSERT ON payments FOR EACH ROW WHEN (NEW.status='posted') EXECUTE FUNCTION imp_post_payment_gl();

CREATE OR REPLACE FUNCTION imp_post_loan_disbursement_gl() RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE cash_account UUID; receivable UUID; jid UUID;
BEGIN
 IF NEW.status='disbursed' AND OLD.status IS DISTINCT FROM 'disbursed' THEN
  PERFORM imp_ensure_gl(NEW.organization_id);
  SELECT id INTO cash_account FROM accounting_accounts WHERE organization_id=NEW.organization_id AND code='1000';
  SELECT id INTO receivable FROM accounting_accounts WHERE organization_id=NEW.organization_id AND code='1200';
  INSERT INTO accounting_journal_entries(organization_id,branch_id,entry_date,reference_type,reference_id,description,posted_by)
  VALUES(NEW.organization_id,NEW.branch_id,COALESCE(NEW.disbursed_at::date,CURRENT_DATE),'loan_disbursement',NEW.id,'Loan disbursement '||NEW.loan_number,NEW.approved_by) RETURNING id INTO jid;
  INSERT INTO accounting_journal_lines(journal_id,account_id,debit,credit,description) VALUES(jid,receivable,NEW.disbursed_amount,0,'Loan receivable created');
  INSERT INTO accounting_journal_lines(journal_id,account_id,debit,credit,description) VALUES(jid,cash_account,0,NEW.disbursed_amount,'Loan cash disbursed');
 END IF;
 RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS trg_loan_disbursement_gl ON loans;
CREATE TRIGGER trg_loan_disbursement_gl AFTER UPDATE OF status ON loans FOR EACH ROW EXECUTE FUNCTION imp_post_loan_disbursement_gl();

-- Keep imp_ensure_gl because the trigger functions call it at runtime.
INSERT INTO schema_migrations(version) VALUES ('022_financial_gl_integration') ON CONFLICT(version) DO NOTHING;
