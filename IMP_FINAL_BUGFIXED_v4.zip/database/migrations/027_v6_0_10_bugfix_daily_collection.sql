-- 027_v6_0_10_bugfix_daily_collection
--
-- 1) Idempotency keys for daily-collection savings deposits and expense
--    entries, matching the pattern payments already uses (migration 002),
--    so a mobile network retry / accidental double-submit of a daily
--    collection sheet cannot create duplicate money movements.
--
-- 2) A distinct 'written_off' loan status, separate from 'completed', so a
--    written-off loan (a recognized loss) can no longer be confused with a
--    loan that was genuinely repaid in full.

ALTER TABLE savings_transactions ADD COLUMN IF NOT EXISTS idempotency_key VARCHAR(150);

CREATE UNIQUE INDEX IF NOT EXISTS savings_transactions_org_idem_idx
  ON savings_transactions(organization_id, idempotency_key)
  WHERE idempotency_key IS NOT NULL;

ALTER TABLE expense_entries ADD COLUMN IF NOT EXISTS idempotency_key VARCHAR(150);

CREATE UNIQUE INDEX IF NOT EXISTS expense_entries_org_idem_idx
  ON expense_entries(organization_id, idempotency_key)
  WHERE idempotency_key IS NOT NULL;

ALTER TABLE loans DROP CONSTRAINT IF EXISTS loans_status_check;
ALTER TABLE loans ADD CONSTRAINT loans_status_check
  CHECK (status IN ('draft','pending','approved','disbursed','active','completed','written_off','cancelled','rejected'));

INSERT INTO schema_migrations(version)
VALUES ('027_v6_0_10_bugfix_daily_collection')
ON CONFLICT(version) DO NOTHING;
