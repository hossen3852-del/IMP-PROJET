-- 11.P.3 — Authentication API foundation.
-- User display name is server-owned; authentication no longer depends on browser storage.

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS full_name VARCHAR(200);

UPDATE users
SET full_name = COALESCE(NULLIF(full_name, ''), split_part(email, '@', 1))
WHERE full_name IS NULL OR full_name = '';

ALTER TABLE users
  ALTER COLUMN full_name SET NOT NULL;

-- Login is email-only, so an email must be globally unique to avoid ambiguous accounts.
CREATE UNIQUE INDEX IF NOT EXISTS users_lower_email_unique_idx
  ON users (lower(email));

-- Canonical authentication permissions for the current API surface.
INSERT INTO permissions(code) VALUES
  ('payment.create'),('payment.cancel'),('payment.reverse'),
  ('member.create'),('member.update'),('member.document.upload'),('member.document.delete'),
  ('loan.create'),('loan.update'),('loan.approve')
ON CONFLICT(code) DO NOTHING;

INSERT INTO role_permissions(role, permission_id)
SELECT 'organization_admin', id FROM permissions
WHERE code IN (
  'payment.create','payment.cancel','payment.reverse',
  'member.create','member.update','member.document.upload','member.document.delete',
  'loan.create','loan.update','loan.approve'
)
ON CONFLICT DO NOTHING;

INSERT INTO role_permissions(role, permission_id)
SELECT 'super_admin', id FROM permissions
ON CONFLICT DO NOTHING;

INSERT INTO schema_migrations(version)
VALUES ('003_auth_api')
ON CONFLICT(version) DO NOTHING;
