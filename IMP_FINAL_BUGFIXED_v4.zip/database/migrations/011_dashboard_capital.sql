-- 11.P.15 — Dashboard UI + Organization Settings Customization
-- Additive migration only. No existing table, column or constraint is altered
-- or dropped. Financial source of truth stays in PostgreSQL; nothing here is
-- computed or stored client-side.
--
-- Adds:
--   1. capital_entries      — general ledger for opening capital / admission
--                              fee / insurance / capital in / adjustment /
--                              withdrawal postings (organization-scoped).
--   2. New RBAC permissions — capital.view, capital.manage, dashboard.customize.
--   3. Grants for the new permissions on existing organizations' default
--      roles (organization_admin, accountant), and updates the
--      create_default_org_rbac() factory so every organization created from
--      now on gets the same grants automatically.
--
-- Dashboard/Settings customization itself (KPI show/hide, order, sections)
-- reuses the existing organization_settings(organization_id, setting_key,
-- setting_value) table added in 002_core_domain.sql — no new table needed.

CREATE TABLE IF NOT EXISTS capital_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES branches(id) ON DELETE SET NULL,
  entry_type VARCHAR(30) NOT NULL CHECK (entry_type IN (
    'capital_in', 'capital_adjustment', 'capital_withdrawal',
    'admission_fee', 'insurance'
  )),
  amount NUMERIC(18,2) NOT NULL CHECK (amount <> 0),
  entry_date DATE NOT NULL,
  description TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  -- Only capital_adjustment is allowed to be negative (a correction). All
  -- other entry types must be posted as positive amounts; capital_withdrawal
  -- is subtracted by the application/query layer, never stored negative.
  CONSTRAINT capital_entries_sign_ck CHECK (
    entry_type = 'capital_adjustment' OR amount > 0
  )
);
CREATE INDEX IF NOT EXISTS capital_entries_org_date_idx
  ON capital_entries(organization_id, entry_date DESC);
CREATE INDEX IF NOT EXISTS capital_entries_org_type_idx
  ON capital_entries(organization_id, entry_type);

-- New canonical permissions.
INSERT INTO permissions(code) VALUES
 ('capital.view'),
 ('capital.manage'),
 ('dashboard.customize')
ON CONFLICT(code) DO NOTHING;

-- Grant the new permissions to already-existing organizations' default roles.
-- organization_admin gets full capital + dashboard-customize access.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id
FROM roles r
CROSS JOIN permissions p
WHERE r.is_system = FALSE
  AND r.code = 'organization_admin'
  AND p.code IN ('capital.view','capital.manage','dashboard.customize')
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- accountant gets capital.view (financial visibility) but not manage/customize.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id
FROM roles r
CROSS JOIN permissions p
WHERE r.is_system = FALSE
  AND r.code = 'accountant'
  AND p.code IN ('capital.view')
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- super_admin (global system role) already has every permission granted via
-- its CROSS JOIN in 005_rbac_api.sql; re-run that grant so the three new
-- permission codes are included for it too.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'super_admin' AND r.is_system = TRUE
  AND p.code IN ('capital.view','capital.manage','dashboard.customize')
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- Update the org-creation RBAC factory so future organizations receive the
-- same grants automatically (branch_manager/collector/viewer are
-- intentionally left without capital access, matching the RBAC policy in
-- the handoff spec: capital configuration is admin/accountant territory).
CREATE OR REPLACE FUNCTION create_default_org_rbac(p_organization_id UUID)
RETURNS VOID
LANGUAGE plpgsql
AS $$
DECLARE
  role_record RECORD;
BEGIN
  INSERT INTO roles(organization_id,code,name,description,is_system,is_protected)
  VALUES
    (p_organization_id,'organization_admin','Organization Admin','Full organization administration',FALSE,TRUE),
    (p_organization_id,'branch_manager','Branch Manager','Branch-level operational management',FALSE,FALSE),
    (p_organization_id,'collector','Collector','Collection and payment operations',FALSE,FALSE),
    (p_organization_id,'accountant','Accountant','Financial and payment operations',FALSE,FALSE),
    (p_organization_id,'viewer','Viewer','Read-only organization access',FALSE,FALSE)
  ON CONFLICT (organization_id,code) WHERE is_system=FALSE DO NOTHING;

  FOR role_record IN
    SELECT id,code FROM roles
    WHERE organization_id=p_organization_id AND is_system=FALSE
  LOOP
    INSERT INTO role_permissions(role,permission_id,role_id)
    SELECT role_record.code,p.id,role_record.id
    FROM permissions p
    WHERE p.code = ANY(
      CASE role_record.code
        WHEN 'organization_admin' THEN ARRAY[
          'dashboard.view','dashboard.customize',
          'organization.view','organization.update',
          'branch.view','branch.create','branch.update','branch.delete',
          'user.view','user.create','user.update','user.delete',
          'role.view','role.create','role.update','role.delete','role.manage',
          'permission.view','settings.view','settings.update',
          'member.view','member.create','member.update','member.delete',
          'member.status.update','member.financial.update',
          'member.document.upload','member.document.delete',
          'loan.view','loan.create','loan.update','loan.delete','loan.approve',
          'loan.status.update','loan.financial.update',
          'loan.payment.create','loan.payment.update','loan.payment.delete','loan.schedule.update',
          'payment.view','payment.create','payment.cancel','payment.reverse',
          'capital.view','capital.manage'
        ]
        WHEN 'branch_manager' THEN ARRAY[
          'dashboard.view','branch.view','user.view','user.create','user.update',
          'settings.view','member.view','member.create','member.update',
          'member.status.update','member.financial.update','member.document.upload',
          'loan.view','loan.create','loan.update','loan.approve','loan.status.update',
          'loan.financial.update','loan.payment.create','loan.schedule.update'
        ]
        WHEN 'collector' THEN ARRAY[
          'dashboard.view','member.view','loan.view','payment.view','payment.create','loan.payment.create'
        ]
        WHEN 'accountant' THEN ARRAY[
          'dashboard.view','member.view','member.financial.update','loan.view',
          'loan.financial.update','payment.view','payment.create','loan.payment.create',
          'loan.payment.update','capital.view'
        ]
        ELSE ARRAY[
          'dashboard.view','organization.view','branch.view','user.view',
          'member.view','loan.view','payment.view'
        ]
      END::VARCHAR[]
    )
    ON CONFLICT (role_id,permission_id) DO NOTHING;
  END LOOP;
END;
$$;

INSERT INTO schema_migrations(version)
VALUES ('011_dashboard_capital')
ON CONFLICT(version) DO NOTHING;
