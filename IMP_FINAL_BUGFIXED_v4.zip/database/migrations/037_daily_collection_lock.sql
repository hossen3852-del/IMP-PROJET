-- Bugfix: the "once per day per frequency" daily-collection guard
-- (POST /collections/daily) checked for a prior closure by querying
-- audit_logs at the START of the request, then only wrote the closure
-- marker to audit_logs at the END, after every entry in the batch (up to
-- 500) had been processed one by one. Neither step was backed by a unique
-- constraint or a lock, so two concurrent submissions for the same
-- organization/branch/date/frequency (e.g. a field officer's app retries
-- after a network timeout while the first request is still processing)
-- could both pass the initial check and both process the full batch —
-- duplicating every member's collection for that day, protected only by
-- per-row idempotency keys that are not guaranteed to be stable across a
-- page reload / resubmission.
--
-- This adds a real table with a unique constraint on
-- (organization_id, branch_key, collection_date, frequency). The slot is
-- now reserved with a single atomic INSERT before any entries are
-- processed: whichever concurrent request's INSERT wins holds the slot for
-- the rest of the batch; the other is rejected immediately. If the batch
-- that won ends up with zero successful entries, its row is deleted so a
-- genuine retry is still possible.

CREATE TABLE IF NOT EXISTS daily_collection_locks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  branch_key TEXT NOT NULL DEFAULT '',
  collection_date DATE NOT NULL,
  frequency VARCHAR(20) NOT NULL,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS daily_collection_locks_uidx
  ON daily_collection_locks(organization_id, branch_key, collection_date, frequency);

INSERT INTO schema_migrations(version) VALUES ('037_daily_collection_lock')
ON CONFLICT(version) DO NOTHING;
