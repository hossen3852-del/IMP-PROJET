-- 11.P.5 — Canonical PostgreSQL RBAC
-- Roles are tenant-scoped unless is_system=TRUE. Permissions are global.
-- role_permissions is keyed by role_id; users.role_id is authoritative.

CREATE TABLE IF NOT EXISTS roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  code VARCHAR(80) NOT NULL,
  name VARCHAR(120) NOT NULL,
  description VARCHAR(500),
  is_system BOOLEAN NOT NULL DEFAULT FALSE,
  is_protected BOOLEAN NOT NULL DEFAULT FALSE,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT roles_scope_ck CHECK (
    (is_system = TRUE AND organization_id IS NULL)
    OR (is_system = FALSE AND organization_id IS NOT NULL)
  )
);

CREATE UNIQUE INDEX IF NOT EXISTS roles_global_code_uidx
  ON roles(code) WHERE is_system = TRUE;
CREATE UNIQUE INDEX IF NOT EXISTS roles_org_code_uidx
  ON roles(organization_id,code) WHERE is_system = FALSE;
CREATE INDEX IF NOT EXISTS roles_org_idx ON roles(organization_id);

ALTER TABLE users ADD COLUMN IF NOT EXISTS role_id UUID;

-- Canonical registry. Legacy aliases such as *.edit are intentionally not seeded.
INSERT INTO permissions(code) VALUES
 ('dashboard.view'),
 ('organization.view'),('organization.update'),
 ('branch.view'),('branch.create'),('branch.update'),('branch.delete'),
 ('user.view'),('user.create'),('user.update'),('user.delete'),
 ('role.view'),('role.create'),('role.update'),('role.delete'),('role.manage'),
 ('permission.view'),
 ('settings.view'),('settings.update'),
 ('member.view'),('member.create'),('member.update'),('member.delete'),
 ('member.status.update'),('member.financial.update'),
 ('member.document.upload'),('member.document.delete'),
 ('loan.view'),('loan.create'),('loan.update'),('loan.delete'),
 ('loan.approve'),('loan.status.update'),('loan.financial.update'),
 ('loan.payment.create'),('loan.payment.update'),('loan.payment.delete'),
 ('loan.schedule.update'),
 ('payment.view'),('payment.create'),('payment.cancel'),('payment.reverse')
ON CONFLICT(code) DO NOTHING;

-- Replace the old role-string permission relationship with role_id.
-- Existing rows are legacy role-string grants. They are discarded and rebuilt
-- from the canonical policy below so tenant roles cannot collide by code.
ALTER TABLE role_permissions ADD COLUMN IF NOT EXISTS role_id UUID;
DELETE FROM role_permissions;
ALTER TABLE role_permissions DROP CONSTRAINT IF EXISTS role_permissions_pkey;
ALTER TABLE role_permissions DROP CONSTRAINT IF EXISTS role_permissions_role_id_fk;
ALTER TABLE role_permissions
  ADD CONSTRAINT role_permissions_role_id_fk
  FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE;
ALTER TABLE role_permissions ALTER COLUMN role_id SET NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS role_permissions_role_permission_uidx
  ON role_permissions(role_id,permission_id);

-- Legacy role text is retained temporarily for compatibility but is never
-- consulted by authorization.
ALTER TABLE role_permissions ALTER COLUMN role DROP NOT NULL;

-- Default organization RBAC factory. It is idempotent and is also called
-- transactionally by registration for every newly-created organization.
CREATE OR REPLACE FUNCTION create_default_org_rbac(p_organization_id UUID)
RETURNS VOID
LANGUAGE plpgsql
AS $$
DECLARE
  role_record RECORD;
BEGIN
  INSERT INTO roles(organization_id,code,name,description,is_system,is_protected)
  VALUES
    (p_organization_id,'organization_admin','Organization Admin','Full organization administration',FALSE,TRUE),
    (p_organization_id,'branch_manager','Branch Manager','Branch-level operational management',FALSE,FALSE),
    (p_organization_id,'collector','Collector','Collection and payment operations',FALSE,FALSE),
    (p_organization_id,'accountant','Accountant','Financial and payment operations',FALSE,FALSE),
    (p_organization_id,'viewer','Viewer','Read-only organization access',FALSE,FALSE)
  ON CONFLICT (organization_id,code) WHERE is_system=FALSE DO NOTHING;

  FOR role_record IN
    SELECT id,code FROM roles
    WHERE organization_id=p_organization_id AND is_system=FALSE
  LOOP
    INSERT INTO role_permissions(role,permission_id,role_id)
    SELECT role_record.code,p.id,role_record.id
    FROM permissions p
    WHERE p.code = ANY(
      CASE role_record.code
        WHEN 'organization_admin' THEN ARRAY[
          'dashboard.view','organization.view','organization.update',
          'branch.view','branch.create','branch.update','branch.delete',
          'user.view','user.create','user.update','user.delete',
          'role.view','role.create','role.update','role.delete','role.manage',
          'permission.view','settings.view','settings.update',
          'member.view','member.create','member.update','member.delete',
          'member.status.update','member.financial.update',
          'member.document.upload','member.document.delete',
          'loan.view','loan.create','loan.update','loan.delete','loan.approve',
          'loan.status.update','loan.financial.update',
          'loan.payment.create','loan.payment.update','loan.payment.delete','loan.schedule.update',
          'payment.view','payment.create','payment.cancel','payment.reverse'
        ]
        WHEN 'branch_manager' THEN ARRAY[
          'dashboard.view','branch.view','user.view','user.create','user.update',
          'settings.view','member.view','member.create','member.update',
          'member.status.update','member.financial.update','member.document.upload',
          'loan.view','loan.create','loan.update','loan.approve','loan.status.update',
          'loan.financial.update','loan.payment.create','loan.schedule.update'
        ]
        WHEN 'collector' THEN ARRAY[
          'dashboard.view','member.view','loan.view','payment.view','payment.create','loan.payment.create'
        ]
        WHEN 'accountant' THEN ARRAY[
          'dashboard.view','member.view','member.financial.update','loan.view',
          'loan.financial.update','payment.view','payment.create','loan.payment.create',
          'loan.payment.update'
        ]
        ELSE ARRAY[
          'dashboard.view','organization.view','branch.view','user.view',
          'member.view','loan.view','payment.view'
        ]
      END::VARCHAR[]
    )
    ON CONFLICT (role_id,permission_id) DO NOTHING;
  END LOOP;
END;
$$;

SELECT create_default_org_rbac(id) FROM organizations;

-- One global protected super_admin role.
INSERT INTO roles(organization_id,code,name,description,is_system,is_protected)
VALUES (NULL,'super_admin','Super Admin','System-wide administration',TRUE,TRUE)
ON CONFLICT DO NOTHING;

INSERT INTO role_permissions(role,permission_id,role_id)
SELECT r.code,p.id,r.id
FROM roles r CROSS JOIN permissions p
WHERE r.code='super_admin' AND r.is_system=TRUE
ON CONFLICT (role_id,permission_id) DO NOTHING;

-- Existing users are migrated to the scoped role matching their legacy role.
UPDATE users u
SET role_id = r.id
FROM roles r
WHERE u.role_id IS NULL
  AND r.code=u.role
  AND (
    (r.is_system=TRUE AND r.organization_id IS NULL)
    OR (r.is_system=FALSE AND r.organization_id=u.organization_id)
  );

-- Unknown/legacy roles are safely mapped to viewer instead of granting access.
UPDATE users u
SET role_id = r.id
FROM roles r
WHERE u.role_id IS NULL
  AND r.code='viewer'
  AND r.organization_id=u.organization_id;

ALTER TABLE users
  ADD CONSTRAINT users_role_id_fk
  FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE RESTRICT;

CREATE INDEX IF NOT EXISTS users_role_idx ON users(role_id);

-- The old role text remains for compatibility; role_id is authoritative.
INSERT INTO schema_migrations(version)
VALUES ('005_rbac_api')
ON CONFLICT(version) DO NOTHING;
