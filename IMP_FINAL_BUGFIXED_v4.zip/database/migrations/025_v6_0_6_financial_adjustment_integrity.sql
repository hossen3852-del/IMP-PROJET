-- V6.0.6 financial adjustment integrity hardening.
-- Reconciles waiver/write-off against installments and adds GL support for adjustments.

INSERT INTO accounting_accounts(organization_id,code,name,account_type)
SELECT id,'5010','Loan Waiver / Write-off Expense','expense'
FROM organizations
ON CONFLICT(organization_id,code) DO NOTHING;

CREATE OR REPLACE FUNCTION imp_ensure_gl(p_org UUID) RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
 INSERT INTO accounting_accounts(organization_id,code,name,account_type) VALUES
 (p_org,'1000','Cash','asset'),
 (p_org,'1010','Bank / Digital Wallet','asset'),
 (p_org,'1200','Loan Receivable','asset'),
 (p_org,'4000','Interest Income','income'),
 (p_org,'4100','Penalty Income','income'),
 (p_org,'5000','Operating Expense','expense'),
 (p_org,'5010','Loan Waiver / Write-off Expense','expense')
 ON CONFLICT(organization_id,code) DO NOTHING;
END; $$;

INSERT INTO schema_migrations(version)
VALUES ('025_v6_0_6_financial_adjustment_integrity')
ON CONFLICT(version) DO NOTHING;
