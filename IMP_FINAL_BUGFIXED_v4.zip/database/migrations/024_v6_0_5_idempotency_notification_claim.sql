-- V6.0.5 final hardening: loan-adjustment idempotency and atomic notification claiming.

ALTER TABLE loan_adjustments
  ADD COLUMN IF NOT EXISTS idempotency_key VARCHAR(150);

CREATE UNIQUE INDEX IF NOT EXISTS loan_adjustments_org_idempotency_idx
  ON loan_adjustments(organization_id, idempotency_key)
  WHERE idempotency_key IS NOT NULL;

ALTER TABLE notification_outbox
  DROP CONSTRAINT IF EXISTS notification_outbox_status_check;

ALTER TABLE notification_outbox
  ADD CONSTRAINT notification_outbox_status_check
  CHECK (status IN ('queued','processing','sent','failed','cancelled'));

CREATE INDEX IF NOT EXISTS notification_outbox_processing_idx
  ON notification_outbox(status, updated_at);

INSERT INTO schema_migrations(version)
VALUES ('024_v6_0_5_idempotency_notification_claim')
ON CONFLICT(version) DO NOTHING;
