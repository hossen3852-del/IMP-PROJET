-- Commercial Expansion Pack v1
-- Mobile/offline sync, notification outbox, digital passbook, advanced loan products,
-- loan adjustments, MRA-oriented reports, operational reports and double-entry GL.

ALTER TABLE loans ADD COLUMN IF NOT EXISTS product_id UUID;

CREATE TABLE IF NOT EXISTS loan_products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  code VARCHAR(80) NOT NULL,
  name VARCHAR(160) NOT NULL,
  product_type VARCHAR(40) NOT NULL DEFAULT 'flat',
  interest_method VARCHAR(40) NOT NULL DEFAULT 'flat',
  interest_rate NUMERIC(10,4) NOT NULL DEFAULT 0 CHECK (interest_rate >= 0),
  min_amount NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (min_amount >= 0),
  max_amount NUMERIC(18,2) CHECK (max_amount IS NULL OR max_amount >= min_amount),
  min_installments INTEGER NOT NULL DEFAULT 1 CHECK (min_installments > 0),
  max_installments INTEGER CHECK (max_installments IS NULL OR max_installments >= min_installments),
  frequency VARCHAR(30) NOT NULL DEFAULT 'monthly',
  grace_days INTEGER NOT NULL DEFAULT 0 CHECK (grace_days >= 0),
  penalty_rate NUMERIC(10,4) NOT NULL DEFAULT 0 CHECK (penalty_rate >= 0),
  penalty_type VARCHAR(20) NOT NULL DEFAULT 'percent' CHECK (penalty_type IN ('percent','fixed')),
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(organization_id, code)
);
ALTER TABLE loans DROP CONSTRAINT IF EXISTS loans_product_id_fk;
ALTER TABLE loans ADD CONSTRAINT loans_product_id_fk FOREIGN KEY(product_id) REFERENCES loan_products(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS loan_products_org_active_idx ON loan_products(organization_id, active);
CREATE INDEX IF NOT EXISTS loans_product_idx ON loans(product_id);

CREATE TABLE IF NOT EXISTS loan_adjustments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES branches(id) ON DELETE RESTRICT,
  loan_id UUID NOT NULL REFERENCES loans(id) ON DELETE RESTRICT,
  member_id UUID NOT NULL REFERENCES members(id) ON DELETE RESTRICT,
  adjustment_type VARCHAR(30) NOT NULL CHECK (adjustment_type IN ('penalty','waiver','reschedule','write_off','partial_payment')),
  amount NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (amount >= 0),
  effective_date DATE NOT NULL DEFAULT CURRENT_DATE,
  reason TEXT NOT NULL,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS loan_adjustments_org_loan_idx ON loan_adjustments(organization_id, loan_id, effective_date DESC);

CREATE TABLE IF NOT EXISTS notification_outbox (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  member_id UUID REFERENCES members(id) ON DELETE SET NULL,
  channel VARCHAR(20) NOT NULL CHECK (channel IN ('sms','whatsapp')),
  recipient VARCHAR(100) NOT NULL,
  template_code VARCHAR(100) NOT NULL,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(20) NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','sent','failed','cancelled')),
  provider_message_id VARCHAR(255),
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT,
  scheduled_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  sent_at TIMESTAMPTZ,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS notification_outbox_org_status_idx ON notification_outbox(organization_id,status,scheduled_at);

CREATE TABLE IF NOT EXISTS field_sync_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES branches(id) ON DELETE RESTRICT,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  client_event_id VARCHAR(120) NOT NULL,
  event_type VARCHAR(60) NOT NULL,
  entity_type VARCHAR(60) NOT NULL,
  entity_id UUID,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(20) NOT NULL DEFAULT 'accepted' CHECK (status IN ('accepted','rejected','duplicate')),
  error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(organization_id,user_id,client_event_id)
);
CREATE INDEX IF NOT EXISTS field_sync_org_user_created_idx ON field_sync_events(organization_id,user_id,created_at DESC);

CREATE TABLE IF NOT EXISTS accounting_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  code VARCHAR(40) NOT NULL,
  name VARCHAR(160) NOT NULL,
  account_type VARCHAR(30) NOT NULL CHECK (account_type IN ('asset','liability','equity','income','expense')),
  parent_id UUID REFERENCES accounting_accounts(id) ON DELETE SET NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(organization_id,code)
);

CREATE TABLE IF NOT EXISTS accounting_journal_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES branches(id) ON DELETE RESTRICT,
  entry_date DATE NOT NULL DEFAULT CURRENT_DATE,
  reference_type VARCHAR(60),
  reference_id UUID,
  description TEXT NOT NULL,
  posted_by UUID REFERENCES users(id),
  posted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS accounting_journal_lines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  journal_id UUID NOT NULL REFERENCES accounting_journal_entries(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounting_accounts(id) ON DELETE RESTRICT,
  debit NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (debit >= 0),
  credit NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (credit >= 0),
  description TEXT,
  CHECK ((debit > 0 AND credit = 0) OR (credit > 0 AND debit = 0))
);
CREATE INDEX IF NOT EXISTS accounting_journal_org_date_idx ON accounting_journal_entries(organization_id,entry_date DESC);
CREATE INDEX IF NOT EXISTS accounting_lines_account_idx ON accounting_journal_lines(account_id);

CREATE TABLE IF NOT EXISTS report_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id),
  report_code VARCHAR(100) NOT NULL,
  filters JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(20) NOT NULL DEFAULT 'completed' CHECK (status IN ('queued','running','completed','failed')),
  result JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ
);

INSERT INTO permissions(code) VALUES
 ('field.sync'),('field.route.view'),
 ('notification.view'),('notification.send'),
 ('passbook.view'),
 ('loan.product.view'),('loan.product.manage'),('loan.adjustment.view'),('loan.adjustment.manage'),
 ('report.view'),('report.mra.view'),
 ('accounting.view'),('accounting.manage'),
 ('ops.view')
ON CONFLICT(code) DO NOTHING;

CREATE OR REPLACE FUNCTION seed_expansion_permissions(p_org UUID) RETURNS VOID LANGUAGE plpgsql AS $$
DECLARE r RECORD;
BEGIN
  FOR r IN SELECT id,code FROM roles WHERE organization_id=p_org AND is_system=FALSE LOOP
    INSERT INTO role_permissions(role,permission_id,role_id)
    SELECT r.code,p.id,r.id FROM permissions p
    WHERE p.code = ANY(CASE r.code
      WHEN 'organization_admin' THEN ARRAY['field.sync','field.route.view','notification.view','notification.send','passbook.view','loan.product.view','loan.product.manage','loan.adjustment.view','loan.adjustment.manage','report.view','report.mra.view','accounting.view','accounting.manage','ops.view']
      WHEN 'branch_manager' THEN ARRAY['field.sync','field.route.view','notification.view','notification.send','passbook.view','loan.product.view','loan.product.manage','loan.adjustment.view','loan.adjustment.manage','report.view','report.mra.view','accounting.view']
      WHEN 'collector' THEN ARRAY['field.sync','field.route.view','notification.view','passbook.view','loan.product.view','loan.adjustment.view','report.view']
      WHEN 'accountant' THEN ARRAY['notification.view','passbook.view','loan.product.view','loan.adjustment.view','report.view','report.mra.view','accounting.view','accounting.manage']
      ELSE ARRAY['passbook.view','loan.product.view','report.view']
    END::VARCHAR[])
    ON CONFLICT(role_id,permission_id) DO NOTHING;
  END LOOP;
END; $$;
SELECT seed_expansion_permissions(id) FROM organizations;
DROP FUNCTION seed_expansion_permissions(UUID);

INSERT INTO role_permissions(role,permission_id,role_id)
SELECT r.code,p.id,r.id FROM roles r CROSS JOIN permissions p
WHERE r.code='super_admin' AND r.is_system=TRUE
  AND p.code IN ('field.sync','field.route.view','notification.view','notification.send','passbook.view','loan.product.view','loan.product.manage','loan.adjustment.view','loan.adjustment.manage','report.view','report.mra.view','accounting.view','accounting.manage','ops.view')
ON CONFLICT(role_id,permission_id) DO NOTHING;

CREATE OR REPLACE FUNCTION ensure_default_gl_accounts(p_org UUID) RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO accounting_accounts(organization_id,code,name,account_type) VALUES
    (p_org,'1000','Cash','asset'),
    (p_org,'1010','Bank / Digital Wallet','asset'),
    (p_org,'1200','Loan Receivable','asset'),
    (p_org,'4000','Interest Income','income'),
    (p_org,'4100','Penalty Income','income'),
    (p_org,'5000','Operating Expense','expense')
  ON CONFLICT(organization_id,code) DO NOTHING;
END; $$;
SELECT ensure_default_gl_accounts(id) FROM organizations;
DROP FUNCTION ensure_default_gl_accounts(UUID);

INSERT INTO schema_migrations(version) VALUES ('021_commercial_expansion') ON CONFLICT(version) DO NOTHING;
