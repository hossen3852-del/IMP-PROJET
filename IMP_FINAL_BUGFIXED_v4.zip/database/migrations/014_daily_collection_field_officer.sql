-- 11.P.16 — Daily Collection (Field Officer route sheet) + member-wise Insurance ledger
--
-- 1. member_insurance_transactions: per-member insurance premium/claim ledger,
--    mirroring savings_transactions. Existing capital_entries('insurance',
--    'insurance_new','insurance_claim') rows remain valid for manual/backdated
--    organization-level adjustments; this table adds member-level granularity
--    so a member's own insurance history can be shown (loan-profile, member
--    profile, daily collection route sheet). The dashboard "মোট বীমা" KPI sums
--    BOTH sources (see server/routes/capital.js).
-- 2. New permissions: insurance.view, insurance.manage, collection.create.
-- 3. New 'field_officer' role (the Add User form already offers this role in
--    the UI — it was never backed by a real RBAC role; this migration makes
--    it real) with route-sheet / daily-collection level access.

CREATE TABLE IF NOT EXISTS member_insurance_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  member_id UUID NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES branches(id) ON DELETE SET NULL,
  loan_id UUID REFERENCES loans(id) ON DELETE SET NULL,
  transaction_type VARCHAR(30) NOT NULL CHECK (transaction_type IN ('premium','claim')),
  amount NUMERIC(18,2) NOT NULL CHECK (amount > 0),
  transaction_date DATE NOT NULL,
  description TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS member_insurance_org_member_idx ON member_insurance_transactions(organization_id,member_id);
CREATE INDEX IF NOT EXISTS member_insurance_org_date_idx ON member_insurance_transactions(organization_id,transaction_date DESC);

-- ---------------------------------------------------------------------
-- New permissions.
-- ---------------------------------------------------------------------
INSERT INTO permissions(code) VALUES
 ('insurance.view'), ('insurance.manage'),
 ('collection.create')
ON CONFLICT(code) DO NOTHING;

-- organization_admin: everything.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id FROM roles r CROSS JOIN permissions p
WHERE r.is_system = FALSE AND r.code = 'organization_admin'
  AND p.code IN ('insurance.view','insurance.manage','collection.create')
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- branch_manager: full insurance + can also run daily collection.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id FROM roles r CROSS JOIN permissions p
WHERE r.is_system = FALSE AND r.code = 'branch_manager'
  AND p.code IN ('insurance.view','insurance.manage','collection.create')
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- accountant: view + manage insurance (financial ledger owner).
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id FROM roles r CROSS JOIN permissions p
WHERE r.is_system = FALSE AND r.code = 'accountant'
  AND p.code IN ('insurance.view','insurance.manage')
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- collector: field-level collection (installment + savings + insurance in one sheet).
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id FROM roles r CROSS JOIN permissions p
WHERE r.is_system = FALSE AND r.code = 'collector'
  AND p.code IN ('insurance.view','insurance.manage','collection.create')
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- super_admin: everything.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id FROM roles r CROSS JOIN permissions p
WHERE r.code = 'super_admin' AND r.is_system = TRUE
  AND p.code IN ('insurance.view','insurance.manage','collection.create')
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- ---------------------------------------------------------------------
-- 'field_officer' role: add to every existing organization, and to the
-- default factory for future organizations.
-- ---------------------------------------------------------------------
INSERT INTO roles(organization_id,code,name,description,is_system,is_protected)
SELECT o.id,'field_officer','Field Officer','Daily member visits: loan installment, savings and insurance collection',FALSE,FALSE
FROM organizations o
ON CONFLICT (organization_id,code) WHERE is_system=FALSE DO NOTHING;

INSERT INTO role_permissions(role,permission_id,role_id)
SELECT r.code,p.id,r.id
FROM roles r CROSS JOIN permissions p
WHERE r.is_system = FALSE AND r.code = 'field_officer'
  AND p.code IN (
    'dashboard.view','member.view','loan.view','payment.view','payment.create',
    'loan.payment.create','savings.view','savings.manage',
    'insurance.view','insurance.manage','collection.create'
  )
ON CONFLICT (role_id, permission_id) DO NOTHING;

CREATE OR REPLACE FUNCTION create_default_org_rbac(p_organization_id UUID)
RETURNS VOID
LANGUAGE plpgsql
AS $$
DECLARE
  role_record RECORD;
BEGIN
  INSERT INTO roles(organization_id,code,name,description,is_system,is_protected)
  VALUES
    (p_organization_id,'organization_admin','Organization Admin','Full organization administration',FALSE,TRUE),
    (p_organization_id,'branch_manager','Branch Manager','Branch-level operational management',FALSE,FALSE),
    (p_organization_id,'collector','Collector','Collection and payment operations',FALSE,FALSE),
    (p_organization_id,'accountant','Accountant','Financial and payment operations',FALSE,FALSE),
    (p_organization_id,'field_officer','Field Officer','Daily member visits: loan installment, savings and insurance collection',FALSE,FALSE),
    (p_organization_id,'viewer','Viewer','Read-only organization access',FALSE,FALSE)
  ON CONFLICT (organization_id,code) WHERE is_system=FALSE DO NOTHING;

  FOR role_record IN
    SELECT id,code FROM roles
    WHERE organization_id=p_organization_id AND is_system=FALSE
  LOOP
    INSERT INTO role_permissions(role,permission_id,role_id)
    SELECT role_record.code,p.id,role_record.id
    FROM permissions p
    WHERE p.code = ANY(
      CASE role_record.code
        WHEN 'organization_admin' THEN ARRAY[
          'dashboard.view','dashboard.customize',
          'organization.view','organization.update',
          'branch.view','branch.create','branch.update','branch.delete',
          'user.view','user.create','user.update','user.delete',
          'role.view','role.create','role.update','role.delete','role.manage',
          'permission.view','settings.view','settings.update',
          'member.view','member.create','member.update','member.delete',
          'member.status.update','member.financial.update',
          'member.document.upload','member.document.delete',
          'loan.view','loan.create','loan.update','loan.delete','loan.approve',
          'loan.status.update','loan.financial.update',
          'loan.payment.create','loan.payment.update','loan.payment.delete','loan.schedule.update',
          'payment.view','payment.create','payment.cancel','payment.reverse',
          'capital.view','capital.manage',
          'savings.view','savings.manage','expense.view','expense.manage',
          'insurance.view','insurance.manage','collection.create'
        ]
        WHEN 'branch_manager' THEN ARRAY[
          'dashboard.view','branch.view','user.view','user.create','user.update',
          'settings.view','member.view','member.create','member.update',
          'member.status.update','member.financial.update','member.document.upload',
          'loan.view','loan.create','loan.update','loan.approve','loan.status.update',
          'loan.financial.update','loan.payment.create','loan.schedule.update',
          'savings.view','savings.manage','expense.view',
          'insurance.view','insurance.manage','collection.create'
        ]
        WHEN 'collector' THEN ARRAY[
          'dashboard.view','member.view','loan.view','payment.view','payment.create',
          'loan.payment.create','savings.view','savings.manage',
          'insurance.view','insurance.manage','collection.create'
        ]
        WHEN 'field_officer' THEN ARRAY[
          'dashboard.view','member.view','loan.view','payment.view','payment.create',
          'loan.payment.create','savings.view','savings.manage',
          'insurance.view','insurance.manage','collection.create'
        ]
        WHEN 'accountant' THEN ARRAY[
          'dashboard.view','member.view','member.financial.update','loan.view',
          'loan.financial.update','payment.view','payment.create','loan.payment.create',
          'loan.payment.update','capital.view',
          'savings.view','savings.manage','expense.view','expense.manage',
          'insurance.view','insurance.manage'
        ]
        ELSE ARRAY[
          'dashboard.view','organization.view','branch.view','user.view',
          'member.view','loan.view','payment.view'
        ]
      END::VARCHAR[]
    )
    ON CONFLICT (role_id,permission_id) DO NOTHING;
  END LOOP;
END;
$$;

INSERT INTO schema_migrations(version) VALUES ('014_daily_collection_field_officer') ON CONFLICT(version) DO NOTHING;
