-- V6.0.18 hardening: loan-creation idempotency (DB-level).
-- Previously, loan-create idempotency was checked only against audit_logs
-- with no unique constraint or row lock behind it, so two concurrent
-- double-submit requests with the same Idempotency-Key could both create a
-- loan. This brings loans in line with the pattern already used for
-- payments, loan_adjustments, savings_transactions and expense_entries.

ALTER TABLE loans
  ADD COLUMN IF NOT EXISTS idempotency_key VARCHAR(150);

CREATE UNIQUE INDEX IF NOT EXISTS loans_org_idempotency_idx
  ON loans(organization_id, idempotency_key)
  WHERE idempotency_key IS NOT NULL;

INSERT INTO schema_migrations(version)
VALUES ('035_loan_idempotency')
ON CONFLICT(version) DO NOTHING;
