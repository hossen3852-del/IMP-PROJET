-- 11.P.7 — Member API + Frontend Member Cut-over
-- The server/API becomes authoritative for member data. Existing member child
-- tables remain normalized; legacy prototype-only nested state is stored in
-- JSONB columns only where the current UI has no normalized table yet.

ALTER TABLE members ADD COLUMN IF NOT EXISTS personal_info JSONB NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE members ADD COLUMN IF NOT EXISTS financial JSONB NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE members ADD COLUMN IF NOT EXISTS family JSONB NOT NULL DEFAULT '{"members":[],"notes":""}'::jsonb;

UPDATE members
SET personal_info = jsonb_build_object(
  'fullName', full_name,
  'fatherName', COALESCE(personal_info->>'fatherName',''),
  'motherName', COALESCE(personal_info->>'motherName',''),
  'spouseName', COALESCE(personal_info->>'spouseName',''),
  'dateOfBirth', COALESCE(personal_info->>'dateOfBirth',''),
  'gender', COALESCE(personal_info->>'gender',''),
  'nid', nid_or_passport,
  'mobile', phone,
  'email', COALESCE(email,''),
  'address', COALESCE(address,'')
)
WHERE personal_info = '{}'::jsonb;

CREATE INDEX IF NOT EXISTS members_org_status_created_idx
  ON members(organization_id,status,created_at DESC);
CREATE INDEX IF NOT EXISTS members_org_nid_idx
  ON members(organization_id,nid_or_passport);

INSERT INTO schema_migrations(version)
VALUES ('007_member_api')
ON CONFLICT(version) DO NOTHING;
