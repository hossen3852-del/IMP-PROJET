-- 11.P.16 — Organization Admin credential management UI/API.
-- No schema change is required: users.email/password_hash, sessions and audit_logs already exist.
-- This migration is a version marker so deployed databases can track the feature release.
INSERT INTO schema_migrations(version)
VALUES ('029_admin_credentials_settings')
ON CONFLICT(version) DO NOTHING;
