-- IMP V6.0.17 — Legacy loan import, completed-loan separation,
-- per-user sidebar visibility and organization share profiles.

ALTER TABLE members
  ADD COLUMN IF NOT EXISTS member_origin VARCHAR(30) NOT NULL DEFAULT 'new',
  ADD COLUMN IF NOT EXISTS legacy_current_installments_paid INTEGER NOT NULL DEFAULT 0 CHECK (legacy_current_installments_paid >= 0),
  ADD COLUMN IF NOT EXISTS legacy_current_installment_amount NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (legacy_current_installment_amount >= 0),
  ADD COLUMN IF NOT EXISTS legacy_savings_balance NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (legacy_savings_balance >= 0);
ALTER TABLE members DROP CONSTRAINT IF EXISTS members_member_origin_check;
ALTER TABLE members ADD CONSTRAINT members_member_origin_check CHECK (member_origin IN ('new','previous_borrower'));

ALTER TABLE loans
  ADD COLUMN IF NOT EXISTS loan_source_type VARCHAR(30) NOT NULL DEFAULT 'new',
  ADD COLUMN IF NOT EXISTS legacy_original_paid_amount NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (legacy_original_paid_amount >= 0),
  ADD COLUMN IF NOT EXISTS legacy_original_paid_installments INTEGER NOT NULL DEFAULT 0 CHECK (legacy_original_paid_installments >= 0);
ALTER TABLE loans DROP CONSTRAINT IF EXISTS loans_loan_source_type_check;
ALTER TABLE loans ADD CONSTRAINT loans_loan_source_type_check CHECK (loan_source_type IN ('new','previous_loan'));
CREATE INDEX IF NOT EXISTS loans_org_source_idx ON loans(organization_id,loan_source_type);
CREATE INDEX IF NOT EXISTS members_org_origin_idx ON members(organization_id,member_origin);

CREATE TABLE IF NOT EXISTS capital_share_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  member_id UUID REFERENCES members(id) ON DELETE SET NULL,
  shareholder_name VARCHAR(200) NOT NULL,
  shareholder_phone VARCHAR(50),
  shareholder_email VARCHAR(254),
  share_units NUMERIC(18,4) NOT NULL CHECK (share_units > 0),
  issue_price_per_share NUMERIC(18,2) NOT NULL CHECK (issue_price_per_share > 0),
  invested_amount NUMERIC(18,2) NOT NULL CHECK (invested_amount >= 0),
  acquisition_date DATE NOT NULL DEFAULT CURRENT_DATE,
  status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
  notes TEXT,
  created_by UUID REFERENCES users(id),
  updated_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS capital_share_profiles_org_idx ON capital_share_profiles(organization_id,status);
CREATE INDEX IF NOT EXISTS capital_share_profiles_org_member_idx ON capital_share_profiles(organization_id,member_id);

INSERT INTO permissions(code) VALUES
  ('capital.share.view'),('capital.share.manage'),('ui.visibility.manage')
ON CONFLICT(code) DO NOTHING;

-- Organization admin/super admin receive share + UI customization rights.
INSERT INTO role_permissions(role,permission_id,role_id)
SELECT r.code,p.id,r.id FROM roles r CROSS JOIN permissions p
WHERE r.is_system=FALSE AND r.code='organization_admin'
  AND p.code IN ('capital.share.view','capital.share.manage','ui.visibility.manage')
ON CONFLICT(role_id,permission_id) DO NOTHING;
INSERT INTO role_permissions(role,permission_id,role_id)
SELECT r.code,p.id,r.id FROM roles r CROSS JOIN permissions p
WHERE r.is_system=TRUE AND r.code='super_admin'
  AND p.code IN ('capital.share.view','capital.share.manage','ui.visibility.manage')
ON CONFLICT(role_id,permission_id) DO NOTHING;

-- Keep the established RBAC factory untouched. V6.0.17 grants are additive.
CREATE OR REPLACE FUNCTION grant_v617_permissions(p_organization_id UUID)
RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO role_permissions(role,permission_id,role_id)
  SELECT r.code,p.id,r.id FROM roles r CROSS JOIN permissions p
  WHERE r.organization_id=p_organization_id AND r.is_system=FALSE
    AND p.code IN ('capital.share.view','capital.share.manage','ui.visibility.manage')
  ON CONFLICT(role_id,permission_id) DO NOTHING;
END;
$$;

DO $$ DECLARE org_rec RECORD; BEGIN
  FOR org_rec IN SELECT id FROM organizations LOOP
    PERFORM grant_v617_permissions(org_rec.id);
  END LOOP;
END $$;


INSERT INTO schema_migrations(version) VALUES ('031_v6_0_17_legacy_loans_shares_ui_visibility') ON CONFLICT(version) DO NOTHING;
