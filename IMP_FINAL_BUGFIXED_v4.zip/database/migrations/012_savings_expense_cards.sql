-- 11.P.15 (extension) — Current Balance / Loan / Daily Collection / Savings /
-- Insurance / Admission Fee / Expense dashboard cards.
--
-- Confirmed with the org owner:
--   * "Current Balance" and "বর্তমান মূলধন" are ONE merged card, not two.
--   * "মোট বীমা" = insurance + insurance_new (two premium categories) − claim payouts.
--   * "মোট ভর্তি ফি" = admission_fee + admission_fee_new (two fee categories).
--   * Re-loan and interest are read from the existing loans ledger (no new
--     "is_reloan" flag needed — every disbursed loan already counts toward
--     disbursement, and loans.interest_amount already tracks interest).
--
-- Additive only: no existing table/column/row is altered or dropped.

-- ---------------------------------------------------------------------
-- 1. Widen capital_entries.entry_type to carry the two new fee/premium
--    categories and the conditional insurance claim payout.
-- ---------------------------------------------------------------------
ALTER TABLE capital_entries DROP CONSTRAINT IF EXISTS capital_entries_entry_type_check;
ALTER TABLE capital_entries ADD CONSTRAINT capital_entries_entry_type_check CHECK (entry_type IN (
  'capital_in', 'capital_adjustment', 'capital_withdrawal',
  'admission_fee', 'admission_fee_new',
  'insurance', 'insurance_new', 'insurance_claim'
));

-- ---------------------------------------------------------------------
-- 2. Savings ledger (per member). Total Savings card =
--    deposit + daily_deposit − withdrawal − installment_payment.
--    "installment_payment" is a savings→loan internal transfer: it reduces
--    the member's savings balance AND reduces the loan outstanding balance
--    (see dashboard.js), but is NOT counted again as fresh cash collection
--    in Current Balance, since no new external cash entered the org.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS savings_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  member_id UUID NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES branches(id) ON DELETE SET NULL,
  loan_id UUID REFERENCES loans(id) ON DELETE SET NULL,
  transaction_type VARCHAR(30) NOT NULL CHECK (transaction_type IN (
    'deposit', 'daily_deposit', 'withdrawal', 'installment_payment'
  )),
  amount NUMERIC(18,2) NOT NULL CHECK (amount > 0),
  transaction_date DATE NOT NULL,
  description TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT savings_installment_requires_loan CHECK (
    transaction_type <> 'installment_payment' OR loan_id IS NOT NULL
  )
);
CREATE INDEX IF NOT EXISTS savings_tx_org_date_idx ON savings_transactions(organization_id, transaction_date DESC);
CREATE INDEX IF NOT EXISTS savings_tx_org_member_idx ON savings_transactions(organization_id, member_id);
CREATE INDEX IF NOT EXISTS savings_tx_org_type_idx ON savings_transactions(organization_id, transaction_type);

-- ---------------------------------------------------------------------
-- 3. Expense ledger. মোট খরচ card = office + travel + equipment (+ other).
--    আজকের ডেইলি কালেকশন card subtracts SUM(all categories) for today,
--    not just one category — "ডেইলি খরচ" means "today's expense total".
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS expense_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES branches(id) ON DELETE SET NULL,
  category VARCHAR(20) NOT NULL CHECK (category IN ('office', 'travel', 'equipment', 'other')),
  amount NUMERIC(18,2) NOT NULL CHECK (amount > 0),
  expense_date DATE NOT NULL,
  description TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS expense_entries_org_date_idx ON expense_entries(organization_id, expense_date DESC);
CREATE INDEX IF NOT EXISTS expense_entries_org_category_idx ON expense_entries(organization_id, category);

-- ---------------------------------------------------------------------
-- 4. New permissions + grants (existing orgs) + factory update (future orgs).
-- ---------------------------------------------------------------------
INSERT INTO permissions(code) VALUES
 ('savings.view'), ('savings.manage'),
 ('expense.view'), ('expense.manage')
ON CONFLICT(code) DO NOTHING;

-- organization_admin: everything.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id FROM roles r CROSS JOIN permissions p
WHERE r.is_system = FALSE AND r.code = 'organization_admin'
  AND p.code IN ('savings.view','savings.manage','expense.view','expense.manage')
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- accountant: full savings + expense (day-to-day financial operations).
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id FROM roles r CROSS JOIN permissions p
WHERE r.is_system = FALSE AND r.code = 'accountant'
  AND p.code IN ('savings.view','savings.manage','expense.view','expense.manage')
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- branch_manager: full savings, view-only expense.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id FROM roles r CROSS JOIN permissions p
WHERE r.is_system = FALSE AND r.code = 'branch_manager'
  AND p.code IN ('savings.view','savings.manage','expense.view')
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- collector: field-level savings collection, no expense access.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id FROM roles r CROSS JOIN permissions p
WHERE r.is_system = FALSE AND r.code = 'collector'
  AND p.code IN ('savings.view','savings.manage')
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- super_admin: everything.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id FROM roles r CROSS JOIN permissions p
WHERE r.code = 'super_admin' AND r.is_system = TRUE
  AND p.code IN ('savings.view','savings.manage','expense.view','expense.manage')
ON CONFLICT (role_id, permission_id) DO NOTHING;

CREATE OR REPLACE FUNCTION create_default_org_rbac(p_organization_id UUID)
RETURNS VOID
LANGUAGE plpgsql
AS $$
DECLARE
  role_record RECORD;
BEGIN
  INSERT INTO roles(organization_id,code,name,description,is_system,is_protected)
  VALUES
    (p_organization_id,'organization_admin','Organization Admin','Full organization administration',FALSE,TRUE),
    (p_organization_id,'branch_manager','Branch Manager','Branch-level operational management',FALSE,FALSE),
    (p_organization_id,'collector','Collector','Collection and payment operations',FALSE,FALSE),
    (p_organization_id,'accountant','Accountant','Financial and payment operations',FALSE,FALSE),
    (p_organization_id,'viewer','Viewer','Read-only organization access',FALSE,FALSE)
  ON CONFLICT (organization_id,code) WHERE is_system=FALSE DO NOTHING;

  FOR role_record IN
    SELECT id,code FROM roles
    WHERE organization_id=p_organization_id AND is_system=FALSE
  LOOP
    INSERT INTO role_permissions(role,permission_id,role_id)
    SELECT role_record.code,p.id,role_record.id
    FROM permissions p
    WHERE p.code = ANY(
      CASE role_record.code
        WHEN 'organization_admin' THEN ARRAY[
          'dashboard.view','dashboard.customize',
          'organization.view','organization.update',
          'branch.view','branch.create','branch.update','branch.delete',
          'user.view','user.create','user.update','user.delete',
          'role.view','role.create','role.update','role.delete','role.manage',
          'permission.view','settings.view','settings.update',
          'member.view','member.create','member.update','member.delete',
          'member.status.update','member.financial.update',
          'member.document.upload','member.document.delete',
          'loan.view','loan.create','loan.update','loan.delete','loan.approve',
          'loan.status.update','loan.financial.update',
          'loan.payment.create','loan.payment.update','loan.payment.delete','loan.schedule.update',
          'payment.view','payment.create','payment.cancel','payment.reverse',
          'capital.view','capital.manage',
          'savings.view','savings.manage','expense.view','expense.manage'
        ]
        WHEN 'branch_manager' THEN ARRAY[
          'dashboard.view','branch.view','user.view','user.create','user.update',
          'settings.view','member.view','member.create','member.update',
          'member.status.update','member.financial.update','member.document.upload',
          'loan.view','loan.create','loan.update','loan.approve','loan.status.update',
          'loan.financial.update','loan.payment.create','loan.schedule.update',
          'savings.view','savings.manage','expense.view'
        ]
        WHEN 'collector' THEN ARRAY[
          'dashboard.view','member.view','loan.view','payment.view','payment.create',
          'loan.payment.create','savings.view','savings.manage'
        ]
        WHEN 'accountant' THEN ARRAY[
          'dashboard.view','member.view','member.financial.update','loan.view',
          'loan.financial.update','payment.view','payment.create','loan.payment.create',
          'loan.payment.update','capital.view',
          'savings.view','savings.manage','expense.view','expense.manage'
        ]
        ELSE ARRAY[
          'dashboard.view','organization.view','branch.view','user.view',
          'member.view','loan.view','payment.view'
        ]
      END::VARCHAR[]
    )
    ON CONFLICT (role_id,permission_id) DO NOTHING;
  END LOOP;
END;
$$;

INSERT INTO schema_migrations(version)
VALUES ('012_savings_expense_cards')
ON CONFLICT(version) DO NOTHING;
