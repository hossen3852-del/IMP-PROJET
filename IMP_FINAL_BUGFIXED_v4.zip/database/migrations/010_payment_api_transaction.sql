-- 11.P.10 — Payment API + Transaction
-- PostgreSQL is authoritative for payments, allocations, balances and receipts.

CREATE SEQUENCE IF NOT EXISTS payment_number_seq START 1;
CREATE SEQUENCE IF NOT EXISTS receipt_number_seq START 1;

ALTER TABLE payment_allocations ADD COLUMN IF NOT EXISTS status VARCHAR(30) NOT NULL DEFAULT 'active';
ALTER TABLE payment_allocations DROP CONSTRAINT IF EXISTS payment_allocations_status_check;
ALTER TABLE payment_allocations ADD CONSTRAINT payment_allocations_status_check CHECK (status IN ('active','cancelled','reversed'));
ALTER TABLE payment_allocations ADD COLUMN IF NOT EXISTS cancelled_at TIMESTAMPTZ;
ALTER TABLE payment_allocations ADD COLUMN IF NOT EXISTS reversed_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS payments_org_status_date_idx ON payments(organization_id,status,payment_date DESC);
CREATE INDEX IF NOT EXISTS payment_allocations_org_status_idx ON payment_allocations(organization_id,status,created_at DESC);

-- Strengthen tenant relationships for payment and allocation rows.
ALTER TABLE payments DROP CONSTRAINT IF EXISTS payments_branch_org_fk;
ALTER TABLE payments ADD CONSTRAINT payments_branch_org_fk
  FOREIGN KEY (organization_id,branch_id) REFERENCES branches(organization_id,id) ON DELETE RESTRICT;
ALTER TABLE payment_allocations DROP CONSTRAINT IF EXISTS payment_allocations_loan_installment_consistency;

INSERT INTO schema_migrations(version)
VALUES ('010_payment_api_transaction')
ON CONFLICT(version) DO NOTHING;
