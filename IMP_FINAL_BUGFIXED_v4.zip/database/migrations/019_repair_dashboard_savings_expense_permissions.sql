-- 11.P.19 — Repair missing dashboard/capital/savings/expense permissions
--
-- Some databases may already have migrations 011/012 recorded in
-- schema_migrations while one or more permission rows are missing (for
-- example after a partial/manual migration).  The migration runner skips
-- recorded versions, so those databases need an idempotent repair migration.
-- This migration only INSERTs missing permission rows and missing grants.

INSERT INTO permissions(code) VALUES
  ('capital.view'),
  ('capital.manage'),
  ('dashboard.customize'),
  ('savings.view'),
  ('savings.manage'),
  ('expense.view'),
  ('expense.manage')
ON CONFLICT (code) DO NOTHING;

-- Organization Admin: full access to these dashboard/financial features.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id
FROM roles r
CROSS JOIN permissions p
WHERE r.is_system = FALSE
  AND r.code = 'organization_admin'
  AND p.code IN (
    'capital.view','capital.manage','dashboard.customize',
    'savings.view','savings.manage','expense.view','expense.manage'
  )
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- Branch Manager: dashboard customization is intentionally not granted;
-- financial/savings/expense access follows the existing RBAC policy.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id
FROM roles r
CROSS JOIN permissions p
WHERE r.is_system = FALSE
  AND r.code = 'branch_manager'
  AND p.code IN ('savings.view','savings.manage','expense.view')
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- Accountant: financial visibility and ledger management.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id
FROM roles r
CROSS JOIN permissions p
WHERE r.is_system = FALSE
  AND r.code = 'accountant'
  AND p.code IN (
    'capital.view','savings.view','savings.manage',
    'expense.view','expense.manage'
  )
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- Collector / field officer: operational savings collection access.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id
FROM roles r
CROSS JOIN permissions p
WHERE r.is_system = FALSE
  AND r.code IN ('collector','field_officer')
  AND p.code IN ('savings.view','savings.manage','expense.view')
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- System super admin receives all seven permissions.
INSERT INTO role_permissions(role, permission_id, role_id)
SELECT r.code, p.id, r.id
FROM roles r
CROSS JOIN permissions p
WHERE r.is_system = TRUE
  AND r.code = 'super_admin'
  AND p.code IN (
    'capital.view','capital.manage','dashboard.customize',
    'savings.view','savings.manage','expense.view','expense.manage'
  )
ON CONFLICT (role_id, permission_id) DO NOTHING;

INSERT INTO schema_migrations(version)
VALUES ('019_repair_dashboard_savings_expense_permissions')
ON CONFLICT (version) DO NOTHING;
