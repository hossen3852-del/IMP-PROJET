-- 11.P.18 — Enforce globally unique user email (case-insensitive).
--
-- The application always looks users up by email alone, with no
-- organization filter (login, registration duplicate-check, and the
-- user-management duplicate-check all run
-- `WHERE lower(email)=lower($1)` across the whole users table).
--
-- The original users table, however, only enforced
-- UNIQUE(organization_id, email) — uniqueness *within* an organization,
-- not across the platform. That mismatch leaves a narrow but real race
-- window: two organizations registering the same email at nearly the
-- same time could both pass the application's SELECT-then-INSERT
-- duplicate check and both succeed, since the database itself does not
-- forbid it. Once that happens, the login query's `LIMIT 1` (with no
-- ORDER BY) returns whichever of the two matching rows the planner
-- picks, so login effectively becomes non-deterministic for one of the
-- two accounts.
--
-- This migration adds the constraint the application already assumes.
--
-- NOTE: if any duplicate (case-insensitive) emails already exist across
-- different organizations in this database, creating the unique index
-- below will fail until they are manually resolved (rename or merge the
-- older account) — that failure is intentional: it surfaces the exact
-- data problem this migration exists to prevent, rather than silently
-- leaving it in place.

CREATE UNIQUE INDEX IF NOT EXISTS users_email_lower_unique_idx
  ON users (lower(email));

INSERT INTO schema_migrations(version)
VALUES ('018_users_email_global_unique')
ON CONFLICT(version) DO NOTHING;
