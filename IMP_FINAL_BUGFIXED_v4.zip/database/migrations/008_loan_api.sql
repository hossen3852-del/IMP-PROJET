-- 11.P.8 — Loan API + Frontend Loan Cut-over
-- Server/API and PostgreSQL become authoritative for loan records.

ALTER TABLE loans ADD COLUMN IF NOT EXISTS disbursed_amount NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (disbursed_amount >= 0);
ALTER TABLE loans ADD COLUMN IF NOT EXISTS outstanding_amount NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (outstanding_amount >= 0);

UPDATE loans SET outstanding_amount = total_payable WHERE outstanding_amount = 0 AND status IN ('draft','pending','approved');
UPDATE loans SET disbursed_amount = loan_amount WHERE disbursed_at IS NOT NULL AND disbursed_amount = 0;

ALTER TABLE loans DROP CONSTRAINT IF EXISTS loans_branch_org_fk;
ALTER TABLE loans
  ADD CONSTRAINT loans_branch_org_fk
  FOREIGN KEY (organization_id,branch_id)
  REFERENCES branches(organization_id,id)
  ON DELETE RESTRICT;

CREATE INDEX IF NOT EXISTS loans_org_created_idx ON loans(organization_id,created_at DESC);
CREATE INDEX IF NOT EXISTS loans_org_member_status_idx ON loans(organization_id,member_id,status);

INSERT INTO schema_migrations(version)
VALUES ('008_loan_api')
ON CONFLICT(version) DO NOTHING;
