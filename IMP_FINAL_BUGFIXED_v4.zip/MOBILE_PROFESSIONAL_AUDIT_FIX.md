# IMP V6.0.17 — Mobile Professional Frontend Audit & Fix

## Audit Summary (2026-09-25)

### Status
- Architecture: Production-ready single-org MFI platform (Node/Express + vanilla JS frontend)
- Version: 1.6.17 / V6.0.17
- Mobile foundation: Already present (`css/mobile-responsive.css`)

### Issues Found & Fixed
1. **Mobile sidebar UX** — On ≤768px the sidebar was fixed-width desktop layout; users had no easy way to open/close it.
   - **Fix**: Off-canvas drawer with slide-in animation, backdrop overlay, ☰ floating toggle button (auto-injected via `js/core/home-nav.js`).
2. **Touch targets & iOS zoom** — Some inputs could trigger zoom; buttons not consistently 44px.
   - **Fix**: Enforced `min-height: 44px`, `font-size: 16px` on inputs inside media queries.
3. **Typography for Bangla** — Generic Arial only.
   - **Fix**: Added Noto Sans Bengali / Hind Siliguri system font stack.
4. **Safe-area / notch** — No `env(safe-area-inset-*)` support.
   - **Fix**: Added safe-area padding for modern phones.
5. **Card / grid density** — Stats grids stayed 4-column on tablet/phone.
   - **Fix**: Progressive collapse 4 → 2 → 1 columns.

### Already Correct (no change needed)
- Single-organization mode (registration removed)
- Design tokens in `css/style.css` (teal primary, slate neutrals)
- Focus-visible accessibility
- Reduced-motion preference
- RBAC + per-user sidebar visibility
- Dashboard customization permissions (migration 032)

### How to verify
1. Open any authenticated page on phone width (≤768px)
2. Tap ☰ (top-left teal button) → sidebar slides in
3. Tap outside → closes
4. Forms stay full-width, tables scroll horizontally

### Deploy note
Same as previous V6.0.17:
```
npm ci && npm run db:migrate && npm run db:validate && npm start
```
After deploy, hard-refresh (Ctrl+Shift+R) so new CSS/JS load.
