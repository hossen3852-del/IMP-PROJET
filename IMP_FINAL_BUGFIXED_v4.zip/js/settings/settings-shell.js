/**
 * Settings shell — module navigation header + language control.
 * Language switcher lives here (not floating top-right on every page).
 */
(function (global) {
  'use strict';

  const MODULES = [
    { id: 'hub', href: 'settings.html', labelBn: 'সেটিংস হোম', labelEn: 'Settings Home', match: /settings\.html$/ },
    { id: 'organization', href: 'organization-settings.html', labelBn: 'প্রতিষ্ঠান', labelEn: 'Organization', match: /organization-settings/ },
    { id: 'dashboard', href: 'dashboard-settings.html', labelBn: 'ড্যাশবোর্ড', labelEn: 'Dashboard', match: /dashboard-settings/ },
    { id: 'members', href: 'member-registration-settings.html', labelBn: 'সদস্য ফর্ম', labelEn: 'Member Form', match: /member-registration/ },
    { id: 'loans', href: 'loan-settings.html', labelBn: 'লোন', labelEn: 'Loan', match: /loan-settings/ },
    { id: 'payments', href: 'payment-settings.html', labelBn: 'পেমেন্ট', labelEn: 'Payment', match: /payment-settings/ },
    { id: 'language', href: 'language-settings.html', labelBn: 'ভাষা', labelEn: 'Language', match: /language-settings/ },
    { id: 'userUiVisibility', href: 'user-ui-visibility.html', labelBn: 'ইউজার UI নিয়ন্ত্রণ', labelEn: 'User UI Visibility', match: /user-ui-visibility/ },
    { id: 'adminCredentials', href: 'admin-credentials.html', labelBn: 'Organization Admin', labelEn: 'Organization Admin', match: /admin-credentials/ }
  ];

  function isEn() {
    try {
      return !!(global.IMP_I18N && typeof global.IMP_I18N.lang === 'function' && global.IMP_I18N.lang() === 'en');
    } catch (_) {
      return false;
    }
  }

  function currentPath() {
    return (location.pathname || '').split('/').pop() || '';
  }

  function injectNav() {
    if (document.getElementById('settingsTopNav')) return;

    const en = isEn();
    const path = currentPath();
    const nav = document.createElement('nav');
    nav.id = 'settingsTopNav';
    nav.className = 'settings-topnav';
    nav.setAttribute('aria-label', 'Settings modules');

    MODULES.forEach((m) => {
      const a = document.createElement('a');
      a.href = m.href;
      a.textContent = en ? m.labelEn : m.labelBn;
      a.dataset.module = m.id;
      if (m.match.test(path)) a.classList.add('active');
      nav.appendChild(a);
    });

    const spacer = document.createElement('div');
    spacer.className = 'nav-spacer';
    nav.appendChild(spacer);

    const lang = document.createElement('div');
    lang.className = 'settings-lang';
    lang.innerHTML =
      '<label for="impLanguageSelect">Language / ভাষা</label>' +
      '<select id="impLanguageSelect" aria-label="Language"></select>';
    nav.appendChild(lang);

    // Insert at top of main/page-container or body
    const host =
      document.querySelector('main.page-container') ||
      document.querySelector('.page-container') ||
      document.querySelector('main') ||
      document.body;

    if (host === document.body) {
      host.insertBefore(nav, host.firstChild);
    } else {
      host.insertBefore(nav, host.firstChild);
    }

    if (global.IMP_I18N && typeof IMP_I18N.bindLanguageSelect === 'function') {
      IMP_I18N.bindLanguageSelect(document.getElementById('impLanguageSelect'));
    } else {
      // i18n may load after this script — bind on next tick / DOMContentLoaded
      const sel = document.getElementById('impLanguageSelect');
      if (sel) {
        sel.innerHTML = '<option value="bn">বাংলা</option><option value="en">English</option>';
        try { sel.value = (global.IMP_I18N && typeof global.IMP_I18N.lang === 'function') ? global.IMP_I18N.lang() : 'bn'; } catch (_) { sel.value = 'bn'; }
        sel.addEventListener('change', (e) => {
          if (global.IMP_I18N && IMP_I18N.setLang) IMP_I18N.setLang(e.target.value);
          else {
            try { const v = e.target.value === 'en' ? 'en' : 'bn'; if (global.IMP_I18N && typeof global.IMP_I18N.setLang === 'function') global.IMP_I18N.setLang(v); } catch (_) {}
            location.reload();
          }
        });
      }
    }
  }

  function boot() {
    injectNav();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  global.SettingsShell = { injectNav, MODULES };
})(typeof window !== 'undefined' ? window : this);
