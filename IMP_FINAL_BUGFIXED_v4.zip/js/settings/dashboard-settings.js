/**
 * 11.P.15.6 — Dashboard Customize UI.
 * Reads/writes organization-scoped dashboard config via
 * /api/dashboard/config. This page only controls presentation
 * (which KPI cards show, in what order, which sections are enabled) —
 * it never computes or stores the KPI numbers themselves.
 */
(function () {
    "use strict";

    // Must stay in sync with KPI_CARD_KEYS / DEFAULT_CONFIG in
    // server/routes/dashboard.js and CARD_DEFS in js/app.js.
    const KPI_CARDS = [
        { key: "currentCapital", title: "বর্তমান ব্যালেন্স", defaultVisible: true },
        { key: "loanBalance", title: "লোন", defaultVisible: true },
        { key: "todayCollection", title: "ডেইলি কালেকশন", defaultVisible: true },
        { key: "totalSavings", title: "মোট সঞ্চয়", defaultVisible: true },
        { key: "insurance", title: "মোট বীমা", defaultVisible: true },
        { key: "admissionFee", title: "মোট ভর্তি ফি", defaultVisible: true },
        { key: "totalExpense", title: "মোট খরচ", defaultVisible: true },
        { key: "totalMembers", title: "মোট সদস্য", defaultVisible: false },
        { key: "totalLoans", title: "মোট লোন", defaultVisible: false },
        { key: "totalCollection", title: "মোট কালেকশন", defaultVisible: false },
        { key: "totalDue", title: "মোট বকেয়া", defaultVisible: false },
        { key: "todayLoan", title: "আজকের লোন", defaultVisible: false },
        { key: "overdue", title: "Overdue", defaultVisible: false },
        { key: "closedLoans", title: "Completed Loans", defaultVisible: true },
        { key: "cancelledLoans", title: "Cancelled Loans", defaultVisible: false }
    ];

    const SECTIONS = [
        { key: "collectionSummary", title: "Collection Summary" },
        { key: "loanSummary", title: "Loan Summary" },
        { key: "dueOverdueSummary", title: "Due / Overdue Summary" },
        { key: "recentPayments", title: "Recent Payments" },
        { key: "recentLoans", title: "Recent Loans" },
        { key: "recentMembers", title: "Recent Members" },
        { key: "collectionChart", title: "Collection Chart" },
        { key: "loanChart", title: "Loan Chart" },
        { key: "recoveryPerformance", title: "Recovery Performance" },
        { key: "branchWiseSummary", title: "Branch-wise Summary" },
        { key: "centerGroupWiseSummary", title: "Center/Group-wise Summary" }
    ];

    function defaultConfig() {
        return {
            kpiCards: KPI_CARDS.map(c => ({ key: c.key, visible: c.defaultVisible })),
            sections: SECTIONS.reduce((acc, s) => { acc[s.key] = true; return acc; }, {})
        };
    }

    function titleFor(key) {
        const def = KPI_CARDS.find(c => c.key === key);
        return def ? def.title : key;
    }

    let dragSourceEl = null;

    function renderKpiList(config) {
        const list = document.getElementById("kpiOrderList");
        if (!list) return;
        list.innerHTML = "";

        const order = Array.isArray(config.kpiCards) && config.kpiCards.length
            ? config.kpiCards
            : defaultConfig().kpiCards;

        order.forEach(item => {
            const li = document.createElement("li");
            li.className = "kpi-order-item";
            li.draggable = true;
            li.dataset.key = item.key;

            li.innerHTML = `
                <span class="drag-handle" aria-hidden="true">⠿</span>
                <label>
                    <input type="checkbox" class="kpi-visible-toggle" ${item.visible ? "checked" : ""}>
                    ${Utils.escapeHtml(titleFor(item.key))}
                </label>
            `;

            li.addEventListener("dragstart", () => {
                dragSourceEl = li;
                li.classList.add("dragging");
            });
            li.addEventListener("dragend", () => {
                li.classList.remove("dragging");
                dragSourceEl = null;
            });
            li.addEventListener("dragover", event => {
                event.preventDefault();
                if (!dragSourceEl || dragSourceEl === li) return;
                const rect = li.getBoundingClientRect();
                const before = (event.clientY - rect.top) < rect.height / 2;
                list.insertBefore(dragSourceEl, before ? li : li.nextSibling);
            });

            list.appendChild(li);
        });
    }

    function renderSections(config) {
        const grid = document.getElementById("sectionsGrid");
        if (!grid) return;
        grid.innerHTML = "";
        const sections = config.sections || defaultConfig().sections;

        SECTIONS.forEach(section => {
            const label = document.createElement("label");
            label.innerHTML = `
                <input type="checkbox" class="section-toggle" data-key="${section.key}" ${sections[section.key] !== false ? "checked" : ""}>
                ${Utils.escapeHtml(section.title)}
            `;
            grid.appendChild(label);
        });
    }

    function collectConfig() {
        const kpiCards = Array.from(document.querySelectorAll("#kpiOrderList .kpi-order-item")).map(li => ({
            key: li.dataset.key,
            visible: li.querySelector(".kpi-visible-toggle").checked
        }));

        const sections = {};
        document.querySelectorAll("#sectionsGrid .section-toggle").forEach(input => {
            sections[input.dataset.key] = input.checked;
        });

        return { kpiCards, sections };
    }

    async function loadConfig() {
        try {
            let config;
            if (typeof SettingsAPI !== "undefined") {
                config = await SettingsAPI.get("dashboard_config");
            } else {
                const result = await IMP_API.get("/dashboard/config");
                config = result?.config;
            }
            config = config && typeof config === "object" ? config : defaultConfig();
            // Ensure shape
            if (!Array.isArray(config.kpiCards)) config = defaultConfig();
            renderKpiList(config);
            renderSections(config);
        } catch (error) {
            Utils.showMessage("dashboardSettingsMessage", error.message || "কনফিগ লোড করা যায়নি।", "error");
            renderKpiList(defaultConfig());
            renderSections(defaultConfig());
        }
    }

    async function saveConfig() {
        const saveBtn = document.getElementById("saveDashboardConfig");
        if (saveBtn) saveBtn.disabled = true;
        try {
            const payload = collectConfig();
            if (typeof SettingsAPI !== "undefined") {
                await SettingsAPI.put("dashboard_config", payload);
            } else {
                await IMP_API.put("/dashboard/config", payload);
            }
            Utils.showMessage("dashboardSettingsMessage", "Dashboard configuration saved.", "success");
        } catch (error) {
            Utils.showMessage("dashboardSettingsMessage", error.message || "সংরক্ষণ ব্যর্থ হয়েছে।", "error");
        } finally {
            if (saveBtn) saveBtn.disabled = false;
        }
    }

    function resetToDefault() {
        const config = defaultConfig();
        renderKpiList(config);
        renderSections(config);
        Utils.showMessage("dashboardSettingsMessage", "ডিফল্ট মান পুনরায় সেট করা হয়েছে। সংরক্ষণ করতে Save চাপুন।", "success");
    }

    document.addEventListener("DOMContentLoaded", async function () {
        if (!(await SessionManager.requireAuth())) return;
        await RBACManager.bootstrap();

        if (!(await AccessGuard.requirePermission(PERMISSIONS.DASHBOARD_CUSTOMIZE))) return;

        const saveBtn = document.getElementById("saveDashboardConfig");
        if (saveBtn) saveBtn.addEventListener("click", saveConfig);

        const resetBtn = document.getElementById("resetDashboardConfig");
        if (resetBtn) resetBtn.addEventListener("click", resetToDefault);

        await loadConfig();
    });
})();
