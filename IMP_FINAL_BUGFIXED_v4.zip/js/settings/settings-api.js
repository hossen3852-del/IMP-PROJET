/**
 * Server-authoritative organization settings client.
 * UI config is loaded/saved via /api/settings — not localStorage.
 */
(function (global) {
  'use strict';

  const KEYS = {
    LOAN: 'loan_ui_config',
    PAYMENT: 'payment_ui_config',
    MEMBER_REGISTRATION: 'member_registration_ui',
    DASHBOARD: 'dashboard_config',
    DAILY_COLLECTION: 'daily_collection_config',
    LOAN_SCHEDULE: 'loan_schedule_config'
  };

  async function get(key) {
    if (typeof IMP_API === 'undefined') throw new Error('IMP_API not loaded');
    const res = await IMP_API.get(`/settings/${encodeURIComponent(key)}`);
    return res && res.value ? res.value : {};
  }

  async function put(key, value) {
    if (typeof IMP_API === 'undefined') throw new Error('IMP_API not loaded');
    const res = await IMP_API.put(`/settings/${encodeURIComponent(key)}`, { value });
    return res && res.value ? res.value : value;
  }

  async function getAll() {
    if (typeof IMP_API === 'undefined') throw new Error('IMP_API not loaded');
    const res = await IMP_API.get('/settings');
    return res && res.settings ? res.settings : {};
  }

  global.SettingsAPI = { KEYS, get, put, getAll };
})(window);
