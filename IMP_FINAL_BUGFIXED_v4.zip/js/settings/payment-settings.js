(function () {
  'use strict';
  const KEY = 'payment_ui_config';
  const DAILY_KEY = 'daily_collection_config';
  const DAILY_DEFAULT = {
    collectionTypes: { installment: true, savings: true },
    defaultPaymentMethod: 'cash', showOverdueHint: true, allowBranchOverride: false, requireNoteOnAdvance: false, allowAdvance: true, autoIncludeInactiveMembers: false
  };

  const DEFAULT = {
    methods: { cash: true, bkash: true, nagad: true, rocket: true, bank_transfer: true, cheque: true, other: true },
    requireReferenceFor: ['bkash', 'nagad', 'rocket', 'bank_transfer', 'cheque'],
    allowAdvanceDefault: true,
    listColumns: { paymentNumber: true, memberName: true, amount: true, method: true, date: true, status: true }
  };

  function merge(a, b) {
    const o = { ...a };
    Object.keys(b || {}).forEach(k => {
      o[k] = b[k] && typeof b[k] === 'object' && !Array.isArray(b[k])
        ? merge(a[k] || {}, b[k]) : b[k];
    });
    return o;
  }

  let cache = null;

  async function load() {
    try {
      if (typeof SettingsAPI !== 'undefined') {
        cache = merge(DEFAULT, await SettingsAPI.get(KEY));
        try { cache.dailyCollection = merge(DAILY_DEFAULT, await SettingsAPI.get(DAILY_KEY)); } catch (_) { cache.dailyCollection = merge(DAILY_DEFAULT, {}); }
      } else { cache = merge(DEFAULT, {}); cache.dailyCollection = merge(DAILY_DEFAULT, {}); }
    } catch (e) {
      console.warn('payment settings load failed', e);
      cache = merge(DEFAULT, {});
    }
    return cache;
  }

  function getSync() { return cache ? merge(DEFAULT, cache) : merge(DEFAULT, {}); }

  async function save(value) {
    const merged = merge(DEFAULT, value);
    if (typeof SettingsAPI !== 'undefined') cache = await SettingsAPI.put(KEY, merged);
    else cache = merged;
    return cache;
  }

  function row(id, label, checked) {
    return `<label class="checkbox-row"><input type="checkbox" id="${id}" ${checked ? 'checked' : ''}> ${label}</label>`;
  }

  function render(c) {
    const host = document.getElementById('paymentSettingsFields');
    if (!host) return;
    const methods = c.methods || {};
    const cols = c.listColumns || {};
    const daily = c.dailyCollection || merge(DAILY_DEFAULT, {});
    host.innerHTML =
      '<h2>Daily Collection</h2>' +
      '<p class="settings-section-hint">Daily Collection-এ কিস্তি ও সঞ্চয় সংগ্রহ করুন। Advance চালু করলে বর্তমান বকেয়ার অতিরিক্ত টাকা ভবিষ্যৎ কিস্তিতে FIFO অনুযায়ী বরাদ্দ হবে।</p>' +
      row('dc_installment', 'কিস্তি ব্যবহার করুন', daily.collectionTypes.installment) +
      row('dc_savings', 'সঞ্চয় ব্যবহার করুন', daily.collectionTypes.savings) +
      row('dc_allowAdvance', 'অগ্রিম কিস্তি গ্রহণ করুন', !!daily.allowAdvance) +
      '<h2>Payment Methods</h2>' +
      Object.entries(methods).map(([k, v]) => row('pm_' + k, k, v)).join('') +
      '<h2>List Columns</h2>' +
      Object.entries(cols).map(([k, v]) => row('pc_' + k, k, v)).join('') +
      '<h2>Options</h2>' +
      row('allowAdvanceDefault', 'Allow advance payment by default', !!c.allowAdvanceDefault);
  }

  function collect() {
    const c = getSync();
    Object.keys(c.methods || {}).forEach(k => {
      const el = document.getElementById('pm_' + k);
      if (el) c.methods[k] = el.checked;
    });
    Object.keys(c.listColumns || {}).forEach(k => {
      const el = document.getElementById('pc_' + k);
      if (el) c.listColumns[k] = el.checked;
    });
    const adv = document.getElementById('allowAdvanceDefault');
    if (adv) c.allowAdvanceDefault = adv.checked;
    c.dailyCollection = c.dailyCollection || merge(DAILY_DEFAULT, {});
    c.dailyCollection.collectionTypes.installment = !!document.getElementById('dc_installment')?.checked;
    c.dailyCollection.collectionTypes.savings = !!document.getElementById('dc_savings')?.checked;
    c.dailyCollection.allowAdvance = !!document.getElementById('dc_allowAdvance')?.checked;
    return c;
  }

  async function saveDailyCollection(value) {
    const merged = merge(DAILY_DEFAULT, value);
    if (typeof SettingsAPI !== 'undefined') return await SettingsAPI.put(DAILY_KEY, merged);
    return merged;
  }

  document.addEventListener('DOMContentLoaded', async () => {
    const c = await load();
    render(c);
    const saveBtn = document.getElementById('savePaymentSettings');
    const resetBtn = document.getElementById('resetPaymentSettings');
    if (saveBtn) {
      saveBtn.onclick = async () => {
        try {
          const value = collect();
          await save(value);
          if (value.dailyCollection) await saveDailyCollection(value.dailyCollection);
          if (typeof Utils !== 'undefined') Utils.showMessage('paymentSettingsMessage', 'Settings saved.', 'success');
        } catch (e) {
          if (typeof Utils !== 'undefined') Utils.showMessage('paymentSettingsMessage', e.message || 'Save failed', 'error');
        }
      };
    }
    if (resetBtn) {
      resetBtn.onclick = async () => {
        try {
          await save(DEFAULT);
          await saveDailyCollection(DAILY_DEFAULT);
          const reset = merge(DEFAULT, { dailyCollection: DAILY_DEFAULT });
          render(reset);
          if (typeof Utils !== 'undefined') Utils.showMessage('paymentSettingsMessage', 'Reset to default.', 'success');
        } catch (e) {
          if (typeof Utils !== 'undefined') Utils.showMessage('paymentSettingsMessage', e.message || 'Reset failed', 'error');
        }
      };
    }
  });

  window.PaymentSettings = { load, getSync, save, saveDailyCollection, DEFAULT, DAILY_DEFAULT };
})();
