(function () {
  'use strict';
  const KEY = 'loan_ui_config';
  const DEFAULT = {
    formFields: {
      loanType: true, loanPurpose: true, loanAmount: true, interestAmount: true,
      numberOfInstallments: true, installmentFrequency: true, startDate: true,
      firstInstallmentDate: true, branchId: true
    },
    defaults: { installmentFrequency: 'daily', interestRateHint: true },
    weeklyOffDay:5, skipFriday:true, allowAdvance:true, allowFullSettlement:true, renewalMode:'new_loan',
    listColumns: {
      loanNumber: true, memberName: true, loanAmount: true,
      outstanding: true, status: true, branch: true
    },
    dashboardCards: { totalLoans: true, totalDisbursed: true, totalOutstanding: true, activeLoans: true }
  };

  function merge(a, b) {
    const o = { ...a };
    Object.keys(b || {}).forEach(k => {
      o[k] = b[k] && typeof b[k] === 'object' && !Array.isArray(b[k])
        ? merge(a[k] || {}, b[k]) : b[k];
    });
    return o;
  }

  let cache = null;

  async function load() {
    try {
      if (typeof SettingsAPI !== 'undefined') {
        cache = merge(DEFAULT, await SettingsAPI.get(KEY));
      } else {
        cache = merge(DEFAULT, {});
      }
    } catch (e) {
      console.warn('loan settings load failed', e);
      cache = merge(DEFAULT, {});
    }
    return cache;
  }

  function getSync() {
    return cache ? merge(DEFAULT, cache) : merge(DEFAULT, {});
  }

  async function save(value) {
    const merged = merge(DEFAULT, value);
    if (typeof SettingsAPI !== 'undefined') {
      cache = await SettingsAPI.put(KEY, merged);
    } else {
      cache = merged;
    }
    return cache;
  }

  function row(id, label, checked) {
    return `<label class="checkbox-row"><input type="checkbox" id="${id}" ${checked ? 'checked' : ''}> ${label}</label>`;
  }

  function render(c) {
    const host = document.getElementById('loanSettingsFields');
    if (!host) return;
    const ff = c.formFields || {};
    const lc = c.listColumns || {};
    host.innerHTML =
      '<h2>Form Fields</h2>' +
      Object.entries(ff).map(([k, v]) => row('ff_' + k, k, v)).join('') +
      '<h2>List Columns</h2>' +
      Object.entries(lc).map(([k, v]) => row('lc_' + k, k, v)).join('') +
      '<h2>ঋণ/কিস্তি নিয়ম</h2>' +
      '<label>ডিফল্ট ফ্রিকোয়েন্সি <select id="defaultFrequency"><option value="daily">দৈনিক</option><option value="weekly">সাপ্তাহিক</option><option value="biweekly">পাক্ষিক</option><option value="monthly">মাসিক</option></select></label>' +
      '<label class="checkbox-row"><input type="checkbox" id="skipFriday"> শুক্রবার কিস্তি বন্ধ</label>' +
      '<label class="checkbox-row"><input type="checkbox" id="allowAdvance"> এডভান্স কিস্তি গ্রহণ</label>' +
      '<label class="checkbox-row"><input type="checkbox" id="allowFullSettlement"> একবারে সম্পূর্ণ পরিশোধ</label>';
  }

  function collect() {
    const c = getSync();
    c.defaults = c.defaults || {};
    c.defaults.installmentFrequency = document.getElementById('defaultFrequency')?.value || 'daily';
    c.skipFriday = !!document.getElementById('skipFriday')?.checked;
    c.allowAdvance = !!document.getElementById('allowAdvance')?.checked;
    c.allowFullSettlement = !!document.getElementById('allowFullSettlement')?.checked;
    Object.keys(c.formFields || {}).forEach(k => {
      const el = document.getElementById('ff_' + k);
      if (el) c.formFields[k] = el.checked;
    });
    Object.keys(c.listColumns || {}).forEach(k => {
      const el = document.getElementById('lc_' + k);
      if (el) c.listColumns[k] = el.checked;
    });
    return c;
  }

  document.addEventListener('DOMContentLoaded', async () => {
    const c = await load();
    render(c);
    const df=document.getElementById('defaultFrequency'); if(df) df.value=c.defaults?.installmentFrequency||'daily';
    const sf=document.getElementById('skipFriday'); if(sf) sf.checked=c.skipFriday!==false;
    const aa=document.getElementById('allowAdvance'); if(aa) aa.checked=c.allowAdvance!==false;
    const fs=document.getElementById('allowFullSettlement'); if(fs) fs.checked=c.allowFullSettlement!==false;
    const saveBtn = document.getElementById('saveLoanSettings');
    const resetBtn = document.getElementById('resetLoanSettings');
    if (saveBtn) {
      saveBtn.onclick = async () => {
        try {
          await save(collect());
          if (typeof Utils !== 'undefined') Utils.showMessage('loanSettingsMessage', 'Settings saved.', 'success');
        } catch (e) {
          if (typeof Utils !== 'undefined') Utils.showMessage('loanSettingsMessage', e.message || 'Save failed', 'error');
        }
      };
    }
    if (resetBtn) {
      resetBtn.onclick = async () => {
        try {
          await save(DEFAULT);
          render(DEFAULT);
          if (typeof Utils !== 'undefined') Utils.showMessage('loanSettingsMessage', 'Reset to default.', 'success');
        } catch (e) {
          if (typeof Utils !== 'undefined') Utils.showMessage('loanSettingsMessage', e.message || 'Reset failed', 'error');
        }
      };
    }
  });

  window.LoanSettings = { load, getSync, save, DEFAULT };
})();
