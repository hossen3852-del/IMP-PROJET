(function () {
  'use strict';
  const KEY = 'member_registration_ui';
  const DEFAULT = {
    layout: 'two-column',
    memberPhotoVisible: true,
    memberPhotoRequired: false,
    nomineeVisible: true,
    nomineePhotoVisible: true,
    nomineePhotoRequired: false,
    nomineeRequired: true,
    memberFields: {
      fullName: true, fatherName: true, motherName: true, spouseName: true,
      dateOfBirth: true, gender: true, nid: true, mobile: true, email: true,
      occupation: true, monthlyIncome: true, sourceOfIncome: true, address: true
    },
    nomineeFields: { name: true, relation: true, nid: true, mobile: true, address: true }
  };
  const labels = {
    fullName: 'পূর্ণ নাম', fatherName: 'পিতার নাম', motherName: 'মাতার নাম',
    spouseName: 'স্বামী/স্ত্রীর নাম', dateOfBirth: 'জন্মতারিখ', gender: 'লিঙ্গ',
    nid: 'NID', mobile: 'মোবাইল', email: 'ইমেইল', occupation: 'পেশা',
    monthlyIncome: 'মাসিক আয়', sourceOfIncome: 'আয়ের উৎস', address: 'ঠিকানা',
    name: 'নমিনির নাম', relation: 'সম্পর্ক'
  };

  function merge(a, b) {
    const o = { ...a };
    Object.keys(b || {}).forEach(k => {
      o[k] = b[k] && typeof b[k] === 'object' && !Array.isArray(b[k])
        ? merge(a[k] || {}, b[k]) : b[k];
    });
    return o;
  }

  let cache = null;

  async function load() {
    try {
      if (typeof SettingsAPI !== 'undefined') {
        cache = merge(DEFAULT, await SettingsAPI.get(KEY));
      } else cache = merge(DEFAULT, {});
    } catch (e) {
      console.warn('member registration settings load failed', e);
      cache = merge(DEFAULT, {});
    }
    return cache;
  }

  function getSync() { return cache ? merge(DEFAULT, cache) : merge(DEFAULT, {}); }

  async function save(value) {
    const merged = merge(DEFAULT, value);
    if (typeof SettingsAPI !== 'undefined') cache = await SettingsAPI.put(KEY, merged);
    else cache = merged;
    return cache;
  }

  function row(id, text, v) {
    return `<label class="checkbox-row"><input type="checkbox" id="${id}" ${v ? 'checked' : ''}> ${text}</label>`;
  }

  function render(c) {
    const h = document.getElementById('memberRegistrationFields');
    if (!h) return;
    h.innerHTML =
      '<h2>সদস্য</h2>' +
      row('memberPhotoVisible', 'সদস্যের ছবি দেখান', c.memberPhotoVisible) +
      row('memberPhotoRequired', 'সদস্যের ছবি বাধ্যতামূলক', c.memberPhotoRequired) +
      '<h2>নমিনি</h2>' +
      row('nomineeVisible', 'নমিনি সেকশন দেখান', c.nomineeVisible) +
      row('nomineePhotoVisible', 'নমিনির ছবি দেখান', c.nomineePhotoVisible) +
      row('nomineePhotoRequired', 'নমিনির ছবি বাধ্যতামূলক', c.nomineePhotoRequired) +
      row('nomineeRequired', 'নমিনি তথ্য বাধ্যতামূলক', c.nomineeRequired) +
      '<h2>Member Fields</h2>' +
      Object.entries(c.memberFields || {}).map(([k, v]) => row('m_' + k, labels[k] || k, v)).join('') +
      '<h2>Nominee Fields</h2>' +
      Object.entries(c.nomineeFields || {}).map(([k, v]) => row('n_' + k, labels[k] || k, v)).join('');
  }

  function collect() {
    const c = getSync();
    ['memberPhotoVisible', 'memberPhotoRequired', 'nomineeVisible', 'nomineePhotoVisible', 'nomineePhotoRequired', 'nomineeRequired']
      .forEach(k => { const el = document.getElementById(k); if (el) c[k] = el.checked; });
    Object.keys(c.memberFields || {}).forEach(k => {
      const el = document.getElementById('m_' + k);
      if (el) c.memberFields[k] = el.checked;
    });
    Object.keys(c.nomineeFields || {}).forEach(k => {
      const el = document.getElementById('n_' + k);
      if (el) c.nomineeFields[k] = el.checked;
    });
    return c;
  }

  document.addEventListener('DOMContentLoaded', async () => {
    const c = await load();
    render(c);
    const saveBtn = document.getElementById('saveMemberRegistrationConfig');
    const resetBtn = document.getElementById('resetMemberRegistrationConfig');
    if (saveBtn) {
      saveBtn.onclick = async () => {
        try {
          await save(collect());
          if (typeof Utils !== 'undefined') Utils.showMessage('memberRegistrationSettingsMessage', 'Settings saved.', 'success');
        } catch (e) {
          if (typeof Utils !== 'undefined') Utils.showMessage('memberRegistrationSettingsMessage', e.message || 'Save failed', 'error');
        }
      };
    }
    if (resetBtn) {
      resetBtn.onclick = async () => {
        try {
          await save(DEFAULT);
          render(DEFAULT);
          if (typeof Utils !== 'undefined') Utils.showMessage('memberRegistrationSettingsMessage', 'Reset to default.', 'success');
        } catch (e) {
          if (typeof Utils !== 'undefined') Utils.showMessage('memberRegistrationSettingsMessage', e.message || 'Reset failed', 'error');
        }
      };
    }
  });

  window.MemberRegistrationSettings = { load, getSync, save, DEFAULT };
})();
