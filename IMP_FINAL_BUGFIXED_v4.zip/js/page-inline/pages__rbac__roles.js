document.addEventListener("DOMContentLoaded", async () => {
    await RBACManager.bootstrap();

    if (!(await AccessGuard.requirePermission("role.view"))) return;

    const container = document.getElementById("roleList");
    try {
        const result = await IMP_API.get("/rbac/roles");
        (result.roles || []).forEach(role => {
            const card = document.createElement("div");
            card.className = "role-card";
            const permissionCount = role.is_system ? "System role" : "Organization role";
            card.innerHTML = `
                <h3>${Utils.escapeHtml(role.name)}</h3>
                <p>${Utils.escapeHtml(role.description || "")}</p>
                <strong>Scope:</strong>
                <span>${Utils.escapeHtml(permissionCount)}</span>
            `;
            container.appendChild(card);
        });
    } catch (error) {
        container.innerHTML = `<p>Unable to load roles.</p>`;
        console.error("[IMP] RBAC roles load failed:", error);
    }
});
