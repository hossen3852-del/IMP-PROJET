document.addEventListener(
    "DOMContentLoaded",
    async () => {


        /* =====================================================
           AUTHENTICATION CHECK
        ====================================================== */

        if (
            !(await SessionManager.requireAuth())
        ) {

            return;

        }



        /* =====================================================
           ORGANIZATION VIEW PERMISSION
        ====================================================== */

        if (
            !(await AccessGuard.requirePermission(
                "organization.view",
                "../dashboard/dashboard.html"
            ))
        ) {

            return;

        }



        /* =====================================================
           ELEMENTS
        ====================================================== */

        const form =
            document.getElementById(
                "organizationForm"
            );


        const alertBox =
            document.getElementById(
                "organizationAlert"
            );


        const saveButton =
            document.getElementById(
                "saveOrganizationButton"
            );



        /* =====================================================
           CURRENT ORGANIZATION
        ====================================================== */

        let organization = null;



        /* =====================================================
           LOAD EXISTING ORGANIZATION FROM API
        ====================================================== */

        OrganizationManager.getCurrent().then(function (loaded) {
            organization = loaded;
            if (organization) {


            document.getElementById(
                "organizationName"
            ).value =
                organization.name || "";


            document.getElementById(
                "organizationPhone"
            ).value =
                organization.phone || "";


            document.getElementById(
                "organizationEmail"
            ).value =
                organization.email || "";


            document.getElementById(
                "organizationAddress"
            ).value =
                organization.address || "";


            document.getElementById(
                "organizationStatus"
            ).value =
                organization.status || "active";

        }
        }).catch(function (error) {
            Utils.showMessage(alertBox, error.message || "Unable to load organization.", "error");
        });


        /* =====================================================
           APPLY ELEMENT LEVEL RBAC
        ====================================================== */

        AccessGuard.apply();



        /* =====================================================
           FORM SUBMIT
        ====================================================== */

        form.addEventListener(
            "submit",
            async event => {


                event.preventDefault();



                /* =============================================
                   UPDATE PERMISSION CHECK
                ============================================== */

                if (
                    !RBACManager.hasPermission(
                        "organization.update"
                    )
                ) {

                    Utils.showMessage(
                        alertBox,
                        "You do not have permission to update organization.",
                        "error"
                    );

                    alertBox.style.display =
                        "block";

                    return;

                }



                try {


                    /* =========================================
                       COLLECT FORM DATA
                    ========================================== */

                    const data = {

                        name:
                            Utils.normalizeText(
                                document.getElementById(
                                    "organizationName"
                                ).value
                            ),


                        phone:
                            Utils.normalizeText(
                                document.getElementById(
                                    "organizationPhone"
                                ).value
                            ),


                        email:
                            Utils.normalizeEmail(
                                document.getElementById(
                                    "organizationEmail"
                                ).value
                            ),


                        address:
                            Utils.normalizeText(
                                document.getElementById(
                                    "organizationAddress"
                                ).value
                            ),


                        status:
                            document.getElementById(
                                "organizationStatus"
                            ).value

                    };



                    /* =========================================
                       VALIDATION
                    ========================================== */

                    if (!data.name) {

                        throw new Error(
                            "Organization name is required."
                        );

                    }



                    if (
                        data.email &&
                        !Utils.isValidEmail(
                            data.email
                        )
                    ) {

                        throw new Error(
                            "Please enter a valid email address."
                        );

                    }



                    /* =========================================
                       UPDATE EXISTING ORGANIZATION
                    ========================================== */

                    if (organization) {


                        organization = await OrganizationManager.update(
                            organization.id,
                            data
                        );


                    }



                    /* =========================================
                       CREATE NEW ORGANIZATION
                    ========================================== */

                    else {
                        throw new Error("Organization creation is performed during registration.");
                    }


                    /* =========================================
                       SUCCESS MESSAGE
                    ========================================== */

                    Utils.showMessage(
                        alertBox,
                        "Organization saved successfully.",
                        "success"
                    );


                    alertBox.style.display =
                        "block";



                    /* =========================================
                       DISABLE BUTTON TEMPORARILY
                    ========================================== */

                    saveButton.disabled =
                        true;


                    saveButton.textContent =
                        "Saved";



                    /* =========================================
                       RELOAD
                    ========================================== */

                    setTimeout(
                        () => {

                            window.location.reload();

                        },
                        700
                    );


                }


                /* =============================================
                   ERROR
                ============================================== */

                catch (error) {


                    Utils.showMessage(
                        alertBox,
                        error.message ||
                            "Failed to save organization.",
                        "error"
                    );


                    alertBox.style.display =
                        "block";

                }

            }
        );

    }
);
