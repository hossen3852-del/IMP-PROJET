(async () => {
if (!(await SessionManager.requireAuth())) return;

const memberId =
    Utils.getQueryParam("id");

(async () => { await MemberDocumentsManager.render(memberId); })();

document
    .getElementById("documentForm")
    .addEventListener(
        "submit",
        event => {

            event.preventDefault();

            try {

                MemberDocumentsManager
                    .addDocument(
                        memberId,
                        {

                            type:
                                document
                                    .getElementById(
                                        "documentType"
                                    )
                                    .value,

                            name:
                                document
                                    .getElementById(
                                        "documentName"
                                    )
                                    .value
                                    .trim(),

                            reference:
                                document
                                    .getElementById(
                                        "documentReference"
                                    )
                                    .value
                                    .trim(),

                            description:
                                document
                                    .getElementById(
                                        "documentDescription"
                                    )
                                    .value
                                    .trim()
                        }
                    );

                event.target.reset();

                MemberDocumentsManager
                    .render(
                        memberId
                    );

                Utils.showMessage(
                    "Document added.",
                    "success"
                );

            } catch (error) {

                Utils.showMessage(
                    error.message,
                    "error"
                );
            }
        }
    );

})();
