document.addEventListener(
    "DOMContentLoaded",
    async () => {

        if (
            !(await SessionManager.requireAuth())
        ) {

            return;

        }


        const organizationId =
            SessionManager
                .getOrganizationId();


        const table =
            document.getElementById(
                "branchTable"
            );


        const form =
            document.getElementById(
                "branchForm"
            );


        const message =
            document.getElementById(
                "branchMessage"
            );


        async function renderBranches() {

            table.innerHTML = "";

            let branches;
            try {
                branches = await BranchManager.getOrganizationBranches(organizationId);
            } catch (error) {
                Utils.showMessage(message, error.message || "Unable to load branches.", "error");
                return;
            }


            if (!branches.length) {

                table.innerHTML = `
                    <tr>
                        <td colspan="5">
                            No branches found.
                        </td>
                    </tr>
                `;

                return;

            }


            branches.forEach(
                branch => {

                    const row =
                        document.createElement(
                            "tr"
                        );


                    row.innerHTML = `

                        <td>
                            ${Utils.escapeHtml(
                                branch.branchCode
                            )}
                        </td>

                        <td>
                            ${Utils.escapeHtml(
                                branch.name
                            )}
                        </td>

                        <td>
                            ${Utils.escapeHtml(
                                branch.managerName ||
                                "-"
                            )}
                        </td>

                        <td>
                            ${Utils.escapeHtml(
                                branch.phone ||
                                "-"
                            )}
                        </td>

                        <td>
                            ${Utils.escapeHtml(
                                branch.status
                            )}
                        </td>

                    `;


                    table.appendChild(
                        row
                    );

                }
            );

        }


        form.addEventListener(
            "submit",
            async event => {

                event.preventDefault();


                try {

                    await BranchManager.create({

                        organizationId,

                        name:
                            document.getElementById(
                                "branchName"
                            ).value,

                        phone:
                            document.getElementById(
                                "branchPhone"
                            ).value,

                        managerName:
                            document.getElementById(
                                "managerName"
                            ).value,

                        address:
                            document.getElementById(
                                "branchAddress"
                            ).value

                    });


                    Utils.showMessage(
                        message,
                        "Branch created successfully.",
                        "success"
                    );


                    form.reset();

                    renderBranches();


                } catch (error) {

                    Utils.showMessage(
                        message,
                        error.message,
                        "error"
                    );

                }

            }
        );


        renderBranches();

    }
);
