(async () => {
if (!(await SessionManager.requireAuth())) return;

const memberId =
    Utils.getQueryParam("id");

(async () => { await MemberManager.preload(memberId); await MemberNomineeManager.render(memberId); })();

document
    .getElementById("nomineeForm")
    .addEventListener(
        "submit",
        async event => {

            event.preventDefault();

            try {

                await MemberNomineeManager.save(
                    memberId,
                    {

                        name:
                            document
                                .getElementById(
                                    "nomineeName"
                                )
                                .value
                                .trim(),

                        relation:
                            document
                                .getElementById(
                                    "nomineeRelation"
                                )
                                .value
                                .trim(),

                        mobile:
                            document
                                .getElementById(
                                    "nomineeMobile"
                                )
                                .value
                                .trim(),

                        nid:
                            document
                                .getElementById(
                                    "nomineeNid"
                                )
                                .value
                                .trim(),

                        address:
                            document
                                .getElementById(
                                    "nomineeAddress"
                                )
                                .value
                                .trim()
                    }
                );

                Utils.showMessage(
                    "Nominee saved successfully.",
                    "success"
                );

            } catch (error) {

                Utils.showMessage(
                    error.message,
                    "error"
                );
            }
        }
    );

})();
