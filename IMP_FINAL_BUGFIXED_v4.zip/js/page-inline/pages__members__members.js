(async function () {
    try {
        await SessionManager.waitUntilReady();
        if (!SessionManager.isAuthenticated()) {
            SessionManager.redirectToLogin();
            return;
        }

        // Critical: permissions arrive asynchronously from /api/auth/me.
        // Do not evaluate member.create before RBAC bootstrap completes.
        await RBACManager.bootstrap();

        if (!RBACManager.hasPermission(PERMISSIONS.MEMBER_VIEW)) {
            Utils.showMessage("You do not have permission to view members.", "error");
            return;
        }

        const addButton = document.getElementById("addMemberButton");
        if (!RBACManager.hasPermission(PERMISSIONS.MEMBER_CREATE) && addButton) {
            addButton.style.display = "none";
        }

        // BranchManager is API-backed and therefore returns a Promise.
        const branches = await BranchManager.getOrganizationBranches();
        const branchFilter = document.getElementById("branchFilter");

        branches.forEach(branch => {
            const option = document.createElement("option");
            option.value = branch.id;
            option.textContent = branch.name;
            branchFilter.appendChild(option);
        });

        await MemberListManager.init();
    } catch (error) {
        console.error("[IMP] Members page initialization failed:", error);
        Utils.showMessage(error.message || "Unable to initialize member management.", "error");
    }
})();
