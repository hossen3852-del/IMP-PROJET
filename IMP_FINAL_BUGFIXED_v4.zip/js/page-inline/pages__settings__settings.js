(async function () {
  try {
    await SessionManager.requireAuth();
    await RBACManager.bootstrap();
    if (typeof AccessGuard !== 'undefined' && AccessGuard.apply) AccessGuard.apply();
    const me = await IMP_API.get('/auth/me');
    const role = me?.user?.role || '';
    document.querySelectorAll('[data-role]').forEach(el => {
      if (el.dataset.role && el.dataset.role !== role) el.remove();
    });
  } catch (e) {
    console.error(e);
  }
})();
