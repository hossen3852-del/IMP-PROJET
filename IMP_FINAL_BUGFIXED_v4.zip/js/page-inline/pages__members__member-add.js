/**
 * IMP Member Add Page Controller
 *
 * Responsibilities:
 * 1. Authentication
 * 2. RBAC permission
 * 3. Branch loading
 * 4. Registration settings
 * 5. Photo preview
 * 6. Member form initialization
 */

(async function () {

    "use strict";


    // =========================================================
    // DOM Helpers
    // =========================================================

    const branchSelect =
        document.getElementById(
            "branchId"
        );

    const branchHelp =
        document.getElementById(
            "branchHelp"
        );

    const submitButton =
        document.getElementById(
            "saveMember"
        );


    // =========================================================
    // Message Helper
    // =========================================================

    function showError(message) {

        if (
            typeof Utils !== "undefined" &&
            typeof Utils.showMessage === "function"
        ) {

            Utils.showMessage(
                message,
                "error"
            );

        } else {

            console.error(
                "[IMP]",
                message
            );
        }
    }


    // =========================================================
    // Escape HTML
    // =========================================================

    function escapeHtml(value) {

        return String(
            value ?? ""
        )
            .replace(
                /&/g,
                "&amp;"
            )
            .replace(
                /</g,
                "&lt;"
            )
            .replace(
                />/g,
                "&gt;"
            )
            .replace(
                /"/g,
                "&quot;"
            )
            .replace(
                /'/g,
                "&#039;"
            );
    }


    // =========================================================
    // Role Detection
    // =========================================================

    function getCurrentRole(session) {

        return (
            session?.role_code ||
            session?.role ||
            ""
        );
    }


    // =========================================================
    // Organization-wide Role
    // =========================================================

    function isOrganizationWideRole(role) {

        return (
            role === "organization_admin" ||
            role === "super_admin"
        );
    }


    // =========================================================
    // Load Branches
    // =========================================================

    async function loadBranches(session) {

        if (!branchSelect) {

            throw new Error(
                "Branch selector is missing."
            );
        }


        const role =
            getCurrentRole(
                session
            );


        const organizationWide =
            isOrganizationWideRole(
                role
            );


        // =====================================================
        // Organization Admin / Super Admin
        // =====================================================

        if (organizationWide) {

            branchSelect.disabled =
                true;


            branchSelect.innerHTML =
                `<option value="">
                    শাখা লোড হচ্ছে...
                </option>`;


            if (
                typeof BranchManager ===
                "undefined" ||
                typeof BranchManager.getAll !==
                "function"
            ) {

                throw new Error(
                    "Branch manager is not available."
                );
            }


            const branches =
                await BranchManager.getAll();


            /*
             * Backend /api/branches returns:
             *
             * {
             *     id,
             *     branch_code,
             *     name,
             *     status
             * }
             *
             * BranchManager returns the same server
             * object.
             */


            const activeBranches =
                Array.isArray(branches)
                    ? branches.filter(
                        branch =>
                            branch &&
                            branch.id &&
                            (
                                !branch.status ||
                                branch.status === "active"
                            )
                    )
                    : [];


            if (!activeBranches.length) {

                branchSelect.innerHTML =
                    `<option value="">
                        কোনো active branch পাওয়া যায়নি
                    </option>`;


                if (branchHelp) {

                    branchHelp.textContent =
                        "সদস্য তৈরি করার আগে অন্তত একটি active branch তৈরি করুন.";
                }


                throw new Error(
                    "No active branch is available. Please create a branch first."
                );
            }


            branchSelect.innerHTML =
                `<option value="">
                    -- শাখা নির্বাচন করুন --
                </option>` +
                activeBranches
                    .map(
                        branch => {

                            const name =
                                branch.name ||
                                branch.branch_name ||
                                "Branch";


                            const code =
                                branch.branch_code ||
                                branch.branchCode ||
                                "";


                            const label =
                                code
                                    ? `${name} (${code})`
                                    : name;


                            return `
                                <option
                                    value="${escapeHtml(branch.id)}"
                                >
                                    ${escapeHtml(label)}
                                </option>
                            `;
                        }
                    )
                    .join("");


            branchSelect.disabled =
                false;


            branchSelect.required =
                true;


            if (branchHelp) {

                branchHelp.textContent =
                    "Organization Admin/Super Admin হিসেবে সদস্য কোন শাখায় থাকবে তা নির্বাচন করুন.";
            }


            return;
        }


        // =====================================================
        // Branch-level User
        // =====================================================

        let ownBranchId =
            null;


        if (
            typeof SessionManager !==
            "undefined" &&
            typeof SessionManager.getBranchId ===
            "function"
        ) {

            ownBranchId =
                SessionManager.getBranchId();
        }


        if (!ownBranchId) {

            branchSelect.innerHTML =
                `<option value="">
                    Branch assigned নয়
                </option>`;


            branchSelect.disabled =
                true;


            throw new Error(
                "Your account is not assigned to a branch."
            );
        }


        // -----------------------------------------------------
        // Verify branch through API
        // -----------------------------------------------------

        let ownBranch = null;


        try {

            if (
                typeof BranchManager !==
                "undefined" &&
                typeof BranchManager.getById ===
                "function"
            ) {

                ownBranch =
                    await BranchManager.getById(
                        ownBranchId
                    );
            }

        } catch (error) {

            console.warn(
                "[IMP] Unable to load assigned branch:",
                error
            );
        }


        const branchName =
            ownBranch?.name ||
            ownBranch?.branch_name ||
            "আমার শাখা";


        const branchCode =
            ownBranch?.branch_code ||
            ownBranch?.branchCode ||
            "";


        const label =
            branchCode
                ? `${branchName} (${branchCode})`
                : branchName;


        branchSelect.innerHTML =
            `
                <option
                    value="${escapeHtml(ownBranchId)}"
                >
                    ${escapeHtml(label)}
                </option>
            `;


        branchSelect.value =
            ownBranchId;


        /*
         * Disabled select values are NOT normally included
         * in FormData, but our collectData() reads the DOM
         * value directly, so this is safe.
         */

        branchSelect.disabled =
            true;


        branchSelect.required =
            true;


        if (branchHelp) {

            branchHelp.textContent =
                "আপনার account-এর assigned branch automatically নির্ধারিত হয়েছে.";
        }
    }


    // =========================================================
    // Registration Settings
    // =========================================================

    async function loadRegistrationConfig() {

        try {

            if (
                typeof MemberRegistrationSettings !==
                "undefined"
            ) {

                if (
                    typeof MemberRegistrationSettings.load ===
                    "function"
                ) {

                    return await MemberRegistrationSettings
                        .load();
                }


                if (
                    typeof MemberRegistrationSettings.getSync ===
                    "function"
                ) {

                    return MemberRegistrationSettings
                        .getSync();
                }


                if (
                    MemberRegistrationSettings.DEFAULT
                ) {

                    return MemberRegistrationSettings
                        .DEFAULT;
                }
            }

        } catch (error) {

            console.warn(
                "[IMP] Registration settings load failed:",
                error
            );
        }


        return {};
    }


    // =========================================================
    // Apply Registration Settings
    // =========================================================

    function applyRegistrationConfig(config) {

        const c =
            config || {};


        // -----------------------------------------------------
        // Nominee panel
        // -----------------------------------------------------

        const nomineePanel =
            document.getElementById(
                "nomineePanel"
            );


        if (nomineePanel) {

            nomineePanel.hidden =
                c.nomineeVisible === false;
        }


        // -----------------------------------------------------
        // Member Photo
        // -----------------------------------------------------

        const memberPhoto =
            document.getElementById(
                "memberPhoto"
            );


        if (memberPhoto) {

            const label =
                memberPhoto.closest(
                    "label"
                );


            if (label) {

                label.style.display =
                    c.memberPhotoVisible === false
                        ? "none"
                        : "";
            }


            memberPhoto.required =
                !!c.memberPhotoRequired;
        }


        // -----------------------------------------------------
        // Nominee Photo
        // -----------------------------------------------------

        const nomineePhoto =
            document.getElementById(
                "nomineePhoto"
            );


        if (nomineePhoto) {

            const label =
                nomineePhoto.closest(
                    "label"
                );


            if (label) {

                label.style.display =
                    c.nomineePhotoVisible === false
                        ? "none"
                        : "";
            }


            nomineePhoto.required =
                !!c.nomineePhotoRequired;
        }


        // -----------------------------------------------------
        // Nominee Required
        // -----------------------------------------------------

        const nomineeName =
            document.getElementById(
                "nomineeName"
            );


        if (nomineeName) {

            nomineeName.required =
                c.nomineeVisible !== false &&
                c.nomineeRequired !== false;
        }


        // -----------------------------------------------------
        // Member Fields
        // -----------------------------------------------------

        Object.entries(
            c.memberFields || {}
        ).forEach(
            ([id, visible]) => {

                const element =
                    document.getElementById(
                        id
                    );


                if (!element) {
                    return;
                }


                const wrapper =
                    element.closest(
                        "div"
                    );


                if (!wrapper) {
                    return;
                }


                wrapper.style.display =
                    visible === false
                        ? "none"
                        : "";
            }
        );


        // -----------------------------------------------------
        // Nominee Fields
        // -----------------------------------------------------

        Object.entries(
            c.nomineeFields || {}
        ).forEach(
            ([key, visible]) => {

                const map = {

                    name:
                        "nomineeName",

                    relation:
                        "nomineeRelation",

                    nid:
                        "nomineeNid",

                    mobile:
                        "nomineeMobile",

                    address:
                        "nomineeAddress"
                };


                const id =
                    map[key] || key;


                const element =
                    document.getElementById(
                        id
                    );


                if (!element) {
                    return;
                }


                const wrapper =
                    element.closest(
                        "div"
                    );


                if (!wrapper) {
                    return;
                }


                wrapper.style.display =
                    visible === false
                        ? "none"
                        : "";
            }
        );
    }


    // =========================================================
    // Photo Preview
    // =========================================================

    function bindPhotoPreview(
        input,
        target
    ) {

        if (
            !input ||
            !target
        ) {
            return;
        }


        input.addEventListener(
            "change",
            () => {

                const file =
                    input.files?.[0];


                if (!file) {
                    return;
                }


                const reader =
                    new FileReader();


                reader.onload =
                    () => {

                        target.innerHTML =
                            '<img alt="photo preview">';


                        const image =
                            target.querySelector(
                                "img"
                            );


                        if (image) {

                            image.src =
                                reader.result;
                        }
                    };


                reader.readAsDataURL(
                    file
                );
            }
        );
    }


    // =========================================================
    // Initialize
    // =========================================================

    try {

        // -----------------------------------------------------
        // Authentication
        // -----------------------------------------------------

        if (
            typeof SessionManager ===
            "undefined"
        ) {

            throw new Error(
                "Session manager is not available."
            );
        }


        const session =
            await SessionManager
                .ensureAuthenticated();


        if (!session) {
            return;
        }


        // -----------------------------------------------------
        // RBAC
        // -----------------------------------------------------

        if (
            typeof RBACManager ===
            "undefined"
        ) {

            throw new Error(
                "RBAC manager is not available."
            );
        }


        await RBACManager
            .bootstrap();


        if (
            !RBACManager.hasPermission(
                "member.create"
            )
        ) {

            throw new Error(
                "You do not have permission to create members."
            );
        }


        // -----------------------------------------------------
        // Branch
        // -----------------------------------------------------

        await loadBranches(
            session
        );


        const memberOrigin = document.getElementById("memberOrigin");
        const legacyFields = document.getElementById("legacyMemberFields");
        const toggleLegacy = () => { if (legacyFields) legacyFields.classList.toggle("legacy-member-fields", memberOrigin?.value === "previous_borrower"); legacyFields?.classList.toggle("hidden", memberOrigin?.value !== "previous_borrower"); };
        memberOrigin?.addEventListener("change", toggleLegacy);
        toggleLegacy();

        // -----------------------------------------------------
        // Registration Settings
        // -----------------------------------------------------

        const config =
            await loadRegistrationConfig();


        applyRegistrationConfig(
            config
        );


        // -----------------------------------------------------
        // Photo Preview
        // -----------------------------------------------------

        bindPhotoPreview(
            document.getElementById(
                "memberPhoto"
            ),
            document.getElementById(
                "memberPhotoPreview"
            )
        );


        bindPhotoPreview(
            document.getElementById(
                "nomineePhoto"
            ),
            document.getElementById(
                "nomineePhotoPreview"
            )
        );


        // -----------------------------------------------------
        // Member Form
        // -----------------------------------------------------

        if (
            typeof MemberFormManager ===
            "undefined"
        ) {

            throw new Error(
                "Member form manager is not available."
            );
        }


        MemberFormManager
            .bindCreateForm();


        // -----------------------------------------------------
        // Ready
        // -----------------------------------------------------

        if (submitButton) {

            submitButton.disabled =
                false;
        }


        console.log(
            "[IMP] Member add page initialized successfully."
        );

    } catch (error) {

        console.error(
            "[IMP] Member add initialization failed:",
            error
        );


        if (submitButton) {

            submitButton.disabled =
                true;
        }


        showError(
            error?.message ||
            "Member registration could not be initialized."
        );
    }

})();