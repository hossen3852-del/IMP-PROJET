(async () => {
if (!(await SessionManager.requireAuth())) return;

const memberId =
    Utils.getQueryParam("id");

(async () => { await MemberActivityManager.render(memberId); })();

})();
