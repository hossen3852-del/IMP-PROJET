(async function () {
        try {
            await SessionManager.requireAuth();
            await RBACManager.bootstrap();
            if (!RBACManager.hasPermission("payment.create")) {
                const box = document.getElementById("paymentMessage");
                if (box) { box.textContent = "You do not have permission to create payments."; box.className = "payment-message error"; }
                return;
            }
            if (typeof initializePaymentEntry === "function") initializePaymentEntry();
        } catch (error) {
            const box = document.getElementById("paymentMessage");
            if (box) { box.textContent = error.message || "Unable to initialize payment entry."; box.className = "payment-message error"; }
        }
    })();
