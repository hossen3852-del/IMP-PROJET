(async function () {
    if (!(await SessionManager.requireAuth())) return;
    const memberId = Utils.getQueryParam('id');
    if (!memberId) return;
    try {
        await MemberManager.preload(memberId);
        const form = document.getElementById('statusForm');
        if (form) form.addEventListener('submit', async (event) => {
            event.preventDefault();
            try {
                const status = document.getElementById('status')?.value || document.getElementById('memberStatus')?.value;
                const reason = document.getElementById('reason')?.value || '';
                await MemberStatusManager.changeStatus(memberId, status, reason);
                if (typeof Utils !== 'undefined') Utils.showMessage('Member status updated successfully.', 'success');
            } catch (e) { if (typeof Utils !== 'undefined') Utils.showMessage(e.message, 'error'); }
        });
    } catch (e) { if (typeof Utils !== 'undefined') Utils.showMessage(e.message, 'error'); }
})();
