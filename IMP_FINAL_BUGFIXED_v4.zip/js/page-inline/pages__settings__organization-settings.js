document.addEventListener(
    "DOMContentLoaded",
    async () => {

        if (
            !(await SessionManager.requireAuth())
        ) {

            return;

        }


        const organizationId =
            SessionManager
                .getOrganizationId();


        if (!organizationId) {

            alert(
                "No organization is assigned to this account."
            );

            return;

        }


        const settings =
            await CompanySettingsManager.get(
                organizationId
            );


        document.getElementById(
            "currency"
        ).value =
            settings.currency;


        document.getElementById(
            "currencySymbol"
        ).value =
            settings.currencySymbol;


        document.getElementById(
            "dateFormat"
        ).value =
            settings.dateFormat;


        document.getElementById(
            "installmentFrequency"
        ).value =
            settings.installmentFrequency;


        document.getElementById(
            "defaultGraceDays"
        ).value =
            settings.defaultGraceDays;


        document.getElementById(
            "receiptPrefix"
        ).value =
            settings.receiptPrefix;


        document.getElementById(
            "memberPrefix"
        ).value =
            settings.memberPrefix;


        document.getElementById(
            "loanPrefix"
        ).value =
            settings.loanPrefix;


        document.getElementById(
            "smsEnabled"
        ).checked =
            settings.smsEnabled;


        document.getElementById(
            "emailEnabled"
        ).checked =
            settings.emailEnabled;


        document.getElementById(
            "appNotificationEnabled"
        ).checked =
            settings.appNotificationEnabled;


        document.getElementById(
            "settingsForm"
        ).addEventListener(
            "submit",
            async event => {

                event.preventDefault();


                const message =
                    document.getElementById(
                        "settingsMessage"
                    );


                try {

                    await CompanySettingsManager.save(
                        organizationId,
                        {

                            currency:
                                document.getElementById(
                                    "currency"
                                ).value,

                            currencySymbol:
                                document.getElementById(
                                    "currencySymbol"
                                ).value,

                            dateFormat:
                                document.getElementById(
                                    "dateFormat"
                                ).value,

                            installmentFrequency:
                                document.getElementById(
                                    "installmentFrequency"
                                ).value,

                            defaultGraceDays:
                                Number(
                                    document.getElementById(
                                        "defaultGraceDays"
                                    ).value
                                ),

                            receiptPrefix:
                                document.getElementById(
                                    "receiptPrefix"
                                ).value,

                            memberPrefix:
                                document.getElementById(
                                    "memberPrefix"
                                ).value,

                            loanPrefix:
                                document.getElementById(
                                    "loanPrefix"
                                ).value,

                            smsEnabled:
                                document.getElementById(
                                    "smsEnabled"
                                ).checked,

                            emailEnabled:
                                document.getElementById(
                                    "emailEnabled"
                                ).checked,

                            appNotificationEnabled:
                                document.getElementById(
                                    "appNotificationEnabled"
                                ).checked

                        }
                    );


                    Utils.showMessage(
                        message,
                        "Settings saved successfully.",
                        "success"
                    );


                } catch (error) {

                    Utils.showMessage(
                        message,
                        error.message,
                        "error"
                    );

                }

            }
        );

    }
);
