(async () => {
if (!(await SessionManager.requireAuth())) return;

const memberId =
    Utils.getQueryParam("id");

(async () => { await MemberManager.preload(memberId); await MemberFamilyManager.render(memberId); })();

document
    .getElementById("familyForm")
    .addEventListener(
        "submit",
        async event => {

            event.preventDefault();

            try {

                await MemberFamilyManager
                    .addFamilyMember(
                        memberId,
                        {

                            name:
                                document
                                    .getElementById(
                                        "familyName"
                                    )
                                    .value
                                    .trim(),

                            relation:
                                document
                                    .getElementById(
                                        "familyRelation"
                                    )
                                    .value
                                    .trim(),

                            mobile:
                                document
                                    .getElementById(
                                        "familyMobile"
                                    )
                                    .value
                                    .trim(),

                            occupation:
                                document
                                    .getElementById(
                                        "familyOccupation"
                                    )
                                    .value
                                    .trim(),

                            dateOfBirth:
                                document
                                    .getElementById(
                                        "familyDob"
                                    )
                                    .value
                        }
                    );

                event.target.reset();

                await MemberFamilyManager.render(
                    memberId
                );

                Utils.showMessage(
                    "Family member added.",
                    "success"
                );

            } catch (error) {

                Utils.showMessage(
                    error.message,
                    "error"
                );
            }
        }
    );

})();
