(async function () {
    try {
        const session = await SessionManager.ensureAuthenticated();
        if (!session) return;
        await RBACManager.bootstrap();
        await MemberProfileManager.init();
    } catch (error) {
        console.error(error);
        Utils.showMessage(error.message || "Unable to load member profile.", "error");
    }
})();
