(async function () {

if (!(await SessionManager.requireAuth())) return;

const memberId =
    Utils.getQueryParam("id");

const financial =
    await MemberFinancialManager.get(
        memberId
    );

document.getElementById(
    "occupation"
).value =
    financial.occupation || "";

document.getElementById(
    "monthlyIncome"
).value =
    financial.monthlyIncome || "";

document.getElementById(
    "sourceOfIncome"
).value =
    financial.sourceOfIncome || "";

document.getElementById(
    "bankAccount"
).value =
    financial.bankAccount || "";

document.getElementById(
    "mobileBanking"
).value =
    financial.mobileBanking || "";

document
    .getElementById("financialForm")
    .addEventListener(
        "submit",
        async event => {

            event.preventDefault();

            try {

                await MemberFinancialManager.save(
                    memberId,
                    {

                        occupation:
                            document
                                .getElementById(
                                    "occupation"
                                )
                                .value
                                .trim(),

                        monthlyIncome:
                            document
                                .getElementById(
                                    "monthlyIncome"
                                )
                                .value,

                        sourceOfIncome:
                            document
                                .getElementById(
                                    "sourceOfIncome"
                                )
                                .value
                                .trim(),

                        bankAccount:
                            document
                                .getElementById(
                                    "bankAccount"
                                )
                                .value
                                .trim(),

                        mobileBanking:
                            document
                                .getElementById(
                                    "mobileBanking"
                                )
                                .value
                                .trim()
                    }
                );

                Utils.showMessage(
                    "Financial profile saved.",
                    "success"
                );

            } catch (error) {

                Utils.showMessage(
                    error.message,
                    "error"
                );
            }
        }
    );


})();
