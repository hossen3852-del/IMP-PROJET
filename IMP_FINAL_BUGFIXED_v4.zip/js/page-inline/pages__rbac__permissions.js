document.addEventListener("DOMContentLoaded", async () => {
    await RBACManager.bootstrap();

    if (!(await AccessGuard.requirePermission("permission.view"))) return;

    const container = document.getElementById("permissionList");
    try {
        const result = await IMP_API.get("/rbac/permissions");
        (result.permissions || []).forEach(permission => {
            const row = document.createElement("div");
            row.className = "permission-row";
            row.textContent = permission.code;
            container.appendChild(row);
        });
    } catch (error) {
        container.innerHTML = `<p>Unable to load permissions.</p>`;
        console.error("[IMP] RBAC permissions load failed:", error);
    }
});
