/**
 * IMP — Member Edit Page Controller
 *
 * Responsibilities:
 * 1. Authentication
 * 2. RBAC permission
 * 3. Load member
 * 4. Load branch information
 * 5. Select current member branch
 * 6. Initialize edit form
 */

(async function () {

    "use strict";


    // =========================================================
    // DOM
    // =========================================================

    const branchSelect =
        document.getElementById("branchId");

    const branchHelp =
        document.getElementById("branchHelp");

    const form =
        document.getElementById("memberEditForm");


    // =========================================================
    // Message Helper
    // =========================================================

    function showMessage(
        message,
        type = "error"
    ) {

        if (
            typeof Utils !== "undefined" &&
            typeof Utils.showMessage === "function"
        ) {

            Utils.showMessage(
                message,
                type
            );

        } else {

            console.error(
                "[IMP]",
                message
            );
        }
    }


    // =========================================================
    // Escape HTML
    // =========================================================

    function escapeHtml(value) {

        return String(value ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }


    // =========================================================
    // Organization-wide Role
    // =========================================================

    function isOrganizationWideRole(role) {

        return (
            role === "super_admin" ||
            role === "organization_admin"
        );
    }


    // =========================================================
    // Get Current Role
    // =========================================================

    function getCurrentRole(session) {

        return (
            session?.role ||
            ""
        );
    }


    // =========================================================
    // Get Branch ID From Member
    // =========================================================

    function getMemberBranchId(member) {

        return (
            member?.branchId ||
            member?.branch_id ||
            null
        );
    }


    // =========================================================
    // Branch Label
    // =========================================================

    function getBranchLabel(branch) {

        const name =
            branch?.name ||
            branch?.branch_name ||
            "Branch";

        const code =
            branch?.branch_code ||
            branch?.branchCode ||
            "";

        return code
            ? `${name} (${code})`
            : name;
    }


    // =========================================================
    // Load Branches
    // =========================================================

    async function loadBranches(
        session,
        member
    ) {

        if (!branchSelect) {

            throw new Error(
                "Branch selector is missing from the page."
            );
        }


        const role =
            getCurrentRole(
                session
            );


        const organizationWide =
            isOrganizationWideRole(
                role
            );


        const memberBranchId =
            getMemberBranchId(
                member
            );


        // =====================================================
        // Organization Admin / Super Admin
        // =====================================================

        if (organizationWide) {

            branchSelect.disabled =
                true;


            branchSelect.innerHTML =
                `
                <option value="">
                    শাখা লোড হচ্ছে...
                </option>
                `;


            const branches =
                await BranchManager.getAll();


            if (
                !Array.isArray(branches)
            ) {

                throw new Error(
                    "Unable to load branches."
                );
            }


            // -------------------------------------------------
            // Only active branches
            // -------------------------------------------------

            const activeBranches =
                branches.filter(
                    branch => {

                        if (
                            !branch ||
                            !branch.id
                        ) {
                            return false;
                        }


                        return (
                            !branch.status ||
                            branch.status === "active"
                        );
                    }
                );


            // -------------------------------------------------
            // No branch
            // -------------------------------------------------

            if (
                activeBranches.length === 0
            ) {

                branchSelect.innerHTML =
                    `
                    <option value="">
                        কোনো active branch পাওয়া যায়নি
                    </option>
                    `;


                if (branchHelp) {

                    branchHelp.textContent =
                        "Member update করার জন্য অন্তত একটি active branch প্রয়োজন।";
                }


                throw new Error(
                    "No active branch is available."
                );
            }


            // -------------------------------------------------
            // Options
            // -------------------------------------------------

            branchSelect.innerHTML =
                `
                <option value="">
                    -- শাখা নির্বাচন করুন --
                </option>
                ` +
                activeBranches
                    .map(
                        branch => {

                            return `
                                <option value="${escapeHtml(branch.id)}">
                                    ${escapeHtml(
                                        getBranchLabel(branch)
                                    )}
                                </option>
                            `;
                        }
                    )
                    .join("");


            // -------------------------------------------------
            // Select member's current branch
            // -------------------------------------------------

            if (memberBranchId) {

                const exists =
                    activeBranches.some(
                        branch =>
                            String(branch.id) ===
                            String(memberBranchId)
                    );


                if (exists) {

                    branchSelect.value =
                        String(
                            memberBranchId
                        );

                } else {

                    /*
                     * Member may belong to an inactive branch.
                     *
                     * We should NOT silently move the member
                     * to another branch.
                     *
                     * Add the existing branch temporarily so
                     * the current value remains visible.
                     */

                    let currentBranch =
                        null;


                    try {

                        currentBranch =
                            await BranchManager.getById(
                                memberBranchId
                            );

                    } catch (error) {

                        console.warn(
                            "[IMP] Unable to load current member branch:",
                            error
                        );
                    }


                    if (currentBranch) {

                        const option =
                            document.createElement(
                                "option"
                            );


                        option.value =
                            String(
                                currentBranch.id
                            );


                        option.textContent =
                            `${getBranchLabel(
                                currentBranch
                            )} — current`;


                        branchSelect.appendChild(
                            option
                        );


                        branchSelect.value =
                            String(
                                currentBranch.id
                            );

                    } else {

                        branchSelect.value =
                            "";

                    }
                }

            }


            branchSelect.disabled =
                false;


            branchSelect.required =
                true;


            if (branchHelp) {

                branchHelp.textContent =
                    "Organization Admin/Super Admin হিসেবে সদস্যের branch পরিবর্তন করতে পারবেন।";
            }


            return;
        }


        // =====================================================
        // Branch-level User
        // =====================================================

        const ownBranchId =
            SessionManager.getBranchId();


        if (!ownBranchId) {

            branchSelect.innerHTML =
                `
                <option value="">
                    Branch assigned নয়
                </option>
                `;


            branchSelect.disabled =
                true;


            throw new Error(
                "Your account is not assigned to a branch."
            );
        }


        // -----------------------------------------------------
        // Security:
        // Member must belong to user's branch
        // -----------------------------------------------------

        if (
            memberBranchId &&
            String(memberBranchId) !==
            String(ownBranchId)
        ) {

            branchSelect.innerHTML =
                `
                <option value="">
                    Access denied
                </option>
                `;


            branchSelect.disabled =
                true;


            throw new Error(
                "You do not have access to this member's branch."
            );
        }


        // -----------------------------------------------------
        // Load assigned branch
        // -----------------------------------------------------

        let branch = null;


        try {

            branch =
                await BranchManager.getById(
                    ownBranchId
                );

        } catch (error) {

            console.warn(
                "[IMP] Unable to load assigned branch:",
                error
            );
        }


        const label =
            branch
                ? getBranchLabel(branch)
                : "আমার শাখা";


        branchSelect.innerHTML =
            `
            <option value="${escapeHtml(ownBranchId)}">
                ${escapeHtml(label)}
            </option>
            `;


        branchSelect.value =
            String(
                ownBranchId
            );


        /*
         * Keep disabled for branch-level users.
         *
         * MemberFormManager reads branchSelect.value
         * directly, so the value is still available.
         */

        branchSelect.disabled =
            true;


        branchSelect.required =
            true;


        if (branchHelp) {

            branchHelp.textContent =
                "আপনার assigned branch অনুযায়ী সদস্যটি আপডেট হবে।";
        }
    }


    // =========================================================
    // Initialize
    // =========================================================

    try {

        // =====================================================
        // 1. Authentication
        // =====================================================

        const authenticated =
            await SessionManager.requireAuth();


        if (!authenticated) {
            return;
        }


        const session =
            SessionManager.getCurrentUser();


        if (!session) {

            throw new Error(
                "Unable to load current user session."
            );
        }


        // =====================================================
        // 2. RBAC
        // =====================================================

        await RBACManager.bootstrap();


        if (
            !RBACManager.hasPermission(
                "member.update"
            )
        ) {

            showMessage(
                "You do not have permission to update members.",
                "error"
            );

            return;
        }


        // =====================================================
        // 3. Member ID
        // =====================================================

        const memberId =
            Utils.getQueryParam(
                "id"
            );


        if (!memberId) {

            showMessage(
                "Member ID is missing.",
                "error"
            );

            return;
        }


        // =====================================================
        // 4. Load Member
        // =====================================================

        const member = await MemberManager.preload(memberId);


        if (!member) {

            showMessage(
                "Member not found or you do not have access.",
                "error"
            );

            return;
        }


        console.log(
            "[IMP] Member loaded:",
            member
        );


        // =====================================================
        // 5. Load Branch
        // =====================================================

        await loadBranches(
            session,
            member
        );


        // =====================================================
        // 6. Initialize Edit Form
        // =====================================================

        if (
            typeof MemberFormManager ===
            "undefined"
        ) {

            throw new Error(
                "MemberFormManager is not available."
            );
        }


        MemberFormManager.bindEditForm(
            memberId
        );


        // =====================================================
        // 7. Ready
        // =====================================================

        if (form) {

            form.dataset.initialized =
                "true";
        }


        console.log(
            "[IMP] Member edit page initialized successfully."
        );


    } catch (error) {

        console.error(
            "[IMP] Member edit initialization failed:",
            error
        );


        showMessage(
            error?.message ||
            "Unable to load member.",
            "error"
        );
    }

})();