/**
 * IMP Dashboard bootstrap — server-backed tenant context.
 * Dashboard never uses localStorage as authority for organization, counts,
 * role, or financial KPI numbers. Every figure shown here is fetched live
 * from PostgreSQL via /api/dashboard/summary. Card visibility/order comes
 * from /api/dashboard/config (11.P.15 Dashboard Customization).
 */
(function () {
    "use strict";

    function formatBDT(n) {
        const value = Number(n) || 0;
        return "৳" + value.toLocaleString("en-BD", { maximumFractionDigits: 2 });
    }

    function formatCount(n) {
        return String(Number(n) || 0);
    }

    // Card key -> { title, permission, navigate, render(summary) }
    // navigate is the drill-down target from section 3 of the handoff spec
    // (প্রতিটি card পুরোটাই clickable, শুধু ছোট link নয়).
    const CARD_DEFS = {
        totalMembers: {
            title: "মোট সদস্য",
            permission: "member.view",
            href: "../members/members.html",
            render: s => formatCount(s.totalMembers)
        },
        totalLoans: {
            title: "মোট লোন",
            permission: "loan.view",
            href: "../loans/loan-list.html",
            render: s => formatCount(s.totalLoans),
            sub: s => "Outstanding: " + formatBDT(s.loanOutstanding)
        },
        totalCollection: {
            title: "মোট কালেকশন",
            permission: "payment.view",
            href: "../payments/payment-dashboard.html",
            render: s => formatBDT(s.totalCollection)
        },
        totalDue: {
            title: "মোট বকেয়া",
            permission: "loan.view",
            href: "../loans/partial-overdue.html",
            render: s => formatBDT(s.totalDue)
        },
        currentCapital: {
            title: "বর্তমান ব্যালেন্স",
            permission: "capital.view",
            href: "../capital/capital.html",
            render: s => formatBDT(s.currentCapital)
        },
        loanBalance: {
            title: "লোন",
            permission: "loan.view",
            href: "../loans/loan-list.html",
            render: s => formatBDT(s.loanBalance)
        },
        admissionFee: {
            title: "সদস্য ভর্তি ফি",
            permission: "capital.view",
            href: "../capital/capital.html?type=admission_fee",
            render: s => formatBDT(s.admissionFee)
        },
        insurance: {
            title: "বীমা",
            permission: "capital.view",
            href: "../capital/capital.html?type=insurance",
            render: s => formatBDT(s.insurance)
        },
        todayCollection: {
            title: "আজকের কালেকশন",
            permission: "payment.view",
            href: "../payments/payment-dashboard.html",
            render: s => formatBDT(s.todayCollection)
        },
        todayLoan: {
            title: "আজকের লোন",
            permission: "loan.view",
            href: "../loans/loan-list.html",
            render: s => formatBDT(s.todayLoan)
        },
        overdue: {
            title: "Overdue",
            permission: "loan.view",
            href: "../loans/partial-overdue.html",
            render: s => formatCount(s.overdue),
            sub: s => formatBDT(s.overdueAmount)
        },
        totalSavings: {
            title: "মোট সঞ্চয়",
            permission: "savings.view",
            href: "../savings/savings.html",
            render: s => formatBDT(s.totalSavings)
        },
        totalExpense: {
            title: "মোট খরচ",
            permission: "expense.view",
            href: "../expenses/expenses.html",
            render: s => formatBDT(s.totalExpense)
        },
        closedLoans: {
            title: "Closed Loans",
            permission: "loan.view",
            href: "../loans/loan-list.html?status=completed",
            render: s => formatCount(s.closedLoans)
        },
        cancelledLoans: {
            title: "Cancelled Loans",
            permission: "loan.view",
            href: "../loans/loan-list.html?status=cancelled",
            render: s => formatCount(s.cancelledLoans)
        }
    };

    const DEFAULT_ORDER = [
        "currentCapital", "loanBalance", "todayCollection", "totalSavings",
        "insurance", "admissionFee", "totalExpense",
        "totalMembers", "totalLoans", "totalCollection", "totalDue", "todayLoan", "overdue",
        "closedLoans", "cancelledLoans"
    ];

    function renderKpiGrid(summary, config) {
        const grid = document.getElementById("kpiGrid");
        if (!grid) return;
        grid.innerHTML = "";

        const order = Array.isArray(config?.kpiCards) && config.kpiCards.length
            ? config.kpiCards.map(c => c.key)
            : DEFAULT_ORDER;
        const visibility = {};
        (config?.kpiCards || []).forEach(c => { visibility[c.key] = c.visible; });

        order.forEach(key => {
            const def = CARD_DEFS[key];
            if (!def) return;
            const visible = key in visibility ? visibility[key] : true;
            if (!visible) return;
            if (def.permission && typeof RBACManager !== "undefined" && !RBACManager.hasPermission(def.permission)) return;

            const card = document.createElement("a");
            card.className = "stat-card kpi-card";
            card.href = def.href;

            const h3 = document.createElement("h3");
            h3.textContent = def.title;
            card.appendChild(h3);

            const strong = document.createElement("strong");
            try { strong.textContent = def.render(summary); } catch (_) { strong.textContent = "-"; }
            card.appendChild(strong);

            if (typeof def.sub === "function") {
                const small = document.createElement("small");
                try { small.textContent = def.sub(summary); } catch (_) { small.textContent = ""; }
                card.appendChild(small);
            }

            grid.appendChild(card);
        });

        if (!grid.children.length) {
            const empty = document.createElement("p");
            empty.className = "kpi-loading";
            empty.textContent = "কোনো KPI কার্ড দৃশ্যমান নয়।";
            grid.appendChild(empty);
        }
    }

    function setupProfileMenu(session) {
        const menu = document.getElementById("profileMenu");
        const trigger = document.getElementById("profileTrigger");
        const dropdown = document.getElementById("profileDropdown");
        if (!menu || !trigger || !dropdown) return;

        const user = session || {};
        const org = user.organization || {};
        const branch = org.branch || null;
        const roleLabels = {
            organization_admin: "Organization Admin",
            branch_manager: "Branch Manager",
            collector: "Collector",
            accountant: "Accountant",
            viewer: "Viewer",
            super_admin: "Super Admin"
        };
        const role = user.roleName || roleLabels[user.role] || user.role || "-";
        const name = user.name || user.email || "User";
        const set = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value || "-"; };
        set("profileName", name);
        set("profileRole", role);
        set("profileOrg", org.name || "-");
        set("profileEmail", user.email || "-");
        set("profileOrgValue", org.name || "-");
        set("profileRoleValue", role);
        set("profileBranchValue", branch?.name || "All Branches / Not Assigned");
        const avatar = document.getElementById("profileAvatar");
        if (avatar) avatar.textContent = name.trim().charAt(0).toUpperCase() || "U";

        const close = () => { dropdown.hidden = true; trigger.setAttribute("aria-expanded", "false"); };
        trigger.addEventListener("click", event => {
            event.stopPropagation();
            dropdown.hidden = !dropdown.hidden;
            trigger.setAttribute("aria-expanded", String(!dropdown.hidden));
        });
        document.addEventListener("click", event => { if (!menu.contains(event.target)) close(); });
        document.addEventListener("keydown", event => { if (event.key === "Escape") close(); });
        const logout = document.getElementById("profileLogout");
        if (logout) logout.addEventListener("click", () => AuthManager.logout());
    }

    document.addEventListener("DOMContentLoaded", async function () {
        const kpiLoading = document.getElementById("kpiLoading");
        try {
            const session = await SessionManager.waitUntilReady();

            if (!session || !SessionManager.isAuthenticated()) {
                SessionManager.redirectToLogin();
                return;
            }

            setupProfileMenu(session);

            const welcome = document.getElementById("welcome");
            if (welcome) {
                const name = session.name || session.email || "";
                welcome.textContent = name ? ("স্বাগতম, " + name) : "স্বাগতম";
            }

            const userRole = document.getElementById("userRole");
            if (userRole) {
                const roleLabels = {
                    organization_admin: "Organization Admin",
                    branch_manager: "Branch Manager",
                    collector: "Collector",
                    accountant: "Accountant",
                    viewer: "Viewer",
                    super_admin: "Super Admin"
                };
                userRole.textContent = roleLabels[session.role] || session.role || "-";
            }

            if (typeof RBACManager !== "undefined" && RBACManager.bootstrap) {
                await RBACManager.bootstrap();
                RBACManager.applyUIProtection();
            }
            if (typeof AccessGuard !== "undefined" && AccessGuard.apply) {
                AccessGuard.apply();
            }

            // Organization identity, branch/user counts and every financial KPI
            // are fetched live from PostgreSQL through the API — never derived
            // client-side and never read from localStorage.
            const [summaryResult, configResult] = await Promise.all([
                IMP_API.get("/dashboard/summary"),
                RBACManager.hasPermission("dashboard.view") ? IMP_API.get("/dashboard/config").catch(() => null) : Promise.resolve(null)
            ]);

            const summary = summaryResult?.summary || {};
            const organization = summary.organization || {};

            const organizationName = document.getElementById("organizationName");
            if (organizationName) organizationName.textContent = organization.name || "-";

            const branchCount = document.getElementById("branchCount");
            if (branchCount) branchCount.textContent = String(summary.branchCount ?? 0);

            const userCount = document.getElementById("userCount");
            if (userCount) userCount.textContent = String(summary.userCount ?? 0);

            if (kpiLoading) kpiLoading.remove();
            renderKpiGrid(summary, configResult?.config || null);
        } catch (error) {
            console.error("[IMP] Dashboard initialization failed:", error);
            const organizationName = document.getElementById("organizationName");
            if (organizationName) organizationName.textContent = "লোড করা যায়নি";
            if (kpiLoading) kpiLoading.textContent = "লোড করা যায়নি";
        }
    });
})();
