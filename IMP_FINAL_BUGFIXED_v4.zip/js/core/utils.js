/**
 * IMP Core Utility Methods
 * Standardized across all UI and Business Logic modules
 */
var Utils = {
    now() {
        return new Date().toISOString();
    },

    generateId(prefix = 'ID') {
        const uuid = (globalThis.crypto && typeof globalThis.crypto.randomUUID === 'function') ? globalThis.crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
        return `${prefix}-${uuid}`;
    },

    generateCode(prefix = 'CODE') {
        return `${prefix}-${Math.floor(1000 + Math.random() * 9000)}`;
    },

    normalizeText(str) {
        return (str || '').trim().toLowerCase();
    },

    normalizeEmail(email) {
        return (email || '').trim().toLowerCase();
    },

    isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    },

    isValidPassword(pw) {
        // Aligned with server Zod rule (min 8) for consistent UX
        return typeof pw === 'string' && pw.length >= 8;
    },

    escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    },

    // Alias for Case Mismatch Fix
    escapeHTML(str) {
        return this.escapeHtml(str);
    },

    redirect(url) {
        window.location.href = url;
    },

    getQueryParam(param) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(param);
    },

    /**
     * Flexible message helper.
     * Supports:
     *   Utils.showMessage(elementId, message, isError)
     *   Utils.showMessage(message, "error"|"success")
     * Falls back to a floating toast if no target element exists.
     */
    showMessage(elementIdOrMessage, messageOrType, isError = false) {
        let el = null;
        let text = "";
        let error = false;

        if (typeof elementIdOrMessage === "string" && document.getElementById(elementIdOrMessage)) {
            el = document.getElementById(elementIdOrMessage);
            text = messageOrType != null ? String(messageOrType) : "";
            error = isError === true || isError === "error";
        } else if (elementIdOrMessage && typeof elementIdOrMessage === "object" && elementIdOrMessage.nodeType) {
            el = elementIdOrMessage;
            text = messageOrType != null ? String(messageOrType) : "";
            error = isError === true || isError === "error";
        } else {
            text = elementIdOrMessage != null ? String(elementIdOrMessage) : "";
            error = messageOrType === true || messageOrType === "error";
            el = document.getElementById("formMessage")
                || document.getElementById("message")
                || document.getElementById("registrationMessage")
                || document.getElementById("loginMessage")
                || document.querySelector(".alert-target");
        }

        if (!el) {
            el = document.createElement("div");
            el.id = "imp-toast-message";
            el.style.cssText = "position:fixed;top:16px;right:16px;z-index:9999;padding:12px 16px;border-radius:8px;max-width:360px;box-shadow:0 8px 24px rgba(0,0,0,.15);font-size:14px;";
            document.body.appendChild(el);
            setTimeout(function () {
                if (el && el.parentNode) el.parentNode.removeChild(el);
            }, 4000);
        }

        el.textContent = text;
        el.className = error ? "alert alert-danger" : "alert alert-success";
        el.style.display = "block";
        if (el.id === "imp-toast-message") {
            el.style.background = error ? "#fee2e2" : "#d1fae5";
            el.style.color = error ? "#991b1b" : "#065f46";
            el.style.border = error ? "1px solid #fecaca" : "1px solid #a7f3d0";
        }
    },

    hideMessage(elementId) {
        const el = typeof elementId === "string" ? document.getElementById(elementId) : elementId;
        if (el) el.style.display = "none";
    },

    // Migration Bridge to SessionManager
    async requireLogin() {
        if (typeof SessionManager !== 'undefined' && SessionManager.requireAuth) {
            return SessionManager.requireAuth();
        }
        return false;
    }
};

window.Utils = Utils;
