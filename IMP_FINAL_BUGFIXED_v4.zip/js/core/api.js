/**
 * IMP API client — browser never receives or stores the session token.
 * Authentication is carried by the HttpOnly cookie set by the server.
 */
const IMP_API = {
    baseUrl: (typeof APP_CONFIG !== 'undefined' && APP_CONFIG.api && APP_CONFIG.api.baseUrl)
        ? APP_CONFIG.api.baseUrl
        : '/api',

    async request(path, options = {}) {
        const config = { ...options, credentials: 'include', headers: { ...(options.headers || {}) } };
        if (config.body && typeof config.body !== 'string') {
            config.headers['Content-Type'] = 'application/json';
            config.body = JSON.stringify(config.body);
        }

        const response = await fetch(`${this.baseUrl}${path}`, config);
        if (response.status === 204) return null;

        let payload = null;
        try { payload = await response.json(); } catch (_) {}
        if (!response.ok) {
            const error = new Error(payload?.error || `Request failed (${response.status})`);
            error.status = response.status;
            error.payload = payload;
            throw error;
        }
        return payload;
    },

    get(path) { return this.request(path); },
    post(path, body, headers) { return this.request(path, { method: 'POST', body, headers }); },
    patch(path, body) { return this.request(path, { method: 'PATCH', body }); },
    put(path, body) { return this.request(path, { method: 'PUT', body }); },
    delete(path) { return this.request(path, { method: 'DELETE' }); }
};

window.IMP_API = IMP_API;
