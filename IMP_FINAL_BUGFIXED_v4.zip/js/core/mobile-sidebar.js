
/* Mobile sidebar toggle helper - IMP V6.0.17 professional */
(function () {
  function ensureToggle() {
    if (window.innerWidth > 768) return;
    var sidebar = document.getElementById("dashboardSidebar") || document.querySelector(".sidebar");
    if (!sidebar) return;
    if (document.getElementById("impMobileMenuBtn")) return;

    var btn = document.createElement("button");
    btn.id = "impMobileMenuBtn";
    btn.type = "button";
    btn.setAttribute("aria-label", "মেনু");
    btn.innerHTML = "☰";
    btn.style.cssText = "position:fixed;top:56px;right:12px;left:auto;z-index:1300;width:44px;height:44px;border:0;border-radius:12px;background:#0f766e;color:#fff;font-size:22px;box-shadow:0 4px 14px rgba(15,23,42,.2);display:flex;align-items:center;justify-content:center;";
    document.body.appendChild(btn);

    btn.addEventListener("click", function (e) {
      e.stopPropagation();
      sidebar.classList.toggle("open");
      document.body.classList.toggle("sidebar-open");
    });

    document.body.addEventListener("click", function (e) {
      if (!sidebar.classList.contains("open")) return;
      if (sidebar.contains(e.target) || btn.contains(e.target)) return;
      sidebar.classList.remove("open");
      document.body.classList.remove("sidebar-open");
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", ensureToggle);
  } else {
    ensureToggle();
  }
  window.addEventListener("resize", function () {
    if (window.innerWidth > 768) {
      var s = document.getElementById("dashboardSidebar") || document.querySelector(".sidebar");
      if (s) s.classList.remove("open");
      document.body.classList.remove("sidebar-open");
      var b = document.getElementById("impMobileMenuBtn");
      if (b) b.style.display = "none";
    } else {
      var b = document.getElementById("impMobileMenuBtn");
      if (b) b.style.display = "flex";
      else ensureToggle();
    }
  });
})();
