/**
 * Global "Main Dashboard" home control — available on every authenticated app page.
 */
(function (global) {
  'use strict';

  function pathParts() {
    return (location.pathname || '').split('/').filter(Boolean);
  }

  function isAuthPage() {
    const p = location.pathname || '';
    return /\/pages\/auth\//.test(p) || /\/(login|register|forgot-password|reset-password)\.html$/i.test(p);
  }

  function isDashboardPage() {
    return /\/pages\/dashboard\/dashboard\.html$/i.test(location.pathname || '');
  }

  function dashboardHref() {
    // pages/<section>/file.html → ../dashboard/dashboard.html
    // pages/dashboard/x.html → ./dashboard.html
    const parts = pathParts();
    const pagesIdx = parts.indexOf('pages');
    if (pagesIdx >= 0 && parts[pagesIdx + 1] === 'dashboard') {
      return './dashboard.html';
    }
    if (pagesIdx >= 0) {
      return '../dashboard/dashboard.html';
    }
    // fallback from root-served paths
    return '/pages/dashboard/dashboard.html';
  }

  function label() {
    try {
      const lang =
        (global.IMP_I18N && IMP_I18N.lang && IMP_I18N.lang()) || 'bn';
      return lang === 'en' ? 'Dashboard' : 'ড্যাশবোর্ড';
    } catch (_) {
      return 'ড্যাশবোর্ড';
    }
  }

  function mount() {
    if (isAuthPage()) return;
    if (document.getElementById('impHomeNav')) return;

    const a = document.createElement('a');
    a.id = 'impHomeNav';
    a.href = dashboardHref();
    a.title = 'Main Dashboard';
    a.setAttribute('aria-label', 'Main Dashboard');
    a.innerHTML =
      '<span class="imp-logo-mark" aria-hidden="true">IMP</span>' +
      '<span class="imp-home-label">' + label() + '</span>';

    // On dashboard itself, still useful as brand; keep clickable refresh/home
    document.body.appendChild(a);
    document.body.classList.add('has-imp-home-nav');

    // Refresh label when language changes
    global.addEventListener('imp:languagechange', function () {
      const el = a.querySelector('.imp-home-label');
      if (el) el.textContent = label();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mount);
  } else {
    mount();
  }

  global.IMP_HomeNav = { mount, dashboardHref };
})(typeof window !== 'undefined' ? window : this);


/* ---- Mobile sidebar drawer (professional mobile-first) ---- */
(function () {
  function ensureToggle() {
    if (window.innerWidth > 768) {
      var b = document.getElementById("impMobileMenuBtn");
      if (b) b.style.display = "none";
      return;
    }
    var sidebar = document.getElementById("dashboardSidebar") || document.querySelector(".sidebar");
    if (!sidebar) return;
    var existing = document.getElementById("impMobileMenuBtn");
    if (existing) {
      existing.style.display = "flex";
      return;
    }

    var btn = document.createElement("button");
    btn.id = "impMobileMenuBtn";
    btn.type = "button";
    btn.setAttribute("aria-label", "মেনু");
    btn.innerHTML = "☰";
    btn.style.cssText = "position:fixed;top:56px;right:12px;left:auto;z-index:1300;width:44px;height:44px;border:0;border-radius:12px;background:#0f766e;color:#fff;font-size:22px;line-height:1;box-shadow:0 4px 14px rgba(15,23,42,.22);display:flex;align-items:center;justify-content:center;cursor:pointer;";
    document.body.appendChild(btn);

    btn.addEventListener("click", function (e) {
      e.stopPropagation();
      sidebar.classList.toggle("open");
      document.body.classList.toggle("sidebar-open");
    });

    document.body.addEventListener("click", function (e) {
      if (!sidebar.classList.contains("open")) return;
      if (sidebar.contains(e.target) || btn.contains(e.target)) return;
      sidebar.classList.remove("open");
      document.body.classList.remove("sidebar-open");
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", ensureToggle);
  } else {
    ensureToggle();
  }
  window.addEventListener("resize", ensureToggle);
})();
