/* IMP Offline-First Store
 * Data resilience for Daily Collection + Field Officer.
 * IndexedDB only; no business data is persisted in localStorage.
 */
(function (global) {
  "use strict";
  const DB_NAME = "imp-offline-v1";
  const DB_VERSION = 1;
  const ROUTES = "dailyRoutes";
  const QUEUE = "dailyQueue";
  let dbPromise;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(ROUTES)) {
          db.createObjectStore(ROUTES, { keyPath: "cacheKey" });
        }
        if (!db.objectStoreNames.contains(QUEUE)) {
          const s = db.createObjectStore(QUEUE, { keyPath: "queueId" });
          s.createIndex("createdAt", "createdAt");
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error("IndexedDB unavailable"));
    });
    return dbPromise;
  }

  function request(store, mode, fn) {
    return open().then(db => new Promise((resolve, reject) => {
      const tx = db.transaction(store, mode);
      let result;
      try { result = fn(tx.objectStore(store)); } catch (e) { reject(e); return; }
      if (result && typeof result.onsuccess !== "undefined") {
        result.onsuccess = () => resolve(result.result);
        result.onerror = () => reject(result.error);
      } else {
        tx.oncomplete = () => resolve(result);
      }
      tx.onerror = () => reject(tx.error);
    }));
  }

  const api = {
    online: () => navigator.onLine !== false,
    cacheRoute: (key, value) => request(ROUTES, "readwrite", s => s.put({
      cacheKey: key, value, cachedAt: new Date().toISOString()
    })),
    getRoute: key => request(ROUTES, "readonly", s => s.get(key)),
    queue: item => request(QUEUE, "readwrite", s => s.put({
      queueId: item.queueId,
      endpoint: item.endpoint,
      payload: item.payload,
      createdAt: item.createdAt || new Date().toISOString(),
      attempts: item.attempts || 0,
      lastError: null
    })),
    allQueued: () => request(QUEUE, "readonly", s => s.getAll()),
    remove: id => request(QUEUE, "readwrite", s => s.delete(id)),
    update: item => request(QUEUE, "readwrite", s => s.put(item))
  };

  global.IMP_OFFLINE = api;
})(window);
