/**
 * IMP Application Configuration
 * Pure API/PostgreSQL architecture. Browser storage is not an application-data authority.
 */
const APP_CONFIG = {

    appName: "Installment Management Platform",

    version: "1.0.0",

   api: {
    baseUrl: "/api"
},

    defaults: {
        userStatus: "active"
    },

    session: {
        timeoutMinutes: 120
    }

};
