/**
 * Savings management page. All balances come from /api/savings/* — nothing
 * is computed client-side or read from localStorage.
 */
(function () {
    "use strict";

    const TX_LABELS = {
        deposit: "সঞ্চয় জমা",
        daily_deposit: "ডেইলি সঞ্চয়",
        withdrawal: "সঞ্চয় উত্তোলন",
        installment_payment: "কিস্তি পরিশোধ (সঞ্চয় থেকে)"
    };

    let selectedMember = null;

    function formatBDT(n) {
        const value = Number(n) || 0;
        return "৳" + value.toLocaleString("en-BD", { maximumFractionDigits: 2 });
    }

    function setText(id, value) {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    }

    async function loadOrgSummary() {
        const result = await IMP_API.get("/savings/summary");
        const s = result?.summary || {};
        setText("orgSavingsBalance", formatBDT(s.balance));
        setText("orgSavingsDeposits", formatBDT(s.deposits));
        setText("orgSavingsWithdrawals", formatBDT(s.withdrawals));
        setText("orgSavingsInstallments", formatBDT(s.installmentPayments));
    }

    async function searchMembers() {
        const q = document.getElementById("memberSearchInput").value.trim();
        const list = document.getElementById("memberSearchResults");
        list.innerHTML = "";
        if (!q) return;

        try {
            const result = await IMP_API.get(`/members?q=${encodeURIComponent(q)}&limit=10`);
            const members = result?.members || result?.data || [];
            if (!members.length) {
                list.innerHTML = "<li>কোনো সদস্য পাওয়া যায়নি।</li>";
                return;
            }
            members.forEach(member => {
                const li = document.createElement("li");
                li.innerHTML = `<span>${Utils.escapeHtml(member.fullName || member.full_name || "")} (${Utils.escapeHtml(member.memberCode || member.member_code || "")})</span><span>${Utils.escapeHtml(member.phone || "")}</span>`;
                li.addEventListener("click", () => selectMember(member));
                list.appendChild(li);
            });
        } catch (error) {
            Utils.showMessage("savingsMessage", error.message || "সদস্য খুঁজে পাওয়া যায়নি।", "error");
        }
    }

    async function selectMember(member) {
        selectedMember = {
            id: member.id,
            name: member.fullName || member.full_name || "",
            code: member.memberCode || member.member_code || ""
        };
        document.getElementById("memberSearchResults").innerHTML = "";
        document.getElementById("memberSearchInput").value = "";
        document.getElementById("selectedMemberLabel").textContent =
            `নির্বাচিত সদস্য: ${selectedMember.name} (${selectedMember.code})`;
        document.getElementById("memberSavingsSection").hidden = false;

        await Promise.all([loadMemberSummary(), loadMemberTransactions(), loadMemberLoans()]);
    }

    async function loadMemberSummary() {
        if (!selectedMember) return;
        const result = await IMP_API.get(`/savings/summary?memberId=${selectedMember.id}`);
        setText("memberSavingsBalance", formatBDT(result?.summary?.balance));
    }

    async function loadMemberLoans() {
        const select = document.getElementById("txLoan");
        select.innerHTML = "";
        if (!selectedMember) return;
        try {
            const result = await IMP_API.get(`/loans?member_id=${selectedMember.id}&limit=50`);
            const loans = result?.loans || result?.data || [];
            loans.forEach(loan => {
                const option = document.createElement("option");
                option.value = loan.id;
                option.textContent = loan.loanNumber || loan.loan_number || loan.id;
                select.appendChild(option);
            });
        } catch (error) {
            Utils.showMessage("savingsMessage", error.message || "লোন লোড করা যায়নি।", "error");
        }
    }

    function renderRow(tx, canManage) {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${Utils.escapeHtml(tx.transactionDate)}</td>
            <td>${Utils.escapeHtml(TX_LABELS[tx.transactionType] || tx.transactionType)}</td>
            <td>${formatBDT(tx.amount)}</td>
            <td>${Utils.escapeHtml(tx.description || "")}</td>
            <td></td>
        `;
        if (canManage) {
            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = "btn btn-danger";
            btn.textContent = "Delete";
            btn.addEventListener("click", () => deleteTx(tx.id));
            tr.lastElementChild.appendChild(btn);
        }
        return tr;
    }

    async function loadMemberTransactions() {
        const body = document.getElementById("memberTxBody");
        if (!selectedMember) {
            body.innerHTML = `<tr><td colspan="5">সদস্য নির্বাচন করুন।</td></tr>`;
            return;
        }
        const result = await IMP_API.get(`/savings/transactions?memberId=${selectedMember.id}`);
        const transactions = result?.transactions || [];
        const canManage = RBACManager.hasPermission(PERMISSIONS.SAVINGS_MANAGE);

        body.innerHTML = "";
        if (!transactions.length) {
            body.innerHTML = `<tr><td colspan="5">কোনো এন্ট্রি পাওয়া যায়নি।</td></tr>`;
            return;
        }
        transactions.forEach(tx => body.appendChild(renderRow(tx, canManage)));
    }

    async function deleteTx(id) {
        if (!window.confirm("এই এন্ট্রিটি মুছে ফেলতে চান?")) return;
        try {
            await IMP_API.delete(`/savings/transactions/${id}`);
            await Promise.all([loadOrgSummary(), loadMemberSummary(), loadMemberTransactions()]);
        } catch (error) {
            Utils.showMessage("savingsMessage", error.message || "মুছে ফেলা যায়নি।", "error");
        }
    }

    function toggleLoanField() {
        const type = document.getElementById("txType").value;
        document.getElementById("txLoanGroup").hidden = type !== "installment_payment";
    }

    async function handleSubmit(event) {
        event.preventDefault();
        if (!selectedMember) {
            Utils.showMessage("savingsMessage", "প্রথমে একজন সদস্য নির্বাচন করুন।", "error");
            return;
        }

        const txType = document.getElementById("txType").value;
        const payload = {
            memberId: selectedMember.id,
            transactionType: txType,
            amount: Number(document.getElementById("txAmount").value),
            transactionDate: document.getElementById("txDate").value,
            description: document.getElementById("txDescription").value.trim()
        };
        if (txType === "installment_payment") {
            payload.loanId = document.getElementById("txLoan").value;
        }

        const submitBtn = event.target.querySelector("button[type=submit]");
        if (submitBtn) submitBtn.disabled = true;
        try {
            await IMP_API.post("/savings/transactions", payload);
            Utils.showMessage("savingsMessage", "Savings entry saved.", "success");
            document.getElementById("savingsEntryForm").reset();
            document.getElementById("txDate").valueAsDate = new Date();
            toggleLoanField();
            await Promise.all([loadOrgSummary(), loadMemberSummary(), loadMemberTransactions()]);
        } catch (error) {
            Utils.showMessage("savingsMessage", error.message || "Save failed.", "error");
        } finally {
            if (submitBtn) submitBtn.disabled = false;
        }
    }

    document.addEventListener("DOMContentLoaded", async function () {
        if (!(await SessionManager.requireAuth())) return;
        await RBACManager.bootstrap();

        if (!(await AccessGuard.requirePermission(PERMISSIONS.SAVINGS_VIEW))) return;
        RBACManager.applyUIProtection();
        AccessGuard.apply();

        const dateInput = document.getElementById("txDate");
        if (dateInput) dateInput.valueAsDate = new Date();

        document.getElementById("memberSearchBtn").addEventListener("click", searchMembers);
        document.getElementById("memberSearchInput").addEventListener("keydown", e => {
            if (e.key === "Enter") { e.preventDefault(); searchMembers(); }
        });
        document.getElementById("txType").addEventListener("change", toggleLoanField);
        document.getElementById("savingsEntryForm").addEventListener("submit", handleSubmit);
        toggleLoanField();

        try {
            await loadOrgSummary();
        } catch (error) {
            Utils.showMessage("savingsMessage", error.message || "লোড করা যায়নি।", "error");
        }
    });
})();
