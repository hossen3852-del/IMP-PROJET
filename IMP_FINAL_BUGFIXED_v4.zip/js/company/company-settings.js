"use strict";
const CompanySettingsManager=Object.freeze({
 async get(organizationId){if(!organizationId)throw new Error("Organization is required.");return SettingsAPI.get(SettingsAPI.KEYS.PAYMENT);},
 async save(organizationId,data){if(!organizationId)throw new Error("Organization is required.");return SettingsAPI.put(SettingsAPI.KEYS.PAYMENT,data);}
});
