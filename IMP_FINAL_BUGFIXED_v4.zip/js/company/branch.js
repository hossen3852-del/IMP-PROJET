/** 11.P.4 — Server-backed branch manager. */
(function (global) {
    "use strict";
    var BranchManager = {
        async getAll() {
            const result = await IMP_API.get('/branches');
            return result.branches || [];
        },
        async getOrganizationBranches() { return this.getAll(); },
        async getById(id) {
            const result = await IMP_API.get('/branches/' + encodeURIComponent(id));
            return result.branch || null;
        },
        async getCurrentBranch() {
            const id = SessionManager.getBranchId();
            return id ? this.getById(id) : null;
        },
        async create(data) {
            const result = await IMP_API.post('/branches', {
                name: Utils.normalizeText(data.name),
                phone: Utils.normalizeText(data.phone) || null,
                address: Utils.normalizeText(data.address) || null,
                managerName: Utils.normalizeText(data.managerName) || null
            });
            return result.branch;
        },
        async update(id, data) {
            const payload = {};
            ['name','phone','address','managerName','status'].forEach(function (key) {
                if (data[key] !== undefined) payload[key] = key === 'status' ? data[key] : (Utils.normalizeText(data[key]) || null);
            });
            const result = await IMP_API.patch('/branches/' + encodeURIComponent(id), payload);
            return result.branch;
        },
        async delete(id) {
            await IMP_API.post('/branches/' + encodeURIComponent(id) + '/deactivate');
            return true;
        }
    };
    global.BranchManager = BranchManager;
})(typeof window !== "undefined" ? window : this);
