const AccessGuard = {
    async requirePermission(permission, redirect = "../dashboard/dashboard.html") {
        const ok = await SessionManager.requireAuth();
        if (!ok) return false;
        if (!RBACManager._ready) await RBACManager.bootstrap();
        if (RBACManager.hasPermission(permission)) return true;
        alert("Access denied. You do not have permission to access this page.");
        window.location.href = redirect;
        return false;
    },

    async requireAnyPermission(permissions, redirect = "../dashboard/dashboard.html") {
        const ok = await SessionManager.requireAuth();
        if (!ok) return false;
        if (!RBACManager._ready) await RBACManager.bootstrap();
        if (RBACManager.hasAnyPermission(permissions)) return true;
        alert("Access denied.");
        window.location.href = redirect;
        return false;
    },

    async requireAllPermissions(permissions, redirect = "../dashboard/dashboard.html") {
        const ok = await SessionManager.requireAuth();
        if (!ok) return false;
        if (!RBACManager._ready) await RBACManager.bootstrap();
        if (RBACManager.hasAllPermissions(permissions)) return true;
        alert("Access denied.");
        window.location.href = redirect;
        return false;
    },

    apply() {
        if (!SessionManager.isAuthenticated()) return;
        document.querySelectorAll("[data-permission]").forEach(element => {
            if (!RBACManager.hasPermission(element.dataset.permission)) element.remove();
        });
    }
};
window.AccessGuard = AccessGuard;
