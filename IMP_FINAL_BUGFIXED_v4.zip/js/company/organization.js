/** 11.P.4 — Server-backed organization manager. */
(function (global) {
    "use strict";
    var OrganizationManager = {
        async getCurrent() {
            const result = await IMP_API.get('/organization');
            return result.organization || null;
        },
        async getById(id) {
            const current = await this.getCurrent();
            return current && String(current.id) === String(id) ? current : null;
        },
        async update(id, data) {
            const current = await this.getCurrent();
            if (!current || String(current.id) !== String(id)) throw new Error('Organization not found.');
            const result = await IMP_API.patch('/organization', data);
            return result.organization;
        },
        async create(data) {
            throw new Error('Organization creation is performed during registration.');
        }
    };
    global.OrganizationManager = OrganizationManager;
})(typeof window !== "undefined" ? window : this);
