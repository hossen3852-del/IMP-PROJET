document.addEventListener('DOMContentLoaded', async () => {
    const message = document.getElementById('userMessage');
    const table = document.getElementById('userTable');
    try {
        if (!(await SessionManager.requireAuth())) return;
        const users = await OrganizationUserManager.getOrganizationUsers();
        table.innerHTML = '';
        if (!users.length) {
            table.innerHTML = '<tr><td colspan="6">No users found.</td></tr>';
            return;
        }
        users.forEach(user => {
            const row = document.createElement('tr');
            row.innerHTML = `
              <td>${Utils.escapeHtml(user.userCode || '-')}</td>
              <td>${Utils.escapeHtml(user.name || '')}</td>
              <td>${Utils.escapeHtml(user.email || '')}</td>
              <td>${Utils.escapeHtml(String(user.roleName || user.roleCode || '').split('_').map(x => x.charAt(0).toUpperCase()+x.slice(1)).join(' '))}</td>
              <td>${Utils.escapeHtml(user.branchName || '-')}</td>
              <td>${Utils.escapeHtml(user.active ? 'active' : 'inactive')}</td>`;
            table.appendChild(row);
        });
    } catch (error) {
        Utils.showMessage(message, error.message || 'Unable to load users.', 'error');
    }
});
