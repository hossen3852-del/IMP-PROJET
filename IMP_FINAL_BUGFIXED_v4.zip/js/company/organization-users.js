/** Server-backed organization user API. No passwords or authoritative users are stored in localStorage. */
const OrganizationUserManager = {
    async getOrganizationUsers() {
        const result = await IMP_API.get('/users');
        return result.users || [];
    },
    async getById(id) {
        const result = await IMP_API.get('/users/' + encodeURIComponent(id));
        return result.user || null;
    },
    async create(data) {
        const result = await IMP_API.post('/users', data);
        return result.user;
    },
    async update(id, data) {
        const result = await IMP_API.patch('/users/' + encodeURIComponent(id), data);
        return result.user;
    },
    async deactivate(id) {
        await IMP_API.delete('/users/' + encodeURIComponent(id));
        return true;
    }
};
window.OrganizationUserManager = OrganizationUserManager;
