document.addEventListener('DOMContentLoaded', async () => {
    const form = document.getElementById('userForm');
    const message = document.getElementById('userMessage');
    const branchSelect = document.getElementById('branchId');
    try {
        if (!(await SessionManager.requireAuth())) return;
        const session = SessionManager.getSession();
        const organizationWide = ['organization_admin', 'super_admin'].includes(session?.role || '');
        const roleSelect = document.getElementById('role');
        if (!organizationWide) {
            roleSelect.querySelector('option[value="organization_admin"]')?.remove();
        }
        const branches = await BranchManager.getOrganizationBranches();
        branches.filter(b => b.status === 'active' && (organizationWide || String(b.id) === String(session?.branchId))).forEach(branch => {
            const option = document.createElement('option');
            option.value = branch.id;
            option.textContent = `${branch.name} (${branch.branchCode || ''})`;
            branchSelect.appendChild(option);
        });
        form.addEventListener('submit', async event => {
            event.preventDefault();
            const button = form.querySelector('button[type="submit"]');
            if (button) button.disabled = true;
            try {
                await OrganizationUserManager.create({
                    name: document.getElementById('name').value.trim(),
                    email: document.getElementById('email').value.trim(),
                    password: document.getElementById('password').value,
                    roleCode: document.getElementById('role').value,
                    branchId: branchSelect.value || null
                });
                Utils.showMessage(message, 'User created successfully.', 'success');
                form.reset();
            } catch (error) {
                Utils.showMessage(message, error.message || 'User creation failed.', 'error');
            } finally { if (button) button.disabled = false; }
        });
    } catch (error) {
        Utils.showMessage(message, error.message || 'Unable to load user form.', 'error');
    }
});
