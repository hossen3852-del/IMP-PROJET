document.addEventListener('DOMContentLoaded', () => {
    const requestForm = document.getElementById('resetRequestForm');
    const resetForm = document.getElementById('resetPasswordForm');
    const message = document.getElementById('resetMessage');
    const devToken = document.getElementById('devResetToken');
    const devBox = document.getElementById('devResetTokenBox');

    const show = (text, type) => {
        if (message) Utils.showMessage(message, text, type);
    };

    // A reset link may be opened as reset-password.html?token=...
    if (resetForm) {
        const tokenInput = document.getElementById('resetToken');
        const tokenFromUrl = new URLSearchParams(window.location.search).get('token');
        if (tokenInput && tokenFromUrl) tokenInput.value = tokenFromUrl;

        resetForm.addEventListener('submit', async event => {
            event.preventDefault();
            if (message) Utils.hideMessage(message);
            const token = tokenInput?.value.trim();
            const password = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmNewPassword').value;
            if (!token) return show('Reset token is required.', 'error');
            if (password !== confirmPassword) return show('Passwords do not match.', 'error');
            if (password.length < 8) return show('Password must be at least 8 characters.', 'error');
            const button = resetForm.querySelector('button[type="submit"]');
            if (button) button.disabled = true;
            try {
                await AuthManager.resetPassword(token, password);
                resetForm.reset();
                show('Password reset successful. You can now login with your new password.', 'success');
                window.setTimeout(() => { window.location.href = 'login.html'; }, 1000);
            } catch (error) {
                show(error.message || 'Unable to reset password.', 'error');
            } finally { if (button) button.disabled = false; }
        });
    }

    if (requestForm) {
        requestForm.addEventListener('submit', async event => {
            event.preventDefault();
            if (message) Utils.hideMessage(message);
            const button = requestForm.querySelector('button[type="submit"]');
            if (button) button.disabled = true;
            try {
                const result = await AuthManager.requestPasswordReset(document.getElementById('resetEmail').value.trim());
                show(result.message || 'If the account exists, a password reset link has been created.', 'success');
                if (devToken && result.devToken && devBox) {
                    devToken.value = result.devToken;
                    devBox.style.display = 'block';
                }
            } catch (error) {
                show(error.message || 'Unable to process the request.', 'error');
            } finally { if (button) button.disabled = false; }
        });
    }
});
