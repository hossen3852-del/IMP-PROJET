/**
 * 11.P.3 — Authentication API facade.
 * Legacy browser-storage authentication has been removed from the auth path.
 */
const AuthManager = {
    async register(data) {
        if (!data?.name || !data?.organizationName || !data?.companyCode || !data?.companyType || !data?.address || !data?.phone || !data?.country || !data?.currency || !Array.isArray(data?.workingDays) || !data?.workingDays.length || !data?.officeStartTime || !data?.officeEndTime || !data?.timezone || !data?.email || !data?.password) {
            throw new Error('Complete company and administrator information are required.');
        }
        const result = await IMP_API.post('/auth/register', data);
        SessionManager.setSession({
            ...result.user,
            userId: result.user.id,
            organization: result.organization || null
        });
        // Full session (roleName, branch, permissions) from /auth/me
        await SessionManager.refresh();
        return result.user;
    },

    async login(email, password) {
        const result = await IMP_API.post('/auth/login', { email, password });
        SessionManager.setSession({
            ...result.user,
            userId: result.user.id,
            organization: result.organization || null
        });
        // Refresh from /auth/me for roleName, full permissions and branch.
        const session = await SessionManager.refresh();
        return session || result.user;
    },

    async logout() {
        try { await IMP_API.post('/auth/logout'); }
        finally {
            SessionManager.clearSession();
            window.location.href = '../../pages/auth/login.html';
        }
    },

    async requestPasswordReset(email) {
        return IMP_API.post('/auth/password-reset/request', { email });
    },

    async resetPassword(token, newPassword) {
        return IMP_API.post('/auth/password-reset/confirm', { token, password: newPassword });
    }
};

window.AuthManager = AuthManager;
