document.addEventListener('DOMContentLoaded', async () => {
    const form = document.getElementById('loginForm');
    const message = document.getElementById('loginMessage');
    if (!form) return;

    const existing = await SessionManager.waitUntilReady();
    if (existing) {
        window.location.href = '../dashboard/dashboard.html';
        return;
    }

    form.addEventListener('submit', async event => {
        event.preventDefault();
        Utils.hideMessage(message);
        const button = form.querySelector('button[type="submit"]');
        if (button) button.disabled = true;

        try {
            await AuthManager.login(
                document.getElementById('email').value.trim(),
                document.getElementById('password').value
            );
            window.location.href = '../dashboard/dashboard.html';
        } catch (error) {
            Utils.showMessage(message, error.message, 'error');
        } finally {
            if (button) button.disabled = false;
        }
    });
});
