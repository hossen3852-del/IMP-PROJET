/**
 * 11.P.3 — Server-backed authentication session.
 * No password, bearer token, or authoritative user record is stored in localStorage.
 */
const SessionManager = {
    _session: null,
    _ready: null,

    bootstrap() {
        if (this._ready) return this._ready;
        this._ready = IMP_API.get('/auth/me')
            .then(result => {
                this._session = result?.user ? {
                    ...result.user,
                    organization: result.organization || null,
                    userId: result.user.id
                } : null;
                return this._session;
            })
            .catch(error => {
                if (error.status === 401) this._session = null;
                else console.error('[IMP] Session bootstrap failed:', error);
                return null;
            });
        return this._ready;
    },

    async refresh() {
        this._ready = null;
        return this.bootstrap();
    },

    async waitUntilReady() {
        return this.bootstrap();
    },

    getSession() {
        return this._session;
    },

    setSession(userData) {
        this._session = userData || null;
        // Invalidate cached bootstrap so next waitUntilReady/refresh hits /auth/me
        // and loads organization + role after login/register.
        this._ready = null;
        return this._session;
    },

    clearSession() {
        this._session = null;
        this._ready = null;
    },

    create(user) {
        return this.setSession(user);
    },

    isAuthenticated() {
        return !!(this._session && (this._session.userId || this._session.id));
    },

    /**
     * Async auth guard. Prefer this over the legacy requireAuth().
     * Resolves session from /auth/me (cookie) and redirects if unauthenticated.
     */
    async ensureAuthenticated() {
        const session = await this.waitUntilReady();
        if (session && (session.userId || session.id)) return session;
        this.redirectToLogin();
        return null;
    },

    /**
     * Legacy-compatible guard. Now properly awaits bootstrap when needed.
     * Pages that already `await SessionManager.requireAuth()` will wait for /auth/me.
     */
    async requireAuth() {
        if (this.isAuthenticated() && this._session?.organization) return true;
        const session = await this.waitUntilReady();
        if (session && (session.userId || session.id)) return true;
        this.redirectToLogin();
        return false;
    },

    redirectToLogin() {
        const path = window.location.pathname || '';
        const loginPath = path.includes('/pages/')
            ? path.replace(/\/pages\/.*$/, '/pages/auth/login.html')
            : 'pages/auth/login.html';
        window.location.href = loginPath;
    },

    getCurrentUser() { return this._session; },
    getUserId() { return this._session?.userId || this._session?.id || null; },
    getOrganizationId() { return this._session?.organizationId || this._session?.organization?.id || null; },
    getBranchId() { return this._session?.branchId || this._session?.organization?.branch?.id || null; },
    getPermissions() { return Array.isArray(this._session?.permissions) ? this._session.permissions : []; }
};

window.SessionManager = SessionManager;
SessionManager.bootstrap();
