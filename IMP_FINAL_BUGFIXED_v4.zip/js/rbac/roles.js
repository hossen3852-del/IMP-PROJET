'use strict';

/**
 * 11.P.5 — Role catalog for display/default labels only.
 * Permission authority is no longer stored in browser role definitions.
 */
const ROLES = Object.freeze({
  SUPER_ADMIN: { name: "super_admin", description: "System-wide administration" },
  ORGANIZATION_ADMIN: { name: "organization_admin", description: "Full organization administration" },
  BRANCH_MANAGER: { name: "branch_manager", description: "Branch-level operational management" },
  COLLECTOR: { name: "collector", description: "Collection and payment operations" },
  ACCOUNTANT: { name: "accountant", description: "Financial and payment operations" },
  VIEWER: { name: "viewer", description: "Read-only organization access" }
});

window.ROLES = ROLES;
