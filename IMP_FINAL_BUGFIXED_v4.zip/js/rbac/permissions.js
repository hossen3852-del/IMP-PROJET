'use strict';

/**
 * 11.P.5 — Canonical permission registry.
 * These identifiers are shared by frontend UI checks and server authorization.
 * The frontend registry is descriptive only; the server/database is authoritative.
 */
const PERMISSIONS = Object.freeze({
  DASHBOARD_VIEW: "dashboard.view",
  DASHBOARD_CUSTOMIZE: "dashboard.customize",
  UI_VISIBILITY_MANAGE: "ui.visibility.manage",
  CAPITAL_SHARE_VIEW: "capital.share.view",
  CAPITAL_SHARE_MANAGE: "capital.share.manage",
  CAPITAL_VIEW: "capital.view",
  CAPITAL_MANAGE: "capital.manage",
  SAVINGS_VIEW: "savings.view",
  SAVINGS_MANAGE: "savings.manage",
  EXPENSE_VIEW: "expense.view",
  EXPENSE_MANAGE: "expense.manage",
  INSURANCE_VIEW: "insurance.view",
  INSURANCE_MANAGE: "insurance.manage",
  COLLECTION_CREATE: "collection.create",
  ORGANIZATION_VIEW: "organization.view",
  ORGANIZATION_UPDATE: "organization.update",
  BRANCH_VIEW: "branch.view",
  BRANCH_CREATE: "branch.create",
  BRANCH_UPDATE: "branch.update",
  BRANCH_DELETE: "branch.delete",
  USER_VIEW: "user.view",
  USER_CREATE: "user.create",
  USER_UPDATE: "user.update",
  USER_DELETE: "user.delete",
  ROLE_VIEW: "role.view",
  ROLE_CREATE: "role.create",
  ROLE_UPDATE: "role.update",
  ROLE_DELETE: "role.delete",
  ROLE_MANAGE: "role.manage",
  PERMISSION_VIEW: "permission.view",
  SETTINGS_VIEW: "settings.view",
  SETTINGS_UPDATE: "settings.update",
  MEMBER_VIEW: "member.view",
  MEMBER_CREATE: "member.create",
  MEMBER_UPDATE: "member.update",
  MEMBER_DELETE: "member.delete",
  MEMBER_STATUS_UPDATE: "member.status.update",
  MEMBER_FINANCIAL_UPDATE: "member.financial.update",
  MEMBER_DOCUMENT_UPLOAD: "member.document.upload",
  MEMBER_DOCUMENT_DELETE: "member.document.delete",
  LOAN_VIEW: "loan.view",
  LOAN_CREATE: "loan.create",
  LOAN_UPDATE: "loan.update",
  LOAN_DELETE: "loan.delete",
  LOAN_APPROVE: "loan.approve",
  LOAN_STATUS_UPDATE: "loan.status.update",
  LOAN_FINANCIAL_UPDATE: "loan.financial.update",
  LOAN_PAYMENT_CREATE: "loan.payment.create",
  LOAN_PAYMENT_UPDATE: "loan.payment.update",
  LOAN_PAYMENT_DELETE: "loan.payment.delete",
  LOAN_SCHEDULE_UPDATE: "loan.schedule.update",
  PAYMENT_VIEW: "payment.view",
  PAYMENT_CREATE: "payment.create",
  PAYMENT_CANCEL: "payment.cancel",
  PAYMENT_REVERSE: "payment.reverse"
});

const ALL_PERMISSIONS = Object.freeze(Object.values(PERMISSIONS));
window.PERMISSIONS = PERMISSIONS;
window.ALL_PERMISSIONS = ALL_PERMISSIONS;
