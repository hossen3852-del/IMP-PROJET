/**
 * IMP RBAC Manager — 11.P.5 server-backed UI authorization.
 * It never derives authority from localStorage or hard-coded role permissions.
 * Server /api/auth/me is the authority; this object only mirrors its result for UX.
 */
(function (global) {
  "use strict";

  function RBACManagerClass() {
    this._permissions = new Set();
    this._role = null;
    this._ready = false;
    this._readyPromise = null;
  }

  RBACManagerClass.prototype.bootstrap = function () {
    var self = this;
    if (this._readyPromise) return this._readyPromise;

    this._readyPromise = (typeof SessionManager !== "undefined"
      ? SessionManager.waitUntilReady()
      : Promise.resolve(null)
    ).then(function (session) {
      session = session || (typeof SessionManager !== "undefined" ? SessionManager.getCurrentUser() : null);
      self._role = session ? (session.role || null) : null;
      self._permissions = new Set(
        session && Array.isArray(session.permissions) ? session.permissions : []
      );
      self._ready = true;
      return session;
    }).catch(function (error) {
      self._ready = true;
      self._role = null;
      self._permissions = new Set();
      console.error("[IMP] RBAC bootstrap failed:", error);
      return null;
    });

    return this._readyPromise;
  };

  RBACManagerClass.prototype.getCurrentRole = function () {
    return this._role;
  };

  RBACManagerClass.prototype.getPermissions = function () {
    return Array.from(this._permissions);
  };

  RBACManagerClass.prototype.hasPermission = function (permissionCode) {
    if (!permissionCode) return true;
    if (!this._ready) this.bootstrap();
    return this._permissions.has(permissionCode);
  };

  RBACManagerClass.prototype.hasAnyPermission = function (permissions) {
    return Array.isArray(permissions) && permissions.some(this.hasPermission.bind(this));
  };

  RBACManagerClass.prototype.hasAllPermissions = function (permissions) {
    return Array.isArray(permissions) && permissions.every(this.hasPermission.bind(this));
  };

  RBACManagerClass.prototype.can = function (action, resource) {
    if (!action || !resource) return false;
    return this.hasPermission(resource + "." + action);
  };

  RBACManagerClass.prototype.enforcePermission = function (permissionCode) {
    if (!this.hasPermission(permissionCode)) {
      console.warn("Access denied: missing permission [" + permissionCode + "]");
      if (typeof Utils !== "undefined" && Utils.redirect) {
        Utils.redirect("../../pages/dashboard/dashboard.html");
      }
      return false;
    }
    return true;
  };

  RBACManagerClass.prototype.belongsToOrganization = function (record) {
    var currentUser = typeof SessionManager !== "undefined" ? SessionManager.getCurrentUser() : null;
    if (!currentUser || !record || record.organizationId == null) return false;
    return String(record.organizationId) === String(currentUser.organizationId);
  };

  RBACManagerClass.prototype.applyUIProtection = function () {
    var self = this;
    if (typeof document === "undefined") return;
    document.querySelectorAll("[data-permission]").forEach(function (el) {
      var required = el.getAttribute("data-permission");
      if (!self.hasPermission(required)) {
        el.remove();
      }
    });
  };

  global.RBACManager = new RBACManagerClass();
  global.RBACManager.bootstrap();
})(typeof window !== "undefined" ? window : this);
