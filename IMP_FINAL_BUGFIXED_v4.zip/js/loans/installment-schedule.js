/** IMP 11.P.9 — API-backed installment schedule. */
'use strict';

function esc(v) { const d=document.createElement('div'); d.textContent=v ?? ''; return d.innerHTML; }
function money(v) { return Number(v || 0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2}); }
function date(v) { return v ? new Date(`${v}T00:00:00`).toLocaleDateString() : '-'; }
function loanId() { return new URLSearchParams(location.search).get('id') || new URLSearchParams(location.search).get('loanId'); }
function renderLoan(loan) {
  const el=document.getElementById('loanSummary'); if(!el) return;
  el.innerHTML=`<h2>${esc(loan.memberName || 'Loan')}</h2><p>Loan: ${esc(loan.loanNumber)} · ${esc(loan.loanType)} · Total payable: ${money(loan.totalPayable)}</p>`;
}
function render(rows) {
  const body=document.getElementById('scheduleBody');
  const counts={paid:0,partial:0,overdue:0};
  rows.forEach(r=>{ if(counts[r.status]!==undefined) counts[r.status]++; });
  document.getElementById('totalInstallments').textContent=rows.length;
  document.getElementById('paidCount').textContent=counts.paid;
  document.getElementById('partialCount').textContent=counts.partial;
  document.getElementById('overdueCount').textContent=counts.overdue;
  body.innerHTML=rows.map(r=>`<tr><td>${r.installmentNumber}</td><td>${date(r.dueDate)}</td><td>${money(r.amount)}</td><td>${money(r.paidAmount)}</td><td>${money(r.outstandingAmount)}</td><td>${esc(r.status)}</td></tr>`).join('');
}
async function initInstallmentSchedule() {
  try {
    await SessionManager.requireAuth();
    await RBACManager.bootstrap();
    if (!RBACManager.hasPermission('loan.view')) throw new Error('You do not have permission to view installments');
    const id=loanId(); if(!id) throw new Error('Loan ID is required');
    const loan=(await LoanManager.findLoan(id)); if(!loan) throw new Error('Loan not found or you do not have access');
    renderLoan(loan);
    let result=await IMP_API.get('/installments?loan_id='+encodeURIComponent(id));
    let rows=result.installments || [];
    if(!rows.length && ['approved','disbursed','active','completed'].includes(loan.status)) {
      result=await IMP_API.post('/installments/generate',{loanId:id}); rows=result.installments || [];
    }
    render(rows);
    document.getElementById('backBtn')?.addEventListener('click',()=>history.back());
    document.getElementById('paymentBtn')?.addEventListener('click',()=>{ location.href=`payment-collection.html?loanId=${encodeURIComponent(id)}`; });
  } catch(e) {
    const el=document.getElementById('scheduleBody'); if(el) el.innerHTML=`<tr><td colspan="6">${esc(e.message || 'Unable to load installment schedule')}</td></tr>`;
  }
}
window.InstallmentScheduleManager=Object.freeze({list:async loanId=>(await IMP_API.get('/installments?loan_id='+encodeURIComponent(loanId))).installments||[],generate:async loanId=>(await IMP_API.post('/installments/generate',{loanId})).installments||[]});
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',initInstallmentSchedule); else initInstallmentSchedule();
