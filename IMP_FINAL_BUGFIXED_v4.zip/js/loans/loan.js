/**
 * IMP Loan API Service — 11.P.8
 * PostgreSQL/API is authoritative. No loan persistence or authorization is
 * performed through browser storage.
 */
'use strict';

(function (global) {
  const LoanManager = {
    async list(filters = {}) {
      const params = new URLSearchParams();
      if (filters.q) params.set('q', filters.q);
      if (filters.status) params.set('status', filters.status);
      if (filters.branchId) params.set('branch_id', filters.branchId);
      if (filters.memberId) params.set('member_id', filters.memberId);
      if (filters.limit) params.set('limit', String(filters.limit));
      if (filters.offset) params.set('offset', String(filters.offset));
      const query = params.toString();
      const result = await IMP_API.get('/loans' + (query ? '?' + query : ''));
      return result.loans || [];
    },

    async findLoan(id) {
      if (!id) return null;
      try {
        const result = await IMP_API.get('/loans/' + encodeURIComponent(id));
        return result.loan || null;
      } catch (error) {
        if (error.status === 404) return null;
        throw error;
      }
    },

    async createLoan(data) {
      const result = await IMP_API.post('/loans', data);
      return result.loan;
    },

    async updateLoan(id, data) {
      const result = await IMP_API.patch('/loans/' + encodeURIComponent(id), data);
      return result.loan;
    },

    async approveLoan(id) {
      const result = await IMP_API.post('/loans/' + encodeURIComponent(id) + '/approve', {});
      return result.loan;
    },

    async disburseLoan(id) {
      const result = await IMP_API.post('/loans/' + encodeURIComponent(id) + '/disburse', {});
      return result.loan;
    },

    async changeStatus(id, status) {
      const result = await IMP_API.post('/loans/' + encodeURIComponent(id) + '/status', { status });
      return result.loan;
    },

    async deleteLoan(id) {
      await IMP_API.delete('/loans/' + encodeURIComponent(id));
      return true;
    }
  };

  global.LoanManager = Object.freeze(LoanManager);
  global.LoanService = LoanManager;
})(window);
