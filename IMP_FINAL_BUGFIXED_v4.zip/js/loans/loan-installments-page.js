'use strict';
/**
 * Loan Installments page controller — wires loan-installments.html to API.
 * Replaces mismatched installment-schedule.js binding on this page.
 */
(function () {
  function $(id) { return document.getElementById(id); }
  function esc(v) {
    return String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function money(v) {
    return new Intl.NumberFormat('en-BD', { style: 'currency', currency: 'BDT' }).format(Number(v || 0));
  }
  function dateStr(v) {
    if (!v) return '—';
    const d = new Date(v);
    if (Number.isNaN(d.getTime())) return String(v).slice(0, 10);
    return d.toISOString().slice(0, 10);
  }
  function setText(id, value) {
    const el = $(id);
    if (!el) return;
    const t = value == null || value === '' ? '—' : String(value);
    el.textContent = t;
    el.dataset.i18nOriginal = t;
    el.dataset.i18nSkip = '1';
  }
  function loanIdFromUrl() {
    const p = new URLSearchParams(location.search);
    return p.get('id') || p.get('loanId') || p.get('loan_id') || '';
  }
  function showLoading(on) {
    const load = $('loadingMessage');
    const content = $('installmentContent');
    const err = $('errorMessage');
    if (load) load.classList.toggle('hidden', !on);
    if (content) content.classList.toggle('hidden', on);
    if (err) err.classList.add('hidden');
  }
  function showError(msg) {
    showLoading(false);
    const content = $('installmentContent');
    if (content) content.classList.add('hidden');
    const err = $('errorMessage');
    if (err) {
      err.textContent = msg || 'Unable to load installment schedule';
      err.classList.remove('hidden');
      err.style.display = 'block';
    }
  }

  async function loadSchedule(loanId) {
    let result = await IMP_API.get('/installments?loan_id=' + encodeURIComponent(loanId));
    let rows = Array.isArray(result?.installments) ? result.installments : [];
    return rows;
  }

  async function generateSchedule(loanId) {
    const result = await IMP_API.post('/installments/generate', { loanId });
    return Array.isArray(result?.installments) ? result.installments : [];
  }

  function renderLoanHeader(loan) {
    setText('loanNumber', loan.loanNumber || loan.loan_number || '—');
    setText('memberName', loan.memberName || loan.member_name || loan.memberId || '—');
    setText('loanAmount', money(loan.loanAmount ?? loan.loan_amount));
    setText('installmentAmount', money(loan.installmentAmount ?? loan.installment_amount));
    setText('installmentFrequency', loan.installmentFrequency || loan.repaymentFrequency || '—');
    setText('totalPayable', money(loan.totalPayable ?? loan.total_payable));
  }

  function renderStats(loan, rows) {
    const paid = rows.filter((r) => String(r.status).toLowerCase() === 'paid').length;
    const partial = rows.filter((r) => String(r.status).toLowerCase() === 'partial').length;
    const overdue = rows.filter((r) => {
      const st = String(r.status).toLowerCase();
      if (st === 'overdue') return true;
      if (['paid', 'waived', 'cancelled'].includes(st)) return false;
      const due = r.dueDate || r.due_date;
      if (!due) return false;
      const d = new Date(due);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      return !Number.isNaN(d.getTime()) && d < today && Number(r.outstandingAmount ?? r.outstanding ?? 0) > 0;
    }).length;
    const dueOpen = rows.filter((r) => {
      const st = String(r.status).toLowerCase();
      return st === 'pending' || st === 'partial' || st === 'overdue';
    }).length;

    const totalPaidAmt = rows.reduce((s, r) => s + Number(r.paidAmount ?? r.paid_amount ?? 0), 0);
    const totalDueAmt = rows.reduce((s, r) => s + Number(r.outstandingAmount ?? r.outstanding ?? 0), 0);
    const payable = Number(loan.totalPayable ?? loan.total_payable ?? 0);
    const remaining = Number(loan.outstandingAmount != null ? loan.outstandingAmount : totalDueAmt);
    const progress = payable > 0 ? Math.min(100, Math.round((totalPaidAmt / payable) * 100)) : 0;

    setText('totalInstallments', rows.length);
    setText('paidInstallments', paid);
    setText('dueInstallments', dueOpen);
    setText('overdueInstallments', overdue);
    setText('totalPaid', money(totalPaidAmt));
    setText('totalDue', money(totalDueAmt));
    setText('remainingBalance', money(remaining));
    setText('progressPercent', progress + '%');
    const bar = $('progressBar');
    if (bar) {
      bar.style.width = progress + '%';
      bar.dataset.i18nSkip = '1';
    }
  }

  function renderTable(rows) {
    const body = $('installmentTableBody');
    if (!body) return;
    if (!rows.length) {
      body.innerHTML = '<tr><td colspan="7">No installment schedule yet. Approve &amp; disburse the loan, then generate schedule.</td></tr>';
      return;
    }
    body.innerHTML = rows.map((r) => {
      const n = r.installmentNumber ?? r.installment_number ?? '';
      const due = dateStr(r.dueDate || r.due_date);
      const amt = money(r.amount ?? r.installmentAmount ?? r.installment_amount);
      const paid = money(r.paidAmount ?? r.paid_amount);
      const out = money(r.outstandingAmount ?? r.outstanding);
      const paidDate = dateStr(r.paidDate || r.paid_date);
      const rawStatus = String(r.status || '').toLowerCase();
      const statusLabels = {
        paid: 'পরিশোধিত',
        partial: 'আংশিক',
        overdue: 'বকেয়া',
        pending: 'বকেয়া',
        due: 'বকেয়া',
        waived: 'মওকুফ',
        cancelled: 'বাতিল'
      };
      // After daily collection, remaining due installments show as বকেয়া
      let displayStatus = statusLabels[rawStatus] || r.status || '—';
      const dueDate = r.dueDate || r.due_date;
      const outstanding = Number(r.outstandingAmount ?? r.outstanding_amount ?? r.amount ?? 0) - Number(r.paidAmount ?? r.paid_amount ?? 0);
      if (['pending', 'due', 'partial'].includes(rawStatus) || (outstanding > 0.009 && !['paid','waived','cancelled'].includes(rawStatus))) {
        if (dueDate) {
          const d = new Date(dueDate);
          const today = new Date();
          today.setHours(0,0,0,0);
          if (!isNaN(d.getTime()) && d <= today && outstanding > 0.009) {
            displayStatus = 'বকেয়া';
          }
        } else if (outstanding > 0.009 && rawStatus !== 'paid') {
          displayStatus = statusLabels[rawStatus] || 'বকেয়া';
        }
      }
      const badgeClass = (displayStatus === 'বকেয়া' || rawStatus === 'overdue') ? 'overdue' : rawStatus;
      const status = esc(displayStatus);
      return `<tr>
        <td>${esc(n)}</td>
        <td>${esc(due)}</td>
        <td>${esc(amt)}</td>
        <td>${esc(paid)}</td>
        <td>${esc(out)}</td>
        <td>${esc(paidDate)}</td>
        <td><span class="status-badge status-${esc(badgeClass)}">${status}</span></td>
      </tr>`;
    }).join('');
  }

  async function init() {
    showLoading(true);
    try {
      const ok = await SessionManager.requireAuth();
      if (!ok) return;
      await RBACManager.bootstrap();
      if (!RBACManager.hasPermission('loan.view')) {
        throw new Error('You do not have permission to view installments.');
      }

      const id = loanIdFromUrl();
      if (!id) {
        // This is a loan-specific detail page. Guide users back to the loan list
        // instead of showing a raw JavaScript error when opened from a bookmark
        // or an old navigation link.
        showError('কিস্তির বিস্তারিত দেখতে একটি ঋণ নির্বাচন করুন। আপনাকে ঋণ তালিকায় নেওয়া হচ্ছে…');
        setTimeout(() => {
          window.location.href = './loan-list.html?view=installments';
        }, 900);
        return;
      }

      const loan = await LoanManager.findLoan(id);
      if (!loan) throw new Error('Loan not found or you do not have access.');

      let rows = await loadSchedule(id);

      // Auto-generate when allowed and empty
      if (!rows.length && ['approved', 'disbursed', 'active', 'completed'].includes(loan.status)) {
        try {
          rows = await generateSchedule(id);
        } catch (genErr) {
          console.warn('[IMP] Schedule generate:', genErr);
          // still show empty with message
        }
      }

      renderLoanHeader(loan);
      renderStats(loan, rows);
      renderTable(rows);

      showLoading(false);
      const content = $('installmentContent');
      if (content) content.classList.remove('hidden');

      // Empty state helper for draft/pending
      if (!rows.length) {
        const body = $('installmentTableBody');
        if (body) {
          const tip = ['draft', 'pending'].includes(loan.status)
            ? `Loan status is "${loan.status}". Approve and disburse the loan before generating an installment schedule.`
            : 'No installment schedule found for this loan.';
          body.innerHTML = `<tr><td colspan="7">${esc(tip)}</td></tr>`;
        }
      }

      $('backBtn')?.addEventListener('click', () => history.back());
      $('loanProfileBtn')?.addEventListener('click', () => {
        location.href = './loan-profile.html?id=' + encodeURIComponent(id);
      });
    } catch (e) {
      console.error('[IMP] loan-installments page:', e);
      showError(e.message || 'Unable to load installment schedule');
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
