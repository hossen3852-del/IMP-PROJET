"use strict";

document.addEventListener("DOMContentLoaded", async function () {
    const params = new URLSearchParams(location.search);
    const loanId = params.get("id") || params.get("loanId");
    const message = document.getElementById("message");
    const select = document.getElementById("installmentId");
    const amountInput = document.getElementById("amount");
    const form = document.getElementById("paymentForm");
    const show = (text, type="error") => { if(message){message.textContent=text;message.className=`message ${type}`;} };
    const esc = v => String(v ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;");
    try {
        await SessionManager.requireAuth();
        await RBACManager.bootstrap();
        if (!RBACManager.hasPermission("payment.create")) throw new Error("You do not have permission to create payments.");
        if (!loanId) throw new Error("Loan ID is required.");
        const loan = await LoanManager.findLoan(loanId);
        if (!loan) throw new Error("Loan not found or you do not have access.");
        const scheduleResult = await IMP_API.get(`/installments?loan_id=${encodeURIComponent(loanId)}`);
        const installments = Array.isArray(scheduleResult?.installments) ? scheduleResult.installments : [];
        const open = installments.filter(i => !["paid","waived","cancelled"].includes(i.status) && Number(i.outstandingAmount ?? i.outstanding ?? 0) > 0);
        const info = document.getElementById("loanInfo");
        if(info) info.innerHTML=`<h2>${esc(loan.loanNumber || "Loan")}</h2><p>Loan Amount: <strong>৳${Number(loan.loanAmount||0).toFixed(2)}</strong></p><p>Outstanding: <strong>৳${Number(loan.outstandingAmount||0).toFixed(2)}</strong></p>`;
        if(select){ select.innerHTML=`<option value="">Select installment</option>`; open.forEach(i=>{const o=document.createElement("option");o.value=i.id;o.textContent=`Installment #${i.installmentNumber} — Due ৳${Number(i.outstandingAmount ?? i.outstanding ?? 0).toFixed(2)} — ${i.dueDate||""}`;select.appendChild(o);}); }
        const dateInput=document.getElementById("paymentDate"); if(dateInput) dateInput.value=new Date().toISOString().slice(0,10);
        select?.addEventListener("change",()=>{const i=open.find(x=>String(x.id)===String(select.value));if(i&&amountInput)amountInput.value=Number(i.outstandingAmount ?? i.outstanding ?? 0).toFixed(2);});
        form?.addEventListener("submit",async e=>{e.preventDefault();try{const i=open.find(x=>String(x.id)===String(select?.value));if(!i)throw new Error("Please select an installment.");const amount=Number(amountInput?.value);const max=Number(i.outstandingAmount ?? i.outstanding ?? 0);if(!Number.isFinite(amount)||amount<=0||amount>max)throw new Error("Invalid payment amount.");const result=await PaymentAPI.create({memberId:loan.memberId,loanId:loan.id,amount,paymentDate:new Date(`${dateInput?.value||new Date().toISOString().slice(0,10)}T00:00:00`).toISOString(),paymentMethod:document.getElementById("paymentMethod")?.value||"cash",transactionReference:"",bankName:"",bankAccount:"",collectorId:null,notes:document.getElementById("note")?.value?.trim()||""});show("Payment collected successfully.","success");setTimeout(()=>location.href=`../payments/payment-receipt.html?paymentId=${encodeURIComponent(result.payment.id)}`,500);}catch(err){show(err.message||"Unable to record payment.");}});
        document.getElementById("backBtn")?.addEventListener("click",()=>history.back());
    } catch(e) { show(e.message||"Unable to initialize payment collection."); }
});
