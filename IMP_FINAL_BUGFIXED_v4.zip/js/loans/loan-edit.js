'use strict';

document.addEventListener('DOMContentLoaded', async function () {
  const params=new URLSearchParams(location.search); const id=params.get('id') || params.get('loanId');
  const message=document.getElementById('message'); const $=id=>document.getElementById(id);
  const show=(text,type='success')=>{message.textContent=text;message.className='message '+type;};
  await SessionManager.requireAuth(); await RBACManager.bootstrap();
  if(!RBACManager.hasPermission('loan.update')){show('You do not have permission to edit loans.','error');return;}
  let loan;
  try{loan=await LoanManager.findLoan(id);}catch(e){show(e.message||'Unable to load loan','error');return;}
  if(!loan){show('Loan not found.','error');return;}
  if(!['draft','pending'].includes(loan.status)){show('Only draft or pending loans can be edited.','error');return;}
  $('loanNumber').value=loan.loanNumber||''; $('loanType').value=loan.loanType||''; $('loanAmount').value=loan.loanAmount||0; $('interestAmount').value=loan.interestAmount||0; $('installmentAmount').value=loan.installmentAmount||0; $('startDate').value=loan.startDate||''; $('loanPurpose').value=loan.loanPurpose||''; if($('status')) $('status').value=loan.status;
  if($('status')) $('status').closest('.form-group')?.remove();
  $('backBtn').onclick=()=>history.back(); $('cancelBtn').onclick=()=>history.back();
  $('editLoanForm').addEventListener('submit',async event=>{
    event.preventDefault();
    try{
      const updated=await LoanManager.updateLoan(id,{loanType:$('loanType').value.trim(),loanAmount:Number($('loanAmount').value),interestAmount:Number($('interestAmount').value||0),installmentAmount:Number($('installmentAmount').value),startDate:$('startDate').value,loanPurpose:$('loanPurpose').value.trim()});
      show('Loan updated successfully.');
      setTimeout(()=>location.href='./loan-profile.html?id='+encodeURIComponent(updated.id),500);
    }catch(e){show(e.message||'Unable to update loan','error');}
  });
});
