'use strict';

document.addEventListener('DOMContentLoaded', async function () {
  const setText = (id, value) => {
    const el = document.getElementById(id);
    if (!el) return;
    const v = value == null || value === '' ? '—' : String(value);
    el.textContent = v;
    el.dataset.i18nOriginal = v;
    el.dataset.i18nSkip = '1';
  };

  const currency = (v) =>
    new Intl.NumberFormat('en-BD', { style: 'currency', currency: 'BDT' }).format(Number(v || 0));

  try {
    const ok = await SessionManager.requireAuth();
    if (!ok) return;
    await RBACManager.bootstrap();
    if (!RBACManager.hasPermission('loan.view')) {
      location.href = '../../pages/dashboard/dashboard.html';
      return;
    }

    const loans = await LoanManager.list({ limit: 500 });
    const activeStatuses = new Set(['draft', 'pending', 'approved', 'disbursed', 'active']);
    const portfolio = Array.isArray(loans) ? loans : [];

    // Disbursed = sum of disbursed_amount (only real disbursements)
    const totalDisbursed = portfolio.reduce((s, l) => s + Number(l.disbursedAmount || 0), 0);

    // Outstanding = sum of outstanding on non-closed loans
    const outstanding = portfolio
      .filter((l) => activeStatuses.has(l.status) || l.status === 'completed')
      .reduce((s, l) => {
        if (l.status === 'completed' || l.status === 'cancelled' || l.status === 'rejected') return s;
        return s + Number(l.outstandingAmount != null ? l.outstandingAmount : l.totalPayable || 0);
      }, 0);

    // Total paid ≈ disbursed principal path: totalPayable - outstanding for disbursed/active/completed
    // Prefer: sum (totalPayable - outstanding) for loans that have been disbursed
    const totalPaid = portfolio.reduce((s, l) => {
      if (!['disbursed', 'active', 'completed'].includes(l.status)) return s;
      const payable = Number(l.totalPayable || 0);
      const out = Number(l.outstandingAmount != null ? l.outstandingAmount : payable);
      return s + Math.max(0, payable - out);
    }, 0);

    const completedLoans = portfolio.filter((l) => l.status === 'completed').length;

    // Overdue: from installments API (status overdue or past due with outstanding)
    let overdueAmount = 0;
    try {
      const instResult = await IMP_API.get('/installments?limit=1000');
      const rows = Array.isArray(instResult?.installments) ? instResult.installments : [];
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      overdueAmount = rows.reduce((s, i) => {
        const status = String(i.status || '').toLowerCase();
        const out = Number(i.outstandingAmount ?? i.outstanding ?? 0);
        if (out <= 0) return s;
        if (status === 'overdue') return s + out;
        if (status === 'paid' || status === 'waived' || status === 'cancelled') return s;
        const due = i.dueDate || i.due_date;
        if (due) {
          const d = new Date(due);
          if (!Number.isNaN(d.getTime()) && d < today) return s + out;
        }
        return s;
      }, 0);
    } catch (_) {
      // Installment list may require loan_id on some deployments — leave 0
      overdueAmount = 0;
    }

    const statusCounts = {};
    portfolio.forEach((l) => {
      const st = l.status || 'unknown';
      statusCounts[st] = (statusCounts[st] || 0) + 1;
    });

    setText('totalLoans', portfolio.length);
    setText('totalDisbursed', currency(totalDisbursed));
    setText('totalPaid', currency(totalPaid));
    setText('outstanding', currency(outstanding));
    setText('overdue', currency(overdueAmount));
    setText('completedLoans', completedLoans);

    const summary = document.getElementById('statusSummary');
    if (summary) {
      summary.innerHTML = '';
      const order = ['draft', 'pending', 'approved', 'disbursed', 'active', 'completed', 'written_off', 'cancelled', 'rejected'];
      const keys = [...order.filter((k) => statusCounts[k]), ...Object.keys(statusCounts).filter((k) => !order.includes(k))];
      keys.forEach((status) => {
        const div = document.createElement('div');
        div.className = 'status-item';
        const span = document.createElement('span');
        span.textContent = status;
        span.dataset.i18nSkip = '1';
        const strong = document.createElement('strong');
        strong.textContent = String(statusCounts[status]);
        strong.dataset.i18nSkip = '1';
        div.append(span, strong);
        summary.appendChild(div);
      });
      if (!keys.length) {
        summary.textContent = 'No loans yet.';
      }
    }
  } catch (e) {
    console.error('[IMP] Loan dashboard failed:', e);
    const err = document.getElementById('dashboardError');
    if (err) { err.style.display = 'block'; err.textContent = e.message || 'Unable to load loan dashboard'; }
    const el = document.getElementById('statusSummary');
    if (el) el.textContent = e.message || 'Unable to load loan dashboard';
  }

  const completedCard = document.getElementById('completedLoans');
  completedCard?.closest('.stat-card')?.addEventListener('click', () => { location.href = './loan-list.html?status=completed'; });
  const btn = document.getElementById('loanListBtn');
  if (btn) btn.onclick = () => { location.href = './loan-list.html'; };
});
