/**
 * IMP Loan Profile — 11.P.8 API cut-over.
 * Loan/member/branch records are loaded from server APIs only.
 */
'use strict';

function $(id) { return document.getElementById(id); }
function escapeHTML(value) { return String(value ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }

async function findLoan() {
  const params = new URLSearchParams(window.location.search);
  return LoanManager.findLoan(params.get('id') || params.get('loanId') || params.get('loanCode'));
}

async function findMember(loan) {
  if (!loan?.memberId) return null;
  try { const result=await IMP_API.get('/members/'+encodeURIComponent(loan.memberId)); return result.member || null; }
  catch (_) { return null; }
}

async function findBranch(loan) {
  if (!loan?.branchId) return null;
  try { const result=await IMP_API.get('/branches/'+encodeURIComponent(loan.branchId)); return result.branch || null; }
  catch (_) { return null; }
}

function getLoanIdFromURL() {
  const params=new URLSearchParams(window.location.search);
  return params.get('id') || params.get('loanId') || params.get('loanCode');
}

function formatCurrency(value) {

    const number =
        Number(value);

    if (Number.isNaN(number)) {
        return "-";
    }

    return new Intl.NumberFormat(
        "en-BD",
        {
            style: "currency",
            currency: "BDT",
            maximumFractionDigits: 2
        }
    ).format(number);

}


/* =========================================================
   Format Date
========================================================= */

function formatDate(value) {

    if (!value) {
        return "-";
    }

    const date =
        new Date(value);

    if (Number.isNaN(date.getTime())) {
        return escapeHTML(value);
    }

    return date.toLocaleDateString(
        "en-GB",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );

}


/* =========================================================
   Format DateTime
========================================================= */

function formatDateTime(value) {

    if (!value) {
        return "-";
    }

    const date =
        new Date(value);

    if (Number.isNaN(date.getTime())) {
        return escapeHTML(value);
    }

    return date.toLocaleString(
        "en-GB",
        {
            day: "2-digit",
            month: "short",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
        }
    );

}


/* =========================================================
   Text Helper
========================================================= */

function getValue(
    object,
    paths,
    fallback = "-"
) {

    for (const path of paths) {

        const parts =
            path.split(".");

        let value =
            object;

        for (const part of parts) {

            if (
                value === null ||
                value === undefined
            ) {
                value = undefined;
                break;
            }

            value =
                value[part];
        }

        if (
            value !== undefined &&
            value !== null &&
            value !== ""
        ) {
            return value;
        }

    }

    return fallback;
}


/* =========================================================
   Set Text
========================================================= */

function setText(
    elementId,
    value
) {

    const element =
        $(elementId);

    if (!element) {
        return;
    }

    element.textContent =
        value ?? "-";
}


/* =========================================================
   Status
========================================================= */

function setStatus(status) {

    const element =
        $("loanStatus");

    if (!element) {
        return;
    }

    const normalized =
        String(status || "unknown")
            .toLowerCase()
            .replace(/\s+/g, "-");

    element.textContent =
        status || "Unknown";

    element.className =
        "status-badge status-" +
        normalized;

}


/* =========================================================
   Render Loan
========================================================= */

function renderLoan(
    loan,
    member,
    branch
) {

    /* Member Hero */
    const memberName = getValue(member || {}, ["personalInfo.fullName","fullName","name"], "-");
    const memberPhone = getValue(member || {}, ["personalInfo.mobile","personalInfo.phone","mobile","phone"], "-");
    setText("loanMemberHeroName", memberName);
    setText("loanMemberHeroPhone", memberPhone);
    const photo = $("loanMemberPhoto");
    const photoPlaceholder = $("loanMemberPhotoPlaceholder");
    const photoSrc = member?.memberPhoto || member?.photoPath || member?.photo_path || null;
    if (photo && photoSrc) {
        photo.src = photoSrc;
        photo.hidden = false;
        if (photoPlaceholder) photoPlaceholder.hidden = true;
        photo.onerror = () => {
            photo.hidden = true;
            if (photoPlaceholder) photoPlaceholder.hidden = false;
        };
    }

    /* Loan Summary */

    setText(
        "loanNumber",
        getValue(
            loan,
            [
                "loanNumber",
                "loanCode",
                "id"
            ]
        )
    );

    setText(
        "loanType",
        getValue(
            loan,
            [
                "loanType",
                "type",
                "productName"
            ]
        )
    );


    setText(
        "loanAmount",
        formatCurrency(
            getValue(
                loan,
                [
                    "loanAmount",
                    "amount",
                    "principalAmount"
                ],
                0
            )
        )
    );


    setText(
        "totalPayable",
        formatCurrency(
            getValue(
                loan,
                [
                    "totalPayable",
                    "totalAmount",
                    "payableAmount"
                ],
                0
            )
        )
    );


    setText(
        "installmentAmount",
        formatCurrency(
            getValue(
                loan,
                [
                    "installmentAmount",
                    "emi",
                    "installment"
                ],
                0
            )
        )
    );


    setText(
        "installmentFrequency",
        getValue(
            loan,
            [
                "installmentFrequency",
                "frequency",
                "paymentFrequency"
            ]
        )
    );


    setText(
        "loanDuration",
        getValue(
            loan,
            [
                "duration",
                "loanDuration",
                "term"
            ]
        )
    );


    setText(
        "startDate",
        formatDate(
            getValue(
                loan,
                [
                    "startDate",
                    "loanStartDate",
                    "disbursementDate"
                ],
                null
            )
        )
    );


    setStatus(
        getValue(
            loan,
            [
                "status",
                "loanStatus"
            ],
            "Unknown"
        )
    );


    /* Member */

    setText(
        "memberCode",
        getValue(
            loan,
            [
                "member.memberCode",
                "memberCode"
            ],
            getValue(
                member || {},
                [
                    "memberCode",
                    "code",
                    "id"
                ]
            )
        )
    );


    setText(
        "memberName",
        getValue(
            loan,
            [
                "member.fullName",
                "member.name"
            ],
            getValue(
                member || {},
                [
                    "personalInfo.fullName",
                    "fullName",
                    "name"
                ]
            )
        )
    );


    setText(
        "memberPhone",
        getValue(
            loan,
            [
                "member.phone",
                "member.mobile"
            ],
            getValue(
                member || {},
                [
                    "personalInfo.mobile",
                    "personalInfo.phone",
                    "mobile",
                    "phone"
                ]
            )
        )
    );


    setText(
        "memberAddress",
        getValue(
            loan,
            [
                "member.address"
            ],
            getValue(
                member || {},
                [
                    "personalInfo.address",
                    "address",
                    "presentAddress"
                ]
            )
        )
    );


    /* Organization */

    setText(
        "organizationName",
        getValue(
            loan,
            [
                "organizationName",
                "companyName",
                "organization.name",
                "company.name"
            ],
            "-"
        )
    );


    setText(
        "branchName",
        getValue(
            loan,
            [
                "branch.name",
                "branchName"
            ],
            getValue(
                branch || {},
                [
                    "branchName",
                    "name"
                ]
            )
        )
    );


    setText(
        "fieldOfficer",
        getValue(
            loan,
            [
                "fieldOfficer.name",
                "fieldOfficerName",
                "officerName",
                "assignedOfficer"
            ]
        )
    );


    /* Purpose */

    setText(
        "loanPurpose",
        getValue(
            loan,
            [
                "loanPurpose",
                "purpose",
                "reason"
            ]
        )
    );


    /* Timeline */

    setText(
        "applicationDate",
        formatDate(
            getValue(
                loan,
                [
                    "applicationDate",
                    "appliedAt",
                    "createdAt"
                ],
                null
            )
        )
    );


    setText(
        "approvalDate",
        formatDate(
            getValue(
                loan,
                [
                    "approvalDate",
                    "approvedAt"
                ],
                null
            )
        )
    );


    setText(
        "timelineStartDate",
        formatDate(
            getValue(
                loan,
                [
                    "startDate",
                    "loanStartDate",
                    "disbursementDate"
                ],
                null
            )
        )
    );


    setText(
        "endDate",
        formatDate(
            getValue(
                loan,
                [
                    "endDate",
                    "expectedEndDate",
                    "maturityDate"
                ],
                null
            )
        )
    );


    /* System */

    setText(
        "createdAt",
        formatDateTime(
            getValue(
                loan,
                [
                    "createdAt",
                    "createdDate"
                ],
                null
            )
        )
    );


    setText(
        "createdBy",
        getValue(
            loan,
            [
                "createdBy.name",
                "createdByName",
                "createdBy"
            ]
        )
    );


    setText(
        "updatedAt",
        formatDateTime(
            getValue(
                loan,
                [
                    "updatedAt",
                    "updatedDate"
                ],
                null
            )
        )
    );

}


/* =========================================================
   Permission
========================================================= */

function canEditLoan() {
        return typeof RBACManager !== 'undefined' && RBACManager.hasPermission('loan.update');
    }

    /* =========================================================
       Edit Button
========================================================= */

function setupEditButton(loan) {

    const editBtn =
        $("editBtn");

    if (!editBtn) {
        return;
    }

    if (!canEditLoan()) {

        editBtn.style.display =
            "none";

        return;
    }

    editBtn.addEventListener(
        "click",
        function () {

            const id =
                getValue(
                    loan,
                    [
                        "id",
                        "loanId",
                        "loanNumber",
                        "loanCode"
                    ],
                    ""
                );

            if (!id) {
                return;
            }

            window.location.href =
                "./loan-edit.html?id=" +
                encodeURIComponent(id);

        }
    );

}


/* =========================================================
   Submit for Approval Button
========================================================= */

function canSubmitLoan() {
    return typeof RBACManager !== 'undefined' && RBACManager.hasPermission('loan.status.update');
}

function setupFullSettlement(loan){const b=$("fullSettlementBtn"),o=Number(loan?.outstandingAmount||0);if(!b)return;if(!["disbursed","active"].includes(String(loan?.status||""))||o<=.009){b.style.display="none";return}b.onclick=async()=>{if(!confirm(`বর্তমান বকেয়া ${formatCurrency(o)} একবারে পরিশোধ করবেন?`))return;b.disabled=true;try{const d=new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Dhaka"}).format(new Date());await IMP_API.post("/collections/daily",{date:d,branchId:loan.branchId||null,dailyExpense:0,entries:[{memberId:loan.memberId,loanId:loan.id,installmentAmount:o,savingsAmount:0,paymentMethod:"cash",notes:"Full loan settlement",status:"paid",idempotencyKey:(crypto.randomUUID?crypto.randomUUID():String(Date.now()))}]});alert("লোনের সম্পূর্ণ বকেয়া পরিশোধ হয়েছে।");location.reload()}catch(e){alert(e.message||"সম্পূর্ণ পরিশোধ ব্যর্থ হয়েছে");b.disabled=false}}}

function setupSubmitButton(loan) {

    const submitBtn =
        $("submitBtn");

    if (!submitBtn) {
        return;
    }

    if (loan.status !== 'draft' || !canSubmitLoan()) {

        submitBtn.style.display =
            "none";

        return;
    }

    submitBtn.addEventListener(
        "click",
        async function () {

            const id =
                getValue(
                    loan,
                    [
                        "id",
                        "loanId",
                        "loanNumber",
                        "loanCode"
                    ],
                    ""
                );

            if (!id) {
                return;
            }

            submitBtn.disabled = true;

            try {
                await LoanManager.changeStatus(id, 'pending');
                window.location.reload();
            } catch (e) {
                alert(e.message || 'Unable to submit loan for approval.');
                submitBtn.disabled = false;
            }

        }
    );

}


/* =========================================================
   Back Button
========================================================= */

function setupBackButton() {

    const button =
        $("backBtn");

    if (!button) {
        return;
    }

    button.addEventListener(
        "click",
        function () {

            if (
                document.referrer &&
                document.referrer.includes(
                    window.location.origin
                )
            ) {

                window.history.back();

                return;
            }

            window.location.href =
                "./loan-list.html";

        }
    );

}


/* =========================================================
   Show Error
========================================================= */

function showError(message) {

    const loading =
        $("loadingMessage");

    const error =
        $("errorMessage");

    const content =
        $("loanContent");

    if (loading) {
        loading.classList.add("hidden");
    }

    if (content) {
        content.classList.add("hidden");
    }

    if (error) {

        error.textContent =
            message;

        error.classList.remove(
            "hidden"
        );

    }

}


async function loadLoanMemberSavings(memberId) {
    if (!memberId) return;
    try {
        const result = await IMP_API.get("/savings/summary?memberId=" + encodeURIComponent(memberId));
        const s = result.summary || {};
        const money = (v) => formatCurrency(v);
        setText("loanSavingsDeposit", money(s.deposits));
        setText("loanSavingsDaily", money(s.dailyDeposits));
        setText("loanSavingsWithdrawal", money(s.withdrawals));
        setText("loanSavingsInstallmentPayment", money(s.installmentPayments));
        setText("loanSavingsBalance", money(s.balance));
    } catch (e) {
        console.warn("[IMP] Loan profile savings summary unavailable:", e);
    }
}

/* =========================================================
   Initialize
========================================================= */

async function initLoanProfile() {
    setupBackButton();
    try {
        const loan = await findLoan();
        if (!loan) { showError('Loan information could not be found or you do not have access to this loan.'); return; }
        const [member, branch] = await Promise.all([findMember(loan), findBranch(loan)]);
        renderLoan(loan, member, branch);
        await loadLoanMemberSavings(loan.memberId);
        setupEditButton(loan);
        setupSubmitButton(loan);
    setupFullSettlement(loan);
        setupInstallmentScheduleButton(loan);
        await loadRepaymentSummary(loan);
        const loading=$('loadingMessage'), content=$('loanContent');
        if (loading) loading.classList.add('hidden');
        if (content) content.classList.remove('hidden');
    } catch (e) { showError(e.message || 'Unable to load loan information.'); }
}


/* =========================================================
   Installment / Repayment Status Summary
========================================================= */

function moneyNum(v) {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
}

function parseDay(value) {
    if (!value) return null;
    const s = String(value).slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) {
        const d = new Date(value);
        if (Number.isNaN(d.getTime())) return null;
        return d;
    }
    const [y, m, d] = s.split("-").map(Number);
    return new Date(y, m - 1, d);
}

function todayLocal() {
    const n = new Date();
    return new Date(n.getFullYear(), n.getMonth(), n.getDate());
}

function installmentNote(inst, today) {
    const status = String(inst.status || "").toLowerCase();
    const due = parseDay(inst.dueDate || inst.due_date);
    const paidDate = parseDay(inst.paidDate || inst.paid_date || inst.paidAt || inst.paid_at);
    const paid = moneyNum(inst.paidAmount || inst.paid_amount);
    const outstanding = moneyNum(inst.outstandingAmount || inst.outstanding_amount);
    if (status === "paid" || (paid > 0 && outstanding <= 0.009)) {
        if (paidDate && due && paidDate < due) return "অগ্রিম পরিশোধ";
        if (paidDate && due && paidDate > due) return "দেরিতে পরিশোধ";
        return "সম্পূর্ণ পরিশোধ";
    }
    if (status === "partial" || (paid > 0.009 && outstanding > 0.009)) return "আংশিক পরিশোধ";
    if (status === "overdue" || (due && due < today && outstanding > 0.009)) return "বকেয়া";
    if (status === "pending" || outstanding > 0.009) return "বাকি";
    return status || "—";
}

function statusBn(status) {
    const s = String(status || "").toLowerCase();
    const map = {
        paid: "পরিশোধিত",
        partial: "আংশিক",
        overdue: "বকেয়া",
        pending: "বাকি",
        cancelled: "বাতিল"
    };
    return map[s] || (status || "—");
}

async function loadRepaymentSummary(loan) {
    const loanId = getValue(loan || {}, ["id", "loanId"], "");
    if (!loanId) return;

    const today = todayLocal();
    let installments = [];
    let payments = [];

    try {
        const ir = await IMP_API.get(
            "/installments?loan_id=" + encodeURIComponent(loanId) + "&limit=1000"
        );
        installments = Array.isArray(ir?.installments) ? ir.installments : (Array.isArray(ir) ? ir : []);
    } catch (e) {
        console.warn("[IMP] installments load failed:", e);
    }

    try {
        const pr = await IMP_API.get(
            "/payments?loanId=" + encodeURIComponent(loanId) + "&status=posted&limit=500"
        );
        payments = Array.isArray(pr?.payments) ? pr.payments : (Array.isArray(pr) ? pr : []);
        // fallback alternate query param names
        if (!payments.length) {
            const pr2 = await IMP_API.get(
                "/payments?loan_id=" + encodeURIComponent(loanId) + "&limit=500"
            ).catch(() => null);
            payments = Array.isArray(pr2?.payments) ? pr2.payments : [];
        }
    } catch (e) {
        console.warn("[IMP] payments load failed:", e);
    }

    let paidCount = 0;
    let partialCount = 0;
    let overdueCount = 0;
    let pendingCount = 0;
    let advanceCount = 0;
    let totalPaidAmt = 0;
    let totalOverdueAmt = 0;

    installments.forEach((inst) => {
        const status = String(inst.status || "").toLowerCase();
        const due = parseDay(inst.dueDate || inst.due_date);
        const paidDate = parseDay(inst.paidDate || inst.paid_date || inst.paidAt || inst.paid_at);
        const paid = moneyNum(inst.paidAmount || inst.paid_amount);
        const outstanding = moneyNum(inst.outstandingAmount || inst.outstanding_amount);
        const amount = moneyNum(inst.amount || inst.installmentAmount || inst.installment_amount);

        totalPaidAmt += paid;

        const isFullyPaid = status === "paid" || (paid > 0 && outstanding <= 0.009);
        const isPartial = status === "partial" || (paid > 0.009 && outstanding > 0.009);
        const isOverdue =
            status === "overdue" ||
            (!isFullyPaid && due && due < today && outstanding > 0.009);
        const isPending = !isFullyPaid && !isOverdue && (status === "pending" || outstanding > 0.009);

        if (isFullyPaid) {
            paidCount += 1;
            if (paidDate && due && paidDate < due) advanceCount += 1;
        } else if (isPartial) {
            partialCount += 1;
            if (isOverdue) {
                overdueCount += 1;
                totalOverdueAmt += outstanding;
            }
        } else if (isOverdue) {
            overdueCount += 1;
            totalOverdueAmt += outstanding > 0 ? outstanding : amount;
        } else if (isPending) {
            pendingCount += 1;
        }
    });

    const outstandingLoan = moneyNum(
        getValue(loan, ["outstandingAmount", "outstanding_amount"], 0)
    );
    const postedPayments = payments.filter(
        (p) => String(p.status || "posted").toLowerCase() === "posted"
    );
    const paymentCount = postedPayments.length;

    // Detect one-shot full settlement: single large payment covering outstanding,
    // or notes mentioning settlement, or completed with one payment.
    const notesHit = postedPayments.some((p) =>
        /full\s*loan\s*settlement|সম্পূর্ণ|full settlement/i.test(String(p.notes || p.note || ""))
    );
    const loanStatus = String(getValue(loan, ["status"], "")).toLowerCase();
    const isCompleted = loanStatus === "completed" || outstandingLoan <= 0.009;
    let fullSettlement = "না";
    if (notesHit) fullSettlement = "হ্যাঁ (নোট)";
    else if (isCompleted && paymentCount === 1 && moneyNum(postedPayments[0]?.amount) >= outstandingLoan - 0.01 && paidCount <= 1)
        fullSettlement = "হ্যাঁ (একবারে)";
    else if (isCompleted && paymentCount <= 2 && installments.length > 3 && paidCount <= 2)
        fullSettlement = "সম্ভবত হ্যাঁ";
    else if (isCompleted) fullSettlement = "না (কিস্তিভিত্তিক)";
    else fullSettlement = "এখনো বাকি";

    // Rating similar to member profile: start 100, -5 per overdue, +2 per advance
    let rating = Math.max(0, Math.min(100, 100 - overdueCount * 5 + advanceCount * 2));
    if (isCompleted && overdueCount === 0) rating = Math.min(100, rating + 5);

    setText("sumTotalInstallments", String(installments.length));
    setText("sumPaidInstallments", String(paidCount));
    setText("sumPartialInstallments", String(partialCount));
    setText("sumOverdueInstallments", String(overdueCount));
    setText("sumPendingInstallments", String(pendingCount));
    setText("sumAdvanceInstallments", String(advanceCount));
    setText("sumTotalPaidAmount", formatCurrency(totalPaidAmt));
    setText("sumTotalOverdueAmount", formatCurrency(totalOverdueAmt));
    setText("sumOutstandingAmount", formatCurrency(outstandingLoan));
    setText("sumPaymentCount", String(paymentCount));
    setText("sumFullSettlement", fullSettlement);
    setText("sumRepaymentRating", rating.toFixed(0) + "/100");

    const badge = $("repaymentHealthBadge");
    if (badge) {
        let label = "চলমান";
        let cls = "status-badge status-active";
        if (isCompleted && overdueCount === 0) {
            label = "ভালো · সম্পূর্ণ";
            cls = "status-badge status-completed";
        } else if (isCompleted && overdueCount > 0) {
            label = "সম্পূর্ণ · বকেয়া ছিল";
            cls = "status-badge status-completed";
        } else if (overdueCount > 0) {
            label = "বকেয়া আছে";
            cls = "status-badge status-overdue";
        } else if (partialCount > 0) {
            label = "আংশিক";
            cls = "status-badge status-partial";
        }
        badge.textContent = label;
        badge.className = cls;
    }

    const tbody = $("repaymentInstallmentBody");
    if (tbody) {
        if (!installments.length) {
            tbody.innerHTML =
                '<tr><td colspan="7" class="empty-cell">কোনো কিস্তি শিডিউল পাওয়া যায়নি।</td></tr>';
        } else {
            const sorted = installments.slice().sort((a, b) => {
                const da = String(a.dueDate || a.due_date || "");
                const db = String(b.dueDate || b.due_date || "");
                return da.localeCompare(db);
            });
            tbody.innerHTML = sorted
                .map((inst, idx) => {
                    const due = formatDate(inst.dueDate || inst.due_date);
                    const amt = formatCurrency(
                        moneyNum(inst.amount || inst.installmentAmount || inst.installment_amount)
                    );
                    const paid = formatCurrency(moneyNum(inst.paidAmount || inst.paid_amount));
                    const out = formatCurrency(
                        moneyNum(inst.outstandingAmount || inst.outstanding_amount)
                    );
                    const st = statusBn(inst.status);
                    const note = installmentNote(inst, today);
                    return (
                        "<tr>" +
                        "<td>" +
                        (inst.installmentNumber || inst.installment_number || idx + 1) +
                        "</td>" +
                        "<td>" +
                        escapeHTML(due) +
                        "</td>" +
                        "<td>" +
                        amt +
                        "</td>" +
                        "<td>" +
                        paid +
                        "</td>" +
                        "<td>" +
                        out +
                        "</td>" +
                        "<td>" +
                        escapeHTML(st) +
                        "</td>" +
                        "<td>" +
                        escapeHTML(note) +
                        "</td>" +
                        "</tr>"
                    );
                })
                .join("");
        }
    }

    const noteEl = $("repaymentSummaryNote");
    if (noteEl) {
        noteEl.textContent =
            "অগ্রিম = due date-এর আগে সম্পূর্ণ পরিশোধ · বকেয়া = due date পেরিয়েও outstanding · " +
            "Rating = 100 − (বকেয়া×5) + (অগ্রিম×2)";
    }
}


function setupInstallmentScheduleButton(loan) {

    const button =
        $("installmentScheduleBtn");

    if (!button) {
        return;
    }

    button.addEventListener(
        "click",
        function () {

            const id =
                getValue(
                    loan,
                    [
                        "id",
                        "loanId",
                        "loanNumber",
                        "loanCode"
                    ],
                    ""
                );

            if (!id) {
                return;
            }

            window.location.href =
                "./loan-installments.html?id=" +
                encodeURIComponent(id);
        }
    );
}

/* =========================================================
   Start
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    initLoanProfile
);