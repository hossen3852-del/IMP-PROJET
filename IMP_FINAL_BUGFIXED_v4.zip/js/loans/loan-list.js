'use strict';

document.addEventListener('DOMContentLoaded', async function () {
  const tbody = document.getElementById('loanTableBody');
  const search = document.getElementById('searchInput');
  const statusFilter = document.getElementById('statusFilter');
  let loans = [];
  const initialStatus = new URLSearchParams(location.search).get('status') || '';
  if (initialStatus) statusFilter.value = initialStatus;

  const escapeHTML = value => String(value ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  const currency = value => new Intl.NumberFormat('en-BD',{style:'currency',currency:'BDT'}).format(Number(value || 0));

  function render() {
    const query = search.value.trim().toLowerCase();
    const status = statusFilter.value;
    const filtered = loans.filter(loan => {
      const text = `${loan.loanNumber || ''} ${loan.loanType || ''} ${loan.memberName || ''} ${loan.memberCode || ''}`.toLowerCase();
      return (!query || text.includes(query)) && (!status || loan.status === status);
    });
    tbody.innerHTML = filtered.length ? filtered.map(loan => `
      <tr>
        <td>${escapeHTML(loan.loanNumber)}</td>
        <td>${escapeHTML(loan.memberName || loan.memberCode || '-')}</td>
        <td>${currency(loan.loanAmount)}</td>
        <td>${currency(loan.installmentAmount)}</td>
        <td><span class="status">${escapeHTML(loan.status)}</span></td>
        <td>${escapeHTML(loan.startDate || '-')}</td>
        <td>
          <button class="view-btn" data-id="${escapeHTML(loan.id)}">View</button>
          ${['draft','pending'].includes(loan.status) && RBACManager.hasPermission('loan.update') ? `<button class="edit-btn" data-id="${escapeHTML(loan.id)}">Edit</button>` : ''}
          ${loan.status === 'draft' && RBACManager.hasPermission('loan.status.update') ? `<button class="submit-btn" data-id="${escapeHTML(loan.id)}">Submit for Approval</button>` : ''}
          ${loan.status === 'pending' && RBACManager.hasPermission('loan.approve') ? `<button class="approve-btn" data-id="${escapeHTML(loan.id)}">Approve</button>` : ''}
          ${loan.status === 'approved' && RBACManager.hasPermission('loan.status.update') ? `<button class="disburse-btn" data-id="${escapeHTML(loan.id)}" data-loan-amount="${escapeHTML(loan.loanAmount ?? loan.loan_amount ?? 0)}">Disburse</button>` : ''}
          ${RBACManager.hasPermission('loan.view') ? `<button class="installments-btn" data-id="${escapeHTML(loan.id)}">Installments</button>` : ''}
        </td>
      </tr>`).join('') : '<tr><td colspan="7">No loans found.</td></tr>';

    tbody.querySelectorAll('.view-btn').forEach(b => b.onclick = () => location.href = './loan-profile.html?id=' + encodeURIComponent(b.dataset.id));
    tbody.querySelectorAll('.edit-btn').forEach(b => b.onclick = () => location.href = './loan-edit.html?id=' + encodeURIComponent(b.dataset.id));
    tbody.querySelectorAll('.submit-btn').forEach(b => b.onclick = async () => { await mutate(() => LoanManager.changeStatus(b.dataset.id, 'pending')); });
    tbody.querySelectorAll('.approve-btn').forEach(b => b.onclick = async () => { await mutate(() => LoanManager.approveLoan(b.dataset.id)); });
    tbody.querySelectorAll('.disburse-btn').forEach(b => b.onclick = async () => {
      const loanAmount = Number(b.dataset.loanAmount || 0);
      const insurance = Math.round(loanAmount * 0.02 * 100) / 100;
      const ok = window.confirm(
        `ঋণ বিতরণ করবেন?\nস্বয়ংক্রিয় বীমা (২%): ৳${insurance.toFixed(2)}`
      );
      if (!ok) return;
      await mutate(() => LoanManager.disburseLoan(b.dataset.id));
    });
    tbody.querySelectorAll('.installments-btn').forEach(b => b.onclick = () => location.href = './loan-installments.html?id=' + encodeURIComponent(b.dataset.id));
  }

  async function mutate(fn) {
    try { await fn(); await load(); } catch (e) { alert(e.message || 'Request failed'); }
  }

  async function load() {
    try {
      loans = await LoanManager.list({ q: search.value.trim(), status: statusFilter.value });
      render();
    } catch (e) {
      tbody.innerHTML = `<tr><td colspan="7">${escapeHTML(e.message || 'Unable to load loans')}</td></tr>`;
    }
  }

  search.addEventListener('input', load);
  statusFilter.addEventListener('change', load);
  document.getElementById('addLoanBtn').onclick = () => location.href = './loan-add.html';
  document.getElementById('dashboardBtn').onclick = () => location.href = './loan-dashboard.html';
  await SessionManager.requireAuth();
  await RBACManager.bootstrap();
  if (!RBACManager.hasPermission('loan.view')) { location.href = '../../pages/dashboard/dashboard.html'; return; }
  await load();
});
