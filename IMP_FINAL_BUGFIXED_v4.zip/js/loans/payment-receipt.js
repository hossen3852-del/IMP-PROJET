"use strict";

document.addEventListener("DOMContentLoaded", async function () {
    const params=new URLSearchParams(location.search);
    const paymentId=params.get("paymentId") || params.get("id");
    const container=document.getElementById("receipt");
    const esc=v=>String(v??"-").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;");
    try {
        await SessionManager.requireAuth(); await RBACManager.bootstrap();
        if(!RBACManager.hasPermission("payment.view")) throw new Error("You do not have permission to view receipts.");
        if(!paymentId) throw new Error("Payment ID is missing.");
        const result=await PaymentAPI.receipt(paymentId); const r=result?.receipt;
        if(!r) throw new Error("Receipt not found.");
        if(container) container.innerHTML=`<div class="receipt-header"><h1>INSTALLMENT MANAGEMENT PLATFORM</h1><h2>PAYMENT RECEIPT</h2></div><div class="receipt-meta"><div><strong>Receipt No.</strong><span>${esc(r.receiptNumber)}</span></div><div><strong>Date</strong><span>${esc(r.paymentDate)}</span></div></div><hr><div class="receipt-details"><p><strong>Payment No.:</strong> ${esc(r.paymentNumber)}</p><p><strong>Loan ID:</strong> ${esc(r.loanId)}</p><p><strong>Member ID:</strong> ${esc(r.memberId)}</p><p><strong>Payment Method:</strong> ${esc(r.paymentMethod)}</p><p><strong>Amount Paid:</strong> ৳${Number(r.amount||0).toFixed(2)}</p><p><strong>Status:</strong> ${esc(r.status)}</p></div><div class="receipt-total">Paid Amount: <strong>৳${Number(r.amount||0).toFixed(2)}</strong></div><div class="signature-area"><span>Collector Signature</span><span>Member Signature</span></div>`;
        document.getElementById("printBtn")?.addEventListener("click",()=>window.print()); document.getElementById("backBtn")?.addEventListener("click",()=>history.back());
    } catch(e) { if(container) container.innerHTML=`<h2>Receipt unavailable</h2><p>${esc(e.message||"Unable to load receipt")}</p>`; }
});
