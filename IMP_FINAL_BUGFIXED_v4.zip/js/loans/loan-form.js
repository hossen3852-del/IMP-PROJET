"use strict";

document.addEventListener("DOMContentLoaded", async function () {
  // =====================================================
  // DOM ELEMENTS
  // =====================================================

  const memberSelect = document.getElementById("memberId");

  const branchSelect = document.getElementById("branchId");
  const renewalSelect = document.getElementById("renewalOfLoanId");
  const loanSourceSelect = document.getElementById("loanSourceType");
  const legacyLoanFields = document.getElementById("legacyLoanFields");
  const legacyPaidInstallments = document.getElementById("legacyPaidInstallments");
  const legacyPaidAmount = document.getElementById("legacyPaidAmount");

  const loanAmountInput = document.getElementById("loanAmount");

  const interestRateInput = document.getElementById("interestRate");

  const installmentCountInput = document.getElementById("numberOfInstallments");

  const installmentAmountInput = document.getElementById("installmentAmount");
  const savingsAmountInput = document.getElementById("savingsAmount");
  const depositAmountInput = document.getElementById("depositAmount");
  const insurancePreview = document.getElementById("insuranceAmountPreview");

  const interestAmountOutput = document.getElementById(
    "calculatedInterestAmount",
  );

  const totalPayableOutput = document.getElementById("totalPayable");

  const installmentAmountOutput = document.getElementById("installmentAmount");

  const totalInstallmentOutput = document.getElementById(
    "totalInstallmentRepayment",
  );

  const form = document.getElementById("loanForm");

  const message = document.getElementById("message");
  const submitBtn = form?.querySelector('button[type="submit"]');
  let isSubmittingLoan = false;

  // =====================================================
  // MESSAGE
  // =====================================================

  function show(text, type = "success") {
    if (!message) {
      return;
    }
    message.textContent = text;
    message.className = "message " + type;
    message.classList.remove("hidden");
    message.hidden = false;
    message.style.display = "block";
  }

  function clearLoanFormFields() {
    if (!form) return;
    form.reset();
    // clear calculated / dependent fields explicitly
    ["interestAmount", "totalPayable", "installmentAmount", "insuranceAmount"].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = "";
    });
    const renew = document.getElementById("renewalOfLoanId");
    if (renew) renew.innerHTML = '<option value="">—</option>';
    try { calculateLoan(); } catch (_) {}
  }

  // =====================================================
  // MONEY
  // =====================================================

  function moneyNumber(value) {
    const number = Number(value || 0);

    if (!Number.isFinite(number)) {
      return 0;
    }

    return Math.round((number + Number.EPSILON) * 100) / 100;
  }

  // =====================================================
  // CALCULATE LOAN — manual installment mode
  // =====================================================

  function calculateLoan() {
    const loanAmount = Number(loanAmountInput?.value || 0);
    const interestRate = Number(interestRateInput?.value || 0);
    const count = Number(installmentCountInput?.value || 0);
    const manualInstallment = Number(installmentAmountInput?.value || 0);

    const interestAmount = (Number.isFinite(loanAmount) && loanAmount > 0 &&
      Number.isFinite(interestRate) && interestRate >= 0)
      ? moneyNumber((loanAmount * interestRate) / 100) : 0;

    const calculatedTotalPayable = moneyNumber(loanAmount + interestAmount);
    const validCount = Number.isInteger(count) && count > 0;
    const validManual = Number.isFinite(manualInstallment) && manualInstallment > 0;

    if (interestAmountOutput) interestAmountOutput.value = interestAmount.toFixed(2);
    if (totalPayableOutput) totalPayableOutput.value = calculatedTotalPayable.toFixed(2);
    if (totalInstallmentOutput) totalInstallmentOutput.value = calculatedTotalPayable.toFixed(2);
    if (insurancePreview) insurancePreview.value =
      (loanAmount > 0 ? moneyNumber(loanAmount * 0.02) : 0).toFixed(2);

    return {
      loanAmount: Number.isFinite(loanAmount) ? loanAmount : 0,
      interestRate: Number.isFinite(interestRate) ? interestRate : 0,
      interestAmount,
      totalPayable: calculatedTotalPayable,
      installmentAmount: validManual ? moneyNumber(manualInstallment) : 0,
      numberOfInstallments: validCount ? count : 0,
      savingsAmount: moneyNumber(savingsAmountInput?.value || 0),
      depositAmount: moneyNumber(depositAmountInput?.value || 0),
    };
  }

  // =====================================================
  // AUTO CALCULATION EVENTS
  // =====================================================

  [loanAmountInput, interestRateInput, installmentCountInput,
   installmentAmountInput, savingsAmountInput, depositAmountInput]
    .filter(Boolean)
    .forEach((input) => {
      input.addEventListener("input", calculateLoan);
      input.addEventListener("change", calculateLoan);
    });

  // =====================================================
  // AUTH
  // =====================================================

  try {
    await SessionManager.requireAuth();

    await RBACManager.bootstrap();
  } catch (error) {
    console.error("[IMP] Authentication failed:", error);

    show(error.message || "Authentication failed.", "error");

    return;
  }

  // =====================================================
  // PERMISSION
  // =====================================================

  if (!RBACManager.hasPermission("loan.create")) {
    show("আপনার ঋণ তৈরি করার অনুমতি নেই।", "error");

    return;
  }

  // =====================================================
  // LOAD MEMBERS + BRANCHES
  // =====================================================

  try {
    const [members, branches] = await Promise.all([
      IMP_API.get("/members?limit=500"),

      IMP_API.get("/branches"),
    ]);

    // -------------------------------------------------
    // MEMBERS
    // -------------------------------------------------

    const activeMembers = (members.members || []).filter(
      (member) => member.status !== "inactive",
    );

    activeMembers.forEach((member) => {
      const option = document.createElement("option");

      option.value = member.id;

      const name =
        member.fullName ||
        member.personalInfo?.fullName ||
        member.memberCode ||
        "-";

      option.textContent = `${member.memberCode || ""} - ${name}`.trim();

      // -------------------------------------------------
      // MEMBER BRANCH
      // -------------------------------------------------

      option.dataset.branchId = member.branchId || member.branch_id || "";
      option.dataset.memberOrigin = member.memberOrigin || member.member_origin || "new";
      option.dataset.legacyPaidInstallments = member.legacyCurrentInstallmentsPaid || 0;
      option.dataset.legacyPaidAmount = (Number(member.legacyCurrentInstallmentsPaid || 0) * Number(member.legacyCurrentInstallmentAmount || 0)) || 0;

      memberSelect.appendChild(option);
    });

    syncLoanSourceUI();

    if (!activeMembers.length) {
      show("কোনো active member পাওয়া যায়নি। আগে member যোগ করুন।", "error");
    }

    // -------------------------------------------------
    // BRANCHES
    // -------------------------------------------------

    (branches.branches || [])
      .filter((branch) => branch.status === "active")
      .forEach((branch) => {
        const option = document.createElement("option");

        option.value = branch.id;

        option.textContent =
          `${branch.branchCode || branch.branch_code || ""} - ${branch.name}`.trim();

        branchSelect.appendChild(option);
      });
  } catch (error) {
    console.error("[IMP] Member/Branch loading failed:", error);

    show(error.message || "Member/Branch তথ্য লোড করা যায়নি।", "error");

    return;
  }

  function syncLoanSourceUI() {
    const previous = loanSourceSelect?.value === "previous_loan";
    if (legacyLoanFields) legacyLoanFields.classList.toggle("hidden", !previous);
    if (renewalSelect) renewalSelect.closest(".form-group")?.style && (renewalSelect.closest(".form-group").style.display = previous ? "none" : "");
    if (memberSelect) {
      const current = memberSelect.value;
      Array.from(memberSelect.options).forEach(o => {
        if (!o.value) return;
        const previousBorrower = o.dataset.memberOrigin === "previous_borrower";
        o.hidden = previous ? !previousBorrower : previousBorrower;
      });
      if (current && memberSelect.selectedOptions[0]?.hidden) memberSelect.value = "";
    }
  }

  loanSourceSelect?.addEventListener("change", syncLoanSourceUI);

  // =====================================================
  // MEMBER → BRANCH AUTO SELECT
  // =====================================================

  if (memberSelect && branchSelect) {
    memberSelect.addEventListener("change", async function () {
      const selected = memberSelect.options[memberSelect.selectedIndex];

      const memberBranchId = selected?.dataset?.branchId || "";
      if (loanSourceSelect?.value === "previous_loan") {
        if (legacyPaidInstallments) legacyPaidInstallments.value = selected?.dataset?.legacyPaidInstallments || 0;
        if (legacyPaidAmount) legacyPaidAmount.value = selected?.dataset?.legacyPaidAmount || 0;
      }
      if (renewalSelect) {
        renewalSelect.innerHTML = '<option value="">নতুন লোন — পূর্বের লোন অপরিবর্তিত থাকবে</option>';
        try {
          const r = await IMP_API.get(`/loans?member_id=${encodeURIComponent(memberSelect.value)}&limit=100`);
          (r.loans || []).filter(x => ['disbursed','active','completed'].includes(String(x.status))).forEach(x => {
            const o=document.createElement('option'); o.value=x.id; o.textContent=`পূর্বের লোন ${x.loanNumber || x.id} — বকেয়া ৳${Number(x.outstandingAmount||0).toFixed(2)}`; renewalSelect.appendChild(o);
          });
        } catch (_) {}
      }

      if (!memberBranchId) { return; }

      const branchOption = Array.from(branchSelect.options).find(
        (option) => String(option.value) === String(memberBranchId),
      );

      if (branchOption) {
        branchSelect.value = memberBranchId;
      }
    });
  }

  // =====================================================
  // NAVIGATION
  // =====================================================

  const backBtn = document.getElementById("backBtn");

  if (backBtn) {
    backBtn.onclick = () => {
      location.href = "./loan-list.html";
    };
  }

  const cancelBtn = document.getElementById("cancelBtn");

  if (cancelBtn) {
    cancelBtn.onclick = () => {
      location.href = "./loan-list.html";
    };
  }

  // =====================================================
  // INITIAL CALCULATION
  // =====================================================

  calculateLoan();

  // =====================================================
  // SUBMIT
  // =====================================================

  if (!form) {
    console.error("[IMP] loanForm not found.");

    return;
  }

  form.addEventListener("submit", async function (event) {
    event.preventDefault();

    // ------------------------------------------------
    // CALCULATE
    // ------------------------------------------------

    const calculation = calculateLoan();

    // ------------------------------------------------
    // VALIDATION
    // ------------------------------------------------

    if (calculation.loanAmount <= 0) {
      show("ঋণের পরিমাণ সঠিকভাবে দিন।", "error");

      return;
    }

    if (calculation.interestRate < 0) {
      show("সুদের হার সঠিকভাবে দিন।", "error");

      return;
    }

    const count = Number(installmentCountInput?.value || 0);

    if (!Number.isInteger(count) || count <= 0) {
      show("কিস্তি সংখ্যা সঠিকভাবে দিন।", "error");

      return;
    }

    const manualInstallment = Number(installmentAmountInput?.value || 0);
    if (!Number.isFinite(manualInstallment) || manualInstallment <= 0) {
      show("কিস্তির পরিমাণ ম্যানুয়ালি দিন।", "error");
      installmentAmountInput?.focus();
      return;
    }

    if (manualInstallment > calculation.totalPayable + 0.01) {
      show("ম্যানুয়াল কিস্তির পরিমাণ মোট পরিশোধযোগ্য টাকার চেয়ে বেশি হতে পারবে না।", "error");
      return;
    }

    if (!memberSelect?.value) {
      show("সদস্য নির্বাচন করুন।", "error");

      return;
    }

    if (!branchSelect?.value) {
      show("শাখা নির্বাচন করুন।", "error");

      return;
    }

    const loanTypeInput = document.getElementById("loanType");

    const loanPurposeInput = document.getElementById("loanPurpose");

    const frequencyInput = document.getElementById("installmentFrequency");

    const startDateInput = document.getElementById("startDate");

    // ------------------------------------------------
    // REQUIRED FIELD VALIDATION
    // ------------------------------------------------

    if (!loanTypeInput || !loanTypeInput.value.trim()) {
      show("ঋণের ধরন নির্বাচন/লিখুন।", "error");

      return;
    }

    if (!frequencyInput || !frequencyInput.value) {
      show("কিস্তির সময়কাল নির্বাচন করুন।", "error");

      return;
    }

    if (!startDateInput || !startDateInput.value) {
      show("ঋণের শুরুর তারিখ দিন।", "error");

      return;
    }

    // =================================================
    // FINAL PAYLOAD
    // =================================================
    //
    // IMPORTANT:
    //
    // interestAmount এবং installmentAmount
    // এখানে পাঠানো হচ্ছে না।
    //
    // কারণ server এগুলো নিজে calculate করবে।
    //
    // =================================================

    const payload = {
      memberId: memberSelect.value,
      loanSourceType: loanSourceSelect?.value || "new",
      legacyPaidInstallments: Number(legacyPaidInstallments?.value || 0),
      legacyPaidAmount: Number(legacyPaidAmount?.value || 0),

      renewalOfLoanId: renewalSelect?.value || null,

      branchId: branchSelect.value,

      loanType: loanTypeInput.value.trim(),

      loanPurpose: loanPurposeInput ? loanPurposeInput.value.trim() : "",

      loanAmount: calculation.loanAmount,

      interestRate: calculation.interestRate,

      numberOfInstallments: count,

      installmentAmount: manualInstallment,

      savingsAmount: Number(savingsAmountInput?.value || 0),

      depositAmount: Number(depositAmountInput?.value || 0),

      installmentFrequency: frequencyInput.value,

      startDate: startDateInput.value,
    };

    // ------------------------------------------------
    // DEBUG
    // ------------------------------------------------

    console.log("[IMP] Loan create payload:", payload);

    // ------------------------------------------------
    // CREATE LOAN
    // ------------------------------------------------

    if (isSubmittingLoan) return;
    isSubmittingLoan = true;
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.dataset.prevText = submitBtn.textContent || "";
      submitBtn.textContent = "সংরক্ষণ হচ্ছে…";
    }

    try {
      const idem = (crypto.randomUUID && crypto.randomUUID()) || (`loan-${Date.now()}-${Math.random()}`);
      const response = payload.loanSourceType === "previous_loan"
        ? await IMP_API.post("/loans/legacy-import", payload, { "Idempotency-Key": idem })
        : await IMP_API.request("/loans", { method: "POST", headers: { "Idempotency-Key": idem }, body: payload });
      const loan = response?.loan || response;

      const code = loan?.loanNumber || loan?.loan_number || "";
      show(
        (code
          ? `ঋণ সফলভাবে তৈরি হয়েছে (${code})।`
          : "ঋণ সফলভাবে তৈরি হয়েছে।") + " নতুন ঋণ যোগ করতে ফর্ম খালি করা হয়েছে।",
        "success"
      );
      clearLoanFormFields();
      // Ensure message sits below submit area: move under form if needed
      if (message && submitBtn && submitBtn.parentElement) {
        submitBtn.parentElement.appendChild(message);
      }
    } catch (error) {
      console.error("[IMP] Loan create failed:", error);
      show(error.message || "ঋণ তৈরি করা যায়নি।", "error");
    } finally {
      isSubmittingLoan = false;
      if (submitBtn) {
        submitBtn.disabled = false;
        if (submitBtn.dataset.prevText) submitBtn.textContent = submitBtn.dataset.prevText;
      }
    }
  });
});
