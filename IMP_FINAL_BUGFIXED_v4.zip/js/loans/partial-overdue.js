"use strict";

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const params =
            new URLSearchParams(
                location.search
            );

        const loanId =
            params.get("id") ||
            params.get("loanId");

        const loan =
            LoanManager.findLoan(
                loanId
            );

        if (!loan) {
            return;
        }

        const installments =
            LoanManager
                .getInstallments(
                    loan.id
                );

        const today =
            new Date();

        let totalDue = 0;
        let totalPaid = 0;
        let outstanding = 0;
        let overdue = 0;

        const tbody =
            document.getElementById(
                "tableBody"
            );

        installments.forEach(
            item => {

                const amount =
                    Number(
                        item.amount || 0
                    );

                const paid =
                    Number(
                        item.paidAmount || 0
                    );

                const balance =
                    Math.max(
                        0,
                        amount - paid
                    );

                let status =
                    item.status || "due";

                const dueDate =
                    new Date(
                        item.dueDate
                    );

                if (
                    balance > 0 &&
                    dueDate < today
                ) {

                    status =
                        "overdue";

                    overdue += balance;
                }

                totalDue += amount;
                totalPaid += paid;
                outstanding += balance;

                const row =
                    document.createElement(
                        "tr"
                    );

                row.innerHTML = `

                    <td>
                        ${item.installmentNo}
                    </td>

                    <td>
                        ${item.dueDate}
                    </td>

                    <td>
                        ৳${amount.toFixed(2)}
                    </td>

                    <td>
                        ৳${paid.toFixed(2)}
                    </td>

                    <td>
                        ৳${balance.toFixed(2)}
                    </td>

                    <td>
                        <span class="status">
                            ${status}
                        </span>
                    </td>

                `;

                tbody.appendChild(row);
            }
        );

        document.getElementById(
            "totalDue"
        ).textContent =
            "৳" +
            totalDue.toFixed(2);

        document.getElementById(
            "totalPaid"
        ).textContent =
            "৳" +
            totalPaid.toFixed(2);

        document.getElementById(
            "outstanding"
        ).textContent =
            "৳" +
            outstanding.toFixed(2);

        document.getElementById(
            "overdue"
        ).textContent =
            "৳" +
            overdue.toFixed(2);

        document
            .getElementById(
                "backBtn"
            )
            .onclick = () =>
                history.back();
    }
);