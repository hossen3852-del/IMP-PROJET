/**
 * Expense management page. All totals come from /api/expenses/* — nothing
 * is computed client-side or read from localStorage.
 */
(function () {
    "use strict";

    const CATEGORY_LABELS = {
        office: "অফিস খরচ",
        travel: "যাতায়াত খরচ",
        equipment: "সরঞ্জাম খরচ",
        other: "ডেইলি খরচ"
    };

    function formatBDT(n) {
        const value = Number(n) || 0;
        return "৳" + value.toLocaleString("en-BD", { maximumFractionDigits: 2 });
    }

    function setText(id, value) {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    }

    async function loadSummary() {
        const result = await IMP_API.get("/expenses/summary");
        const s = result?.summary || {};
        setText("totalExpenseValue", formatBDT(s.total));
        setText("bdOffice", formatBDT(s.office));
        setText("bdTravel", formatBDT(s.travel));
        setText("bdEquipment", formatBDT(s.equipment));
        setText("bdDaily", formatBDT(s.other));
        // total already includes daily from API after server fix
    }

    function renderRow(entry, canManage) {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${Utils.escapeHtml(entry.expenseDate)}</td>
            <td>${Utils.escapeHtml(CATEGORY_LABELS[entry.category] || entry.category)}</td>
            <td>${formatBDT(entry.amount)}</td>
            <td>${Utils.escapeHtml(entry.description || "")}</td>
            <td></td>
        `;
        if (canManage) {
            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = "btn btn-danger";
            btn.textContent = "Delete";
            btn.addEventListener("click", () => deleteEntry(entry.id));
            tr.lastElementChild.appendChild(btn);
        }
        return tr;
    }

    async function loadEntries() {
        const body = document.getElementById("expenseEntriesBody");
        const result = await IMP_API.get("/expenses/entries");
        const entries = result?.entries || [];
        const canManage = RBACManager.hasPermission(PERMISSIONS.EXPENSE_MANAGE);

        body.innerHTML = "";
        if (!entries.length) {
            body.innerHTML = `<tr><td colspan="5">কোনো এন্ট্রি পাওয়া যায়নি।</td></tr>`;
            return;
        }
        entries.forEach(entry => body.appendChild(renderRow(entry, canManage)));
    }

    async function deleteEntry(id) {
        if (!window.confirm("এই এন্ট্রিটি মুছে ফেলতে চান?")) return;
        try {
            await IMP_API.delete(`/expenses/entries/${id}`);
            await Promise.all([loadSummary(), loadEntries()]);
        } catch (error) {
            Utils.showMessage("expenseMessage", error.message || "মুছে ফেলা যায়নি।", "error");
        }
    }

    async function handleSubmit(event) {
        event.preventDefault();
        const payload = {
            expenseDate: document.getElementById("expDate").value,
            category: document.getElementById("expCategory").value,
            amount: Number(document.getElementById("expAmount").value),
            description: document.getElementById("expDescription").value.trim()
        };

        const submitBtn = event.target.querySelector("button[type=submit]");
        if (submitBtn) submitBtn.disabled = true;
        try {
            await IMP_API.post("/expenses/entries", payload);
            Utils.showMessage("expenseMessage", "Expense entry saved.", "success");
            document.getElementById("expenseEntryForm").reset();
            document.getElementById("expDate").valueAsDate = new Date();
            await Promise.all([loadSummary(), loadEntries()]);
        } catch (error) {
            Utils.showMessage("expenseMessage", error.message || "Save failed.", "error");
        } finally {
            if (submitBtn) submitBtn.disabled = false;
        }
    }

    document.addEventListener("DOMContentLoaded", async function () {
        if (!(await SessionManager.requireAuth())) return;
        await RBACManager.bootstrap();

        if (!(await AccessGuard.requirePermission(PERMISSIONS.EXPENSE_VIEW))) return;
        RBACManager.applyUIProtection();
        AccessGuard.apply();

        const dateInput = document.getElementById("expDate");
        if (dateInput) dateInput.valueAsDate = new Date();

        document.getElementById("expenseEntryForm").addEventListener("submit", handleSubmit);

        try {
            await Promise.all([loadSummary(), loadEntries()]);
        } catch (error) {
            Utils.showMessage("expenseMessage", error.message || "লোড করা যায়নি।", "error");
        }
    });
})();
