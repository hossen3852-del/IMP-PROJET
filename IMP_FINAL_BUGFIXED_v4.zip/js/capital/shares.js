(function () {
  "use strict";

  function money(n) {
    return "৳" + Number(n || 0).toLocaleString("en-BD", { maximumFractionDigits: 2 });
  }

  let summaryCache = { totalUnits: 0, investedCapital: 0, marketValue: 0 };
  let photoDataUrl = "";

  async function computeAutoMarketValue() {
    // Formula: current balance + disbursed loans - total savings - total expenses - conditional insurance payout
    let currentBalance = 0, disbursed = 0, savings = 0, expenses = 0, insuranceClaim = 0;
    try {
      const cap = await IMP_API.get("/capital/summary");
      const s = cap?.summary || {};
      currentBalance = Number(s.currentCapital ?? s.currentBalance ?? 0);
      disbursed = Number(s.loanDisbursement ?? s.disbursedLoans ?? 0);
      savings = Number(s.savingsDeposits || 0) + Number(s.dailySavingsDeposits || 0) - Number(s.savingsWithdrawals || 0);
      insuranceClaim = Number(s.insuranceClaim ?? s.conditionalInsurancePayout ?? 0);
    } catch (e) {
      console.warn("[IMP] capital summary for market value:", e);
    }
    try {
      const exp = await IMP_API.get("/expenses/summary");
      expenses = Number(exp?.summary?.total || 0);
    } catch (e) {
      console.warn("[IMP] expense summary for market value:", e);
    }
    const mv = currentBalance + disbursed - savings - expenses - insuranceClaim;
    return Math.max(0, Math.round(mv * 100) / 100);
  }

  function updateIssuePriceFromUnitsAndInvested() {
    const unitsEl = document.getElementById("shareUnits");
    const investedEl = document.getElementById("investedAmount");
    const priceEl = document.getElementById("issuePricePerShare");
    if (!unitsEl || !investedEl || !priceEl) return;
    const units = Number(unitsEl.value || 0);
    const invested = Number(investedEl.value || 0);
    if (units > 0 && invested >= 0) {
      // অটো: ইস্যু মূল্য / শেয়ার = মোট বিনিয়োগ ÷ মোট শেয়ার ইউনিট
      const price = Math.round((invested / units) * 100) / 100;
      priceEl.value = price > 0 ? String(price) : "";
      priceEl.dataset.auto = "1";
    } else if (units <= 0) {
      if (priceEl.dataset.auto === "1") priceEl.value = "";
    }
  }

  function updateOwnershipPreview() {
    updateIssuePriceFromUnitsAndInvested();
    const units = Number(document.getElementById("shareUnits")?.value || 0);
    const invested = Number(document.getElementById("investedAmount")?.value || 0);
    const existingUnits = Number(summaryCache.totalUnits || 0);
    const existingInvested = Number(summaryCache.investedCapital || 0);
    const totalUnits = existingUnits + units;
    const totalInvested = existingInvested + invested;
    // মালিকানা % = নতুন ইউনিট / (বিদ্যমান + নতুন) মোট ইউনিট — মূলধন জমার উপর ভিত্তি করে
    const pct = totalUnits > 0 ? (units / totalUnits) * 100 : 0;
    const el = document.getElementById("previewOwnership");
    if (el) el.textContent = units > 0 ? pct.toFixed(2) + "%" : "—";
    const tu = document.getElementById("previewTotalUnits");
    const ti = document.getElementById("previewTotalInvested");
    if (tu) tu.textContent = totalUnits.toLocaleString("en-BD", { maximumFractionDigits: 4 });
    if (ti) ti.textContent = money(totalInvested);

    // বর্তমান বাজার মূল্যের উপর ভিত্তি করে এই হোল্ডারের হিস্যা প্রিভিউ
    const marketValue = Number(summaryCache.marketValue || 0);
    const holderMv = totalUnits > 0 && units > 0 ? (units / totalUnits) * marketValue : 0;
    const mvPreview = document.getElementById("previewHolderMarketValue");
    if (mvPreview) mvPreview.textContent = money(holderMv);
  }

  async function load() {
    const r = await IMP_API.get("/capital/shares");
    const shares = r.shares || [];
    const sum = r.summary || {};
    summaryCache = {
      totalUnits: Number(sum.totalUnits || 0),
      investedCapital: Number(sum.investedCapital || 0),
      marketValue: Number(sum.marketValue || 0)
    };
    document.getElementById("totalUnits").textContent = summaryCache.totalUnits.toLocaleString();
    document.getElementById("investedCapital").textContent = money(summaryCache.investedCapital);
    document.getElementById("marketValue").textContent = money(summaryCache.marketValue);
    document.getElementById("marketPrice").textContent = money(sum.marketPricePerShare || 0);
    const mvInput = document.getElementById("organizationMarketValue");
    if (mvInput && !mvInput.dataset.touched) {
      mvInput.value = summaryCache.marketValue || "";
    }
    const body = document.getElementById("sharesBody");
    body.innerHTML = shares.map((x) => {
      const photo = x.photoUrl || x.photo_url || x.shareholderPhoto || "";
      const photoCell = photo
        ? `<img src="${Utils.escapeHtml(photo)}" alt="" class="share-photo-preview" loading="lazy">`
        : `<span class="share-photo-placeholder">${(x.shareholderName || "?").charAt(0)}</span>`;
      return `<tr>
        <td class="share-photo-cell">${photoCell}</td>
        <td>${Utils.escapeHtml(x.shareholderName || "")}</td>
        <td>${Number(x.shareUnits).toLocaleString()}</td>
        <td>${money(x.investedAmount)}</td>
        <td>${Number(x.ownershipPercent).toFixed(2)}%</td>
        <td>${money(x.currentMarketValue)}</td>
        <td><a class="btn btn-secondary" href="share-profile.html?id=${encodeURIComponent(x.id)}">Profile</a></td>
      </tr>`;
    }).join("") || '<tr><td colspan="7">কোনো শেয়ার প্রোফাইল নেই।</td></tr>';
    updateOwnershipPreview();
  }

  document.addEventListener("DOMContentLoaded", async () => {
    await SessionManager.requireAuth();
    await RBACManager.bootstrap();
    if (!RBACManager.hasPermission("capital.share.view")) return;

    document.getElementById("acquisitionDate").valueAsDate = new Date();

    ["shareUnits", "investedAmount"].forEach((id) => {
      const el = document.getElementById(id);
      if (el) el.addEventListener("input", updateOwnershipPreview);
    });

    const photoInput = document.getElementById("shareholderPhoto");
    const preview = document.getElementById("photoPreview");
    if (photoInput) {
      photoInput.addEventListener("change", () => {
        const file = photoInput.files && photoInput.files[0];
        photoDataUrl = "";
        if (!file) { if (preview) preview.hidden = true; return; }
        if (file.size > 2.5 * 1024 * 1024) {
          Utils.showMessage("shareMessage", "ছবি ২.৫MB এর কম হতে হবে।", "error");
          photoInput.value = "";
          return;
        }
        const reader = new FileReader();
        reader.onload = () => {
          photoDataUrl = String(reader.result || "");
          if (preview) {
            preview.src = photoDataUrl;
            preview.hidden = false;
          }
        };
        reader.readAsDataURL(file);
      });
    }

    const mvInput = document.getElementById("organizationMarketValue");
    if (mvInput) mvInput.addEventListener("input", () => { mvInput.dataset.touched = "1"; });

    document.getElementById("btnAutoMarket").onclick = async () => {
      try {
        const mv = await computeAutoMarketValue();
        mvInput.value = mv;
        mvInput.dataset.touched = "1";
        Utils.showMessage("shareMessage", "অটো বাজার মূল্য হিসাব করা হয়েছে: " + money(mv), "success");
      } catch (err) {
        Utils.showMessage("shareMessage", err.message || "Auto calculate failed", "error");
      }
    };

    document.getElementById("saveMarketValue").onclick = async () => {
      try {
        await IMP_API.put("/capital/shares/market-value", {
          marketValue: Number(document.getElementById("organizationMarketValue").value || 0)
        });
        Utils.showMessage("shareMessage", "Market value updated.", "success");
        await load();
      } catch (err) {
        Utils.showMessage("shareMessage", err.message || "Update failed", "error");
      }
    };

    document.getElementById("shareForm").onsubmit = async (e) => {
      e.preventDefault();
      try {
        updateIssuePriceFromUnitsAndInvested();
        const units = Number(shareUnits.value);
        const invested = Number(investedAmount.value);
        let price = Number(issuePricePerShare.value);
        if (!shareholderName.value || !shareholderName.value.trim()) {
          Utils.showMessage("shareMessage", "শেয়ারহোল্ডারের নাম আবশ্যক।", "error");
          return;
        }
        if (!(units > 0)) {
          Utils.showMessage("shareMessage", "মোট শেয়ার ইউনিট ০-এর বেশি হতে হবে।", "error");
          return;
        }
        if (!(invested >= 0)) {
          Utils.showMessage("shareMessage", "মোট বিনিয়োগ সঠিক নয়।", "error");
          return;
        }
        if (!(price > 0) && units > 0 && invested > 0) {
          price = Math.round((invested / units) * 100) / 100;
          issuePricePerShare.value = String(price);
        }
        if (!(price > 0)) {
          Utils.showMessage("shareMessage", "ইস্যু মূল্য / শেয়ার ০-এর বেশি হতে হবে।", "error");
          return;
        }
        // Sync invested to units × price to satisfy server ±0.01 rule
        const expected = Math.round(units * price * 100) / 100;
        if (Math.abs(expected - invested) > 0.01) {
          investedAmount.value = String(expected);
        }
        const email = (shareholderEmail.value || "").trim();
        const payload = {
          shareholderName: shareholderName.value.trim(),
          shareholderPhone: (shareholderPhone.value || "").trim(),
          shareholderEmail: email,
          shareUnits: units,
          issuePricePerShare: price,
          investedAmount: Math.round(units * price * 100) / 100,
          acquisitionDate: acquisitionDate.value || undefined
        };
        if (photoDataUrl) payload.photoDataUrl = photoDataUrl;
        await IMP_API.post("/capital/shares", payload);
        Utils.showMessage("shareMessage", "শেয়ার প্রোফাইল তৈরি হয়েছে।", "success");
        e.target.reset();
        acquisitionDate.valueAsDate = new Date();
        photoDataUrl = "";
        if (preview) preview.hidden = true;
        await load();
      } catch (err) {
        let msg = err.message || "Save failed";
        const details = err.payload && err.payload.details;
        if (Array.isArray(details) && details.length) {
          const first = details[0];
          const path = (first.path && first.path.join(".")) || "";
          msg = (err.payload.message || msg) + (path ? " (" + path + ": " + (first.message || "") + ")" : "");
        } else if (err.payload && err.payload.message) {
          msg = err.payload.message;
        }
        Utils.showMessage("shareMessage", msg, "error");
      }
    };

    // Auto-refresh market value display on load (does not overwrite manual DB value unless empty)
    try {
      const autoMv = await computeAutoMarketValue();
      const note = document.getElementById("marketFormulaNote");
      if (note) note.textContent = note.textContent + " · হিসাবিত: " + money(autoMv);
    } catch (_) {}

    await load();
  });
})();
