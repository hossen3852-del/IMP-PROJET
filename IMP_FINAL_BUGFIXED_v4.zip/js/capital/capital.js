/**
 * 11.P.15.3/15.4 — Capital Management page.
 * All numbers come from /api/capital/summary and /api/capital/entries.
 * Nothing is computed client-side or read from localStorage.
 */
(function () {
    "use strict";

    const TYPE_LABELS = {
        capital_in: "Opening Capital",
        capital_adjustment: "Capital Adjustment",
        capital_withdrawal: "Capital Withdrawal"
    };

    const AMOUNT_HINTS = {
        capital_in: "ধনাত্মক সংখ্যা দিন।",
        capital_withdrawal: "ধনাত্মক সংখ্যা দিন (সিস্টেম স্বয়ংক্রিয়ভাবে বিয়োগ করবে)।",
        capital_adjustment: "ধনাত্মক বা ঋণাত্মক (সংশোধনীর জন্য) সংখ্যা দিতে পারেন।"
    };

    function formatBDT(n) {
        const value = Number(n) || 0;
        return "৳" + value.toLocaleString("en-BD", { maximumFractionDigits: 2 });
    }

    function setText(id, value) {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    }

    async function loadSummary() {
        const result = await IMP_API.get("/capital/summary");
        const s = result?.summary || {};
        setText("currentCapitalValue", formatBDT(s.currentCapital));
        setText("bdCapitalIn", formatBDT(s.capitalIn));
        setText("bdAdmissionFee", formatBDT(s.admissionFee));
        setText("bdInsurance", formatBDT(s.insurance));
        setText("bdInsuranceClaim", formatBDT(s.insuranceClaim));
        setText("bdCollection", formatBDT(s.collection));
        setText("bdSavingsDeposits", formatBDT(s.savingsDeposits));
        setText("bdSavingsWithdrawals", formatBDT(s.savingsWithdrawals));
        setText("bdWithdrawal", formatBDT(s.capitalWithdrawal));
        setText("bdAdjustment", formatBDT(s.capitalAdjustment));
        setText("bdDisbursement", formatBDT(s.loanDisbursement));
    }

    function renderRow(entry, canManage) {
        const tr = document.createElement("tr");

        const amountClass = Number(entry.amount) < 0 ? "amount-negative" : "amount-positive";
        tr.innerHTML = `
            <td>${Utils.escapeHtml(entry.entryDate)}</td>
            <td>${Utils.escapeHtml(TYPE_LABELS[entry.entryType] || entry.entryType)}</td>
            <td class="${amountClass}">${formatBDT(entry.amount)}</td>
            <td>${Utils.escapeHtml(entry.description || "")}</td>
            <td></td>
        `;

        if (canManage) {
            const td = tr.lastElementChild;
            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = "btn btn-danger";
            btn.textContent = "Delete";
            btn.addEventListener("click", () => deleteEntry(entry.id));
            td.appendChild(btn);
        }

        return tr;
    }

    async function loadEntries() {
        const body = document.getElementById("capitalEntriesBody");
        if (!body) return;
        const params = new URLSearchParams(window.location.search);
        const typeFilter = params.get("type");
        const query = typeFilter ? `?entryType=${encodeURIComponent(typeFilter)}` : "";

        const result = await IMP_API.get(`/capital/entries${query}`);
        const entries = result?.entries || [];
        const canManage = RBACManager.hasPermission(PERMISSIONS.CAPITAL_MANAGE);

        body.innerHTML = "";
        if (!entries.length) {
            body.innerHTML = `<tr><td colspan="5">কোনো এন্ট্রি পাওয়া যায়নি।</td></tr>`;
            return;
        }
        entries.forEach(entry => body.appendChild(renderRow(entry, canManage)));
    }

    async function deleteEntry(id) {
        if (!window.confirm("এই এন্ট্রিটি মুছে ফেলতে চান?")) return;
        try {
            await IMP_API.delete(`/capital/entries/${id}`);
            await Promise.all([loadSummary(), loadEntries()]);
        } catch (error) {
            Utils.showMessage("capitalMessage", error.message || "মুছে ফেলা যায়নি।", "error");
        }
    }

    function updateAmountHint() {
        const type = document.getElementById("entryType").value;
        const hint = document.getElementById("amountHint");
        if (hint) hint.textContent = AMOUNT_HINTS[type] || "";
    }

    async function handleSubmit(event) {
        event.preventDefault();
        const message = document.getElementById("capitalMessage");
        const submitBtn = event.target.querySelector("button[type=submit]");

        const payload = {
            entryDate: document.getElementById("entryDate").value,
            entryType: document.getElementById("entryType").value,
            amount: Number(document.getElementById("entryAmount").value),
            description: document.getElementById("entryDescription").value.trim()
        };

        if (submitBtn) submitBtn.disabled = true;
        try {
            await IMP_API.post("/capital/entries", payload);
            Utils.showMessage("capitalMessage", "Capital entry saved.", "success");
            document.getElementById("capitalEntryForm").reset();
            document.getElementById("entryDate").valueAsDate = new Date();
            updateAmountHint();
            await Promise.all([loadSummary(), loadEntries()]);
        } catch (error) {
            Utils.showMessage("capitalMessage", error.message || "Save failed.", "error");
        } finally {
            if (submitBtn) submitBtn.disabled = false;
        }
    }

    document.addEventListener("DOMContentLoaded", async function () {
        if (!(await SessionManager.requireAuth())) return;
        await RBACManager.bootstrap();

        if (!(await AccessGuard.requirePermission(PERMISSIONS.CAPITAL_VIEW))) return;
        RBACManager.applyUIProtection();
        AccessGuard.apply();

        const dateInput = document.getElementById("entryDate");
        if (dateInput) dateInput.valueAsDate = new Date();
        updateAmountHint();

        const typeSelect = document.getElementById("entryType");
        if (typeSelect) typeSelect.addEventListener("change", updateAmountHint);

        const form = document.getElementById("capitalEntryForm");
        if (form) form.addEventListener("submit", handleSubmit);

        try {
            await Promise.all([loadSummary(), loadEntries()]);
        } catch (error) {
            Utils.showMessage("capitalMessage", error.message || "লোড করা যায়নি।", "error");
        }
    });
})();
