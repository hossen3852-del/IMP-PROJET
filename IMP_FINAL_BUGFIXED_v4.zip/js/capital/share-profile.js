document.addEventListener("DOMContentLoaded", async () => {
  await SessionManager.requireAuth();
  await RBACManager.bootstrap();
  const id = new URLSearchParams(location.search).get("id");
  if (!id) return;

  let photoDataUrl = "";

  function money(n) {
    return "৳" + Number(n || 0).toLocaleString("en-BD", { maximumFractionDigits: 2 });
  }

  function setPhoto(url, name) {
    const img = document.getElementById("sharePhoto");
    const ph = document.getElementById("sharePhotoPh");
    if (url) {
      img.src = url;
      img.hidden = false;
      if (ph) ph.hidden = true;
    } else {
      img.hidden = true;
      if (ph) {
        ph.hidden = false;
        ph.textContent = (name || "?").charAt(0).toUpperCase();
      }
    }
  }

  try {
    const r = await IMP_API.get("/capital/shares/" + encodeURIComponent(id));
    const x = r.share || {};
    const name = x.shareholderName || "-";
    document.getElementById("shareName").textContent = name;
    document.getElementById("spUnits").textContent = Number(x.shareUnits || 0).toLocaleString();
    document.getElementById("spInvested").textContent = money(x.investedAmount);
    document.getElementById("spOwnership").textContent = Number(x.ownershipPercent || 0).toFixed(2) + "%";
    document.getElementById("spOwnership2").textContent = Number(x.ownershipPercent || 0).toFixed(2) + "%";
    document.getElementById("spMarket").textContent = money(x.currentMarketValue);
    document.getElementById("spIssuePrice").textContent = money(x.issuePricePerShare);
    document.getElementById("spDate").textContent = x.acquisitionDate || "—";

    // Org market value from shares summary
    try {
      const sum = await IMP_API.get("/capital/shares");
      const mv = Number(sum?.summary?.marketValue || 0);
      document.getElementById("spOrgMarket").textContent = money(mv);
    } catch (_) {
      document.getElementById("spOrgMarket").textContent = "—";
    }

    setPhoto(x.photoUrl || x.photo_url || x.shareholderPhoto || "", name);
  } catch (e) {
    document.getElementById("shareName").textContent = e.message || "Share profile unavailable";
  }

  const input = document.getElementById("profilePhotoInput");
  if (input) {
    input.addEventListener("change", () => {
      const file = input.files && input.files[0];
      photoDataUrl = "";
      if (!file) return;
      if (file.size > 2.5 * 1024 * 1024) {
        document.getElementById("profilePhotoMsg").textContent = "ছবি ২.৫MB এর কম হতে হবে।";
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        photoDataUrl = String(reader.result || "");
        setPhoto(photoDataUrl, document.getElementById("shareName").textContent);
      };
      reader.readAsDataURL(file);
    });
  }

  const saveBtn = document.getElementById("savePhotoBtn");
  if (saveBtn) {
    saveBtn.addEventListener("click", async () => {
      const msg = document.getElementById("profilePhotoMsg");
      if (!photoDataUrl) {
        msg.textContent = "আগে একটি ছবি নির্বাচন করুন।";
        return;
      }
      try {
        // Best-effort: PATCH share with photo if API supports it
        await IMP_API.patch("/capital/shares/" + encodeURIComponent(id), { photoDataUrl });
        msg.textContent = "ছবি সংরক্ষণ হয়েছে।";
        msg.style.color = "#166534";
      } catch (err) {
        // Fallback: local-only message if endpoint not available yet
        msg.textContent = (err && err.status === 404)
          ? "ছবি UI প্রস্তুত — সার্ভার ফটো এন্ডপয়েন্ট পরবর্তী মাইগ্রেশনে যুক্ত হবে। প্রিভিউ দেখানো হয়েছে।"
          : (err.message || "ছবি সংরক্ষণ ব্যর্থ।");
        msg.style.color = err && err.status === 404 ? "#92400e" : "#991b1b";
      }
    });
  }
});
