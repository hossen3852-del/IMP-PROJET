(function(){'use strict';
const legacyMap=['organization.view','branch.view','user.view','member.view','loan.view','loan.view','payment.view','collection.create','capital.view','savings.view','expense.view','settings.view','dashboard.customize'];
function isAllowed(allowed,el,index){
  if(!Array.isArray(allowed)) return true;
  const stable=el.getAttribute('data-ui-module');

  // Organization Admin and Super Admin must always retain the core
  // administration entry points when they have the corresponding RBAC
  // permission. A stale/incomplete per-user visibility record must never
  // hide an administration function that the server authorizes.
  const user=(typeof SessionManager!=='undefined' && SessionManager.getCurrentUser)
    ? SessionManager.getCurrentUser() : null;
  const role=String(user?.role||'').toLowerCase();
  const required=el.getAttribute('data-permission')||'';
  if((role==='organization_admin'||role==='super_admin') &&
     (required==='settings.view'||required==='dashboard.customize') &&
     typeof RBACManager!=='undefined' && RBACManager.hasPermission(required)){
    return true;
  }

  if(stable && allowed.includes(stable)) return true;
  const legacy=(el.dataset.permission||'')+'#'+index;
  return allowed.includes(legacy);
}
async function boot(){
  try{
    const s=SessionManager.getCurrentUser();
    if(!s||!s.id)return;
    const r=await IMP_API.get('/settings/user-ui-visibility');
    const allowed=r.visibility?.[s.id];
    // No saved custom visibility means RBACManager remains the authority.
    if(!Array.isArray(allowed))return;
    const links=Array.from(document.querySelectorAll('#dashboardSidebar a[data-permission]'));
    links.forEach((a,i)=>{if(!isAllowed(allowed,a,i))a.remove();});
  }catch(e){console.warn('[IMP] user UI visibility unavailable',e);}
}
document.addEventListener('DOMContentLoaded',boot);
})();
