/**
 * IMP Member Form Manager
 *
 * Member creation/edit form handler.
 *
 * Important:
 * - Branch ID is required for member creation.
 * - Organization-wide users select a branch from the form.
 * - Branch-level users receive their branch from SessionManager.
 * - Server remains the final authority.
 */

class MemberFormManager {

    // =========================================================
    // Generic DOM Value
    // =========================================================

    static getValue(id) {

        const element =
            document.getElementById(id);

        return element
            ? String(element.value ?? "").trim()
            : "";
    }


    // =========================================================
    // Collect Member Data
    // =========================================================

    static collectData() {

        const branchId =
            this.getValue("branchId");


        /*
         * branchId is intentionally included here.
         *
         * Backend:
         *
         * organization_admin / super_admin
         *      -> uses d.branchId
         *
         * branch-level user
         *      -> uses req.auth.branch_id
         */

        return {

            branchId,

            memberOrigin: this.getValue("memberOrigin") || "new",
            legacyCurrentInstallmentsPaid: Number(this.getValue("legacyCurrentInstallmentsPaid") || 0),
            legacyCurrentInstallmentAmount: Number(this.getValue("legacyCurrentInstallmentAmount") || 0),
            legacySavingsBalance: Number(this.getValue("legacySavingsBalance") || 0),
            admissionFee: Number(this.getValue("admissionFee") || 0),

            fullName:
                this.getValue("fullName"),

            fatherName:
                this.getValue("fatherName"),

            motherName:
                this.getValue("motherName"),

            spouseName:
                this.getValue("spouseName"),

            dateOfBirth:
                this.getValue("dateOfBirth"),

            gender:
                this.getValue("gender"),

            nid:
                this.getValue("nid"),

            mobile:
                this.getValue("mobile"),

            email:
                this.getValue("email"),

            address:
                this.getValue("address"),

            occupation:
                this.getValue("occupation"),

            monthlyIncome:
                this.getValue("monthlyIncome"),

            sourceOfIncome:
                this.getValue("sourceOfIncome")
        };
    }


    // =========================================================
    // Validation
    // =========================================================

    static validate(data) {

        if (!data.branchId) {

            throw new Error(
                "Please select a branch."
            );
        }


        if (!data.fullName) {

            throw new Error(
                "Full name is required."
            );
        }


        if (!data.mobile) {

            throw new Error(
                "Mobile number is required."
            );
        }


        if (!data.nid) {

            throw new Error(
                "NID number is required."
            );
        }


        return true;
    }


    // =========================================================
    // Create Form
    // =========================================================

    static bindCreateForm() {

        const form =
            document.getElementById(
                "memberForm"
            );

        if (!form) {
            return;
        }


        /*
         * Prevent duplicate event binding.
         */

        if (form.dataset.memberCreateBound === "true") {
            return;
        }

        form.dataset.memberCreateBound = "true";


        form.addEventListener(
            "submit",
            async event => {

                event.preventDefault();


                try {

                    // -----------------------------------------
                    // Permission
                    // -----------------------------------------

                    if (
                        typeof RBACManager !== "undefined" &&
                        !RBACManager.hasPermission(
                            "member.create"
                        )
                    ) {

                        throw new Error(
                            "Access denied."
                        );
                    }


                    // -----------------------------------------
                    // Collect
                    // -----------------------------------------

                    const data =
                        this.collectData();


                    // -----------------------------------------
                    // Validate
                    // -----------------------------------------

                    this.validate(
                        data
                    );


                    // -----------------------------------------
                    // Photo helper
                    // -----------------------------------------

                    const fileToDataUrl =
                        file => new Promise(
                            (resolve, reject) => {

                                if (!file) {

                                    resolve(null);

                                    return;
                                }


                                const reader =
                                    new FileReader();


                                reader.onload =
                                    () => resolve(
                                        String(
                                            reader.result
                                        )
                                    );


                                reader.onerror =
                                    reject;


                                reader.readAsDataURL(
                                    file
                                );
                            }
                        );


                    // -----------------------------------------
                    // Registration Settings
                    // -----------------------------------------

                    let cfg = {};


                    try {

                        if (
                            typeof MemberRegistrationSettings !==
                            "undefined" &&
                            MemberRegistrationSettings.getSync
                        ) {

                            cfg =
                                MemberRegistrationSettings
                                    .getSync();

                        } else if (
                            typeof SettingsAPI !==
                            "undefined"
                        ) {

                            cfg = {};

                        }

                    } catch (_) {

                        cfg = {};

                    }


                    // -----------------------------------------
                    // Nominee
                    // -----------------------------------------

                    const nominee = {

                        name:
                            this.getValue(
                                "nomineeName"
                            ),

                        relation:
                            this.getValue(
                                "nomineeRelation"
                            ),

                        mobile:
                            this.getValue(
                                "nomineeMobile"
                            ),

                        nid:
                            this.getValue(
                                "nomineeNid"
                            ),

                        address:
                            this.getValue(
                                "nomineeAddress"
                            )
                    };


                    if (
                        cfg.nomineeVisible !== false &&
                        cfg.nomineeRequired !== false &&
                        !nominee.name
                    ) {

                        throw new Error(
                            "Nominee name is required."
                        );
                    }


                    data.nominee =
                        cfg.nomineeVisible === false
                            ? null
                            : nominee;


                    // -----------------------------------------
                    // Photos
                    // -----------------------------------------

                    data.memberPhoto =
                        await fileToDataUrl(
                            document
                                .getElementById(
                                    "memberPhoto"
                                )
                                ?.files?.[0]
                        );


                    data.nomineePhoto =
                        await fileToDataUrl(
                            document
                                .getElementById(
                                    "nomineePhoto"
                                )
                                ?.files?.[0]
                        );


                    // -----------------------------------------
                    // API
                    // -----------------------------------------

                    const member =
                        await MemberManager
                            .createMember(
                                data
                            );


                    if (!member) {

                        throw new Error(
                            "Member could not be created."
                        );
                    }


                    // -----------------------------------------
                    // Success
                    // -----------------------------------------

                    Utils.showMessage(
                        `Member created successfully. Code: ${member.memberCode}`,
                        "success"
                    );


                    // -----------------------------------------
                    // Redirect
                    // -----------------------------------------

                    setTimeout(
                        () => {

                            const mid =
                                member.memberId ||
                                member.id;


                            if (!mid) {

                                window.location.href =
                                    "members.html";

                                return;
                            }


                            window.location.href =
                                `member-profile.html?id=${encodeURIComponent(
                                    mid
                                )}`;

                        },
                        800
                    );

                } catch (error) {

                    console.error(
                        "[IMP] Member creation failed:",
                        error
                    );


                    let message =
                        error?.message ||
                        "Unable to create member.";


                    // -----------------------------------------
                    // 401
                    // -----------------------------------------

                    if (
                        error?.status === 401
                    ) {

                        message =
                            "Your login session has expired. Please log in again.";


                        if (
                            typeof SessionManager !==
                            "undefined"
                        ) {

                            SessionManager
                                .clearSession();

                            setTimeout(
                                () =>
                                    SessionManager
                                        .redirectToLogin(),
                                700
                            );
                        }
                    }


                    // -----------------------------------------
                    // 403
                    // -----------------------------------------

                    else if (
                        error?.status === 403
                    ) {

                        message =
                            error?.message ||
                            "Branch access denied.";
                    }


                    // -----------------------------------------
                    // 409
                    // -----------------------------------------

                    else if (
                        error?.status === 409
                    ) {

                        message =
                            error?.message ||
                            "A member with this information already exists.";
                    }


                    // -----------------------------------------
                    // 400
                    // -----------------------------------------

                    else if (
                        error?.status === 400
                    ) {

                        message =
                            error?.message ||
                            "Invalid member information.";
                    }


                    Utils.showMessage(
                        message,
                        "error"
                    );
                }
            }
        );
    }


    // =========================================================
    // Edit Form
    // =========================================================

    static bindEditForm(memberId) {

        const form =
            document.getElementById(
                "memberEditForm"
            );

        if (!form) {
            return;
        }


        const member =
            MemberManager.findById(
                memberId
            );


        if (!member) {

            Utils.showMessage(
                "Member not found.",
                "error"
            );

            return;
        }


        this.populate(
            member
        );


        form.addEventListener(
            "submit",
            async event => {

                event.preventDefault();


                try {

                    const data =
                        this.collectData();


                    this.validate(
                        data
                    );


                    await MemberManager
                        .updateMember(
                            memberId,
                            {
                                branchId:
                                    data.branchId || null,

                                fullName:
                                    data.fullName,

                                fatherName:
                                    data.fatherName,

                                motherName:
                                    data.motherName,

                                spouseName:
                                    data.spouseName,

                                dateOfBirth:
                                    data.dateOfBirth,

                                gender:
                                    data.gender,

                                nid:
                                    data.nid,

                                mobile:
                                    data.mobile,

                                email:
                                    data.email,

                                address:
                                    data.address,

                                occupation:
                                    data.occupation,

                                monthlyIncome:
                                    Number(
                                        data.monthlyIncome ||
                                        0
                                    ),

                                sourceOfIncome:
                                    data.sourceOfIncome
                            }
                        );


                    Utils.showMessage(
                        "Member updated successfully.",
                        "success"
                    );


                    setTimeout(
                        () => {

                            window.location.href =
                                `member-profile.html?id=${encodeURIComponent(
                                    memberId
                                )}`;

                        },
                        800
                    );

                } catch (error) {

                    Utils.showMessage(
                        error.message,
                        "error"
                    );
                }
            }
        );
    }


    // =========================================================
    // Set Value
    // =========================================================

    static setValue(id, value) {

        const element =
            document.getElementById(id);


        if (element) {

            element.value =
                value ?? "";
        }
    }


    // =========================================================
    // Populate Edit
    // =========================================================

    static populate(member) {

        const info =
            member.personalInfo || {};


        const financial =
            member.financial || {};


        this.setValue(
            "fullName",
            info.fullName
        );


        this.setValue(
            "fatherName",
            info.fatherName
        );


        this.setValue(
            "motherName",
            info.motherName
        );


        this.setValue(
            "spouseName",
            info.spouseName
        );


        this.setValue(
            "dateOfBirth",
            info.dateOfBirth
        );


        this.setValue(
            "gender",
            info.gender
        );


        this.setValue(
            "nid",
            info.nid
        );


        this.setValue(
            "mobile",
            info.mobile
        );


        this.setValue(
            "email",
            info.email
        );


        this.setValue(
            "address",
            info.address
        );


        this.setValue(
            "occupation",
            financial.occupation
        );


        this.setValue(
            "monthlyIncome",
            financial.monthlyIncome
        );


        this.setValue(
            "sourceOfIncome",
            financial.sourceOfIncome
        );
    }
}