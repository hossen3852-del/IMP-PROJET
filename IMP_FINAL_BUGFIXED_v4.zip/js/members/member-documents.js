class MemberDocumentsManager {
    static async getDocuments(memberId) { return MemberService.getDocuments(memberId); }
    static async addDocument(memberId, data) {
        if (!RBACManager.hasPermission('member.document.upload')) throw new Error('Permission denied.');
        return MemberService.addDocument(memberId, { documentType: data.type || '', name: data.name || '', reference: data.reference || '', description: data.description || '' });
    }
    static async removeDocument(memberId, documentId) {
        if (!RBACManager.hasPermission('member.document.delete')) throw new Error('Permission denied.');
        return MemberService.removeDocument(memberId, documentId);
    }
    static async render(memberId) {
        const list = document.getElementById('documentList'); if (!list) return;
        try {
            const documents = await this.getDocuments(memberId);
            if (!documents.length) { list.innerHTML = '<p>No documents found.</p>'; return; }
            list.innerHTML = documents.map(d => `<div class="list-item"><strong>${Utils.escapeHTML(d.name || '')}</strong><p>Type: ${Utils.escapeHTML(d.document_type || d.type || '')}</p><p>Reference: ${Utils.escapeHTML(d.reference || '')}</p><p>Uploaded: ${Utils.escapeHTML(d.uploaded_at || d.uploadedAt || '')}</p></div>`).join('');
        } catch (e) { Utils.showMessage(e.message, 'error'); }
    }
}
window.MemberDocumentsManager = MemberDocumentsManager;
