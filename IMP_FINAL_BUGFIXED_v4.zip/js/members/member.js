/**
 * IMP Member API client — 11.P.7.
 * PostgreSQL/API is authoritative. localStorage is never used for member authority.
 */
var MemberService = {
    _cache: new Map(),

    async getMembers(options = {}) {
        const params = new URLSearchParams();
        if (options.q) params.set('q', options.q);
        if (options.status) params.set('status', options.status);
        if (options.branchId) params.set('branch_id', options.branchId);
        if (options.limit) params.set('limit', String(options.limit));
        if (options.offset) params.set('offset', String(options.offset));
        const result = await IMP_API.get(`/members${params.toString() ? `?${params}` : ''}`);
        const members = Array.isArray(result?.members) ? result.members : [];
        members.forEach(m => this._cache.set(String(m.id || m.memberId), m));
        return members;
    },

    async getMemberById(id) {
        if (!id) return null;
        const result = await IMP_API.get(`/members/${encodeURIComponent(id)}`);
        const member = result?.member || null;
        if (member) this._cache.set(String(member.id || member.memberId), member);
        return member;
    },

    async createMember(data) {
        const result = await IMP_API.post('/members', data);
        const member = result?.member;
        if (member) this._cache.set(String(member.id || member.memberId), member);
        return member;
    },

    async updateMember(id, data) {
        const result = await IMP_API.patch(`/members/${encodeURIComponent(id)}`, data);
        const member = result?.member;
        if (member) this._cache.set(String(member.id || member.memberId), member);
        return member;
    },

    async deleteMember(id) {
        await IMP_API.delete(`/members/${encodeURIComponent(id)}`);
        this._cache.delete(String(id));
        return true;
    },

    async getNominee(id) { return (await IMP_API.get(`/members/${encodeURIComponent(id)}/nominee`))?.nominee || null; },
    async saveNominee(id, data) { return (await IMP_API.put(`/members/${encodeURIComponent(id)}/nominee`, data))?.nominee || null; },
    async getDocuments(id) { return (await IMP_API.get(`/members/${encodeURIComponent(id)}/documents`))?.documents || []; },
    async addDocument(id, data) { return (await IMP_API.post(`/members/${encodeURIComponent(id)}/documents`, data))?.document || null; },
    async removeDocument(id, documentId) { await IMP_API.delete(`/members/${encodeURIComponent(id)}/documents/${encodeURIComponent(documentId)}`); },
    async getActivities(id) { return (await IMP_API.get(`/members/${encodeURIComponent(id)}/activities`))?.activities || []; },
    async addActivity(id, data) { return (await IMP_API.post(`/members/${encodeURIComponent(id)}/activities`, data))?.activity || null; },
    async getFamily(id) { return (await IMP_API.get(`/members/${encodeURIComponent(id)}/family`))?.family || { members: [], notes: '' }; },
    async saveFamily(id, data) { return (await IMP_API.put(`/members/${encodeURIComponent(id)}/family`, data))?.family || data; },
    async getFinancial(id) { return (await IMP_API.get(`/members/${encodeURIComponent(id)}/financial`))?.financial || {}; },
    async saveFinancial(id, data) { return (await IMP_API.patch(`/members/${encodeURIComponent(id)}/financial`, data))?.financial || {}; }
};

var MemberManager = {
    findById(id) { return MemberService._cache.get(String(id)) || null; },
    async preload(id) { return MemberService.getMemberById(id); },
    async createMember(data) { return MemberService.createMember(data); },
    async updateMember(id, data) { return MemberService.updateMember(id, data); },
    async deleteMember(id) { return MemberService.deleteMember(id); },
    async getOrganizationMembers(options = {}) { return MemberService.getMembers(options); },
    async getMembers(options = {}) { return MemberService.getMembers(options); }
};

window.MemberService = MemberService;
window.MemberManager = MemberManager;
