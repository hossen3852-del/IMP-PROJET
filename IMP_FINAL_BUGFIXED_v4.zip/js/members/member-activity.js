class MemberActivityManager {
    static async log(memberId, action, description = "") {
        return MemberService.addActivity(memberId, { activityType: action, description, metadata: {} });
    }
    static async getMemberActivities(memberId) { return MemberService.getActivities(memberId); }
    static async render(memberId) {
        const list = document.getElementById("activityList"); if (!list) return;
        try {
            const activities = await this.getMemberActivities(memberId);
            if (!activities.length) { list.innerHTML = "<p>No activity found.</p>"; return; }
            list.innerHTML = activities.map(a => `<div class="activity-item"><strong>${Utils.escapeHTML(a.activity_type || a.action || "")}</strong><p>${Utils.escapeHTML(a.description || "")}</p><small>${Utils.escapeHTML(a.created_at || a.createdAt || "")}</small></div>`).join("");
        } catch (e) { Utils.showMessage(e.message, "error"); }
    }
}
window.MemberActivityManager = MemberActivityManager;
