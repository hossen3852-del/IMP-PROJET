class MemberProfileManager {

    static async init() {
        const id = Utils.getQueryParam("id");
        if (!id) {
            Utils.showMessage("Member ID is missing.", "error");
            return;
        }

        try {
            const member = await MemberManager.preload(id);
            if (!member) {
                Utils.showMessage("Member not found.", "error");
                return;
            }
            this.render(member);
            await this.loadSavings(id);
            await this.loadLoanHistory(id);
        } catch (error) {
            console.error("[IMP] Member profile load failed:", error);
            Utils.showMessage(
                error.status === 401
                    ? "Please log in again to view this member."
                    : (error.message || "Unable to load member profile."),
                "error"
            );
        }
    }


    static async loadSavings(memberId) {
        try {
            const result = await IMP_API.get(
                "/savings/summary?memberId=" + encodeURIComponent(memberId)
            );
            const summary = result.summary || {};
            const moneyText = (v) => `৳ ${Number(v || 0).toLocaleString("bn-BD", {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            })}`;
            const set = (id, value) => {
                const el = document.getElementById(id);
                if (el) {
                    el.textContent = value;
                    el.dataset.i18nSkip = "1";
                }
            };
            set("savingsDeposit", moneyText(summary.deposits));
            set("savingsDaily", moneyText(summary.dailyDeposits));
            set("savingsWithdrawal", moneyText(summary.withdrawals));
            set("savingsInstallmentPayment", moneyText(summary.installmentPayments));
            set("savingsBalance", moneyText(summary.balance));
        } catch (savingsError) {
            console.warn("[IMP] Savings summary unavailable:", savingsError);
        }
    }


    static async loadLoanHistory(memberId) {
        const host=document.getElementById('loanHistoryContent'); if(!host)return;
        try{
            const r=await IMP_API.get('/loans?member_id='+encodeURIComponent(memberId)+'&limit=100');
            const loans=r.loans||[];
            const previous=loans.filter(x=>x.status==='completed'||x.loanSourceType==='previous_loan'||x.loan_source_type==='previous_loan');
            if(!previous.length){host.innerHTML='<p>পূর্বের/সম্পূর্ণ লোনের কোনো রেকর্ড নেই।</p>';return;}
            const rows=[];
            for(const l of previous){
                let paid=0, overdue=0, advance=0, full=0;
                try{
                    const sr=await IMP_API.get('/installments?loan_id='+encodeURIComponent(l.id)+'&limit=1000'); const ss=sr.installments||[];
                    paid=ss.filter(x=>Number(x.paidAmount||x.paid_amount||0)>0).length;
                    overdue=ss.filter(x=>['overdue'].includes(String(x.status||'').toLowerCase())||Number(x.outstandingAmount||x.outstanding_amount||0)>0&&new Date(x.dueDate||x.due_date)<new Date()).length;
                    advance=ss.filter(x=>String(x.status||'')==='paid' && new Date(x.paidDate||x.paid_date||0)<new Date(x.dueDate||x.due_date||0)).length;
                    full=Number(l.outstandingAmount||0)<=0.009?1:0;
                }catch(_){ }
                const rating=Math.max(0,100-(overdue*5)+(advance*2));
                rows.push('<tr><td>'+Utils.escapeHtml(l.loanNumber||'-')+'</td><td>'+Utils.escapeHtml(l.status||'-')+'</td><td>'+Number(l.loanAmount||0).toLocaleString('en-BD')+'</td><td>'+paid+'</td><td>'+overdue+'</td><td>'+advance+'</td><td>'+full+'</td><td>'+rating.toFixed(0)+'/100</td></tr>');
            }
            host.innerHTML='<div class="table-wrapper"><table><thead><tr><th>লোন</th><th>স্ট্যাটাস</th><th>মূল ঋণ</th><th>পরিশোধিত কিস্তি</th><th>বকেয়া কিস্তি</th><th>অগ্রিম</th><th>Full Settlement</th><th>Rating</th></tr></thead><tbody>'+rows.join('')+'</tbody></table></div>';
        }catch(e){host.textContent=e.message||'Loan history unavailable';}
    }

    static render(member) {
        const info = member.personalInfo || {};
        const financial = member.financial || {};
        // Nominee may arrive as camelCase or snake_case from API
        const rawNominee = member.nominee || {};
        const nominee = {
            name: rawNominee.name || rawNominee.nomineeName || "",
            relation: rawNominee.relation || "",
            mobile: rawNominee.mobile || rawNominee.phone || "",
            nid: rawNominee.nid || "",
            nomineePhoto: rawNominee.nomineePhoto || rawNominee.photo_path || null
        };

        const setText = (id, value) => {
            const element = document.getElementById(id);
            if (!element) return;
            const v = (value === 0 || value) ? String(value) : "-";
            element.textContent = v;
            // Prevent i18n observer from reverting live member data to "-"
            element.dataset.i18nOriginal = v;
            element.dataset.i18nSkip = "1";
        };

        const fullName = info.fullName || member.fullName || "-";
        const mobile = info.mobile || member.mobile || member.phone || "-";
        const nid = info.nid || member.nid || member.nidOrPassport || "-";
        const email = info.email || member.email || "-";
        const address = info.address || member.address || "-";

        setText("memberCode", member.memberCode);
        setText("memberName", fullName);
        setText("fatherName", info.fatherName);
        setText("motherName", info.motherName);
        setText("spouseName", info.spouseName);
        setText("dateOfBirth", info.dateOfBirth);
        setText("gender", info.gender);
        setText("nid", nid);
        setText("mobile", mobile);
        setText("email", email);
        setText("address", address);
        setText("occupation", financial.occupation);
        setText(
            "monthlyIncome",
            financial.monthlyIncome !== undefined && financial.monthlyIncome !== null && financial.monthlyIncome !== ""
                ? `৳ ${financial.monthlyIncome}`
                : "-"
        );
        setText("sourceOfIncome", financial.sourceOfIncome);
        setText("nomineeName", nominee.name);
        setText("nomineeRelation", nominee.relation);
        setText("nomineeMobile", nominee.mobile);
        setText("nomineeNid", nominee.nid);
        setText("memberStatus", member.status);

        const memberPhoto = document.getElementById("memberPhoto");
        const memberPhotoPlaceholder = document.getElementById("memberPhotoPlaceholder");
        if (memberPhoto && member.memberPhoto) {
            memberPhoto.src = member.memberPhoto;
            memberPhoto.hidden = false;
            memberPhoto.onerror = () => { memberPhoto.hidden = true; if (memberPhotoPlaceholder) memberPhotoPlaceholder.hidden = false; };
            if (memberPhotoPlaceholder) memberPhotoPlaceholder.hidden = true;
        }

        const nomineePhoto = document.getElementById("nomineePhoto");
        const nomineePhotoPlaceholder = document.getElementById("nomineePhotoPlaceholder");
        if (nomineePhoto && nominee.nomineePhoto) {
            nomineePhoto.src = nominee.nomineePhoto;
            nomineePhoto.hidden = false;
            nomineePhoto.onerror = () => { nomineePhoto.hidden = true; if (nomineePhotoPlaceholder) nomineePhotoPlaceholder.hidden = false; };
            if (nomineePhotoPlaceholder) nomineePhotoPlaceholder.hidden = true;
        }

        setText("profilePhone", mobile);

        const editButton = document.getElementById("editMemberButton");
        if (editButton) {
            editButton.href = `member-edit.html?id=${encodeURIComponent(member.id || member.memberId)}`;
        }
    }
}
