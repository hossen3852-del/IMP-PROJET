class MemberFinancialManager {

    static async save(
        memberId,
        data
    ) {

        const member =
            await MemberManager.preload(memberId);

        if (!member) {
            throw new Error(
                "Member not found."
            );
        }

        if (
            !RBACManager.hasPermission(
                "member.financial.update"
            )
        ) {
            throw new Error(
                "Permission denied."
            );
        }

        return await MemberService.saveFinancial(memberId, { occupation: data.occupation || '', monthlyIncome: Number(data.monthlyIncome || 0), sourceOfIncome: data.sourceOfIncome || '', bankAccount: data.bankAccount || '', mobileBanking: data.mobileBanking || '' });
    }

    static async get(
        memberId
    ) {

        const member =
            await MemberManager.preload(memberId);

        if (!member) {
            throw new Error(
                "Member not found."
            );
        }

        return MemberService.getFinancial(memberId);
    }
}