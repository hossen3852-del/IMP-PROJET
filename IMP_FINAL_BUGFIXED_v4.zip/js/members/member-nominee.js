class MemberNomineeManager {

    static async save(
        memberId,
        data
    ) {

        const member =
            await MemberManager.preload(memberId);

        if (!member) {
            throw new Error(
                "Member not found."
            );
        }

        if (
            !RBACManager.hasPermission(
                "member.update"
            )
        ) {
            throw new Error(
                "Permission denied."
            );
        }

        return await MemberService.saveNominee(memberId, { name: data.name || '', relation: data.relation || '', mobile: data.mobile || '', nid: data.nid || '', address: data.address || '' });
    }

    static async render(
        memberId
    ) {

        const nominee = await MemberService.getNominee(memberId);
        if (!nominee) return;

        const fields = {

            nomineeName:
                nominee.name,

            nomineeRelation:
                nominee.relation,

            nomineeMobile:
                nominee.mobile,

            nomineeNid:
                nominee.nid,

            nomineeAddress:
                nominee.address
        };

        Object.entries(fields)
            .forEach(
                ([id, value]) => {

                    const element =
                        document.getElementById(
                            id
                        );

                    if (element) {
                        element.value =
                            value || "";
                    }
                }
            );
    }
}