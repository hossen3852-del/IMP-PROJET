class MemberStatusManager {

    static allowedStatuses = [

        "active",

        "inactive",

        "suspended"

    ];

    static async changeStatus(
        memberId,
        status,
        reason = ""
    ) {

        if (
            !this.allowedStatuses
                .includes(status)
        ) {
            throw new Error(
                "Invalid member status."
            );
        }

        const member =
            await MemberManager.preload(memberId);

        if (!member) {
            throw new Error(
                "Member not found."
            );
        }

        if (
            !RBACManager.hasPermission(
                "member.status.update"
            )
        ) {
            throw new Error(
                "Permission denied."
            );
        }

        const oldStatus =
            member.status;

        const updated =
            await MemberManager.updateMember(
                memberId,
                {
                    status
                }
            );

        await MemberActivityManager.log(
            memberId,
            "status_changed",
            `Status changed from ${oldStatus} to ${status}. ${reason}`
        );

        return updated;
    }

    static activate(
        memberId
    ) {

        return this.changeStatus(
            memberId,
            "active"
        );
    }

    static deactivate(
        memberId
    ) {

        return this.changeStatus(
            memberId,
            "inactive"
        );
    }

    static suspend(
        memberId,
        reason = ""
    ) {

        return this.changeStatus(
            memberId,
            "suspended",
            reason
        );
    }

}