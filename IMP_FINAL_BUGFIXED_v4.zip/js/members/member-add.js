"use strict";

/**
 * IMP - Member Add
 * Path:
 * js/members/member-add.js
 *
 * Flow:
 * Member Add Form
 *      ↓
 * RBAC permission check
 *      ↓
 * Branch selection
 *      ↓
 * POST /api/members
 */

document.addEventListener("DOMContentLoaded", async () => {

    // =========================================================
    // DOM
    // =========================================================

    const form = document.getElementById("memberForm");
    const message = document.getElementById("formMessage");

    const branchSelect = document.getElementById("branchId");
    const submitButton =
        document.getElementById("saveMember") ||
        document.getElementById("submitMember") ||
        form?.querySelector('button[type="submit"]');

    if (!form) {
        console.error("[IMP] Member add form not found.");
        return;
    }


    // =========================================================
    // Helpers
    // =========================================================

    function showMessage(text, type = "error") {

        if (typeof Utils !== "undefined" &&
            typeof Utils.showMessage === "function") {

            Utils.showMessage(
                "formMessage",
                text,
                type
            );

            return;
        }

        if (message) {
            message.textContent = text;
            message.className = `alert-target ${type}`;
            message.hidden = false;
        }
    }


    function escapeHtml(value) {

        return String(value ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }


    function getValue(id) {

        const element = document.getElementById(id);

        if (!element) {
            return "";
        }

        return String(element.value ?? "").trim();
    }


    function getOptionalValue(id) {

        const value = getValue(id);

        return value === "" ? null : value;
    }


    function getNumberValue(id) {

        const value = getValue(id);

        if (value === "") {
            return null;
        }

        const number = Number(value);

        return Number.isFinite(number)
            ? number
            : null;
    }


    function setButtonLoading(loading) {

        if (!submitButton) {
            return;
        }

        if (loading) {

            submitButton.disabled = true;

            if (!submitButton.dataset.originalText) {
                submitButton.dataset.originalText =
                    submitButton.textContent;
            }

            submitButton.textContent = "Saving...";

        } else {

            submitButton.disabled = false;

            if (submitButton.dataset.originalText) {
                submitButton.textContent =
                    submitButton.dataset.originalText;
            }
        }
    }


    // =========================================================
    // RBAC
    // =========================================================

    async function checkPermission() {

        if (
            typeof RBACManager === "undefined" ||
            typeof RBACManager.bootstrap !== "function"
        ) {
            throw new Error(
                "RBAC system could not be initialized."
            );
        }

        await RBACManager.bootstrap();

        if (
            typeof RBACManager.hasPermission !== "function" ||
            !RBACManager.hasPermission("member.create")
        ) {
            throw new Error(
                "You do not have permission to create members."
            );
        }
    }


    // =========================================================
    // Branch
    // =========================================================

    async function loadBranches() {

        if (!branchSelect) {
            return;
        }

        /*
         * Organization Admin / Super Admin:
         * branch dropdown is required because a member
         * must belong to a specific branch.
         *
         * Branch-level users:
         * their own branch is selected automatically.
         */

        let auth = null;

        if (
            typeof SessionManager !== "undefined" &&
            typeof SessionManager.getSession === "function"
        ) {
            try {
                auth = await SessionManager.getSession();
            } catch (_) {
                auth = null;
            }
        }

        const role =
            auth?.role_code ||
            auth?.role ||
            "";

        const organizationWide =
            role === "organization_admin" ||
            role === "super_admin";

        // -----------------------------------------------------
        // Organization-wide user
        // -----------------------------------------------------

        if (organizationWide) {

            if (
                typeof BranchManager === "undefined" ||
                typeof BranchManager.getAll !== "function"
            ) {
                throw new Error(
                    "Branch manager is not available."
                );
            }

            const branches =
                await BranchManager.getAll();

            if (!Array.isArray(branches) || !branches.length) {

                branchSelect.innerHTML =
                    `<option value="">No branch available</option>`;

                throw new Error(
                    "No active branch is available. Please create a branch first."
                );
            }

            branchSelect.innerHTML =
                `<option value="">Select Branch</option>` +
                branches
                    .filter(branch =>
                        branch &&
                        branch.id
                    )
                    .map(branch => {

                        const name =
                            branch.name ||
                            branch.branchName ||
                            branch.code ||
                            "Branch";

                        return `
                            <option value="${escapeHtml(branch.id)}">
                                ${escapeHtml(name)}
                            </option>
                        `;
                    })
                    .join("");

            branchSelect.disabled = false;

            return;
        }


        // -----------------------------------------------------
        // Branch-level user
        // -----------------------------------------------------

        let ownBranchId = null;

        if (
            typeof SessionManager !== "undefined" &&
            typeof SessionManager.getBranchId === "function"
        ) {
            ownBranchId =
                SessionManager.getBranchId();
        }

        if (!ownBranchId) {

            throw new Error(
                "Your account is not assigned to a branch."
            );
        }

        branchSelect.innerHTML =
            `<option value="${escapeHtml(ownBranchId)}">
                My Branch
            </option>`;

        branchSelect.value = ownBranchId;
        branchSelect.disabled = true;
    }


    // =========================================================
    // Build Member Payload
    // =========================================================

    function buildPayload() {

        const branchId =
            getValue("branchId");

        if (!branchId) {

            throw new Error(
                "Please select a branch."
            );
        }


        const fullName =
            getValue("fullName");

        if (!fullName) {

            throw new Error(
                "Member name is required."
            );
        }


        const payload = {

            // -------------------------------------------------
            // Required
            // -------------------------------------------------

            fullName,
            branchId,

            // -------------------------------------------------
            // Common member fields
            // -------------------------------------------------

            memberCode:
                getOptionalValue("memberCode"),

            mobile:
                getOptionalValue("mobile"),

            phone:
                getOptionalValue("phone"),

            email:
                getOptionalValue("email"),

            nid:
                getOptionalValue("nid"),

            status:
                getValue("status") || "active",

            // -------------------------------------------------
            // Personal Information
            // -------------------------------------------------

            personalInfo: {

                fullName,

                fatherName:
                    getOptionalValue("fatherName"),

                motherName:
                    getOptionalValue("motherName"),

                spouseName:
                    getOptionalValue("spouseName"),

                dateOfBirth:
                    getOptionalValue("dateOfBirth"),

                gender:
                    getOptionalValue("gender"),

                nid:
                    getOptionalValue("nid"),

                mobile:
                    getOptionalValue("mobile") ||
                    getOptionalValue("phone"),

                email:
                    getOptionalValue("email"),

                address:
                    getOptionalValue("address")
            },

            // -------------------------------------------------
            // Financial Information
            // -------------------------------------------------

            financial: {

                occupation:
                    getOptionalValue("occupation"),

                monthlyIncome:
                    getNumberValue("monthlyIncome"),

                sourceOfIncome:
                    getOptionalValue("sourceOfIncome")
            },

            admissionFee: Math.max(0, getNumberValue("admissionFee") || 0),

            // -------------------------------------------------
            // Nominee
            // -------------------------------------------------

            nominee: {

                name:
                    getOptionalValue("nomineeName"),

                relation:
                    getOptionalValue("nomineeRelation"),

                mobile:
                    getOptionalValue("nomineeMobile"),

                nid:
                    getOptionalValue("nomineeNid")
            }
        };


        /*
         * Remove optional top-level values which are null.
         * This keeps the request clean.
         */

        Object.keys(payload).forEach(key => {

            if (
                payload[key] === null ||
                payload[key] === ""
            ) {
                delete payload[key];
            }
        });


        return payload;
    }


    // =========================================================
    // Submit
    // =========================================================

    async function saveMember(event) {

        event.preventDefault();

        showMessage("", "info");

        try {

            const payload =
                buildPayload();

            console.log(
                "[IMP] Creating member:",
                {
                    branchId: payload.branchId,
                    fullName: payload.fullName
                }
            );

            setButtonLoading(true);


            // -------------------------------------------------
            // API
            // -------------------------------------------------

            const result =
                await IMP_API.post(
                    "/members",
                    payload
                );


            console.log(
                "[IMP] Member created:",
                result
            );


            showMessage(
                "Member created successfully.",
                "success"
            );


            // -------------------------------------------------
            // Redirect
            // -------------------------------------------------

            const memberId =
                result?.member?.id ||
                result?.member?.memberId ||
                result?.id ||
                result?.memberId;


            setTimeout(() => {

                if (memberId) {

                    window.location.href =
                        `member-profile.html?id=${encodeURIComponent(memberId)}`;

                } else {

                    window.location.href =
                        "members.html";
                }

            }, 700);


        } catch (error) {

            console.error(
                "[IMP] Member creation failed:",
                error
            );


            let errorMessage =
                error?.message ||
                "Unable to create member.";


            // -------------------------------------------------
            // Specific 401
            // -------------------------------------------------

            if (error?.status === 401) {

                errorMessage =
                    "Your session has expired. Please log in again.";
            }


            // -------------------------------------------------
            // Specific 403
            // -------------------------------------------------

            else if (error?.status === 403) {

                /*
                 * Backend can return:
                 *
                 * Forbidden
                 * Branch access denied
                 * Your account is not assigned to a branch
                 */

                errorMessage =
                    error?.message ||
                    "You do not have permission to create members or your branch access is invalid.";
            }


            // -------------------------------------------------
            // Specific 400
            // -------------------------------------------------

            else if (error?.status === 400) {

                errorMessage =
                    error?.message ||
                    "Invalid member information. Please check the form.";
            }


            showMessage(
                errorMessage,
                "error"
            );

        } finally {

            setButtonLoading(false);
        }
    }


    // =========================================================
    // Initialization
    // =========================================================

    try {

        // -----------------------------------------------------
        // Authentication
        // -----------------------------------------------------

        if (
            typeof SessionManager !== "undefined" &&
            typeof SessionManager.requireAuth === "function"
        ) {

            await SessionManager.requireAuth();
        }


        // -----------------------------------------------------
        // Permission
        // -----------------------------------------------------

        await checkPermission();


        // -----------------------------------------------------
        // Branch
        // -----------------------------------------------------

        await loadBranches();


        // -----------------------------------------------------
        // Form Submit
        // -----------------------------------------------------

        form.addEventListener(
            "submit",
            saveMember
        );


        console.log(
            "[IMP] Member add page initialized."
        );


    } catch (error) {

        console.error(
            "[IMP] Member add initialization failed:",
            error
        );

        showMessage(
            error?.message ||
            "Member add page could not be initialized.",
            "error"
        );

        if (submitButton) {
            submitButton.disabled = true;
        }
    }

});