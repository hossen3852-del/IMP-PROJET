                   
class MemberFamilyManager {

    static getMember(id) {

        const member =
            MemberManager.findById(id);

        if (!member) {
            throw new Error(
                "Member not found."
            );
        }

        return member;
    }

    static async addFamilyMember(
        memberId,
        data
    ) {

        const member = await MemberManager.preload(memberId);

        if (
            !RBACManager.hasPermission(
                "member.update"
            )
        ) {
            throw new Error(
                "Permission denied."
            );
        }

        const family =
            [
                ...(member.family?.members || [])
            ];

        family.push({

            id:
                Utils.generateId("family"),

            name:
                data.name || "",

            relation:
                data.relation || "",

            mobile:
                data.mobile || "",

            occupation:
                data.occupation || "",

            dateOfBirth:
                data.dateOfBirth || ""
        });

        await MemberService.saveFamily(memberId, { ...member.family, members: family });

        return family;
    }

    static async saveFamilyNotes(
        memberId,
        notes
    ) {

        const member = await MemberManager.preload(memberId);
        await MemberService.saveFamily(memberId, { ...member.family, notes });
    }

    static async render(
        memberId
    ) {

        const member = await MemberManager.preload(memberId);

        const list =
            document.getElementById(
                "familyList"
            );

        if (!list) return;

        const family =
            member.family?.members || [];

        if (!family.length) {

            list.innerHTML =
                "<p>No family members found.</p>";

            return;
        }

        list.innerHTML =
            family.map(
                item => `

                    <div class="list-item">

                        <strong>
                            ${Utils.escapeHTML(
                                item.name
                            )}
                        </strong>

                        <p>
                            Relation:
                            ${Utils.escapeHTML(
                                item.relation
                            )}
                        </p>

                        <p>
                            Mobile:
                            ${Utils.escapeHTML(
                                item.mobile
                            )}
                        </p>

                        <p>
                            Occupation:
                            ${Utils.escapeHTML(
                                item.occupation
                            )}
                        </p>

                    </div>
                `
            ).join("");
    }
}