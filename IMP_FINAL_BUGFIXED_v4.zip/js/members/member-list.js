class MemberListManager {

    static currentMembers = [];

    static async init() {

        this.currentMembers =
            await MemberManager
                .getOrganizationMembers();

        this.render();

        const search =
            document.getElementById(
                "memberSearch"
            );

        if (search) {

            search.addEventListener(
                "input",
                async () => {

                    await this.applyFilters();
                }
            );
        }

        const status =
            document.getElementById(
                "statusFilter"
            );

        if (status) {

            status.addEventListener(
                "change",
                async () => {

                    await this.applyFilters();
                }
            );
        }

        const branch =
            document.getElementById(
                "branchFilter"
            );

        if (branch) {

            branch.addEventListener(
                "change",
                async () => {

                    await this.applyFilters();
                }
            );
        }
    }

    static async applyFilters() {

        const keyword =
            document.getElementById(
                "memberSearch"
            )?.value
                .trim()
                .toLowerCase() || "";

        const status =
            document.getElementById(
                "statusFilter"
            )?.value || "";

        const branchId =
            document.getElementById(
                "branchFilter"
            )?.value || "";

        let members =
            await MemberManager
                .getOrganizationMembers();

        if (keyword) {

            members =
                members.filter(
                    member => {

                        const values = [

                            member.memberCode,

                            member.personalInfo
                                ?.fullName,

                            member.personalInfo
                                ?.mobile,

                            member.personalInfo
                                ?.nid

                        ]
                        .filter(Boolean)
                        .join(" ")
                        .toLowerCase();

                        return values
                            .includes(
                                keyword
                            );
                    }
                );
        }

        if (status) {

            members =
                members.filter(
                    member =>
                        member.status ===
                        status
                );
        }

        if (branchId) {

            members =
                members.filter(
                    member =>
                        member.branchId ===
                        branchId
                );
        }

        this.currentMembers =
            members;

        this.render();
    }

    static render() {

        const tbody =
            document.getElementById(
                "memberTableBody"
            );

        const empty =
            document.getElementById(
                "emptyMembers"
            );

        if (!tbody) return;

        tbody.innerHTML = "";

        if (
            !this.currentMembers.length
        ) {

            if (empty) {
                empty.style.display =
                    "block";
            }

            return;
        }

        if (empty) {
            empty.style.display =
                "none";
        }

        this.currentMembers
            .forEach(member => {

                const row =
                    document.createElement(
                        "tr"
                    );

                row.style.cursor =
                    "pointer";

                row.addEventListener(
                    "click",
                    () => {

                        window.location.href =
                            `member-profile.html?id=${encodeURIComponent(member.id)}`;
                    }
                );

                const memberPhoto = member.memberPhoto
                    ? `<img src="${Utils.escapeHTML(member.memberPhoto)}" alt="Member photo" class="member-list-photo" loading="lazy">`
                    : '';
                const memberPhotoFallback = `<span class="member-list-photo-placeholder" ${member.memberPhoto ? 'hidden' : ''}>—</span>`;
                const nominee = member.nominee || {};
                const nomineePhoto = nominee.nomineePhoto
                    ? `<img src="${Utils.escapeHTML(nominee.nomineePhoto)}" alt="Nominee photo" class="member-list-photo" loading="lazy">`
                    : '';
                const nomineePhotoFallback = `<span class="member-list-photo-placeholder" ${nominee.nomineePhoto ? 'hidden' : ''}>—</span>`;

                row.innerHTML = `
                    <td class="member-photo-cell">
                        ${memberPhoto}
                        ${memberPhotoFallback}
                    </td>

                    <td>
                        ${Utils.escapeHTML(member.memberCode || "-")}
                    </td>

                    <td>
                        ${Utils.escapeHTML(member.personalInfo?.fullName || member.fullName || "-")}
                    </td>

                    <td>
                        ${Utils.escapeHTML(member.personalInfo?.mobile || member.mobile || member.phone || "-")}
                    </td>

                    <td>
                        ${Utils.escapeHTML(member.personalInfo?.nid || member.nid || member.nidOrPassport || "-")}
                    </td>

                    <td>
                        ${Utils.escapeHTML(nominee.name || "-")}
                    </td>

                    <td>
                        ${Utils.escapeHTML(nominee.nid || "-")}
                    </td>

                    <td class="member-photo-cell">
                        ${nomineePhoto}
                        ${nomineePhotoFallback}
                    </td>

                    <td>
                        <span class="status">${Utils.escapeHTML(member.memberOrigin === 'previous_borrower' ? 'পূর্বে লোন গ্রহণকারী' : 'নতুন মেম্বার')}</span>
                    </td>

                    <td>
                        ${Utils.escapeHTML(member.status || "-")}
                    </td>

                    <td class="member-actions-cell">
                        <button type="button" class="btn btn-primary btn-view-member">
                            View
                        </button>
                        ${
                          (member.canDelete !== false && !member.hasBlockingLoan)
                            ? `<button type="button" class="btn btn-danger btn-delete-member" data-permission="member.delete" title="সদস্য মুছুন">Delete</button>`
                            : `<span class="muted" title="ঋণ বিতরণ/সক্রিয় থাকায় মুছা যাবে না">—</span>`
                        }
                    </td>
                `;

                // CSP in production sets script-src-attr 'none', which blocks inline
                // onerror="..."/onclick="..." attributes. Wire the same behavior up
                // as real event listeners instead, after the HTML has been parsed.
                row.querySelectorAll('img.member-list-photo').forEach(img => {
                    img.addEventListener('error', () => {
                        img.hidden = true;
                        if (img.nextElementSibling) img.nextElementSibling.hidden = false;
                    });
                });

                const viewBtn = row.querySelector('.btn-view-member');
                if (viewBtn) {
                    viewBtn.addEventListener('click', (event) => {
                        event.stopPropagation();
                        MemberListManager.viewMember(member.id);
                    });
                }

                const delBtn = row.querySelector('.btn-delete-member');
                if (delBtn) {
                    // Hide if no permission
                    try {
                        if (typeof RBACManager !== 'undefined' && RBACManager.hasPermission && !RBACManager.hasPermission('member.delete')) {
                            delBtn.hidden = true;
                        }
                    } catch (_) {}
                    delBtn.addEventListener('click', (event) => {
                        event.stopPropagation();
                        MemberListManager.deleteMember(member);
                    });
                }

                tbody.appendChild(row);
            });
    }

    static viewMember(id) {

        window.location.href =
            `member-profile.html?id=${encodeURIComponent(id)}`;
    }

    /**
     * Soft-delete (inactive) a member. Server enforces:
     * - no open/active loan
     * - savings balance must be zero
     */
    static async deleteMember(member) {
        const name = member.personalInfo?.fullName || member.fullName || member.memberCode || member.id;
        const code = member.memberCode || '';
        const msg =
            `সদস্য মুছে ফেলতে চান?\n\n` +
            `নাম: ${name}\nকোড: ${code}\n\n` +
            `শর্ত: সক্রিয় ঋণ থাকলে বা সঞ্চয় ব্যালেন্স থাকলে মুছা যাবে না।\n` +
            `এই কাজটি পূর্বাবস্থায় ফেরানো কঠিন।`;
        if (!window.confirm(msg)) return;

        try {
            await IMP_API.delete(`/members/${encodeURIComponent(member.id)}`);
            if (typeof Utils !== 'undefined' && Utils.showMessage) {
                Utils.showMessage('memberMessage', 'সদস্য সফলভাবে মুছে ফেলা হয়েছে।', 'success');
            } else {
                alert('সদস্য সফলভাবে মুছে ফেলা হয়েছে।');
            }
            // Reload list
            if (typeof this.load === 'function') await this.load();
            else if (typeof this.refresh === 'function') await this.refresh();
            else window.location.reload();
        } catch (err) {
            const errorMsg = err?.message || err?.error || 'সদস্য মুছা যায়নি।';
            if (typeof Utils !== 'undefined' && Utils.showMessage) {
                Utils.showMessage('memberMessage', errorMsg, 'error');
            } else {
                alert(errorMsg);
            }
        }
    }
}