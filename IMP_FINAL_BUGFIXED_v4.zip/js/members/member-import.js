"use strict";

// RFC-4180 compatible CSV parser: supports quoted commas, escaped quotes and newlines.
function parseCSV(text) {
  const rows = [];
  let row = [], cell = '', quoted = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i], next = text[i + 1];
    if (quoted) {
      if (ch === '"' && next === '"') { cell += '"'; i++; }
      else if (ch === '"') quoted = false;
      else cell += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ',') { row.push(cell.trim()); cell = ''; }
    else if (ch === '\n') { row.push(cell.trim()); rows.push(row); row = []; cell = ''; }
    else if (ch !== '\r') cell += ch;
  }
  if (quoted) throw new Error('CSV-তে অসম্পূর্ণ quoted field পাওয়া গেছে।');
  if (cell.length || row.length) { row.push(cell.trim()); rows.push(row); }
  return rows.filter(r => r.some(v => v !== ''));
}

function csvRowsToObjects(text) {
  const rows = parseCSV(text);
  if (rows.length < 2) throw new Error('CSV-তে header এবং অন্তত ১টি data row প্রয়োজন।');
  const headers = rows.shift().map(h => h.replace(/^\uFEFF/, '').trim());
  const required = ['fullName', 'mobile'];
  for (const key of required) if (!headers.includes(key)) throw new Error(`CSV header-এ ${key} প্রয়োজন।`);
  return rows.map((values, index) => {
    const obj = Object.fromEntries(headers.map((h, i) => [h, values[i] ?? '']));
    obj.__row = index + 2;
    return obj;
  });
}

window.IMPParseCSV = { parseCSV, csvRowsToObjects };

document.addEventListener("DOMContentLoaded", async () => {
  const f=document.getElementById("csvFile"), b=document.getElementById("importBtn"), out=document.getElementById("result");
  await SessionManager.requireAuth(); await RBACManager.bootstrap();
  b.onclick=async()=>{
    b.disabled = true;
    try {
      const file=f.files?.[0];
      if(!file){out.textContent="CSV নির্বাচন করুন";return;}
      const records = csvRowsToObjects(await file.text());
      let ok=0, fail=0;
      const errors=[];
      for(const r of records){
        try {
          await IMP_API.post("/members",{
            fullName:r.fullName,
            mobile:r.mobile,
            email:r.email||undefined,
            nid:r.nid||undefined,
            address:r.address||undefined,
            branchId:r.branchId||undefined
          });
          ok++;
        } catch(e) {
          fail++;
          errors.push(`Row ${r.__row}: ${e.message || 'Import failed'}`);
        }
      }
      out.textContent=`সফল: ${ok}, ব্যর্থ: ${fail}` + (errors.length ? `\n\n${errors.slice(0,20).join('\n')}` : '');
    } catch(e) {
      out.textContent = e.message || 'CSV import ব্যর্থ হয়েছে';
    } finally { b.disabled = false; }
  };
});
