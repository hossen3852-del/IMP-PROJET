"use strict";

document.addEventListener("DOMContentLoaded", initializePaymentDetails);

async function initializePaymentDetails() {
    try {
        await SessionManager.requireAuth();
        await RBACManager.bootstrap();
        if (!RBACManager.hasPermission("payment.view")) throw new Error("You do not have permission to view payments.");
        const paymentId = new URLSearchParams(location.search).get("paymentId");
        if (!paymentId) throw new Error("Payment ID is missing.");
        const result = await PaymentAPI.get(paymentId);
        if (!result?.payment) throw new Error("Payment not found.");
        renderPaymentDetails(result.payment);
        renderPaymentAllocations(result.allocations || []);
        const receiptLink = document.getElementById("receiptLink");
        if (receiptLink) {
            receiptLink.href = `payment-receipt.html?paymentId=${encodeURIComponent(paymentId)}`;
            receiptLink.classList.remove("hidden");
        }
    } catch (error) { showPaymentDetailsError(error.message || "Unable to load payment."); }
}

function renderPaymentDetails(payment) {
    setDetailsText("detailPaymentId", payment.id);
    setDetailsText("detailMemberId", payment.memberId);
    setDetailsText("detailLoanId", payment.loanId);
    setDetailsText("detailDate", payment.paymentDate);
    setDetailsText("detailAmount", `৳ ${Number(payment.amount || 0).toLocaleString("en-BD", {minimumFractionDigits:2, maximumFractionDigits:2})}`);
    setDetailsText("detailMethod", getPaymentMethod(payment.paymentMethod)?.name || payment.paymentMethod);
    setDetailsText("detailReference", payment.transactionReference || "-");
    setDetailsText("detailBank", payment.bankName || "-");
    setDetailsText("detailStatus", payment.status);
    setDetailsText("detailCollector", payment.collectorId || "-");
    setDetailsText("detailNotes", payment.notes || "-");
}

function renderPaymentAllocations(allocations) {
    const tbody = document.getElementById("detailsAllocationBody");
    if (!tbody) return;
    tbody.innerHTML = "";
    let total = 0, advance = 0;
    (Array.isArray(allocations) ? allocations : []).forEach(a => {
        const amount = Number(a.amount || 0); total += amount;
        if (a.allocationType === "advance") advance += amount;
        const row = document.createElement("tr");
        row.innerHTML = `<td>${escapeDetailsHTML(a.installmentId || "Advance")}</td><td>${escapeDetailsHTML(a.allocationType)}</td><td>৳ ${amount.toLocaleString("en-BD", {minimumFractionDigits:2, maximumFractionDigits:2})}</td>`;
        tbody.appendChild(row);
    });
    setDetailsText("allocationTotal", `৳ ${total.toLocaleString("en-BD", {minimumFractionDigits:2, maximumFractionDigits:2})}`);
    setDetailsText("advanceTotal", `৳ ${advance.toLocaleString("en-BD", {minimumFractionDigits:2, maximumFractionDigits:2})}`);
}

function setDetailsText(id, value) { const el=document.getElementById(id); if(el) el.textContent=value ?? "-"; }
function escapeDetailsHTML(value) { return String(value ?? "-").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"); }
function showPaymentDetailsError(message) { const box=document.getElementById("detailsError"); if(box){box.textContent=message;box.classList.remove("hidden");} else alert(message); }
