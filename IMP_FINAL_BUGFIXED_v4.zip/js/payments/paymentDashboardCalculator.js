"use strict";

/* ============================================================
   PAYMENT DASHBOARD CALCULATOR
   STEP 5.6
   ============================================================ */


/* ============================================================
   MONEY
   ============================================================ */

function dashboardRoundMoney(
    amount
) {

    return Math.round(
        (
            Number(amount) +
            Number.EPSILON
        ) * 100
    ) / 100;
}


/* ============================================================
   FORMAT DATE
   ============================================================ */

function dashboardDateKey(
    dateValue
) {

    if (!dateValue) {
        return null;
    }

    // Prefer explicit YYYY-MM-DD (DATE or ISO prefix) so host timezone
    // cannot shift the calendar day for Bangladesh collections.
    if (typeof dateValue === "string") {
        const m = dateValue.trim().match(/^(\d{4}-\d{2}-\d{2})/);
        if (m) return m[1];
    }

    if (dateValue instanceof Date && !Number.isNaN(dateValue.getTime())) {
        try {
            const parts = new Intl.DateTimeFormat("en-CA", {
                timeZone: "Asia/Dhaka",
                year: "numeric",
                month: "2-digit",
                day: "2-digit"
            }).formatToParts(dateValue);
            const map = Object.fromEntries(parts.filter(p => p.type !== "literal").map(p => [p.type, p.value]));
            return `${map.year}-${map.month}-${map.day}`;
        } catch (_) { /* fall through */ }
    }

    const date = new Date(dateValue);
    if (Number.isNaN(date.getTime())) {
        return null;
    }

    try {
        const parts = new Intl.DateTimeFormat("en-CA", {
            timeZone: "Asia/Dhaka",
            year: "numeric",
            month: "2-digit",
            day: "2-digit"
        }).formatToParts(date);
        const map = Object.fromEntries(parts.filter(p => p.type !== "literal").map(p => [p.type, p.value]));
        return `${map.year}-${map.month}-${map.day}`;
    } catch (_) {
        return [
            date.getFullYear(),
            String(date.getMonth() + 1).padStart(2, "0"),
            String(date.getDate()).padStart(2, "0")
        ].join("-");
    }
}


/* ============================================================
   DAILY COLLECTION
   ============================================================ */

function calculateDailyCollection(
    payments
) {

    const result = {};

    payments.forEach(
        payment => {

            if (
                payment.status !==
                PAYMENT_STATUS.POSTED
            ) {
                return;
            }

            const date =
                dashboardDateKey(
                    payment.paymentDate
                );

            if (!date) {
                return;
            }

            if (!result[date]) {

                result[date] = {

                    date,

                    count: 0,

                    amount: 0
                };
            }

            result[date].count++;

            result[date].amount +=
                Number(payment.amount) || 0;
        }
    );


    return Object.values(result)
        .map(item => ({

            ...item,

            amount:
                dashboardRoundMoney(
                    item.amount
                )
        }))
        .sort(
            (a, b) =>
                b.date.localeCompare(
                    a.date
                )
        );
}


/* ============================================================
   MONTHLY COLLECTION
   ============================================================ */

function calculateMonthlyCollection(
    payments
) {

    const result = {};

    payments.forEach(
        payment => {

            if (
                payment.status !==
                PAYMENT_STATUS.POSTED
            ) {
                return;
            }

            if (
                !payment.paymentDate
            ) {
                return;
            }

            const date =
                new Date(
                    payment.paymentDate
                );

            if (
                Number.isNaN(
                    date.getTime()
                )
            ) {
                return;
            }

            const key = [

                date.getFullYear(),

                String(
                    date.getMonth() + 1
                ).padStart(2, "0")

            ].join("-");


            if (!result[key]) {

                result[key] = {

                    month: key,

                    count: 0,

                    amount: 0
                };
            }

            result[key].count++;

            result[key].amount +=
                Number(payment.amount) || 0;
        }
    );


    return Object.values(result)
        .map(item => ({

            ...item,

            amount:
                dashboardRoundMoney(
                    item.amount
                )
        }))
        .sort(
            (a, b) =>
                b.month.localeCompare(
                    a.month
                )
        );
}


/* ============================================================
   TODAY
   ============================================================ */

function getDashboardToday() {
    // IMP is Bangladesh-focused — "today" is always Asia/Dhaka calendar day.
    try {
        const parts = new Intl.DateTimeFormat("en-CA", {
            timeZone: "Asia/Dhaka",
            year: "numeric",
            month: "2-digit",
            day: "2-digit"
        }).formatToParts(new Date());
        const map = Object.fromEntries(parts.filter(p => p.type !== "literal").map(p => [p.type, p.value]));
        return `${map.year}-${map.month}-${map.day}`;
    } catch (_) {
        return dashboardDateKey(new Date());
    }
}


/* ============================================================
   TODAY COLLECTION
   ============================================================ */

function calculateTodayCollection(
    payments
) {

    const today =
        getDashboardToday();

    return payments
        .filter(
            payment =>
                payment.status ===
                PAYMENT_STATUS.POSTED &&
                dashboardDateKey(
                    payment.paymentDate
                ) === today
        )
        .reduce(
            (
                total,
                payment
            ) =>
                total +
                (
                    Number(
                        payment.amount
                    ) || 0
                ),
            0
        );
}


/* ============================================================
   DATE RANGE TOTAL
   ============================================================ */

function calculateDateRangeCollection(
    payments,
    fromDate,
    toDate
) {

    return payments
        .filter(
            payment => {

                if (
                    payment.status !==
                    PAYMENT_STATUS.POSTED
                ) {
                    return false;
                }

                const day = dashboardDateKey(payment.paymentDate);

                if (
                    fromDate &&
                    day <
                    fromDate
                ) {
                    return false;
                }

                if (
                    toDate &&
                    day >
                    toDate
                ) {
                    return false;
                }

                return true;
            }
        )
        .reduce(
            (
                total,
                payment
            ) =>
                total +
                (
                    Number(
                        payment.amount
                    ) || 0
                ),
            0
        );
}


/* ============================================================
   METHOD BREAKDOWN
   ============================================================ */

function calculatePaymentMethodBreakdown(
    payments
) {

    const result = {

        cash: 0,

        bkash: 0,

        nagad: 0,

        rocket: 0,

        bank_transfer: 0,

        cheque: 0,

        other: 0
    };


    payments.forEach(
        payment => {

            if (
                payment.status !==
                PAYMENT_STATUS.POSTED
            ) {
                return;
            }

            const method =
                payment.paymentMethod;

            const amount =
                Number(payment.amount) || 0;

            if (
                Object.prototype
                    .hasOwnProperty
                    .call(
                        result,
                        method
                    )
            ) {

                result[method] +=
                    amount;
            }

            else {

                result.other +=
                    amount;
            }
        }
    );


    Object.keys(result)
        .forEach(
            key => {

                result[key] =
                    dashboardRoundMoney(
                        result[key]
                    );
            }
        );


    return result;
}