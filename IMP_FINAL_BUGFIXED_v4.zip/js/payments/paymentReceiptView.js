"use strict";

/*
====================================================
PAYMENT RECEIPT VIEW
====================================================
*/

document.addEventListener(
    "DOMContentLoaded",
    initializeReceiptView
);


async function initializeReceiptView() {
    document.getElementById('printReceiptButton')?.addEventListener('click', () => window.print());
    document.getElementById('backReceiptButton')?.addEventListener('click', () => history.back());
    const params = new URLSearchParams(window.location.search);
    const paymentId = params.get("paymentId");
    if (!paymentId) { showReceiptError("Payment ID is missing."); return; }
    try {
        await SessionManager.requireAuth();
        await RBACManager.bootstrap();
        if (!RBACManager.hasPermission("payment.view")) throw new Error("You do not have permission to view receipts.");
        const result = await PaymentAPI.receipt(paymentId);
        if (!result?.receipt) { showReceiptError("Receipt not found."); return; }
        renderReceiptView(result.receipt);
    } catch (error) { showReceiptError(error.message); }
}

function showReceiptError(message) {
    const el = document.getElementById("receiptError");
    if (el) { el.textContent = message; el.classList.remove("hidden"); }
    else alert(message);
}


function renderReceiptView(
    receipt
) {

    setReceiptText(
        "receiptNumber",
        receipt.receiptNumber
    );

    setReceiptText(
        "receiptStatus",
        receipt.status
    );

    setReceiptText(
        "receiptDate",
        receipt.paymentDate
    );

    setReceiptText(
        "receiptPaymentId",
        receipt.paymentId
    );

    setReceiptText(
        "receiptMemberId",
        receipt.memberId
    );

    setReceiptText(
        "receiptLoanId",
        receipt.loanId
    );

    setReceiptText(
        "receiptAmount",
        `৳ ${Number(
            receipt.amount
        ).toLocaleString(
            "en-BD",
            {
                minimumFractionDigits: 2
            }
        )}`
    );

    setReceiptText(
        "receiptMethod",
        getPaymentMethod(
            receipt.paymentMethod
        )?.name ||
        receipt.paymentMethod
    );

    setReceiptText(
        "receiptReference",
        receipt.transactionReference ||
        "-"
    );

    setReceiptText(
        "receiptBank",
        receipt.bankName ||
        "-"
    );

    setReceiptText(
        "receiptCollector",
        receipt.collectorId ||
        "-"
    );

    setReceiptText(
        "receiptNotes",
        receipt.notes ||
        "-"
    );


    renderReceiptAllocation(
        receipt
    );
}


function renderReceiptAllocation(
    receipt
) {

    const tbody =
        document.getElementById(
            "receiptAllocationBody"
        );


    if (!tbody) {
        return;
    }


    const allocations = Array.isArray(receipt.allocations) ? receipt.allocations : [];


    tbody.innerHTML =
        "";


    let total = 0;


    allocations.forEach(
        allocation => {

            const amount =
                Number(
                    allocation.amount
                ) || 0;


            total +=
                amount;


            const row =
                document.createElement(
                    "tr"
                );


            row.innerHTML = `

                <td>
                    ${escapeReceiptHTML(
                        allocation.installmentId ||
                        "Advance"
                    )}
                </td>

                <td>
                    ${escapeReceiptHTML(
                        allocation.allocationType
                    )}
                </td>

                <td>
                    ৳ ${amount.toLocaleString(
                        "en-BD",
                        {
                            minimumFractionDigits: 2
                        }
                    )}
                </td>

            `;


            tbody.appendChild(
                row
            );
        }
    );


    setReceiptText(
        "receiptAllocationTotal",
        `৳ ${total.toLocaleString(
            "en-BD",
            {
                minimumFractionDigits: 2
            }
        )}`
    );
}


function printReceipt() {

    window.print();
}


function setReceiptText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );

    if (element) {

        element.textContent =
            value ?? "-";
    }
}


function escapeReceiptHTML(
    value
) {

    return String(
        value ?? "-"
    )
    .replace(
        /&/g,
        "&amp;"
    )
    .replace(
        /</g,
        "&lt;"
    )
    .replace(
        />/g,
        "&gt;"
    )
    .replace(
        /"/g,
        "&quot;"
    )
    .replace(
        /'/g,
        "&#039;"
    );
}