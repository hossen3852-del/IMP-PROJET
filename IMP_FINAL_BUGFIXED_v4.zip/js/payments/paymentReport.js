"use strict";

/* ====================================================
   PAYMENT REPORT UI
   STEP 5.9
==================================================== */

document.addEventListener(
    "DOMContentLoaded",
    initializePaymentReports
);


let currentPaymentReport = [];


/* ====================================================
   INITIALIZE
==================================================== */

function initializePaymentReports() {

    const methodSelect =
        document.getElementById(
            "reportPaymentMethod"
        );


    if (
        typeof populatePaymentMethodSelect ===
        "function"
    ) {

        populatePaymentMethodSelect(
            methodSelect
        );
    }


    document
        .getElementById(
            "paymentReportFilterForm"
        )
        ?.addEventListener(
            "submit",
            event => {

                event.preventDefault();

                loadPaymentReports();
            }
        );


    document
        .getElementById(
            "clearPaymentReport"
        )
        ?.addEventListener(
            "click",
            () => {

                document
                    .getElementById(
                        "paymentReportFilterForm"
                    )
                    ?.reset();

                loadPaymentReports();
            }
        );


    document
        .getElementById(
            "exportPaymentCSV"
        )
        ?.addEventListener(
            "click",
            () => {

                exportPaymentRecords(
                    currentPaymentReport
                );
            }
        );


    document
        .getElementById(
            "printPaymentReport"
        )
        ?.addEventListener(
            "click",
            printPaymentReport
        );


    document
        .getElementById(
            "exportDailyCSV"
        )
        ?.addEventListener(
            "click",
            () => {

                exportDailyPaymentReport(
                    generateDailyPaymentReport(
                        currentPaymentReport
                    )
                );
            }
        );


    document
        .getElementById(
            "exportMonthlyCSV"
        )
        ?.addEventListener(
            "click",
            () => {

                exportMonthlyPaymentReport(
                    generateMonthlyPaymentReport(
                        currentPaymentReport
                    )
                );
            }
        );


    document
        .getElementById(
            "exportCollectorCSV"
        )
        ?.addEventListener(
            "click",
            () => {

                exportCollectorPaymentReport(
                    generateCollectorPaymentReport(
                        currentPaymentReport
                    )
                );
            }
        );


    document
        .getElementById(
            "exportMethodCSV"
        )
        ?.addEventListener(
            "click",
            () => {

                exportPaymentMethodReport(
                    generatePaymentMethodReport(
                        currentPaymentReport
                    )
                );
            }
        );


    loadPaymentReports();
}


/* ====================================================
   LOAD
==================================================== */

/**
 * 11.P.17 — server-authoritative: getPaymentReportData() used to read a
 * `localStorage` payments cache the real payment flow never writes to.
 * GET /payments/collection-report returns the real, filtered payment list;
 * the existing generate*Report() functions below still do their own
 * (pure, client-side) aggregation over that list exactly as before.
 */
async function loadPaymentReports() {

    const filters = {

        fromDate:
            document.getElementById(
                "reportFromDate"
            )?.value,

        toDate:
            document.getElementById(
                "reportToDate"
            )?.value,

        memberId:
            document.getElementById(
                "reportMemberId"
            )?.value.trim(),

        loanId:
            document.getElementById(
                "reportLoanId"
            )?.value.trim(),

        collectorId:
            document.getElementById(
                "reportCollectorId"
            )?.value.trim(),

        paymentMethod:
            document.getElementById(
                "reportPaymentMethod"
            )?.value,

        status:
            document.getElementById(
                "reportStatus"
            )?.value
    };


    let apiResult;
    try {
        apiResult = await PaymentAPI.collectionReport(filters);
    } catch (e) {
        const el = document.getElementById("reportSummary") || document.getElementById("paymentReportBody");
        if (el) el.textContent = e.message || "রিপোর্ট লোড করা যায়নি।";
        return;
    }
    currentPaymentReport = (apiResult.payments || []).map(p => ({
        ...p,
        paymentDate: String(p.paymentDate || "").slice(0, 10)
    }));


    const summary =
        generatePaymentReportSummary(
            currentPaymentReport
        );


    renderPaymentReportSummary(
        summary
    );


    renderDailyReport(
        generateDailyPaymentReport(
            currentPaymentReport
        )
    );


    renderMonthlyReport(
        generateMonthlyPaymentReport(
            currentPaymentReport
        )
    );


    renderCollectorReport(
        generateCollectorPaymentReport(
            currentPaymentReport
        )
    );


    renderMethodReport(
        generatePaymentMethodReport(
            currentPaymentReport
        )
    );


    renderPaymentReportTable(
        currentPaymentReport
    );
}


/* ====================================================
   SUMMARY
==================================================== */

function renderPaymentReportSummary(
    summary
) {

    setReportText(
        "reportPaymentCount",
        summary.paymentCount
    );


    setReportText(
        "reportTotalAmount",
        money(
            summary.totalAmount
        )
    );


    setReportText(
        "reportPostedAmount",
        money(
            summary.postedAmount
        )
    );


    setReportText(
        "reportCancelledAmount",
        money(
            summary.cancelledAmount
        )
    );


    setReportText(
        "reportCashAmount",
        money(
            summary.cashAmount
        )
    );


    setReportText(
        "reportDigitalAmount",
        money(
            summary.digitalAmount
        )
    );
}


/* ====================================================
   PAYMENT TABLE
==================================================== */

function renderPaymentReportTable(
    payments
) {

    const tbody =
        document.getElementById(
            "paymentReportBody"
        );


    if (!tbody) {
        return;
    }


    tbody.innerHTML = "";


    if (!payments.length) {

        tbody.innerHTML = `
            <tr>
                <td colspan="9">
                    No payment records found.
                </td>
            </tr>
        `;

        return;
    }


    payments.forEach(
        payment => {

            const row =
                document.createElement(
                    "tr"
                );


            row.innerHTML = `

                <td>
                    ${escapeReportHTML(
                        payment.id
                    )}
                </td>

                <td>
                    ${escapeReportHTML(
                        payment.memberId
                    )}
                </td>

                <td>
                    ${escapeReportHTML(
                        payment.loanId
                    )}
                </td>

                <td>
                    ${escapeReportHTML(
                        payment.paymentDate
                    )}
                </td>

                <td>
                    ৳ ${money(
                        payment.amount
                    )}
                </td>

                <td>
                    ${escapeReportHTML(
                        getPaymentMethod(
                            payment.paymentMethod
                        )?.name ||
                        payment.paymentMethod
                    )}
                </td>

                <td>
                    ${escapeReportHTML(
                        payment.collectorId ||
                        "-"
                    )}
                </td>

                <td>
                    ${escapeReportHTML(
                        payment.status
                    )}
                </td>

                <td>
                    <a href="payment-details.html?paymentId=${encodeURIComponent(
                        payment.id
                    )}">
                        View
                    </a>
                </td>

            `;


            tbody.appendChild(
                row
            );
        }
    );
}


/* ====================================================
   DAILY TABLE
==================================================== */

function renderDailyReport(
    report
) {

    const tbody =
        document.getElementById(
            "dailyReportBody"
        );


    if (!tbody) {
        return;
    }


    tbody.innerHTML = "";


    report.forEach(
        item => {

            const row =
                document.createElement(
                    "tr"
                );


            row.innerHTML = `

                <td>
                    ${escapeReportHTML(
                        item.date
                    )}
                </td>

                <td>
                    ${item.count}
                </td>

                <td>
                    ৳ ${money(
                        item.amount
                    )}
                </td>

                <td>
                    ৳ ${money(
                        item.postedAmount
                    )}
                </td>

                <td>
                    ৳ ${money(
                        item.cancelledAmount
                    )}
                </td>

            `;


            tbody.appendChild(
                row
            );
        }
    );
}


/* ====================================================
   MONTHLY TABLE
==================================================== */

function renderMonthlyReport(
    report
) {

    const tbody =
        document.getElementById(
            "monthlyReportBody"
        );


    if (!tbody) {
        return;
    }


    tbody.innerHTML = "";


    report.forEach(
        item => {

            const row =
                document.createElement(
                    "tr"
                );


            row.innerHTML = `

                <td>
                    ${escapeReportHTML(
                        item.month
                    )}
                </td>

                <td>
                    ${item.count}
                </td>

                <td>
                    ৳ ${money(
                        item.amount
                    )}
                </td>

                <td>
                    ৳ ${money(
                        item.postedAmount
                    )}
                </td>

                <td>
                    ৳ ${money(
                        item.cancelledAmount
                    )}
                </td>

            `;


            tbody.appendChild(
                row
            );
        }
    );
}


/* ====================================================
   COLLECTOR TABLE
==================================================== */

function renderCollectorReport(
    report
) {

    const tbody =
        document.getElementById(
            "collectorReportBody"
        );


    if (!tbody) {
        return;
    }


    tbody.innerHTML = "";


    report.forEach(
        item => {

            const row =
                document.createElement(
                    "tr"
                );


            row.innerHTML = `

                <td>
                    ${escapeReportHTML(
                        item.collectorId
                    )}
                </td>

                <td>
                    ${item.count}
                </td>

                <td>
                    ৳ ${money(
                        item.amount
                    )}
                </td>

                <td>
                    ৳ ${money(
                        item.postedAmount
                    )}
                </td>

                <td>
                    ৳ ${money(
                        item.cancelledAmount
                    )}
                </td>

            `;


            tbody.appendChild(
                row
            );
        }
    );
}


/* ====================================================
   METHOD TABLE
==================================================== */

function renderMethodReport(
    report
) {

    const tbody =
        document.getElementById(
            "methodReportBody"
        );


    if (!tbody) {
        return;
    }


    tbody.innerHTML = "";


    report.forEach(
        item => {

            const method =
                getPaymentMethod(
                    item.paymentMethod
                );


            const row =
                document.createElement(
                    "tr"
                );


            row.innerHTML = `

                <td>
                    ${escapeReportHTML(
                        method?.name ||
                        item.paymentMethod
                    )}
                </td>

                <td>
                    ${item.count}
                </td>

                <td>
                    ৳ ${money(
                        item.amount
                    )}
                </td>

                <td>
                    ৳ ${money(
                        item.postedAmount
                    )}
                </td>

                <td>
                    ৳ ${money(
                        item.cancelledAmount
                    )}
                </td>

            `;


            tbody.appendChild(
                row
            );
        }
    );
}


/* ====================================================
   HELPERS
==================================================== */

function money(
    amount
) {

    return Number(
        amount || 0
    ).toLocaleString(
        "en-BD",
        {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }
    );
}


function setReportText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.textContent =
            value;
    }
}


function escapeReportHTML(
    value
) {

    return String(
        value ?? "-"
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );
}