'use strict';

document.addEventListener('DOMContentLoaded', async () => {
  const params=new URLSearchParams(location.search);
  const paymentId=params.get('paymentId');
  if(!paymentId){ showAuditError('Payment ID is missing.'); return; }
  try {
    await SessionManager.requireAuth();
    const result=await PaymentAPI.get(paymentId);
    const payment=result?.payment;
    if(!payment){showAuditError('Payment not found.');return;}
    renderAuditPaymentSummary(payment);
    await renderPaymentAuditHistory(payment.id);
    initializeAuditActions(payment);
  } catch(e){showAuditError(e.message||'Unable to load payment audit.');}
});

function renderAuditPaymentSummary(payment){
  setAuditText('auditPaymentId',payment.id);setAuditText('auditMemberId',payment.memberId);setAuditText('auditLoanId',payment.loanId);
  setAuditText('auditAmount',`৳ ${Number(payment.amount||0).toLocaleString('en-BD',{minimumFractionDigits:2})}`);setAuditText('auditStatus',payment.status);setAuditText('auditDate',payment.paymentDate);
}
async function renderPaymentAuditHistory(paymentId){
  const tbody=document.getElementById('paymentAuditBody'); if(!tbody)return;
  const result=await PaymentAuditAPI.list(paymentId); const audits=result?.audits||[]; tbody.innerHTML='';
  if(!audits.length){tbody.innerHTML='<tr><td colspan="8">No audit records found.</td></tr>';return;}
  audits.forEach(a=>{const row=document.createElement('tr');row.innerHTML=`<td>${esc(a.id)}</td><td>${esc(a.action)}</td><td>${esc(a.previousStatus||'-')}</td><td>${esc(a.newStatus||'-')}</td><td>৳ ${Number(a.amount||0).toLocaleString('en-BD',{minimumFractionDigits:2})}</td><td>${esc(a.reason||'-')}</td><td>${esc(a.performedBy||'-')}</td><td>${esc(new Date(a.performedAt).toLocaleString('en-BD'))}</td>`;tbody.appendChild(row);});
}
function initializeAuditActions(payment){
  const cancel=document.getElementById('cancelPaymentButton'), reverse=document.getElementById('reversePaymentButton');
  if(payment.status!=='posted'){cancel?.setAttribute('disabled','disabled');reverse?.setAttribute('disabled','disabled');return;}
  cancel?.addEventListener('click',async()=>{const reason=prompt('Enter cancellation reason:');if(reason===null||!reason.trim())return alert('Cancellation reason is required.');try{await PaymentAuditAPI.cancel(payment.id,reason.trim());location.reload();}catch(e){alert(e.message);}});
  reverse?.addEventListener('click',async()=>{const reason=prompt('Enter reversal reason:');if(reason===null||!reason.trim())return alert('Reversal reason is required.');try{await PaymentAuditAPI.reverse(payment.id,reason.trim());location.reload();}catch(e){alert(e.message);}});
}
function setAuditText(id,value){const el=document.getElementById(id);if(el)el.textContent=value??'-';}
function esc(v){return String(v??'-').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');}
function showAuditError(message){const box=document.getElementById('auditError');if(box){box.textContent=message;box.classList.remove('hidden');}}
