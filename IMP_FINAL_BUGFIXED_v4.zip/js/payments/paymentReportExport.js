"use strict";

/* ====================================================
   PAYMENT REPORT EXPORT
   STEP 5.9
==================================================== */


/* ====================================================
   CSV ESCAPE
==================================================== */

function escapeCSVValue(value) {

    let text =
        String(
            value ?? ""
        );

    // Formula-injection guard: Excel/Sheets treats a cell starting with
    // =, +, -, or @ as a formula. Member names, notes and references all
    // come from user input with no such restriction, so a value like
    // `=HYPERLINK(...)` would otherwise reach the exported file verbatim
    // and execute when the CSV is opened. Prefixing with a single quote
    // keeps the visible text the same but forces spreadsheet apps to
    // treat it as plain text.
    if (/^[=+\-@]/.test(text)) {
        text = `'${text}`;
    }


    if (
        text.includes(",") ||
        text.includes('"') ||
        text.includes("\n")
    ) {

        return `"${text.replace(
            /"/g,
            '""'
        )}"`;
    }


    return text;
}


/* ====================================================
   DOWNLOAD CSV
==================================================== */

function downloadPaymentCSV(
    filename,
    rows
) {

    if (
        !Array.isArray(rows) ||
        rows.length === 0
    ) {

        alert(
            "No data available for export."
        );

        return;
    }


    const headers =
        Object.keys(
            rows[0]
        );


    const csvRows = [];


    csvRows.push(
        headers
            .map(
                escapeCSVValue
            )
            .join(",")
    );


    rows.forEach(
        row => {

            csvRows.push(
                headers
                    .map(
                        header =>
                            escapeCSVValue(
                                row[header]
                            )
                    )
                    .join(",")
            );
        }
    );


    const csvContent =
        "\uFEFF" +
        csvRows.join("\n");


    const blob =
        new Blob(
            [csvContent],
            {
                type:
                    "text/csv;charset=utf-8;"
            }
        );


    const url =
        URL.createObjectURL(
            blob
        );


    const link =
        document.createElement(
            "a"
        );


    link.href = url;

    link.download =
        filename;


    document.body.appendChild(
        link
    );


    link.click();


    link.remove();


    URL.revokeObjectURL(
        url
    );
}


/* ====================================================
   EXPORT PAYMENT RECORDS
==================================================== */

function exportPaymentRecords(
    payments
) {

    const rows =
        payments.map(
            payment => ({

                Payment_ID:
                    payment.id,

                Member_ID:
                    payment.memberId,

                Loan_ID:
                    payment.loanId,

                Payment_Date:
                    payment.paymentDate,

                Amount:
                    payment.amount,

                Payment_Method:
                    payment.paymentMethod,

                Reference:
                    payment.transactionReference ||
                    "",

                Bank:
                    payment.bankName ||
                    "",

                Collector:
                    payment.collectorId ||
                    "",

                Status:
                    payment.status
            })
        );


    downloadPaymentCSV(
        "payment-report.csv",
        rows
    );
}


/* ====================================================
   EXPORT DAILY
==================================================== */

function exportDailyPaymentReport(
    report
) {

    downloadPaymentCSV(
        "daily-payment-report.csv",
        report
    );
}


/* ====================================================
   EXPORT MONTHLY
==================================================== */

function exportMonthlyPaymentReport(
    report
) {

    downloadPaymentCSV(
        "monthly-payment-report.csv",
        report
    );
}


/* ====================================================
   EXPORT COLLECTOR
==================================================== */

function exportCollectorPaymentReport(
    report
) {

    downloadPaymentCSV(
        "collector-payment-report.csv",
        report
    );
}


/* ====================================================
   EXPORT METHOD
==================================================== */

function exportPaymentMethodReport(
    report
) {

    downloadPaymentCSV(
        "payment-method-report.csv",
        report
    );
}


/* ====================================================
   PRINT
==================================================== */

function printPaymentReport() {

    window.print();
}