"use strict";

/* ====================================================
   PAYMENT REPORT SERVICE
   STEP 5.9
==================================================== */

function getPaymentReportData(filters = {}) {

    let payments = getPayments();

    /* ==================================================
       DATE FILTER
    ================================================== */

    if (filters.fromDate) {

        payments = payments.filter(
            payment =>
                payment.paymentDate >=
                filters.fromDate
        );
    }

    if (filters.toDate) {

        payments = payments.filter(
            payment =>
                payment.paymentDate <=
                filters.toDate
        );
    }


    /* ==================================================
       MEMBER FILTER
    ================================================== */

    if (filters.memberId) {

        payments = payments.filter(
            payment =>
                String(payment.memberId) ===
                String(filters.memberId)
        );
    }


    /* ==================================================
       LOAN FILTER
    ================================================== */

    if (filters.loanId) {

        payments = payments.filter(
            payment =>
                String(payment.loanId) ===
                String(filters.loanId)
        );
    }


    /* ==================================================
       COLLECTOR FILTER
    ================================================== */

    if (filters.collectorId) {

        payments = payments.filter(
            payment =>
                String(payment.collectorId || "") ===
                String(filters.collectorId)
        );
    }


    /* ==================================================
       PAYMENT METHOD
    ================================================== */

    if (filters.paymentMethod) {

        payments = payments.filter(
            payment =>
                payment.paymentMethod ===
                filters.paymentMethod
        );
    }


    /* ==================================================
       STATUS
    ================================================== */

    if (filters.status) {

        payments = payments.filter(
            payment =>
                payment.status ===
                filters.status
        );
    }


    /* ==================================================
       SORT
    ================================================== */

    payments.sort(
        (a, b) => {

            const dateDifference =
                new Date(b.paymentDate) -
                new Date(a.paymentDate);

            if (dateDifference !== 0) {
                return dateDifference;
            }

            return String(b.id)
                .localeCompare(
                    String(a.id)
                );
        }
    );


    return payments;
}


/* ====================================================
   BASIC SUMMARY
==================================================== */

function generatePaymentReportSummary(
    payments
) {

    const summary = {

        paymentCount: 0,

        postedCount: 0,

        cancelledCount: 0,

        reversedCount: 0,

        totalAmount: 0,

        postedAmount: 0,

        cancelledAmount: 0,

        reversedAmount: 0,

        cashAmount: 0,

        digitalAmount: 0
    };


    summary.paymentCount =
        payments.length;


    payments.forEach(
        payment => {

            const amount =
                Number(payment.amount) || 0;


            summary.totalAmount +=
                amount;


            if (
                payment.status ===
                PAYMENT_STATUS.POSTED
            ) {

                summary.postedCount++;

                summary.postedAmount +=
                    amount;

            } else if (
                payment.status ===
                PAYMENT_STATUS.CANCELLED
            ) {

                summary.cancelledCount++;

                summary.cancelledAmount +=
                    amount;

            } else if (
                payment.status ===
                PAYMENT_STATUS.REVERSED
            ) {

                summary.reversedCount++;

                summary.reversedAmount +=
                    amount;
            }


            if (
                payment.paymentMethod ===
                "cash"
            ) {

                summary.cashAmount +=
                    amount;

            } else {

                summary.digitalAmount +=
                    amount;
            }
        }
    );


    Object.keys(summary).forEach(
        key => {

            if (
                key.endsWith(
                    "Amount"
                )
            ) {

                summary[key] =
                    roundMoney(
                        summary[key]
                    );
            }
        }
    );


    return summary;
}


/* ====================================================
   DAILY REPORT
==================================================== */

function generateDailyPaymentReport(
    payments
) {

    const report = {};


    payments.forEach(
        payment => {

            const date =
                payment.paymentDate ||
                "Unknown";


            if (!report[date]) {

                report[date] = {

                    date: date,

                    count: 0,

                    amount: 0,

                    postedAmount: 0,

                    cancelledAmount: 0
                };
            }


            const amount =
                Number(payment.amount) || 0;


            report[date].count++;

            report[date].amount +=
                amount;


            if (
                payment.status ===
                PAYMENT_STATUS.POSTED
            ) {

                report[date].postedAmount +=
                    amount;
            }


            if (
                payment.status ===
                PAYMENT_STATUS.CANCELLED
            ) {

                report[date].cancelledAmount +=
                    amount;
            }
        }
    );


    return Object.values(report)
        .map(item => ({

            ...item,

            amount:
                roundMoney(
                    item.amount
                ),

            postedAmount:
                roundMoney(
                    item.postedAmount
                ),

            cancelledAmount:
                roundMoney(
                    item.cancelledAmount
                )
        }))
        .sort(
            (a, b) =>
                new Date(b.date) -
                new Date(a.date)
        );
}


/* ====================================================
   MONTHLY REPORT
==================================================== */

function generateMonthlyPaymentReport(
    payments
) {

    const report = {};


    payments.forEach(
        payment => {

            const date =
                payment.paymentDate;

            if (!date) {
                return;
            }


            const month =
                date.substring(
                    0,
                    7
                );


            if (!report[month]) {

                report[month] = {

                    month: month,

                    count: 0,

                    amount: 0,

                    postedAmount: 0,

                    cancelledAmount: 0
                };
            }


            const amount =
                Number(payment.amount) || 0;


            report[month].count++;

            report[month].amount +=
                amount;


            if (
                payment.status ===
                PAYMENT_STATUS.POSTED
            ) {

                report[month].postedAmount +=
                    amount;
            }


            if (
                payment.status ===
                PAYMENT_STATUS.CANCELLED
            ) {

                report[month].cancelledAmount +=
                    amount;
            }
        }
    );


    return Object.values(report)
        .map(item => ({

            ...item,

            amount:
                roundMoney(
                    item.amount
                ),

            postedAmount:
                roundMoney(
                    item.postedAmount
                ),

            cancelledAmount:
                roundMoney(
                    item.cancelledAmount
                )
        }))
        .sort(
            (a, b) =>
                b.month.localeCompare(
                    a.month
                )
        );
}


/* ====================================================
   COLLECTOR REPORT
==================================================== */

function generateCollectorPaymentReport(
    payments
) {

    const report = {};


    payments.forEach(
        payment => {

            const collector =
                payment.collectorId ||
                "Unassigned";


            if (!report[collector]) {

                report[collector] = {

                    collectorId:
                        collector,

                    count: 0,

                    amount: 0,

                    postedAmount: 0,

                    cancelledAmount: 0
                };
            }


            const amount =
                Number(payment.amount) || 0;


            report[collector].count++;

            report[collector].amount +=
                amount;


            if (
                payment.status ===
                PAYMENT_STATUS.POSTED
            ) {

                report[collector].postedAmount +=
                    amount;
            }


            if (
                payment.status ===
                PAYMENT_STATUS.CANCELLED
            ) {

                report[collector].cancelledAmount +=
                    amount;
            }
        }
    );


    return Object.values(report)
        .map(item => ({

            ...item,

            amount:
                roundMoney(
                    item.amount
                ),

            postedAmount:
                roundMoney(
                    item.postedAmount
                ),

            cancelledAmount:
                roundMoney(
                    item.cancelledAmount
                )
        }))
        .sort(
            (a, b) =>
                b.amount -
                a.amount
        );
}


/* ====================================================
   METHOD REPORT
==================================================== */

function generatePaymentMethodReport(
    payments
) {

    const report = {};


    payments.forEach(
        payment => {

            const method =
                payment.paymentMethod ||
                "unknown";


            if (!report[method]) {

                report[method] = {

                    paymentMethod:
                        method,

                    count: 0,

                    amount: 0,

                    postedAmount: 0,

                    cancelledAmount: 0
                };
            }


            const amount =
                Number(payment.amount) || 0;


            report[method].count++;

            report[method].amount +=
                amount;


            if (
                payment.status ===
                PAYMENT_STATUS.POSTED
            ) {

                report[method].postedAmount +=
                    amount;
            }


            if (
                payment.status ===
                PAYMENT_STATUS.CANCELLED
            ) {

                report[method].cancelledAmount +=
                    amount;
            }
        }
    );


    return Object.values(report)
        .map(item => ({

            ...item,

            amount:
                roundMoney(
                    item.amount
                ),

            postedAmount:
                roundMoney(
                    item.postedAmount
                ),

            cancelledAmount:
                roundMoney(
                    item.cancelledAmount
                )
        }))
        .sort(
            (a, b) =>
                b.amount -
                a.amount
        );
}


/* ====================================================
   MEMBER REPORT
==================================================== */

function generateMemberPaymentReport(
    payments
) {

    const report = {};


    payments.forEach(
        payment => {

            const member =
                payment.memberId ||
                "Unknown";


            if (!report[member]) {

                report[member] = {

                    memberId:
                        member,

                    count: 0,

                    amount: 0,

                    postedAmount: 0
                };
            }


            const amount =
                Number(payment.amount) || 0;


            report[member].count++;

            report[member].amount +=
                amount;


            if (
                payment.status ===
                PAYMENT_STATUS.POSTED
            ) {

                report[member].postedAmount +=
                    amount;
            }
        }
    );


    return Object.values(report)
        .map(item => ({

            ...item,

            amount:
                roundMoney(
                    item.amount
                ),

            postedAmount:
                roundMoney(
                    item.postedAmount
                )
        }))
        .sort(
            (a, b) =>
                b.amount -
                a.amount
        );
}