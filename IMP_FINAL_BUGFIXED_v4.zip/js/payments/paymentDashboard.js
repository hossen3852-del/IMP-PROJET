"use strict";

/* ============================================================
   PAYMENT COLLECTION DASHBOARD UI
   STEP 5.6
   ============================================================ */

document.addEventListener(
    "DOMContentLoaded",
    initializePaymentDashboard
);


/* ============================================================
   INITIALIZE
   ============================================================ */

function initializePaymentDashboard() {

    populatePaymentMethodSelect(
        document.getElementById(
            "dashboardPaymentMethod"
        )
    );


    const form =
        document.getElementById(
            "dashboardFilterForm"
        );


    form?.addEventListener(
        "submit",
        event => {

            event.preventDefault();

            loadPaymentDashboard();
        }
    );


    document
        .getElementById(
            "dashboardClearFilters"
        )
        ?.addEventListener(
            "click",
            () => {

                form?.reset();

                loadPaymentDashboard();
            }
        );


    document
        .getElementById(
            "exportCollectionCSV"
        )
        ?.addEventListener(
            "click",
            exportDashboardCSV
        );


    setDashboardDefaultDates();

    document.getElementById("toggleArrearsList")?.addEventListener("click", () => {
        const wrap = document.getElementById("arrearsListWrap");
        const btn = document.getElementById("toggleArrearsList");
        if (!wrap || !btn) return;
        const open = wrap.hidden;
        wrap.hidden = !open;
        btn.setAttribute("aria-expanded", open ? "true" : "false");
        btn.textContent = open ? "বকেয়া সদস্য তালিকা লুকান" : "বকেয়া সদস্য তালিকা দেখুন";
    });

    document.getElementById("dashboardSearch")?.addEventListener("input", () => {
        applyDashboardSearchFilter();
    });

    loadPaymentDashboard();
}


/* ============================================================
   DEFAULT DATES
   ============================================================ */

function setDashboardDefaultDates() {

    const today =
        dashboardDateKey(
            new Date()
        );


    const from =
        document.getElementById(
            "dashboardFromDate"
        );

    const to =
        document.getElementById(
            "dashboardToDate"
        );


    if (from) {

        const date =
            new Date();

        date.setDate(
            date.getDate() - 30
        );

        from.value =
            dashboardDateKey(
                date
            );
    }


    if (to) {

        to.value =
            today;
    }
}


/* ============================================================
   LOAD DASHBOARD
   ============================================================ */

/**
 * 11.P.17 — server-authoritative: this used to call buildPaymentCollectionReport(),
 * which read from a `localStorage` payments cache the real payment flow never
 * writes to (payments are created server-side, in Postgres). GET
 * /payments/collection-report returns the same shape these render functions
 * already expect, computed live from the real ledger.
 */
let lastDashboardReport = null;

async function loadPaymentDashboard() {

    const filters =
        getDashboardFilters();

    let report;
    try {
        report = await PaymentAPI.collectionReport(filters);
    } catch (e) {
        setDashboardText("dashboardPaymentCount", 0);
        ["paymentMethodBody","collectorBody","memberCollectionBody","loanCollectionBody","dailyCollectionBody","monthlyCollectionBody"].forEach(id => {
            const tbody = document.getElementById(id);
            if (tbody) tbody.innerHTML = `<tr><td colspan="6" class="empty-cell">${escapeDashboardHTML(e.message || "ড্যাশবোর্ড লোড করা যায়নি।")}</td></tr>`;
        });
        return;
    }

    lastDashboardReport = report;

    // Client fallback if server daily/monthly empty but payments exist
    let daily = Array.isArray(report.daily) ? report.daily : [];
    let monthly = Array.isArray(report.monthly) ? report.monthly : [];
    const payments = Array.isArray(report.payments) ? report.payments : [];
    if ((!daily.length || !monthly.length) && payments.length) {
        const built = buildDailyMonthlyFromPayments(payments);
        if (!daily.length) daily = built.daily;
        if (!monthly.length) monthly = built.monthly;
    }

    renderDashboardSummary(
        report
    );

    renderPaymentMethodTable(
        report.byMethod || []
    );

    renderCollectorTable(
        report.byCollector || []
    );

    renderMemberTable(
        report.byMember || []
    );

    renderLoanTable(
        report.byLoan || []
    );

    renderDailyTable(
        daily
    );

    renderMonthlyTable(
        monthly
    );

    updateDailyPaidBakiSummary(report);
    applyDashboardSearchFilter();
}

/** Client-side daily/monthly rollup from payment list (posted only). */
function buildDailyMonthlyFromPayments(payments) {
    const byDay = {};
    const byMonth = {};
    payments.forEach(p => {
        if (String(p.status || "posted").toLowerCase() !== "posted") return;
        const raw = p.paymentDate || p.payment_date;
        const day = typeof dashboardDateKey === "function" ? dashboardDateKey(raw) : String(raw || "").slice(0, 10);
        if (!day) return;
        const amt = Number(p.amount) || 0;
        if (!byDay[day]) byDay[day] = { date: day, count: 0, amount: 0, dailyCollectionCount: 0, dailyCollectionAmount: 0 };
        byDay[day].count += 1;
        byDay[day].amount += amt;
        if (p.source === "daily_collection" || p.from_daily_collection) {
            byDay[day].dailyCollectionCount += 1;
            byDay[day].dailyCollectionAmount += amt;
        }
        const month = day.slice(0, 7);
        if (!byMonth[month]) byMonth[month] = { month, count: 0, amount: 0 };
        byMonth[month].count += 1;
        byMonth[month].amount += amt;
    });
    return {
        daily: Object.values(byDay).sort((a, b) => String(b.date).localeCompare(String(a.date))),
        monthly: Object.values(byMonth).sort((a, b) => String(b.month).localeCompare(String(a.month)))
    };
}


/* ============================================================
   FILTERS
   ============================================================ */

function getDashboardFilters() {
    return {
        fromDate: document.getElementById("dashboardFromDate")?.value,
        toDate: document.getElementById("dashboardToDate")?.value
    };
}

function getDashboardSearchQuery() {
    return (document.getElementById("dashboardSearch")?.value || "").trim().toLowerCase();
}

/** Apply free-text search across member/loan tables after render. */
function applyDashboardSearchFilter() {
    const q = getDashboardSearchQuery();
    ["memberCollectionBody", "loanCollectionBody", "arrearsMembersBody"].forEach(id => {
        const tbody = document.getElementById(id);
        if (!tbody) return;
        tbody.querySelectorAll("tr").forEach(tr => {
            if (tr.querySelector(".empty-cell")) return;
            const text = (tr.textContent || "").toLowerCase();
            tr.style.display = (!q || text.includes(q)) ? "" : "none";
        });
    });
}


/* ============================================================
   SUMMARY
   ============================================================ */

function renderDashboardSummary(
    report
) {

    const summary =
        report.summary;


    setDashboardText(
        "dashboardPaymentCount",
        summary.paymentCount
    );


    setDashboardText(
        "dashboardPostedAmount",
        formatDashboardMoney(
            summary.postedAmount
        )
    );


    setDashboardText(
        "dashboardAdvanceAmount",
        formatDashboardMoney(
            summary.advanceAmount
        )
    );


    setDashboardText(
        "dashboardInstallmentAmount",
        formatDashboardMoney(
            summary.installmentAmount
        )
    );


    setDashboardText(
        "dashboardAllocatedAmount",
        formatDashboardMoney(
            summary.allocatedAmount
        )
    );


    setDashboardText(
        "dashboardCancelledAmount",
        formatDashboardMoney(
            summary.cancelledAmount
        )
    );


    setDashboardText(
        "dashboardAveragePayment",
        formatDashboardMoney(
            summary.averagePayment
        )
    );


    setDashboardText(
        "dashboardTodayAmount",
        formatDashboardMoney(
            calculateTodayCollection(
                report.payments
            )
        )
    );
}


/* ============================================================
   PAYMENT METHOD TABLE
   ============================================================ */

function renderPaymentMethodTable(
    data
) {

    const tbody =
        document.getElementById(
            "paymentMethodBody"
        );

    if (!tbody) {
        return;
    }


    tbody.innerHTML = "";


    if (!data.length) {

        tbody.innerHTML =
            emptyDashboardRow(
                4
            );

        return;
    }


    data.forEach(
        item => {

            const row =
                document.createElement(
                    "tr"
                );


            row.innerHTML = `

                <td>
                    ${escapeDashboardHTML(
                        (getPaymentMethod(item.name) || {}).name || item.name
                    )}
                </td>

                <td>
                    ${item.count}
                </td>

                <td>
                    ৳ ${formatDashboardMoney(
                        item.amount
                    )}
                </td>

                <td>
                    ${calculatePercentage(
                        item.amount,
                        data.reduce(
                            (
                                total,
                                current
                            ) =>
                                total +
                                Number(
                                    current.amount
                                ),
                            0
                        )
                    )}%
                </td>
            `;


            tbody.appendChild(
                row
            );
        }
    );
}


/* ============================================================
   COLLECTOR TABLE
   ============================================================ */

function renderCollectorTable(
    data
) {

    const tbody =
        document.getElementById(
            "collectorBody"
        );

    if (!tbody) {
        return;
    }


    tbody.innerHTML = "";


    if (!data.length) {

        tbody.innerHTML =
            emptyDashboardRow(
                5
            );

        return;
    }


    data.forEach(
        item => {

            const row =
                document.createElement(
                    "tr"
                );


            row.innerHTML = `

                <td>
                    ${escapeDashboardHTML(
                        item.collectorName || item.collectorId
                    )}
                </td>

                <td>
                    ${item.count}
                </td>

                <td>
                    ৳ ${formatDashboardMoney(
                        item.amount
                    )}
                </td>

                <td>
                    ৳ ${formatDashboardMoney(
                        item.cash
                    )}
                </td>

                <td>
                    ৳ ${formatDashboardMoney(
                        item.digital
                    )}
                </td>
            `;


            tbody.appendChild(
                row
            );
        }
    );
}


/* ============================================================
   MEMBER TABLE
   ============================================================ */

function renderMemberTable(
    data
) {

    const tbody =
        document.getElementById(
            "memberCollectionBody"
        );

    if (!tbody) {
        return;
    }


    tbody.innerHTML = "";


    if (!data.length) {

        tbody.innerHTML =
            emptyDashboardRow(
                4
            );

        return;
    }


    data
        .slice(0, 20)
        .forEach(
            item => {

                const row =
                    document.createElement(
                        "tr"
                    );


                row.innerHTML = `

                    <td>
                        ${escapeDashboardHTML(
                            item.memberName ? `${item.memberName} (${item.memberCode || ''})` : item.memberId
                        )}
                    </td>

                    <td>
                        ${item.count}
                    </td>

                    <td>
                        ৳ ${formatDashboardMoney(
                            item.amount
                        )}
                    </td>

                    <td>
                        ${escapeDashboardHTML(
                            item.lastPaymentDate ? String(item.lastPaymentDate).slice(0,10) : item.lastPaymentDate
                        )}
                    </td>
                `;


                tbody.appendChild(
                    row
                );
            }
        );
}


/* ============================================================
   LOAN TABLE
   ============================================================ */

function renderLoanTable(
    data
) {

    const tbody =
        document.getElementById(
            "loanCollectionBody"
        );

    if (!tbody) {
        return;
    }


    tbody.innerHTML = "";


    if (!data.length) {

        tbody.innerHTML =
            emptyDashboardRow(
                4
            );

        return;
    }


    data
        .slice(0, 20)
        .forEach(
            item => {

                const row =
                    document.createElement(
                        "tr"
                    );


                row.innerHTML = `

                    <td>
                        ${escapeDashboardHTML(
                            item.loanNumber || item.loanId
                        )}
                    </td>

                    <td>
                        ${escapeDashboardHTML(
                            item.memberName || item.memberId
                        )}
                    </td>

                    <td>
                        ${item.count}
                    </td>

                    <td>
                        ৳ ${formatDashboardMoney(
                            item.amount
                        )}
                    </td>
                `;


                tbody.appendChild(
                    row
                );
            }
        );
}


/* ============================================================
   DAILY TABLE
   ============================================================ */

function renderDailyTable(
    data
) {

    const tbody =
        document.getElementById(
            "dailyCollectionBody"
        );

    if (!tbody) {
        return;
    }

    tbody.innerHTML = "";

    if (!data || !data.length) {
        tbody.innerHTML = emptyDashboardRow(4);
        return;
    }

    data
        .slice(0, 31)
        .forEach(
            item => {
                const row = document.createElement("tr");
                const fieldAmt = item.dailyCollectionAmount ?? item.daily_collection_amount ?? 0;
                const fieldCount = item.dailyCollectionCount ?? item.daily_collection_count ?? 0;
                const dateLabel = typeof item.date === "string"
                    ? item.date.slice(0, 10)
                    : escapeDashboardHTML(item.date);
                row.innerHTML = `
                    <td>${escapeDashboardHTML(dateLabel)}</td>
                    <td>${item.count}</td>
                    <td>৳ ${formatDashboardMoney(item.amount)}</td>
                    <td>৳ ${formatDashboardMoney(fieldAmt)}${fieldCount ? ` <small>(${fieldCount})</small>` : ""}</td>
                `;
                tbody.appendChild(row);
            }
        );
}


/* ============================================================
   MONTHLY TABLE
   ============================================================ */

function renderMonthlyTable(
    data
) {

    const tbody =
        document.getElementById(
            "monthlyCollectionBody"
        );

    if (!tbody) {
        return;
    }


    tbody.innerHTML = "";


    if (!data.length) {

        tbody.innerHTML =
            emptyDashboardRow(
                3
            );

        return;
    }


    data
        .slice(0, 12)
        .forEach(
            item => {

                const row =
                    document.createElement(
                        "tr"
                    );


                row.innerHTML = `

                    <td>
                        ${escapeDashboardHTML(
                            item.month
                        )}
                    </td>

                    <td>
                        ${item.count}
                    </td>

                    <td>
                        ৳ ${formatDashboardMoney(
                            item.amount
                        )}
                    </td>
                `;


                tbody.appendChild(
                    row
                );
            }
        );
}


/* ============================================================
   EXPORT
   ============================================================ */

function exportDashboardCSV() {

    if (!lastDashboardReport) {
        return;
    }

    downloadPaymentCollectionCSV(
        lastDashboardReport.payments
    );
}


/* ============================================================
   HELPERS
   ============================================================ */

function formatDashboardMoney(
    amount
) {

    return Number(
        amount || 0
    ).toLocaleString(
        "en-BD",
        {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }
    );
}


function calculatePercentage(
    amount,
    total
) {

    if (!total) {
        return "0.00";
    }

    return (
        (
            Number(amount) /
            Number(total)
        ) * 100
    ).toFixed(2);
}


function setDashboardText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );

    if (element) {

        element.textContent =
            value;
    }
}


function emptyDashboardRow(
    colspan
) {

    return `

        <tr>

            <td
                colspan="${colspan}"
                class="empty-cell"
            >
                No data available.
            </td>

        </tr>
    `;
}


function escapeDashboardHTML(
    value
) {

    return String(
        value ?? "-"
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );
}

function updateDailyPaidBakiSummary(report) {
    const paidEl = document.getElementById("dailyPaidCount");
    const bakiEl = document.getElementById("dailyBakiCount");
    const payments = Array.isArray(report?.payments) ? report.payments : [];
    const paidIds = new Set(payments.filter(p => String(p.status||"posted")==="posted").map(p => String(p.memberId||p.member_id||"")));
    paidIds.delete("");
    const paidCount = report?.paidMemberCount != null ? Number(report.paidMemberCount) : paidIds.size;
    if (paidEl) paidEl.textContent = String(paidCount);

    const arrears = Array.isArray(report?.arrearsMembers) ? report.arrearsMembers
      : (Array.isArray(report?.byMember) ? report.byMember.filter(m => Number(m.overdueAmount||0) > 0) : []);
    if (bakiEl) bakiEl.textContent = String(report?.bakiMemberCount != null ? report.bakiMemberCount : arrears.length);

    const tbody = document.getElementById("arrearsMembersBody");
    if (tbody) {
        if (!arrears.length) {
            tbody.innerHTML = '<tr><td colspan="4" class="empty-cell">এই ফিল্টারে বকেয়া সদস্য নেই।</td></tr>';
        } else {
            tbody.innerHTML = arrears.map(m => {
                const name = escapeDashboardHTML(m.memberName || m.member_name || m.memberId || "—");
                const code = escapeDashboardHTML(m.memberCode || m.member_code || "—");
                const due = formatDashboardMoney(m.overdueAmount || m.overdue_amount || m.amount || 0);
                let last = m.lastPaymentDate || m.last_payment_date || "—";
                if (last && last !== "—" && typeof last === "string") last = last.slice(0, 10);
                last = escapeDashboardHTML(last);
                return `<tr><td>${name}</td><td>${code}</td><td>৳ ${due}</td><td>${last}</td></tr>`;
            }).join("");
        }
    }
}
