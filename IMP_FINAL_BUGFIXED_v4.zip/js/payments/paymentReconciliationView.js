"use strict";

/* ====================================================
   PAYMENT RECONCILIATION UI
   STEP 5.8
==================================================== */

document.addEventListener(
    "DOMContentLoaded",
    initializePaymentReconciliation
);


function initializePaymentReconciliation() {

    const form =
        document.getElementById(
            "reconciliationFilterForm"
        );


    form?.addEventListener(
        "submit",
        event => {

            event.preventDefault();

            loadReconciliation();

        }
    );


    document
        .getElementById(
            "clearReconciliationFilters"
        )
        ?.addEventListener(
            "click",
            () => {

                form?.reset();

                loadReconciliation();

            }
        );


    loadReconciliation();
}


/* ====================================================
   LOAD
==================================================== */

async function loadReconciliation() {

    const filters = {

        memberId:
            document.getElementById(
                "reconcileMemberId"
            )?.value.trim(),

        loanId:
            document.getElementById(
                "reconcileLoanId"
            )?.value.trim(),

        status:
            document.getElementById(
                "reconcileStatus"
            )?.value,

        fromDate:
            document.getElementById(
                "reconcileFromDate"
            )?.value,

        toDate:
            document.getElementById(
                "reconcileToDate"
            )?.value
    };


    let results;
    try {
        results = await reconcileAllPayments(filters);
    } catch (e) {
        const tbody = document.getElementById("reconciliationBody");
        if (tbody) tbody.innerHTML = `<tr><td colspan="7">${escapeReconciliationHTML(e.message || "রিকনসিলিয়েশন ডেটা লোড করা যায়নি।")}</td></tr>`;
        return;
    }

    const summary =
        getReconciliationSummary(
            results
        );


    renderReconciliationSummary(
        summary
    );


    renderReconciliationTable(
        results
    );
}


/* ====================================================
   SUMMARY
==================================================== */

function renderReconciliationSummary(
    summary
) {

    setReconciliationText(
        "reconcileTotal",
        summary.totalPayments
    );


    setReconciliationText(
        "reconcileMatched",
        summary.matched
    );


    setReconciliationText(
        "reconcileMismatch",
        summary.mismatched
    );


    setReconciliationText(
        "reconcileErrors",
        summary.errors
    );


    setReconciliationText(
        "reconcilePaymentAmount",
        `৳ ${formatReconciliationMoney(
            summary.paymentAmount
        )}`
    );


    setReconciliationText(
        "reconcileAllocatedAmount",
        `৳ ${formatReconciliationMoney(
            summary.allocatedAmount
        )}`
    );


    setReconciliationText(
        "reconcileDifference",
        `৳ ${formatReconciliationMoney(
            summary.difference
        )}`
    );
}


/* ====================================================
   TABLE
==================================================== */

function renderReconciliationTable(
    results
) {

    const tbody =
        document.getElementById(
            "reconciliationBody"
        );


    if (!tbody) {
        return;
    }


    tbody.innerHTML = "";


    if (!results.length) {

        tbody.innerHTML = `
            <tr>
                <td colspan="8">
                    No reconciliation records found.
                </td>
            </tr>
        `;

        return;
    }


    results.forEach(
        result => {

            const row =
                document.createElement(
                    "tr"
                );


            const issueText =
                result.issues.length
                    ? result.issues.join(
                        " "
                    )
                    : "No issue";


            const statusClass =
                result.status ===
                "matched"
                    ? "status-matched"
                    : result.status ===
                      "mismatch"
                        ? "status-mismatch"
                        : "status-error";


            row.innerHTML = `

                <td>
                    ${escapeReconciliationHTML(
                        result.paymentId
                    )}
                </td>

                <td>
                    ${escapeReconciliationHTML(
                        result.memberId
                    )}
                </td>

                <td>
                    ${escapeReconciliationHTML(
                        result.loanId
                    )}
                </td>

                <td>
                    ৳ ${formatReconciliationMoney(
                        result.paymentAmount
                    )}
                </td>

                <td>
                    ৳ ${formatReconciliationMoney(
                        result.allocatedAmount
                    )}
                </td>

                <td>
                    ৳ ${formatReconciliationMoney(
                        result.difference
                    )}
                </td>

                <td>
                    <span class="${statusClass}">
                        ${escapeReconciliationHTML(
                            result.status
                        )}
                    </span>
                </td>

                <td>
                    ${escapeReconciliationHTML(
                        issueText
                    )}
                </td>

            `;


            tbody.appendChild(
                row
            );
        }
    );
}


/* ====================================================
   HELPERS
==================================================== */

function setReconciliationText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.textContent =
            value;
    }
}


function formatReconciliationMoney(
    amount
) {

    return Number(
        amount || 0
    ).toLocaleString(
        "en-BD",
        {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }
    );
}


function escapeReconciliationHTML(
    value
) {

    return String(
        value ?? "-"
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );
}