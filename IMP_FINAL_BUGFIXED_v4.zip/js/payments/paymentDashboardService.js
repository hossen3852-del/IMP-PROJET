"use strict";
/** Dashboard metrics come from the server so branch RBAC is enforced centrally. */
const PaymentDashboardService=Object.freeze({
 async getDashboardMetrics(){const r=await IMP_API.get('/dashboard/summary');return r?.summary||r||null;}
});
window.PaymentDashboardService=PaymentDashboardService;
