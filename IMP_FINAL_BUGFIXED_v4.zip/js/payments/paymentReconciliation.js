"use strict";

/* ====================================================
   PAYMENT RECONCILIATION SERVICE
   STEP 5.8
==================================================== */


/* ====================================================
   MONEY NORMALIZATION
==================================================== */

function normalizeReconciliationMoney(
    amount
) {

    return Math.round(
        (
            Number(amount) +
            Number.EPSILON
        ) * 100
    ) / 100;
}


/* ====================================================
   NOTE
==================================================== */

// A single-payment reconcilePayment() used to live here, built against
// getPaymentById()/getAllocationsByPayment() from the pre-API-cutover
// local cache. Neither function exists anymore (see 11.P.17 note below)
// and nothing called it, so it was removed rather than left as a
// ReferenceError waiting to happen. reconcileAllPayments() below is the
// real, server-authoritative path the UI actually uses.


/* ====================================================
   RECONCILE ALL PAYMENTS
==================================================== */

/**
 * 11.P.17 — server-authoritative: GET /payments/reconciliation runs the
 * same amount/allocation match rules against every payment in Postgres,
 * so results here match what the ledger actually contains instead of the
 * (always-empty) local payments cache.
 */
async function reconcileAllPayments(
    filters = {}
) {
    const response = await PaymentAPI.reconciliation(filters);
    return response.results;
}


/* ====================================================
   RECONCILIATION SUMMARY
==================================================== */

function getReconciliationSummary(
    results
) {

    const summary = {

        totalPayments:
            results.length,

        matched:
            0,

        mismatched:
            0,

        errors:
            0,

        paymentAmount:
            0,

        allocatedAmount:
            0,

        difference:
            0
    };


    results.forEach(
        result => {

            summary.paymentAmount +=
                Number(
                    result.paymentAmount
                ) || 0;


            summary.allocatedAmount +=
                Number(
                    result.allocatedAmount
                ) || 0;


            summary.difference +=
                Number(
                    result.difference
                ) || 0;


            if (
                result.status ===
                "matched"
            ) {

                summary.matched++;

            } else if (
                result.status ===
                "mismatch"
            ) {

                summary.mismatched++;

            } else {

                summary.errors++;
            }
        }
    );


    summary.paymentAmount =
        normalizeReconciliationMoney(
            summary.paymentAmount
        );


    summary.allocatedAmount =
        normalizeReconciliationMoney(
            summary.allocatedAmount
        );


    summary.difference =
        normalizeReconciliationMoney(
            summary.difference
        );


    return summary;
}