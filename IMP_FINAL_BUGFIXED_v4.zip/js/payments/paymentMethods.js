"use strict";

/*
====================================================
PAYMENT METHODS
STEP 5.2
====================================================
*/

const PAYMENT_METHODS = Object.freeze([

    {
        id: "cash",
        name: "Cash",
        requiresReference: false,
        requiresBank: false
    },

    {
        id: "bkash",
        name: "bKash",
        requiresReference: true,
        requiresBank: false
    },

    {
        id: "nagad",
        name: "Nagad",
        requiresReference: true,
        requiresBank: false
    },

    {
        id: "rocket",
        name: "Rocket",
        requiresReference: true,
        requiresBank: false
    },

    {
        id: "bank_transfer",
        name: "Bank Transfer",
        requiresReference: true,
        requiresBank: true
    },

    {
        id: "cheque",
        name: "Cheque",
        requiresReference: true,
        requiresBank: true
    },

    {
        id: "other",
        name: "Other",
        requiresReference: false,
        requiresBank: false
    }

]);


function getPaymentMethods() {

    return [...PAYMENT_METHODS];
}


function getPaymentMethod(
    methodId
) {

    return PAYMENT_METHODS.find(
        method =>
            method.id ===
            methodId
    ) || null;
}


function populatePaymentMethodSelect(
    selectElement
) {

    if (!selectElement) {
        return;
    }


    selectElement.innerHTML =
        `<option value="">
            Select Payment Method
        </option>`;


    PAYMENT_METHODS.forEach(
        method => {

            const option =
                document.createElement(
                    "option"
                );

            option.value =
                method.id;

            option.textContent =
                method.name;

            selectElement.appendChild(
                option
            );
        }
    );
}