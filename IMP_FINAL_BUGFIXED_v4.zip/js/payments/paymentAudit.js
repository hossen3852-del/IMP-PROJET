'use strict';

/** Server-authoritative payment audit facade. */
const PaymentAuditAPI = Object.freeze({
  list(paymentId) { return IMP_API.get(`/payments/${encodeURIComponent(paymentId)}/audit`); },
  cancel(paymentId, reason='') { return PaymentAPI.cancel(paymentId, reason); },
  reverse(paymentId, reason='') { return PaymentAPI.reverse(paymentId, reason); }
});
window.PaymentAuditAPI = PaymentAuditAPI;
