"use strict";

async function getPaymentHistory(filters = {}) {
    const result = await PaymentAPI.list(filters);
    return Array.isArray(result?.payments) ? result.payments : [];
}

function getPaymentHistorySummary(payments) {
    const summary = { count: payments.length, total: 0, cash: 0, digital: 0, cancelled: 0 };
    payments.forEach(payment => {
        const amount = Number(payment.amount || 0);
        summary.total += amount;
        if (payment.status === "cancelled" || payment.status === "reversed") { summary.cancelled += amount; return; }
        if (payment.paymentMethod === "cash") summary.cash += amount; else summary.digital += amount;
    });
    return summary;
}
