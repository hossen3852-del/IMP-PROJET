"use strict";

/*
====================================================
PAYMENT ENTRY
STEP 5.4
====================================================
*/

function initializePaymentEntry() {

    const form =
        document.getElementById(
            "paymentForm"
        );


    if (!form) {
        return;
    }


    const methodSelect =
        document.getElementById(
            "paymentMethod"
        );


    populatePaymentMethodSelect(
        methodSelect
    );


    if (methodSelect) {

        methodSelect.addEventListener(
            "change",
            updatePaymentMethodFields
        );
    }


    form.addEventListener(
        "submit",
        handlePaymentSubmit
    );


    setDefaultPaymentDate();
}


/*
====================================================
DEFAULT DATE
====================================================
*/

function setDefaultPaymentDate() {

    const input =
        document.getElementById(
            "paymentDate"
        );


    if (!input) {
        return;
    }


    const today =
        new Date();


    const date =
        today.toISOString()
            .split("T")[0];


    input.value =
        date;
}


/*
====================================================
METHOD FIELDS
====================================================
*/

function updatePaymentMethodFields() {

    const methodId =
        document.getElementById(
            "paymentMethod"
        )?.value;


    const method =
        getPaymentMethod(
            methodId
        );


    const referenceGroup =
        document.getElementById(
            "referenceGroup"
        );


    const bankGroup =
        document.getElementById(
            "bankGroup"
        );


    if (!method) {

        referenceGroup
            ?.classList
            .add("hidden");

        bankGroup
            ?.classList
            .add("hidden");

        return;
    }


    if (
        method.requiresReference
    ) {

        referenceGroup
            ?.classList
            .remove("hidden");

    } else {

        referenceGroup
            ?.classList
            .add("hidden");
    }


    if (
        method.requiresBank
    ) {

        bankGroup
            ?.classList
            .remove("hidden");

    } else {

        bankGroup
            ?.classList
            .add("hidden");
    }
}


/*
====================================================
SUBMIT
====================================================
*/

async function handlePaymentSubmit(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    const data = {
        memberId: formData.get("memberId"), loanId: formData.get("loanId"), amount: Number(formData.get("amount")),
        paymentDate: `${formData.get("paymentDate")}T06:00:00.000Z`, paymentMethod: formData.get("paymentMethod"),
        transactionReference: formData.get("transactionReference") || "", bankName: formData.get("bankName") || "",
        bankAccount: formData.get("bankAccount") || "", collectorId: formData.get("collectorId") || null, notes: formData.get("notes") || ""
    };
    try {
        if (typeof RBACManager !== "undefined" && !RBACManager.hasPermission("payment.create")) {
            throw new Error("You do not have permission to create payments.");
        }
        if (!data.memberId || !data.loanId || !data.paymentMethod || !Number.isFinite(data.amount) || data.amount <= 0) {
            throw new Error("Please enter valid payment data.");
        }
        const result = await PaymentAPI.create(data);
        showPaymentMessage("Payment successfully recorded.", "success");
        setTimeout(() => {
            window.location.href = `payment-receipt.html?paymentId=${encodeURIComponent(result.payment.id)}`;
        }, 400);
    } catch (error) { showPaymentMessage(error.message, "error"); }
}


/*
====================================================
MESSAGE
====================================================
*/

function showPaymentMessage(
    message,
    type
) {

    const box =
        document.getElementById(
            "paymentMessage"
        );


    if (!box) {

        alert(
            message
        );

        return;
    }


    box.textContent =
        message;


    box.className =
        `payment-message ${type}`;
}