"use strict";

/*
====================================================
PAYMENT HISTORY UI
====================================================
*/

document.addEventListener(
    "DOMContentLoaded",
    initializePaymentHistory
);


async function initializePaymentHistory() {
    try {
        await SessionManager.requireAuth();
        await RBACManager.bootstrap();
        if (!RBACManager.hasPermission("payment.view")) throw new Error("You do not have permission to view payment history.");
    } catch (error) {
        const tbody = document.getElementById("paymentHistoryBody");
        if (tbody) tbody.innerHTML = `<tr><td colspan="9">${escapePaymentHTML(error.message || "Access denied")}</td></tr>`;
        return;
    }

    const form =
        document.getElementById(
            "historyFilterForm"
        );


    populatePaymentMethodSelect(
        document.getElementById(
            "filterPaymentMethod"
        )
    );


    form?.addEventListener(
        "submit",
        event => {

            event.preventDefault();

            loadPaymentHistory();
        }
    );


    document
        .getElementById(
            "clearFilters"
        )
        ?.addEventListener(
            "click",
            () => {

                form?.reset();

                loadPaymentHistory();
            }
        );


    loadPaymentHistory();
}


async function loadPaymentHistory() {
    const filters = {
        memberId: document.getElementById("filterMemberId")?.value.trim(),
        loanId: document.getElementById("filterLoanId")?.value.trim(),
        paymentMethod: document.getElementById("filterPaymentMethod")?.value,
        status: document.getElementById("filterStatus")?.value,
        source: document.getElementById("filterSource")?.value,
        fromDate: document.getElementById("filterFromDate")?.value,
        toDate: document.getElementById("filterToDate")?.value
    };
    try {
        const result = await PaymentAPI.list(filters);
        const payments = result.payments || [];
        renderPaymentHistory(payments);
        renderPaymentSummary(getPaymentHistorySummary(payments));
    } catch (error) {
        const tbody = document.getElementById("paymentHistoryBody");
        if (tbody) tbody.innerHTML = `<tr><td colspan="9">${escapePaymentHTML(error.message)}</td></tr>`;
    }
}


function renderPaymentHistory(
    payments
) {

    const tbody =
        document.getElementById(
            "paymentHistoryBody"
        );


    if (!tbody) {
        return;
    }


    tbody.innerHTML =
        "";


    if (!payments.length) {

        tbody.innerHTML = `
            <tr>
                <td colspan="9">
                    No payment records found.
                </td>
            </tr>
        `;

        return;
    }


    payments.forEach(
        payment => {

            const row =
                document.createElement(
                    "tr"
                );


            row.innerHTML = `

                <td>
                    ${escapePaymentHTML(
                        payment.id
                    )}
                </td>

                <td>
                    ${escapePaymentHTML(
                        payment.memberId
                    )}
                </td>

                <td>
                    ${escapePaymentHTML(
                        payment.loanId
                    )}
                </td>

                <td>
                    ${escapePaymentHTML(
                        payment.paymentDate
                    )}
                </td>

                <td>
                    ৳ ${formatPaymentMoney(
                        payment.amount
                    )}
                </td>

                <td>
                    ${escapePaymentHTML(
                        getPaymentMethod(
                            payment.paymentMethod
                        )?.name ||
                        payment.paymentMethod
                    )}
                </td>

                <td>
                    ${escapePaymentHTML(
                        payment.status
                    )}
                </td>

                <td>
                    ${escapePaymentHTML(
                        payment.source === "daily_collection"
                            ? "Daily Collection"
                            : (payment.source || "manual")
                    )}
                </td>

              <td>

    <a
        href="payment-details.html?paymentId=${encodeURIComponent(
            payment.id
        )}"
    >
        View
    </a>

    &nbsp;|&nbsp;

    <a
        href="payment-audit.html?paymentId=${encodeURIComponent(
            payment.id
        )}"
    >
        Audit
    </a>

</td>
            `;


            tbody.appendChild(
                row
            );
        }
    );
}


function renderPaymentSummary(
    summary
) {

    setPaymentText(
        "summaryCount",
        summary.count
    );

    setPaymentText(
        "summaryTotal",
        `৳ ${formatPaymentMoney(
            summary.total
        )}`
    );

    setPaymentText(
        "summaryCash",
        `৳ ${formatPaymentMoney(
            summary.cash
        )}`
    );

    setPaymentText(
        "summaryDigital",
        `৳ ${formatPaymentMoney(
            summary.digital
        )}`
    );
}


function setPaymentText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );

    if (element) {
        element.textContent =
            value;
    }
}


function formatPaymentMoney(
    amount
) {

    return Number(
        amount || 0
    ).toLocaleString(
        "en-BD",
        {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }
    );
}


function escapePaymentHTML(
    value
) {

    return String(
        value ?? "-"
    )
    .replace(
        /&/g,
        "&amp;"
    )
    .replace(
        /</g,
        "&lt;"
    )
    .replace(
        />/g,
        "&gt;"
    )
    .replace(
        /"/g,
        "&quot;"
    )
    .replace(
        /'/g,
        "&#039;"
    );
}