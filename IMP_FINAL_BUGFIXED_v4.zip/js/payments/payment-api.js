'use strict';

/** 11.P.10 — server-authoritative payment client. No payment persistence in localStorage. */
const PaymentAPI = Object.freeze({
  list(filters = {}) {
    const q = new URLSearchParams();
    const map = { memberId:'memberId', loanId:'loanId', paymentMethod:'paymentMethod', status:'status', source:'source', fromDate:'fromDate', toDate:'toDate', limit:'limit', offset:'offset' };
    Object.keys(map).forEach(k => { if (filters[k]) q.set(map[k], filters[k]); });
    return IMP_API.get(`/payments${q.toString() ? `?${q}` : ''}`);
  },
  get(id) { return IMP_API.get(`/payments/${encodeURIComponent(id)}`); },
  create(data, idempotencyKey = (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`)) {
    return IMP_API.request('/payments', { method:'POST', headers:{'Idempotency-Key':idempotencyKey}, body:data });
  },
  allocations(id) { return IMP_API.get(`/payments/${encodeURIComponent(id)}/allocations`); },
  cancel(id, reason='') { return IMP_API.post(`/payments/${encodeURIComponent(id)}/cancel`, { reason }); },
  reverse(id, reason='') { return IMP_API.post(`/payments/${encodeURIComponent(id)}/reverse`, { reason }); },
  receipt(id) { return IMP_API.get(`/payments/${encodeURIComponent(id)}/receipt`); },
  collectionReport(filters = {}) {
    const q = new URLSearchParams();
    const map = { memberId:'memberId', loanId:'loanId', collectorId:'collectorId', paymentMethod:'paymentMethod', branchId:'branchId', status:'status', source:'source', fromDate:'fromDate', toDate:'toDate' };
    Object.keys(map).forEach(k => { if (filters[k]) q.set(map[k], filters[k]); });
    return IMP_API.get(`/payments/collection-report${q.toString() ? `?${q}` : ''}`);
  },
  reconciliation(filters = {}) {
    const q = new URLSearchParams();
    const map = { memberId:'memberId', loanId:'loanId', status:'status', fromDate:'fromDate', toDate:'toDate', limit:'limit' };
    Object.keys(map).forEach(k => { if (filters[k]) q.set(map[k], filters[k]); });
    return IMP_API.get(`/payments/reconciliation${q.toString() ? `?${q}` : ''}`);
  }
});
window.PaymentAPI = PaymentAPI;
