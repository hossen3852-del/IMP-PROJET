# IMP V6.0.6 Release Status

## Release
- Product: Installment Management Platform
- Commercial Expansion: V6.0.6
- Package version: 1.6.6
- Status: Hardened production candidate

## V6.0.6 fix
- Fixed notification outbox worker contract mismatch between PostgreSQL `template_code` and provider `templateCode`.
- Added notification provider contract regression tests.
- Added production configuration validation command: `npm run config:validate`.
- Synchronized package and lockfile versions at 1.6.6.
- Regenerated final automated test output.

## Validation
- Automated tests: 252/252 passed
- JavaScript syntax: 208/208 files passed
- HTML pages: 53 scanned
- Missing local HTML assets: 0
- Notification provider smoke contract: passed
- Production configuration validator: included and fail-closed

## Deployment gate
Live PostgreSQL validation requires a real production/staging `DATABASE_URL` and must be run with:

```bash
npm run db:migrate
npm run db:validate
npm run config:validate
npm test
```

No claim of live PostgreSQL verification is made by this source-only build environment.

## V6.0.6 update hardening

- Adjustment validation now rolls back the active PostgreSQL transaction before returning a conflict.
- Penalty adjustments now increase both `total_payable` and `outstanding_amount` without the previous cap at the original total payable.
- Each penalty creates a dedicated pending installment so the penalty remains allocatable through the normal payment flow.
- Added regression tests for transaction rollback and penalty accounting.
- Final automated regression: 252/252 passed.
