# IMP V5.1 — Strict Production Layered Architecture Update

## Target
Browser → Express → Middleware → Route → Controller → Service → Repository → PostgreSQL

## V5.1 changes
- Removed the obsolete `_v4_controllers` compatibility directory.
- Kept domain services/repositories as the active application boundary.
- Added an architecture contract test for route/controller/service/repository boundaries.
- Added a documented migration gate identifying any remaining Express-router compatibility inside service modules.
- Preserved existing financial/business behavior and regression tests.

## Important
V5.1 is an update/hardening release, not a claim of complete Clean Architecture purity. Existing service modules still contain legacy Express route composition and therefore require a later refactor before they can be called pure domain/application services.

## Required next refactor
1. Remove `router.*` from every `server/services/*Service.js`.
2. Services must accept plain application inputs/context and return values.
3. Controllers must own HTTP status/body/cookie mapping only.
4. Routes must own middleware + endpoint registration only.
5. Repositories must own SQL/DB access only.
6. No `req`, `res`, `next`, `router`, or Express imports in services.
