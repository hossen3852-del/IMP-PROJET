# Daily Collection Logic — Final Fixed Build

Date: 2026-09-18

## Bugs Fixed in this build

### 1. Baki status total mismatch (CRITICAL)
- **Problem**: When a member was marked Baki, `recalcTotals()` still added savings + insurance values from the row into the sticky total bar, while the submit payload forced those amounts to 0. UI showed inflated net collection.
- **Fix**:
  - `recalcTotals()`: if `status === "baki"` → skip the entire row (0 installment, 0 savings, 0 insurance).
  - `setBaki()`: zero and lock (readOnly) installment, savings and insurance inputs.
  - `setPaid()`: restore savings/insurance to editable; re-apply default installment.

### 2. Mobile / Responsive UX
- Expanded media queries (≤768px and ≤400px).
- Sticky total bar with safe-area for notched phones.
- Touch targets ≥36–48px, font-size 16px on inputs (prevents iOS zoom).
- Single-column member inputs, full-width submit button.
- Active press feedback for touch devices.

## Unchanged (correct) behaviour
- Formula: মোট কালেকশন = কিস্তি + সঞ্চয় + বীমা − ডেইলি খরচ
- Default Paid, readonly due amount (dueToday includes overdue).
- Edit → Baki panel → Set as Baki.
- Server: baki + zero amounts → audit only; dailyExpense > 0 → expense entry.

## Verification
- `node --check` on daily-collection.js: clean
- Logic now consistent between UI totals and POST /collections/daily payload.


### 3. CRITICAL — Current daily installment was always zero in the route sheet
- **Root cause:** `/collections/route-sheet` returned `dueTodayAmount`, but the frontend only read `installmentAmount`. Therefore the readonly installment input defaulted to `0.00`, and daily installment totals/POST payloads were wrong.
- **Fix:** server now exposes `installmentAmount = due_today` (remaining unpaid amount through the selected date) and also exposes `scheduledInstallmentAmount` separately. Frontend now prioritizes `dueTodayAmount` / `due_today_amount` when prefilling the installment.
- **Result:** Daily Collection now reflects overdue + selected-date remaining installment amount, after prior payments/partial payments.

### 4. CRITICAL — Paid ↔ Baki UI state could retain stale optional amounts
- **Root cause:** switching to Baki did not clear/lock Savings and Insurance inputs, while the POST payload forced them to zero. The visible form could therefore disagree with its submitted values.
- **Fix:** Baki now clears and locks installment, savings and insurance. Returning to Paid re-enables Savings and Insurance.
- **Result:** visible daily totals and server payload remain consistent.

### 5. Regression tests added
- Added `tests/production/daily-collection-logic.test.js` covering route-sheet amount mapping, frontend due prefill, Baki state consistency and total/payload consistency.

### 6. CRITICAL — Server fallback date could depend on host timezone
- **Root cause:** `getValidCollectionDate()` used `new Date().getFullYear()/getMonth()/getDate()`. On a UTC server, the default date could differ from Bangladesh local date around midnight.
- **Fix:** fallback date is now generated explicitly with `Intl.DateTimeFormat(..., { timeZone: 'Asia/Dhaka' })`.
- **Result:** Daily Collection's default server date is stable for Bangladesh deployments regardless of server host timezone.
