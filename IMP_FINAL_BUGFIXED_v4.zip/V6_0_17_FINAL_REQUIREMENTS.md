# IMP V6.0.17 Final Requirements

Implemented: completed-loan separation, legacy member/loan import workflow, member loan history/rating section, per-user sidebar UI visibility, and organization share profiles.

Migration: `031_v6_0_17_legacy_loans_shares_ui_visibility.sql`
