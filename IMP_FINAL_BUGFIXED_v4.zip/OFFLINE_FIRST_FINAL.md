# IMP V6.0.17 — Offline-First Final Update

## Implemented

- Main **Daily Collection** now has an IndexedDB route-sheet cache.
- Main **Daily Collection** POST batches are queued in IndexedDB when the network/server is unavailable.
- Existing per-entry `idempotencyKey` and daily-expense idempotency key are preserved in queued payloads, making automatic replay safe against duplicate posting.
- Pending daily-collection queue automatically syncs when the browser returns online.
- Offline/online status is shown in the Daily Collection UI.
- Existing **Field Officer** offline cache/queue remains intact.
- Added a root **Service Worker** for app-shell/static asset caching and offline navigation fallback.
- Added **PWA manifest** and 192/512 icons.
- API responses are deliberately excluded from Service Worker caching; authenticated business data continues to use the IndexedDB layer.
- Added static production tests for the offline-first layer.

## Important operational behavior

1. Open Daily Collection while online at least once for the selected date/search/branch so its Route Sheet can be cached.
2. If connectivity drops, the cached Route Sheet can still be displayed.
3. Collection submission while offline is stored locally as a queued batch.
4. When connectivity returns, the queue is replayed automatically.
5. The server remains the source of truth. PostgreSQL/Node.js are not moved into the browser.
