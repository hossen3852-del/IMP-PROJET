# IMP — Final Fee Flow

## Member Registration
- Admission fee is entered in Member Add.
- Member creation and admission-fee ledger posting are one PostgreSQL transaction.
- Ledger: `capital_entries.entry_type = admission_fee`.

## Loan Disbursement
- Insurance amount is entered at the time an approved loan is disbursed.
- Loan disbursement and insurance premium posting are one PostgreSQL transaction.
- Ledger: `member_insurance_transactions.transaction_type = premium` linked to the member and loan.
- The same insurance amount is NOT duplicated into `capital_entries`.

## Daily Collection
- Only installment and savings remain in the daily field collection form.
- Daily expense remains available.
- Admission fee and insurance inputs/totals/settings were removed from Daily Collection.

## Verification
- `npm test` => 193 PASS / 0 FAIL.
- JavaScript syntax checks pass for modified frontend/backend route files.
