'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('V6.0.5 notification worker normalizes DB snake_case template_code to provider camelCase templateCode',()=>{
 const s=read('scripts/process-notification-outbox.js');
 assert.match(s,/templateCode\s*:\s*n\.templateCode\s*\?\?\s*n\.template_code/);
 assert.match(s,/provider\.send\(notification\)/);
});

test('V6.0.5 notification provider has an explicit templateCode contract',()=>{
 const s=read('server/integrations/notificationProvider.js');
 assert.match(s,/async function send\(\{ channel, recipient, templateCode, payload \}\)/);
 assert.match(s,/templateCode/);
});

test('V6.0.5 pending notification query exposes template_code expected by the worker adapter',()=>{
 const s=read('server/repositories/queryRegistry.js');
 assert.match(s,/commercialExpansion:notificationsPending.*SELECT \* FROM notification_outbox/);
 assert.match(s,/template_code/);
});

test('V6.0.5 production config documents password reset email requirements',()=>{
 const s=read('.env.production.example');
 for(const key of ['PASSWORD_RESET_BASE_URL','EMAIL_WEBHOOK_URL','EMAIL_FROM']) assert.match(s,new RegExp(`^${key}=`, 'm'),key);
});
