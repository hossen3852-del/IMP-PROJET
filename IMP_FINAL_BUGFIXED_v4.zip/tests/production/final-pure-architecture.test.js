'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '../..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

const serviceHttp = /\brequire\(['"]express['"]\)|\brouter\.(get|post|put|patch|delete|use)\s*\(|\b(req|res|reply)\.|\bnext\s*\(|\.sendFile\s*\(|\.status\s*\(|\.json\s*\(/i;
const serviceDb = /require\(['"](?:\.\.\/)+config\/db['"]\)|\b(pool|client)\.(query|connect)\s*\(/i;
const sql = /\bSELECT\s+|\bINSERT\s+INTO\s+|\bUPDATE\s+[a-z_]+\s+SET\b|\bDELETE\s+FROM\b/i;

test('final architecture exposes controller adapters for all service middleware guards', () => {
  const pairs = [
    ['server/controllers/members.js', 'guard_members', 'serviceMiddleware(service.guard_members)'],
    ['server/controllers/loans.js', 'guard_loans', 'serviceMiddleware(service.guard_loans)'],
    ['server/controllers/payments.js', 'guard_payments', 'serviceMiddleware(service.guard_payments)'],
    ['server/controllers/settings.js', 'canUpdateSettings', 'serviceMiddleware(service.canUpdateSettings)']
  ];

  for (const [file, symbol, adapter] of pairs) {
    const source = read(file);
    assert.ok(source.includes(`const ${symbol} = ${adapter};`));
    assert.match(source, new RegExp(`\\b${symbol},`));
  }
});

test('all route controller references exist in the matching controller adapter', () => {
  const routeDir = path.join(root, 'server/routes');
  for (const file of fs.readdirSync(routeDir).filter(name => name.endsWith('.js'))) {
    const route = read(`server/routes/${file}`);
    const controllerFile = path.join(root, 'server/controllers', file);
    if (!fs.existsSync(controllerFile)) continue;
    const controller = fs.readFileSync(controllerFile, 'utf8');
    const refs = [...route.matchAll(/controller\.([A-Za-z0-9_]+)/g)].map(match => match[1]);
    for (const ref of new Set(refs)) assert.match(controller, new RegExp(`\\b${ref}\\b`), `${file} references missing controller.${ref}`);
  }
});

test('services remain independent from Express and raw PostgreSQL clients', () => {
  for (const file of fs.readdirSync(path.join(root, 'server/services')).filter(name => name.endsWith('.js'))) {
    const source = read(`server/services/${file}`);
    assert.doesNotMatch(source, serviceHttp, `${file} contains HTTP adapter concerns`);
    assert.doesNotMatch(source, serviceDb, `${file} directly accesses PostgreSQL`);
  }
});

test('routes and controllers remain SQL-free', () => {
  for (const layer of ['routes', 'controllers']) {
    for (const file of fs.readdirSync(path.join(root, 'server', layer)).filter(name => name.endsWith('.js'))) {
      assert.doesNotMatch(read(`server/${layer}/${file}`), sql, `${layer}/${file} contains SQL`);
    }
  }
});

test('legacy V4 compatibility directory is absent', () => {
  assert.equal(fs.existsSync(path.join(root, 'server/_v4_controllers')), false);
});
