"use strict";
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../..');
const runtimeFiles=[];
const walk=(d)=>{for(const ent of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,ent.name);if(ent.isDirectory()&&ent.name!=='node_modules')walk(p);else if(ent.isFile()&&ent.name.endsWith('.js'))runtimeFiles.push(p);}};
walk(path.join(root,'js'));
test('frontend runtime is API-only and has no Storage/localStorage persistence',()=>{
  const offenders=[];
  for(const file of runtimeFiles){const s=fs.readFileSync(file,'utf8');if(/\bStorage\.(get|set|setAll|getAll|insert|update|delete)|localStorage\.(getItem|setItem|removeItem|clear)/.test(s))offenders.push(file.replace(root+path.sep,''));}
  assert.deepEqual(offenders,[]);
});
test('HTML pages do not load legacy storage module',()=>{
  const offenders=[];
  const walk=d=>{for(const ent of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,ent.name);if(ent.isDirectory())walk(p);else if(ent.isFile()&&ent.name.endsWith('.html')&&fs.readFileSync(p,'utf8').includes('js/core/storage.js'))offenders.push(p.replace(root+path.sep,''));}};
  walk(path.join(root,'pages'));assert.deepEqual(offenders,[]);
});

test('legacy core storage module is removed',()=>{ assert.equal(fs.existsSync(path.join(root,'js/core/storage.js')),false); });
