const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');

test('V6.0.17 visibility fallback does not hide everything when no custom record exists', () => {
  const source = fs.readFileSync('server/services/settingsService.js', 'utf8');
  assert.match(source, /No saved custom visibility must not mean/);
  assert.match(source, /visibility:\{\}\}/);
});

test('V6.0.17 migration repairs settings and dashboard customization permissions', () => {
  const source = fs.readFileSync('database/migrations/032_v6_0_17_rbac_settings_dashboard_repair.sql', 'utf8');
  for (const permission of ['settings.view','settings.update','dashboard.view','dashboard.customize']) {
    assert.match(source, new RegExp(permission.replace('.', '\\.'), 'g'));
  }
  assert.match(source, /organization_admin/);
  assert.match(source, /super_admin/);
});

test('admin core settings links cannot be hidden by stale per-user visibility',()=>{
  const a=fs.readFileSync('js/dashboard/sidebar-visibility.js', 'utf8');
  assert.match(a,/role==='organization_admin'\|\|role==='super_admin'/);
  assert.match(a,/required==='settings.view'\|\|required==='dashboard.customize'/);
  assert.match(a,/RBACManager\.hasPermission\(required\)/);
});

