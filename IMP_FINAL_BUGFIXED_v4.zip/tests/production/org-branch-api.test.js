const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '../..');

test('11.P.4 organization and branch routes are registered', () => {
  const app = fs.readFileSync(path.join(root, 'server/app.js'), 'utf8');
  assert.match(app, /routes\/organization/);
  assert.match(app, /routes\/branches/);
  assert.match(app, /\/api\/organization/);
  assert.match(app, /\/api\/branches/);
});

test('11.P.4 migration defines canonical permissions and composite tenant constraints', () => {
  const sql = fs.readFileSync(path.join(root, 'database/migrations/004_organization_branch_api.sql'), 'utf8');
  for (const code of ['organization.view','organization.update','branch.view','branch.create','branch.update']) {
    assert.match(sql, new RegExp(code.replace('.', '\\.') ));
  }
  assert.match(sql, /users_branch_org_fk/);
  assert.match(sql, /members_branch_org_fk/);
  assert.match(sql, /loans_branch_org_fk/);
  assert.match(sql, /payments_branch_org_fk/);
});

test('11.P.4 frontend managers no longer use localStorage for org/branch records', () => {
  const org = fs.readFileSync(path.join(root, 'js/company/organization.js'), 'utf8');
  const branch = fs.readFileSync(path.join(root, 'js/company/branch.js'), 'utf8');
  assert.doesNotMatch(org, /Storage\.KEYS/);
  assert.doesNotMatch(branch, /Storage\.KEYS/);
  assert.match(org, /IMP_API/);
  assert.match(branch, /IMP_API/);
});


test('dashboard summary route is registered and tenant-scoped', () => {
  const route = fs.readFileSync(path.join(root, 'server/routes/dashboard.js'), 'utf8');
  const service = fs.readFileSync(path.join(root, 'server/services/dashboardService.js'), 'utf8');
  assert.match(route, /router\.get\(['"]\/summary['"]/);
  assert.match(route, /requirePermission\(['"]dashboard\.view['"]\)/);
  assert.match(route, /requireTenant/);
  assert.match(service, /context\.auth\.organization_id/);
});
