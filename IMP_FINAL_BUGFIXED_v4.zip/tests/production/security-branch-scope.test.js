'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..','..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('branch scope helper makes non-admin roles branch restricted',()=>{
  const s=read('server/middleware/branchScope.js');
  assert.match(s,/organization_admin/); assert.match(s,/super_admin/); assert.match(s,/auth\.branch_id/); assert.match(s,/1=0/);
});

test('daily collection verifies member and selected branch ownership',()=>{
  const s=read('server/services/collectionsService.js');
  assert.match(s,/assertBranchAccess\(context\.auth, memberBranch\)/);
  assert.match(s,/Member does not belong to the selected branch/);
  assert.match(s,/enforceRequestedBranch/);
});

test('organization user API never accepts a branch outside the caller scope',()=>{
  const s=read('server/services/usersService.js');
  assert.match(s,/assertBranchAccess\(context\.auth,branchId\)/);
  assert.match(s,/!canManageRole/);
  assert.match(s,/password_hash/);
  assert.doesNotMatch(s,/localStorage/);
});

test('uploads are not publicly served',()=>{
  const s=read('server/app.js');
  assert.match(s,/req\.path\.startsWith\('\/uploads\/'\)/);
  assert.match(read('server/services/membersService.js'),/\/api\/members\/\$\{row\.id\}\/photo/);
});

test('production HTML contains no inline script blocks or event handlers',()=>{
  const pagesDir=path.join(root,'pages');
  const files=[];
  (function walk(dir){for(const name of fs.readdirSync(dir)){const p=path.join(dir,name);const st=fs.statSync(p);if(st.isDirectory())walk(p);else if(name.endsWith('.html'))files.push(p);}})(pagesDir);
  for(const p of files){const s=fs.readFileSync(p,'utf8');assert.doesNotMatch(s,/<script>\s*[\s\S]*?<\/script>/i,p);assert.doesNotMatch(s,/\son(?:click|submit|change|input|load)\s*=/i,p);assert.doesNotMatch(s,/\sstyle="/i,p);}
});

test('payment audit uses server API instead of local browser audit storage',()=>{
  const s=read('js/payments/paymentAudit.js');
  assert.match(s,/IMP_API\.get/); assert.doesNotMatch(s,/Storage\./);
});

test('company registration schema includes required organization profile fields',()=>{
  const s=read('server/services/authService.js');
  for(const field of ['companyCode','companyType','country','currency','workingDays','officeStartTime','officeEndTime','timezone']) assert.match(s,new RegExp(field));
  assert.match(read('database/migrations/016_security_branch_scope.sql'),/organizations_company_code_uidx/);
});

test('dashboard installment balance query qualifies joined columns to avoid ambiguity',()=>{
  const s=read('server/repositories/queryRegistry.js');
  assert.match(s,/SUM\(i\.outstanding_amount\)/);
  assert.match(s,/i\.status IN \('pending','partial','overdue'\)/);
  assert.match(s,/i\.due_date < CURRENT_DATE/);
  assert.doesNotMatch(s,/SUM\(outstanding_amount\).*FROM installments i JOIN loans l/);
});

test('auth rate limiter does not block session bootstrap reads',()=>{
  const s=read('server/app.js');
  assert.match(s,/const authLimit = rateLimit/);
  assert.match(s,/skip: req => req\.method === 'GET'/);
});
