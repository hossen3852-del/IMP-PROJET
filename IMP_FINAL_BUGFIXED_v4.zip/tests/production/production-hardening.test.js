const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');

const root = require('node:path').resolve(__dirname, '../..');

test('production environment forbids wildcard CORS and insecure database SSL', () => {
  const env = fs.readFileSync(`${root}/server/config/env.js`, 'utf8');
  assert.match(env, /CORS_ORIGIN.*\*.*production|includes\('\*'\).*production/);
  assert.match(env, /DATABASE_SSL=disable.*not allowed|databaseSsl === 'disable'/);
});

test('production session cookie uses __Host- prefix', () => {
  const env = fs.readFileSync(`${root}/server/config/env.js`, 'utf8');
  const auth = fs.readFileSync(`${root}/server/services/authService.js`, 'utf8');
  assert.match(env, /__Host-imp_session/);
  assert.match(auth, /httpOnly:\s*true/);
  assert.match(auth, /secure:\s*env\.nodeEnv === 'production'/);
  assert.match(auth, /sameSite:\s*'lax'/);
});

test('database client has statement and query timeouts', () => {
  const db = fs.readFileSync(`${root}/server/config/db.js`, 'utf8');
  assert.match(db, /statement_timeout/);
  assert.match(db, /query_timeout/);
});

test('migration runner uses an advisory lock', () => {
  const migration = fs.readFileSync(`${root}/server/db/migrate.js`, 'utf8');
  assert.match(migration, /pg_try_advisory_lock/);
});

test('server has graceful shutdown handlers', () => {
  const server = fs.readFileSync(`${root}/server/server.js`, 'utf8');
  assert.match(server, /SIGTERM/);
  assert.match(server, /SIGINT/);
  assert.match(server, /pool\.end/);
});

test('request correlation ID middleware is installed', () => {
  const app = fs.readFileSync(`${root}/server/app.js`, 'utf8');
  const middleware = fs.readFileSync(`${root}/server/middleware/requestId.js`, 'utf8');
  assert.match(app, /requestId/);
  assert.match(middleware, /X-Request-ID/);
});
