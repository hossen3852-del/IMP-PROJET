'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('final layered architecture has dedicated route/controller/service/repository directories',()=>{
  for(const dir of ['server/routes','server/controllers','server/services','server/repositories']) assert.equal(fs.existsSync(path.join(root,dir)),true,dir);
});

test('controller adapter converts HTTP requests into framework-neutral service context',()=>{
  const s=read('server/controllers/controller.js');
  assert.match(s,/function toContext\(req\)/);
  assert.match(s,/serviceHandler\(toContext\(req\)\)/);
  assert.match(s,/res\.status/);
});

test('application result writes are centralized in controller adapter',()=>{
  const s=read('server/controllers/controller.js');
  assert.match(s,/kind !== 'application-result'/);
  assert.match(s,/res\.cookie/);
  assert.match(s,/\.json\(/);
});
