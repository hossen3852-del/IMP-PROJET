'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '../..');
const routeDir = path.join(root, 'server/routes');
const serviceDir = path.join(root, 'server/services');
const repoFile = path.join(root, 'server/repositories/queryRegistry.js');
const domainRoutes = ['organization.js','branches.js','rbac.js','members.js','loans.js','installments.js','payments.js'];
const tenantMiddlewareRoutes = ['branches.js','rbac.js','members.js','loans.js','installments.js','payments.js'];
function readRoute(name){ return fs.readFileSync(path.join(routeDir,name),'utf8'); }
function readService(name){ return fs.readFileSync(path.join(serviceDir,name.replace(/\.js$/, 'Service.js')),'utf8'); }
const repo = fs.readFileSync(repoFile,'utf8');

test('all protected domain routes use server authentication',()=>{
  for(const name of domainRoutes) assert.match(readRoute(name), /requireAuth/, `${name} must use requireAuth`);
});

test('all tenant-sensitive domain routes use authenticated tenant middleware',()=>{
  for(const name of tenantMiddlewareRoutes) assert.match(readRoute(name), /requireTenant/, `${name} must derive tenant context server-side`);
});

test('member, loan, installment and payment mutations require server RBAC',()=>{
  const permissions = {
    'members.js':'member\.(create|update|delete)',
    'loans.js':'loan\.(create|update|approve|status\.update|delete)',
    'installments.js':'loan\.schedule\.update',
    'payments.js':'payment\.(create|cancel|reverse)'
  };
  for(const [name,pattern] of Object.entries(permissions)) assert.match(readRoute(name),new RegExp(`requirePermission\\(['\"](?:${pattern})`));
});

test('payment posting is transaction protected and row-locks financial state',()=>{
  assert.match(readService('payments.js'),/repository\.begin\(\)/);
  assert.match(readService('payments.js'),/await tx\.commit\(\)/);
  assert.match(readService('payments.js'),/await tx\.rollback\(\)/);
  assert.match(repo,/FOR UPDATE/);
  assert.match(repo,/UPDATE installments SET paid_amount/);
  assert.match(repo,/UPDATE loans SET outstanding_amount/);
});

test('payment posting supports organization-scoped idempotency',()=>{
  assert.match(readService('payments.js'),/Idempotency-Key|idempotency-key/);
  assert.match(repo,/p\.organization_id=\$1/);
  assert.match(repo,/p\.idempotency_key/);
});

test('financial mutation paths never trust client organization_id as tenant authority',()=>{
  for(const name of ['members.js','loans.js','installments.js','payments.js']) {
    const src=readService(name);
    assert.doesNotMatch(src,/context\.body\.organization_id|context\.body\?\.organization_id/,`${name} must not derive tenant from request body`);
  }
});

test('production environment forbids insecure DB SSL and wildcard CORS', () => {
  const src = fs.readFileSync(path.join(root,'server/config/env.js'),'utf8');
  assert.match(src, /DATABASE_SSL=disable.*not allowed|databaseSsl === 'disable'/s);
  assert.match(src, /CORS_ORIGIN.*required in production/);
  assert.match(src, /corsOrigin\.includes\('\*'\).*production/);
});

test('production errors do not expose internal error messages', () => {
  const src = fs.readFileSync(path.join(root,'server/middleware/errorHandler.js'),'utf8');
  assert.match(src, /NODE_ENV === 'production'/);
  assert.match(src, /Internal server error/);
});

test('real PostgreSQL validation remains a hard gate when DATABASE_URL is absent', () => {
  const src = fs.readFileSync(path.join(root,'scripts/validate-production-db.js'),'utf8');
  assert.match(src, /DATABASE_URL/);
  assert.match(src, /process\.exit\(1\)|throw/);
});
