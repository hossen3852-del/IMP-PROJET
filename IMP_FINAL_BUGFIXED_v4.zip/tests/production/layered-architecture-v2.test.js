'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('layered architecture directories exist',()=>{
  for(const dir of ['server/controllers','server/services','server/repositories']) assert.equal(fs.existsSync(path.join(root,dir)),true,dir);
});

test('repository exposes named queries and transactions, not a raw pool',()=>{
  const source=read('server/repositories/index.js');
  assert.match(source,/async function queryNamed/);
  assert.match(source,/async function begin/);
  assert.match(source,/async function withTransaction/);
  assert.doesNotMatch(source,/module\.exports[^\n]*pool/);
  assert.doesNotMatch(read('server/repositories/dbRepository.js'),/\.pool\b/);
});

test('controller boundary exports async adapter wrappers',()=>{
  const {handler,serviceMiddleware}=require(path.join(root,'server/controllers/controller'));
  assert.equal(typeof handler(async()=>({kind:'application-result',status:200,body:{ok:true}})), 'function');
  assert.equal(typeof serviceMiddleware(async()=>null), 'function');
});

test('financial transaction service delegates to repository transaction boundary',()=>{
  const source=read('server/services/transactionService.js');
  assert.match(source,/executeFinancialTransaction/);
  assert.match(source,/repository\.withTransaction/);
});
