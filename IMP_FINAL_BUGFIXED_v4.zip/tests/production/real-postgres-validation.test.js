'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const scriptPath = path.join(__dirname, '../../scripts/validate-production-db.js');
const migrationsDir = path.join(__dirname, '../../database/migrations');

test('11.P.12 ships a real PostgreSQL validation harness', () => {
  if (!fs.existsSync(scriptPath)) throw new Error('Missing PostgreSQL validation harness');
  const source = fs.readFileSync(scriptPath, 'utf8');
  if (!source.includes('DATABASE_URL is required')) throw new Error('Validator must require a real DATABASE_URL');
  if (!source.includes("new Client")) throw new Error('Validator must use PostgreSQL client');
});

test('production migration chain is complete and ordered through dashboard/savings/expense modules', () => {
  const versions = fs.readdirSync(migrationsDir).filter(f => f.endsWith('.sql')).sort().map(f => f.replace(/\.sql$/, ''));
  const expected = [
    '001_production_foundation','002_core_domain','003_auth_api','004_organization_branch_api',
    '005_rbac_api','006_tenant_isolation','007_member_api','008_loan_api',
    '009_installment_api','010_payment_api_transaction','011_dashboard_capital','012_savings_expense_cards',
    '013_member_nominee_registration',
    '014_daily_collection_field_officer','015_loan_interest_rate','015_settings_photo_storage','016_security_branch_scope',
    '017_member_nid_unique','018_users_email_global_unique',
    '019_repair_dashboard_savings_expense_permissions',
    '020_repair_dashboard_savings_expense_permissions_final',
    '021_commercial_expansion','022_financial_gl_integration','023_v6_0_3_adjustment_hardening','024_v6_0_5_idempotency_notification_claim','025_v6_0_6_financial_adjustment_integrity','026_v6_0_9_bugfix_rbac_gl','027_v6_0_10_bugfix_daily_collection','028_single_org_manual_loan_savings','029_admin_credentials_settings','030_v6_0_15_collection_loan_extensions','031_v6_0_17_legacy_loans_shares_ui_visibility','032_v6_0_17_rbac_settings_dashboard_repair'
  ];
  assert.deepStrictEqual(versions, expected);
});

test('11.P.12 validator explicitly fails without DATABASE_URL', () => {
  const source = fs.readFileSync(scriptPath, 'utf8');
  assert.match(source, /if \(!process\.env\.DATABASE_URL\) throw new Error\('DATABASE_URL is required/);
});
