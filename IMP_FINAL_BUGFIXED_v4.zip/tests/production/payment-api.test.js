'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'); const path=require('node:path');
const root=path.resolve(__dirname,'../..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const routes=read('server/routes/payments.js');
const controller=read('server/controllers/payments.js');
const service=read('server/services/paymentsService.js');
const repo=read('server/repositories/queryRegistry.js');
const app=read('server/app.js');
const migration=read('database/migrations/010_payment_api_transaction.sql');
const api=read('js/payments/payment-api.js');
const entry=read('js/payments/paymentEntry.js');
const history=read('js/payments/paymentHistory.js');

test('11.P.10 payment API is registered',()=>{assert.match(app,/require\('\.\/routes\/payments'\)/);assert.match(app,/app\.use\('\/api\/payments', payments\)/);});

test('payment API exposes posting, lookup, allocations, cancellation, reversal and receipt',()=>{
  for(const x of ["router.get('/',","router.post('/',","router.get('/collection-report',","router.get('/reconciliation',","router.get('/:id',","router.get('/:id/allocations',","router.post('/:id/cancel',","router.post('/:id/reverse',","router.get('/:id/receipt',"]){assert.match(routes,new RegExp(x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));}
  assert.match(controller,/require\(['"]\.\.\/services\/paymentsService\.js['"]\)/);
});

test('payment creation is transactional and idempotent',()=>{assert.match(service,/repository\.begin\(\)/);assert.match(service,/await tx\.begin\(\)/);assert.match(service,/await tx\.commit\(\)/);assert.match(service,/await tx\.rollback\(\)/);assert.match(service,/Idempotency-Key|idempotency-key/);assert.match(repo,/idempotency_key/);});
test('payment posting locks loan and installments and updates balances in repository',()=>{assert.match(repo,/FOR UPDATE/);assert.match(repo,/UPDATE installments SET paid_amount/);assert.match(repo,/UPDATE loans SET outstanding_amount/);});
test('payment API uses canonical permissions and tenant middleware',()=>{assert.match(routes,/requirePermission\('payment\.view'\)/);assert.match(routes,/requirePermission\('payment\.create'\)/);assert.match(routes,/requirePermission\('payment\.cancel'\)/);assert.match(routes,/requirePermission\('payment\.reverse'\)/);assert.match(routes,/requireTenant/);assert.doesNotMatch(service,/req\.body\.organizationId/);});
test('payment API creates and voids receipts server-side',()=>{assert.match(repo,/INSERT INTO payment_receipts/);assert.match(repo,/UPDATE payment_receipts SET status='void'/);});
test('payment migration adds allocation lifecycle and sequences',()=>{assert.match(migration,/payment_number_seq/);assert.match(migration,/receipt_number_seq/);assert.match(migration,/payment_allocations ADD COLUMN IF NOT EXISTS status/);assert.match(migration,/010_payment_api_transaction/);});
test('frontend payment entry posts to API and does not persist payment locally',()=>{assert.match(api,/IMP_API/);assert.match(entry,/await PaymentAPI\.create/);assert.doesNotMatch(entry,/createPayment\(/);});
test('frontend payment history is API-backed',()=>{assert.match(history,/await PaymentAPI\.list/);assert.doesNotMatch(history,/getPaymentHistory\(\s*filters/);});
