'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ROOT=path.resolve(__dirname,'../..');
const read=f=>fs.readFileSync(path.join(ROOT,f),'utf8');

test('V5.1 compatibility layer remains removed',()=>assert.equal(fs.existsSync(path.join(ROOT,'server/_v4_controllers')),false));
test('all routes are SQL-free',()=>{
  for(const f of fs.readdirSync(path.join(ROOT,'server/routes')).filter(x=>x.endsWith('.js'))){
    const s=read(`server/routes/${f}`);
    assert.doesNotMatch(s,/pool\.(query|connect)/);
    assert.doesNotMatch(s,/\bSELECT\s+|\bINSERT\s+INTO\s+|\bUPDATE\s+[a-z_]+\s+SET\b|\bDELETE\s+FROM\b/i);
  }
});
test('all controllers are DB-free',()=>{
  for(const f of fs.readdirSync(path.join(ROOT,'server/controllers')).filter(x=>x.endsWith('.js'))){
    const s=read(`server/controllers/${f}`);
    assert.doesNotMatch(s,/require\(['"]\.\.\/config\/db['"]\)/);
    assert.doesNotMatch(s,/pool\.(query|connect)|client\.(query|connect)/);
  }
});
test('all services are HTTP and raw-pool free',()=>{
  for(const f of fs.readdirSync(path.join(ROOT,'server/services')).filter(x=>x.endsWith('.js'))){
    const s=read(`server/services/${f}`);
    assert.doesNotMatch(s,/router\.(get|post|put|patch|delete|use)\s*\(/);
    assert.doesNotMatch(s,/\b(req|res|reply)\./);
    assert.doesNotMatch(s,/require\(['"]\.\.\/config\/db['"]\)/);
    assert.doesNotMatch(s,/\bpool\.(query|connect)\s*\(/);
    assert.doesNotMatch(s,/repository\.pool/);
  }
});
