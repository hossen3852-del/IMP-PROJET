const test = require('node:test');
const assert = require('node:assert/strict');
const { calculateCurrentBalance } = require('../../server/utils/dashboardKpis');

test('Current Balance uses previous capital + new capital and canonical components', () => {
  const value = calculateCurrentBalance({
    previousCapital: 10000,
    newCapital: 5000,
    installmentCollection: 3000,
    savings: 2000,
    insurance: 500,
    admissionFee: 300,
    loanDisbursement: 4000,
    savingsWithdrawal: 500,
    insuranceClaim: 100
  });
  assert.equal(value, 16200);
});

test('capital adjustment can reduce the capital base', () => {
  const value = calculateCurrentBalance({ previousCapital: 10000, newCapital: -1000 });
  assert.equal(value, 9000);
});
