'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const migrationsDir = path.resolve(__dirname, '../../database/migrations');
const foundation = fs.readFileSync(path.join(migrationsDir, '001_production_foundation.sql'), 'utf8');
const domain = fs.readFileSync(path.join(migrationsDir, '002_core_domain.sql'), 'utf8');

for (const table of [
  'organizations','users','sessions','permissions','role_permissions','audit_logs',
  'schema_migrations'
]) {
  test(`001 defines ${table}`, () => {
    assert.match(foundation, new RegExp(`CREATE TABLE IF NOT EXISTS ${table}\\b`, 'i'));
  });
}

for (const table of [
  'branches','members','member_nominees','member_documents','member_activities',
  'loans','installments','payments','payment_allocations','payment_receipts',
  'organization_settings','password_resets'
]) {
  test(`002 defines ${table}`, () => {
    assert.match(domain, new RegExp(`CREATE TABLE IF NOT EXISTS ${table}\\b`, 'i'));
  });
}

test('domain money fields use NUMERIC(18,2)', () => {
  for (const field of ['loan_amount','interest_amount','total_payable','installment_amount','paid_amount','outstanding_amount','amount']) {
    assert.match(domain, new RegExp(`${field}\\s+NUMERIC\\(18,2\\)`, 'i'));
  }
});

test('tenant-owned domain tables include organization_id', () => {
  for (const table of ['branches','members','member_nominees','member_documents','member_activities','loans','installments','payments','payment_allocations','payment_receipts','organization_settings']) {
    const block = domain.split(new RegExp(`CREATE TABLE IF NOT EXISTS ${table}\\b`, 'i'))[1];
    assert.ok(block, `${table} table block missing`);
    assert.match(block, /organization_id UUID NOT NULL REFERENCES organizations\(id\)/i);
  }
});

test('payments have an idempotency key unique per organization', () => {
  assert.match(domain, /CREATE UNIQUE INDEX IF NOT EXISTS payments_org_idempotency_idx/i);
  assert.match(domain, /ON payments\(organization_id,idempotency_key\)/i);
});

test('payment receipt is unique per organization and payment', () => {
  assert.match(domain, /UNIQUE\(organization_id,payment_id\)/i);
});

test('password storage remains hash-only', () => {
  assert.match(foundation, /password_hash TEXT NOT NULL/i);
  assert.doesNotMatch(foundation, /password VARCHAR/i);
});

test('migration runner exists and is wired to package script', () => {
  const runner = fs.readFileSync(path.resolve(__dirname, '../../server/db/migrate.js'), 'utf8');
  const pkg = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../../package.json'), 'utf8'));
  assert.match(runner, /schema_migrations/);
  assert.equal(pkg.scripts['db:migrate'], 'node server/db/migrate.js');
});
