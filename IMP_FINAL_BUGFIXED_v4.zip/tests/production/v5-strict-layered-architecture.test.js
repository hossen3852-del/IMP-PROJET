'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const jsFiles=dir=>fs.readdirSync(path.join(root,dir)).filter(f=>f.endsWith('.js'));

const serviceHttp=/\brequire\(['"]express['"]\)|\brouter\.(get|post|put|patch|delete|use)\s*\(|\b(req|res|reply)\.|\bnext\s*\(|\.sendFile\s*\(|\.status\s*\(|\.json\s*\(/i;
const serviceDb=/require\(['"]\.\.\/config\/db['"]\)|\b(pool|client)\.(query|connect)\s*\(|\bpool\b\s*[,}]/i;
const controllerDb=/require\(['"]\.\.\/config\/db['"]\)|\b(pool|client)\.(query|connect)\s*\(/i;
const repositoryOnlyDb=/require\(['"]\.\.\/config\/db['"]\)/;

test('final route layer is the only domain layer that declares Express routes',()=>{
  const files=jsFiles('server/routes');
  assert.ok(files.length>=15);
  for(const f of files){
    const s=read(`server/routes/${f}`);
    if(f==='transaction.js') continue;
    assert.match(s,/require\(['"]express['"]\)/,`${f} must own Express router creation`);
    assert.match(s,/require\(['"]\.\.\/controllers\//,`${f} must delegate to a controller`);
    assert.doesNotMatch(s,/\b(pool|client)\.(query|connect)\s*\(/,`${f} bypasses repository`);
    assert.doesNotMatch(s,/\bSELECT\s+|\bINSERT\s+INTO\s+|\bUPDATE\s+[a-z_]+\s+SET\b|\bDELETE\s+FROM\b/i,`${f} contains SQL`);
  }
});

test('controller layer contains HTTP adapter logic only',()=>{
  for(const f of jsFiles('server/controllers')){
    if(f==='controller.js'||f==='index.js'||f==='transaction.js') continue;
    const s=read(`server/controllers/${f}`);
    assert.match(s,/require\(['"]\.\.\/services\/[^"']+Service\.js['"]\)/,`${f} must import its service`);
    assert.doesNotMatch(s,controllerDb,`${f} bypasses repository`);
    assert.doesNotMatch(s,/\bSELECT\s+|\bINSERT\s+INTO\s+|\bUPDATE\s+[a-z_]+\s+SET\b|\bDELETE\s+FROM\b/i,`${f} contains SQL`);
    assert.match(s,/handler\(/,`${f} must adapt service handlers`);
  }
});

test('service layer is HTTP-free and DB-free',()=>{
  for(const f of jsFiles('server/services')){
    const s=read(`server/services/${f}`);
    assert.doesNotMatch(s,serviceHttp,`${f} still contains an HTTP adapter concern`);
    assert.doesNotMatch(s,serviceDb,`${f} still bypasses repository`);
  }
});

test('repository layer is the PostgreSQL boundary',()=>{
  assert.match(read('server/repositories/index.js'),repositoryOnlyDb);
  assert.match(read('server/repositories/queryRegistry.js'),/module\.exports\s*=\s*Object\.freeze\(queries\)/);
  assert.doesNotMatch(read('server/repositories/dbRepository.js'),/\.pool\b/);
});

test('raw SQL exists only in repository query registry among application layers',()=>{
  const offenders=[];
  for(const dir of ['routes','controllers','services']){
    for(const f of jsFiles(`server/${dir}`)){
      const s=read(`server/${dir}/${f}`);
      if(/\bSELECT\s+|\bINSERT\s+INTO\s+|\bUPDATE\s+[a-z_]+\s+SET\b|\bDELETE\s+FROM\b/i.test(s)) offenders.push(`${dir}/${f}`);
    }
  }
  assert.deepEqual(offenders,[]);
});

test('legacy V4 compatibility layer is absent',()=>assert.equal(fs.existsSync(path.join(root,'server/_v4_controllers')),false));
