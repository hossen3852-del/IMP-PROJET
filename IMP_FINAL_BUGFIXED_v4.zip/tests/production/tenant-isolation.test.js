'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../..');
const migration = fs.readFileSync(path.join(root, 'database/migrations/006_tenant_isolation.sql'), 'utf8');
const auth = fs.readFileSync(path.join(root, 'server/middleware/auth.js'), 'utf8');
const tenant = fs.readFileSync(path.join(root, 'server/middleware/tenant.js'), 'utf8');
const authRepo = fs.readFileSync(path.join(root, 'server/repositories/queryRegistry.js'), 'utf8');

for (const table of ['users','members','loans','installments','payments','payment_allocations']) {
  test(`11.P.6 composite parent key exists for ${table}`, () => {
    assert.match(migration, new RegExp(`${table}_org_id_uidx`));
  });
}

test('session tenant must match session user tenant', () => {
  assert.match(migration, /sessions_user_org_fk/);
  assert.match(migration, /REFERENCES users\(organization_id,id\)/);
});

test('user role cannot cross organization boundary', () => {
  assert.match(migration, /enforce_user_role_tenant/);
  assert.match(migration, /User role belongs to another organization/);
  assert.match(migration, /users_role_tenant_trg/);
});

test('member child records cannot reference another tenant member', () => {
  for (const name of ['member_nominee_member_org_fk','member_document_member_org_fk','member_activity_member_org_fk']) {
    assert.match(migration, new RegExp(name));
  }
});

test('loan and installment relationships are tenant-bound', () => {
  assert.match(migration, /loans_member_org_fk/);
  assert.match(migration, /installments_loan_org_fk/);
  assert.match(migration, /REFERENCES loans\(organization_id,id\)/);
});

test('payment relationships are tenant-bound', () => {
  for (const name of ['payments_member_org_fk','payments_loan_org_fk','payment_allocations_payment_org_fk','payment_allocations_loan_org_fk','payment_allocations_installment_org_fk','payment_receipts_payment_org_fk']) {
    assert.match(migration, new RegExp(name));
  }
});

test('tenant-scoped actor references are protected', () => {
  for (const name of ['branches_created_by_org_fk','members_created_by_org_fk','loans_created_by_org_fk','payments_created_by_org_fk','payment_receipts_issued_by_org_fk','organization_settings_updated_by_org_fk']) {
    assert.match(migration, new RegExp(name));
  }
});

test('authentication derives tenant from server session and verifies role scope', () => {
  assert.match(auth, /findSessionContext/);
  assert.match(auth, /rows\[0\]\.organization_id/);
  assert.match(authRepo, /s\.organization_id/);
  assert.match(authRepo, /r\.organization_id=s\.organization_id/);
  assert.match(authRepo, /u\.role_id/);
  assert.match(authRepo, /role_permissions/);
});

test('tenant middleware never accepts a client tenant id', () => {
  assert.match(tenant, /req\.auth\.organization_id/);
  assert.doesNotMatch(tenant, /req\.body\.organization_id/);
  assert.doesNotMatch(tenant, /req\.query\.organization_id/);
});

test('migration is registered as 006_tenant_isolation', () => {
  assert.match(migration, /006_tenant_isolation/);
});
