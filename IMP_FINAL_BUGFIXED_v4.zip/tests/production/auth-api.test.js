'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const service=read('server/services/authService.js');
const routes=read('server/routes/auth.js');
const controller=read('server/controllers/auth.js');
const repo=read('server/repositories/queryRegistry.js');
const authMiddleware=read('server/middleware/auth.js');
const session=read('js/auth/session.js');
const auth=read('js/auth/auth.js');
const api=read('js/core/api.js');
const migration=read('database/migrations/003_auth_api.sql');

for(const route of ['/login','/me','/logout','/logout-all','/password-reset/request','/password-reset/confirm']){
  test(`authentication API exposes ${route}`,()=>assert.match(routes,new RegExp(`router\\.(post|get)\\(["']${route.replace('/','\\/')}["']`)));
}

test('every authentication controller adapter has a real service export',()=>{
  assert.match(service,/module\.exports\s*=\s*\{[\s\S]*put_admin_credentials_8[\s,}]/);
  assert.match(controller,/handler\(service\.put_admin_credentials_8\)/);
});

test('authentication routes delegate to controller adapters',()=>{
  assert.match(controller,/require\(['"]\.\.\/services\/authService\.js['"]\)/);
  assert.doesNotMatch(routes,/router\.post\(['"]\/register/);
  assert.doesNotMatch(routes,/controller\.post_register_1/);
  assert.match(routes,/controller\.post_login_2/);
  assert.match(routes,/controller\.get_me_3/);
});

test('passwords are Argon2id hashed server-side',()=>{
  assert.match(service,/argon2\.hash\(data\.password, \{ type: argon2\.argon2id \}\)/);
  assert.match(service,/argon2\.hash\(password, \{ type: argon2\.argon2id \}\)/);
  assert.match(service,/argon2\.verify\(user\.password_hash, password\)/);
});

test('session token remains HttpOnly cookie and is never returned to frontend',()=>{
  assert.match(service,/httpOnly:\s*true/);
  assert.doesNotMatch(service,/json\(\{[^}]*sessionToken/);
  assert.match(authMiddleware,/hashSessionToken\(token\)/);
});

test('frontend auth uses API and does not persist passwords or session tokens',()=>{
  assert.match(api,/credentials:\s*['"]include['"]/);
  assert.match(auth,/IMP_API\.post\(['"]\/auth\/login/);
  assert.doesNotMatch(auth,/localStorage/);
  assert.match(session,/IMP_API\.get\(['"]\/auth\/me/);
  assert.doesNotMatch(session,/Storage\.KEYS\.SESSION/);
});

test('organization registration is transactional through repository boundary',()=>{
  assert.match(service,/const tx = await repository\.begin\(\)/);
  assert.match(service,/await tx\.begin\(\)/);
  assert.match(service,/await tx\.commit\(\)/);
  assert.match(service,/await tx\.rollback\(\)/);
  assert.doesNotMatch(service,/client\.query\(/);
  assert.match(repo,/authService\.js:31:3/);
  assert.match(repo,/authService\.js:48:6/);
});

test('users have server-owned full_name and globally unique login email',()=>{
  assert.match(migration,/ADD COLUMN IF NOT EXISTS full_name VARCHAR\(200\)/i);
  assert.match(migration,/users_lower_email_unique_idx/i);
});

test('password reset SQL is repository-owned',()=>{
  assert.match(service,/hashSessionToken\(token\)/);
  assert.match(repo,/expires_at>NOW\(\)/);
  assert.match(repo,/used_at IS NULL/);
  assert.match(repo,/UPDATE password_resets SET used_at=NOW\(\)/);
  assert.match(repo,/UPDATE sessions SET revoked_at=NOW\(\)/);
});

test('password reset request does not reveal whether an account exists',()=>assert.match(service,/If the account exists, a password reset link has been created/));

test('forgot-password and reset pages exist',()=>{
  const forgot=read('pages/auth/forgot-password.html');
  const reset=read('pages/auth/reset-password.html');
  assert.match(forgot,/id="resetRequestForm"/); assert.match(forgot,/password-reset\.js/);
  assert.match(reset,/id="resetPasswordForm"/); assert.match(reset,/name="viewport"/);
});

test('password reset frontend accepts token from reset-link query string',()=>{
  const resetJs=read('js/auth/password-reset.js');
  assert.match(resetJs,/URLSearchParams/); assert.match(resetJs,/get\(['"]token['"]\)/); assert.match(resetJs,/AuthManager\.resetPassword/);
});
