const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '../..');
const pages = [];
function walk(dir){
  for(const name of fs.readdirSync(dir)){
    const p=path.join(dir,name); const st=fs.statSync(p);
    if(st.isDirectory()) walk(p);
    else if(p.endsWith('.html')) pages.push(p);
  }
}
walk(ROOT);

test('all HTML pages load the shared Bangla/English i18n module', ()=>{
  assert.ok(pages.length >= 40);
  const uiPages = pages.filter(p => fs.statSync(p).size > 0);
  assert.ok(uiPages.length >= 40);
  for(const p of uiPages){
    const html=fs.readFileSync(p,'utf8');
    assert.match(html,/js\/core\/i18n\.js/,path.relative(ROOT,p));
    assert.match(html,/css\/i18n\.css/,path.relative(ROOT,p));
  }
});

test('i18n module provides Bengali default and English switch without server authority', ()=>{
  const src=fs.readFileSync(path.join(ROOT,'js/core/i18n.js'),'utf8');
  assert.match(src,/document\.cookie/);
  assert.match(src,/setLang\(v\)/);
  assert.match(src,/v==='en'\?'en':'bn'/);
  assert.doesNotMatch(src,/IMP_API\.(post|put|patch|delete)/);
});

test('language preference is explicitly UI-only', ()=>{
  const src=fs.readFileSync(path.join(ROOT,'js/core/i18n.js'),'utf8');
  assert.match(src,/UI i18n/);
  assert.match(src,/imp_ui_language/);
});
