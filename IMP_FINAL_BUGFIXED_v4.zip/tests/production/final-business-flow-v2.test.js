'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '../..');

test('Capital API accepts only opening capital, adjustment and withdrawal', () => {
  const route = fs.readFileSync(path.join(root, 'server/services/capitalService.js'), 'utf8');
  assert.match(route, /const ENTRY_TYPES = \[\s*'capital_in', 'capital_adjustment', 'capital_withdrawal'\s*\]/);
  assert.doesNotMatch(route, /'admission_fee_new'|'insurance_new'|'insurance_claim'/);
});

test('Insurance API cannot create a premium outside Loan Disbursement', () => {
  const route = fs.readFileSync(path.join(root, 'server/services/insuranceService.js'), 'utf8');
  assert.match(route, /const TX_TYPES = \['claim'\]/);
  assert.doesNotMatch(route, /const TX_TYPES = \[[^\]]*'premium'/);
});

test('Daily Collection formula excludes admission fee and insurance', () => {
  const kpi = fs.readFileSync(path.join(root, 'server/utils/dashboardKpis.js'), 'utf8');
  assert.match(kpi, /return n\(installmentCollection\) \+ n\(savings\) - n\(dailyExpense\)/);
  const dailyFn = kpi.match(/function calculateDailyCollection[\s\S]*?\n}\n/);
  assert.ok(dailyFn);
  assert.doesNotMatch(dailyFn[0], /admissionFee|insurance/);
});

test('Dashboard daily collection does not query admission fee', () => {
  const route = fs.readFileSync(path.join(root, 'server/services/dashboardService.js'), 'utf8');
  assert.doesNotMatch(route, /todayAdmissionFee/);
  assert.doesNotMatch(route, /entry_type IN \('admission_fee','admission_fee_new'\)/);
});

test('Capital UI exposes only the three permitted manual entry types', () => {
  const html = fs.readFileSync(path.join(root, 'pages/capital/capital.html'), 'utf8');
  assert.match(html, /value="capital_in"/);
  assert.match(html, /value="capital_adjustment"/);
  assert.match(html, /value="capital_withdrawal"/);
  assert.doesNotMatch(html, /value="admission_fee"|value="insurance"|value="insurance_claim"/);
});

test('All HTML pages include viewport and shared mobile responsive stylesheet', () => {
  const pages = [];
  const walk = dir => { for (const entry of fs.readdirSync(dir, { withFileTypes: true })) { const full = path.join(dir, entry.name); if (entry.isDirectory()) walk(full); else if (entry.name.endsWith('.html')) pages.push(full); } };
  walk(root);
  assert.ok(pages.length >= 45);
  for (const file of pages) {
    const html = fs.readFileSync(file, 'utf8');
    assert.match(html, /name="viewport"/);
    assert.match(html, /mobile-responsive\.css/);
  }
});
