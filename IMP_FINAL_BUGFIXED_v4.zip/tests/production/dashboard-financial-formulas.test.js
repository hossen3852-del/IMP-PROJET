'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {
  calculateCurrentBalance,
  calculateLoanBalance,
  calculateDailyCollection,
  calculateTotalSavings,
  calculateTotalInsurance,
  calculateTotalAdmissionFee,
  calculateTotalExpense
} = require('../../server/utils/dashboardKpis');

const root = path.resolve(__dirname, '../..');

test('dashboard exposes the seven required financial KPI cards', () => {
  const app = fs.readFileSync(path.join(root, 'js/app.js'), 'utf8');
  for (const key of ['currentCapital','loanBalance','todayCollection','totalSavings','insurance','admissionFee','totalExpense']) {
    assert.match(app, new RegExp(`${key}\\s*:`));
  }
});

test('Current Balance follows the required formula', () => {
  assert.equal(calculateCurrentBalance({ installmentCollection: 10000, savings: 5000, insurance: 2000, admissionFee: 1000, loanDisbursement: 12000, savingsWithdrawal: 500, insuranceClaim: 300 }), 5200);
});

test('Loan follows loan + reloan + interest - collection - savings installment formula', () => {
  assert.equal(calculateLoanBalance({ loanDisbursement: 50000, reloan: 10000, interest: 5000, collection: 20000, savingsInstallmentPayment: 3000 }), 42000);
});

test('Daily Collection follows installment + savings - daily expense', () => {
  assert.equal(calculateDailyCollection({ installmentCollection: 12000, savings: 3000, dailyExpense: 2500 }), 12500);
});

test('Total Savings follows savings + daily savings - withdrawal - savings installment', () => {
  assert.equal(calculateTotalSavings({ savings: 20000, dailySavings: 5000, withdrawal: 3000, savingsInstallmentPayment: 4000 }), 18000);
});

test('Total Insurance follows insurance + new insurance - conditional payout', () => {
  assert.equal(calculateTotalInsurance({ insurance: 10000, newInsurance: 2500, conditionalPayout: 1500 }), 11000);
});

test('Total Admission Fee follows admission fee + new admission fee', () => {
  assert.equal(calculateTotalAdmissionFee({ admissionFee: 5000, newAdmissionFee: 1200 }), 6200);
});

test('Total Expense follows office + travel + equipment only', () => {
  assert.equal(calculateTotalExpense({ officeExpense: 1000, travelExpense: 500, equipmentExpense: 1500 }), 3000);
});

test('expense summary implements the required three-category total', () => {
  const route = fs.readFileSync(path.join(root, 'server/services/expensesService.js'), 'utf8');
  assert.match(route, /total: office \+ travel \+ equipment/);
});

test('dashboard uses Bangladesh local date for daily KPI boundaries', () => {
  const route = fs.readFileSync(path.join(root, 'server/services/dashboardService.js'), 'utf8');
  assert.ok(route.includes("timeZone: 'Asia/Dhaka'"));
  assert.doesNotMatch(route, /new Date\(\)\.toISOString\(\)\.slice\(0, 10\)/);
});

test('savings balance-changing transactions lock the member row', () => {
  const repo = fs.readFileSync(path.join(root, 'server/repositories/queryRegistry.js'), 'utf8');
  assert.match(repo, /SELECT id FROM members WHERE id=\$1 AND organization_id=\$2 FOR UPDATE/);
});


test('dashboard, capital, savings and expense APIs are registered', () => {
  const app = fs.readFileSync(path.join(root, 'server/app.js'), 'utf8');
  for (const route of ['/api/dashboard', '/api/capital', '/api/savings', '/api/expenses']) assert.match(app, new RegExp(route.replace('/', '\\/')));
});

test('dashboard default configuration starts with the seven required cards', () => {
  const route = fs.readFileSync(path.join(root, 'server/services/dashboardService.js'), 'utf8');
  const settings = fs.readFileSync(path.join(root, 'js/settings/dashboard-settings.js'), 'utf8');
  for (const key of ['currentCapital','loanBalance','todayCollection','totalSavings','insurance','admissionFee','totalExpense']) {
    assert.match(route, new RegExp(`key: ['\"]${key}['\"]`));
    assert.match(settings, new RegExp(`key: [\"]${key}[\"]`));
  }
});
