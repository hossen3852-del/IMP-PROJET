'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'../..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('V6.0.5 loan adjustments require an idempotency key and check existing operations',()=>{
 const s=read('server/services/commercialExpansionService.js');
 assert.match(s,/Idempotency-Key header is required for loan adjustments/);
 assert.match(s,/commercialExpansion:adjustmentExistingByIdempotency/);
 assert.match(s,/loan-adjustment|post_adjustment_6/s);
});

test('V6.0.5 adjustment persistence is tenant-scoped and idempotent',()=>{
 const q=read('server/repositories/queryRegistry.js');
 assert.match(q,/loan_adjustments\(organization_id,branch_id,member_id,loan_id,adjustment_type,amount,effective_date,reason,metadata,idempotency_key,created_by\)/);
 assert.match(read('database/migrations/024_v6_0_5_idempotency_notification_claim.sql'),/loan_adjustments_org_idempotency_idx/);
 assert.match(q,/commercialExpansion:adjustmentExistingByIdempotency/);
});

test('V6.0.5 notification worker claims rows atomically with SKIP LOCKED',()=>{
 const q=read('server/repositories/queryRegistry.js');
 const s=read('scripts/process-notification-outbox.js');
 assert.match(q,/commercialExpansion:notificationsClaim/);
 assert.match(q,/FOR UPDATE SKIP LOCKED/);
 assert.match(q,/status='processing'/);
 assert.match(s,/notificationsClaim/);
});

test('V6.0.5 notification worker persists provider message ids',()=>{
 const q=read('server/repositories/queryRegistry.js');
 const s=read('scripts/process-notification-outbox.js');
 assert.match(q,/provider_message_id=\$5/);
 assert.match(s,/providerMessageId\?\?/);
});

test('V6.0.5 notification schema permits processing state',()=>{
 const m=read('database/migrations/024_v6_0_5_idempotency_notification_claim.sql');
 assert.match(m,/notification_outbox_status_check/);
 assert.match(m,/processing/);
 assert.match(m,/024_v6_0_5_idempotency_notification_claim/);
});
