'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('V6.0.17 version metadata is internally synchronized',()=>{const p=JSON.parse(read('package.json'));const l=JSON.parse(read('package-lock.json'));assert.equal(p.version,'1.6.17');assert.equal(l.version,p.version);assert.equal(l.packages[''].version,p.version);});

test('Installment schedule skips Friday for every frequency when enabled',()=>{const s=read('server/services/loansService.js');assert.match(s,/function loanAddPeriod\(date, frequency, n, skipFriday = true\)/);assert.match(s,/skipFriday && dt\.getUTCDay\(\) === 5/);assert.match(s,/loanAddPeriod\(firstDate, loan\.installment_frequency, n - 1, skipFriday\)/);});

test('Full settlement marks a zero-balance loan completed',()=>{const q=read('server/repositories/queryRegistry.js');assert.match(q,/collectionsService\.js:750:70[\s\S]*status=\s*CASE[\s\S]*WHEN \$1::numeric=0[\s\S]*THEN 'completed'/);});

test('Legacy member import page is mobile and i18n enabled',()=>{const h=read('pages/members/member-import.html');assert.match(h,/mobile-responsive\.css/);assert.match(h,/core\/i18n\.js/);});

test('Advance setting defaults are consistent',()=>{const a=read('server/services/settingsService.js');const b=read('js/settings/payment-settings.js');assert.match(a,/allowAdvanceDefault: true/);assert.match(b,/allowAdvance: true/);assert.match(b,/allowAdvanceDefault: true/);});

test('Member deletion blocks open approved or active loans',()=>{const q=read('server/repositories/queryRegistry.js');assert.match(q,/membersService\.js:delete:activeLoan[\s\S]*status NOT IN \('completed','cancelled','rejected'\)/);});

test('Legacy CSV importer handles quoted commas and escaped quotes',()=>{const s=read('js/members/member-import.js');assert.match(s,/RFC-4180 compatible CSV parser/);assert.match(s,/next === '"'/);assert.match(s,/else if \(ch === ','\)/);});
