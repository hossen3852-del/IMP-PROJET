'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('V6.0.4 never exposes the project root as a public static directory',()=>{
  const s=read('server/app.js');
  assert.doesNotMatch(s,/express\.static\(path\.join\(__dirname, '\.\.'\)\)/);
  assert.match(s,/app\.use\('\/pages', express\.static/);
  assert.match(s,/app\.use\('\/js', express\.static/);
  assert.match(s,/app\.use\('\/css', express\.static/);
  assert.match(s,/app\.use\('\/assets', express\.static/);
});

test('V6.0.4 commercial reports enforce caller branch scope',()=>{
  const s=read('server/services/commercialExpansionService.js');
  assert.match(s,/get_reports_11\(ctx\).*branch\(ctx,ctx\.query\.branchId\)/s);
  assert.match(s,/get_mra_12\(ctx\).*branch\(ctx,ctx\.query\.branchId\)/s);
  assert.match(s,/get_gl_summary_15\(ctx\).*branch\(ctx,ctx\.query\.branchId\)/s);
  assert.match(s,/get_ops_16\(ctx\).*branch\(ctx,ctx\.query\.branchId\)/s);
  assert.match(s,/get_passbook_8\(ctx\).*branch\(ctx,ctx\.query\.branchId\)/s);
  assert.match(s,/get_adjustments_7\(ctx\).*branch\(ctx,ctx\.query\.branchId\)/s);
});

test('V6.0.4 commercial report SQL is branch-filtered and aggregate-safe',()=>{
  const s=read('server/repositories/queryRegistry.js');
  for(const q of ['commercialExpansion:operationalReport','commercialExpansion:reportPortfolio','commercialExpansion:reportCollection','commercialExpansion:reportOverdue','commercialExpansion:reportBranches','commercialExpansion:reportCollectors','commercialExpansion:reportIncomeExpense','commercialExpansion:mraReport']) assert.match(s,new RegExp(q.replace(/[.*+?^${}()|[\\]\\]/g,'\\$&')));
  assert.match(s,/commercialExpansion:operationalReport.*SELECT \(SELECT COUNT\(\*\)/s);
  assert.match(s,/commercialExpansion:reportBranches.*SELECT COUNT\(\*\).*members/s);
  assert.match(s,/commercialExpansion:mraReport.*SELECT \$2::date AS from_date/s);
});

test('V6.0.4 GL summary filters journal entries before aggregating lines',()=>{
  const s=read('server/repositories/queryRegistry.js');
  assert.match(s,/commercialExpansion:glSummary.*FROM accounting_journal_lines l JOIN accounting_journal_entries j/s);
  assert.match(s,/j\.entry_date>=\$2::date/);
  assert.match(s,/j\.entry_date<=\$3::date/);
  assert.match(s,/j\.branch_id=\$4/);
});

test('V6.0.4 journals verify all accounts belong to the tenant',()=>{
  const s=read('server/services/commercialExpansionService.js');
  assert.match(s,/commercialExpansion:journalAccountsOwned/);
  assert.match(s,/do not belong to this organization/);
});

test('V6.0.4 notifications are branch scoped',()=>{
  const s=read('server/services/commercialExpansionService.js');
  assert.match(s,/Branch-scoped users must target a member/);
  assert.match(s,/commercialExpansion:notificationMember/);
  assert.match(s,/get_notifications_10\(ctx\).*branch\(ctx,ctx\.query\.branchId\)/s);
  const q=read('server/repositories/queryRegistry.js');
  assert.match(q,/commercialExpansion:notifications.*m\.branch_id=\$3/s);
});

test('V6.0.6 release versions are aligned',()=>{
  const pkg=JSON.parse(read('package.json'));
  const lock=JSON.parse(read('package-lock.json'));
  assert.match(pkg.version,/^1\.6\.\d+$/);
  assert.equal(lock.version,pkg.version);
  assert.equal(lock.packages[''].version,pkg.version);
});
