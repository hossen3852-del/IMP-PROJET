const test=require("node:test");
const assert=require("node:assert/strict");
const {createSessionToken,hashSessionToken}=require("../../server/utils/sessionToken");

test("session token is cryptographically random and hashes deterministically",()=>{
  const a=createSessionToken(), b=createSessionToken();
  assert.notEqual(a,b);
  assert.equal(hashSessionToken(a),hashSessionToken(a));
  assert.equal(hashSessionToken(a).length,64);
  assert.notEqual(hashSessionToken(a),a);
});

test("environment example does not contain a production secret",()=>{
  const fs=require("node:fs");
  const s=fs.readFileSync(".env.example","utf8");
  assert.match(s,/CHANGE_ME/);
});