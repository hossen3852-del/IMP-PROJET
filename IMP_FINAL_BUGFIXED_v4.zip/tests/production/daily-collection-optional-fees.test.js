'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '../..');

function read(name) { return fs.readFileSync(path.join(root, name), 'utf8'); }

test('daily collection is intentionally free of admission-fee and insurance inputs', () => {
  const html = read('pages/collections/daily-collection.html');
  const js = read('js/collections/daily-collection.js');
  const route = read('server/services/collectionsService.js');
  assert.doesNotMatch(html, /ভর্তি ফি|বীমা|totalAdmissionFee|totalInsurance/);
  assert.doesNotMatch(js, /in-admission-fee|in-insurance|toggle-admission-fee|toggle-insurance|admissionFeeAmount|insuranceAmount/);
  assert.doesNotMatch(route, /admissionFeeAmount|insuranceAmount/);
});

test('member registration owns the admission fee transaction', () => {
  const html = read('pages/members/member-add.html');
  const js = read('js/members/member-add.js');
  const route = read('server/services/membersService.js');
  const repository = read('server/repositories/queryRegistry.js');
  assert.match(html, /id="admissionFee"/);
  assert.match(js, /admissionFee:/);
  assert.match(route, /admissionFee:\s*z\.coerce\.number/);
  assert.match(repository, /entry_type, amount, entry_date/);
  assert.match(repository, /'admission_fee'/);
  assert.match(route, /member_registration/);
});

test('loan disbursement owns the insurance transaction', () => {
  const api = read('js/loans/loan.js');
  const ui = read('js/loans/loan-list.js');
  const route = read('server/services/loansService.js');
  const repository = read('server/repositories/queryRegistry.js');
  assert.match(api, /disburseLoan\(id\)/);
  assert.match(ui, /স্বয়ংক্রিয় বীমা/);
  assert.match(route, /Number\(lr\.loan_amount[^\n]*\* 0\.02/);
  assert.match(repository, /member_insurance_transactions/);
  assert.match(repository, /insurance_transaction.create|loan_disbursement/);
});
