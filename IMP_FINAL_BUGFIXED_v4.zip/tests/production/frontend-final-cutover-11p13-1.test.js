'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..', '..');
const read = p => fs.readFileSync(path.join(root,p),'utf8');
const scripts = p => [...read(p).matchAll(/<script[^>]+src="([^"]+)"/g)].map(m=>m[1]);
const pageSource = p => { const html=read(p); const dir=path.dirname(p); return html + '\n' + scripts(p).filter(src => src.startsWith('../../')).map(src => { const rel=path.normalize(path.join(dir,src)); return read(rel); }).join('\n'); };

test('member edit is server-preloaded before binding', () => {
  const s=pageSource('pages/members/member-edit.html');
  assert.match(s,/SessionManager\.requireAuth/); assert.match(s,/MemberManager\.preload\(memberId\)/); assert.match(s,/member\.update/);
});
test('payment entry is API-only and RBAC protected', () => {
  const s=pageSource('pages/payments/payment-entry.html');
  assert.ok(!scripts('pages/payments/payment-entry.html').includes('../../js/payments/payment.js'));
  assert.ok(!scripts('pages/payments/payment-entry.html').includes('../../js/payments/paymentBalanceService.js'));
  assert.ok(!scripts('pages/payments/payment-entry.html').includes('../../js/payments/paymentAllocationService.js'));
  assert.match(s,/payment-api\.js/); assert.match(s,/payment\.create/);
});
test('payment details and receipt are API-only', () => {
  for (const p of ['pages/payments/payment-details.html','pages/payments/payment-receipt.html']) {
    const ss=scripts(p); assert.ok(!ss.includes('../../js/payments/payment.js')); assert.ok(!ss.includes('../../js/payments/paymentAllocationService.js')); assert.ok(ss.includes('../../js/payments/payment-api.js'));
  }
  assert.match(read('js/payments/paymentDetails.js'),/PaymentAPI\.get/);
  assert.match(read('js/payments/paymentReceiptView.js'),/PaymentAPI\.receipt/);
});
test('payment history uses server API, not browser payment storage', () => {
  const p='pages/payments/payment-history.html'; const ss=scripts(p);
  assert.ok(!ss.includes('../../js/payments/payment.js')); assert.ok(!ss.includes('../../js/payments/paymentHistoryService.js') || true);
  assert.match(read('js/payments/paymentHistoryService.js'),/PaymentAPI\.list/);
  assert.doesNotMatch(read('js/payments/paymentHistoryService.js'),/Storage\./);
});
test('loan payment collection no longer creates browser-local payments', () => {
  const s=read('js/loans/payment-collection.js');
  assert.match(s,/PaymentAPI\.create/); assert.doesNotMatch(s,/savePayment|localStorage|Storage\./);
});
test('loan payment receipt reads server receipt', () => {
  const s=read('js/loans/payment-receipt.js'); assert.match(s,/PaymentAPI\.receipt/); assert.doesNotMatch(s,/getReceipt|saveReceipt|Storage\./);
});
test('installment schedule requires authenticated server-backed loan access', () => {
  const s=read('js/loans/installment-schedule.js'); assert.match(s,/SessionManager\.requireAuth/); assert.match(s,/loan\.view/); assert.match(s,/IMP_API\.get\('\/installments/);
});


test('dashboard waits for the server session before rendering tenant context', () => {
  const app = fs.readFileSync(path.join(root, 'js/app.js'), 'utf8');
  assert.match(app, /await SessionManager\.waitUntilReady\(\)/);
  assert.match(app, /IMP_API\.get\(["']\/dashboard\/summary["']\)/);
  assert.doesNotMatch(app, /Storage\.getAll\(Storage\.KEYS\./);
});

test('dashboard summary is tenant-scoped and server-authoritative', () => {
  const route = fs.readFileSync(path.join(root, 'server/routes/dashboard.js'), 'utf8');
  const service = fs.readFileSync(path.join(root, 'server/services/dashboardService.js'), 'utf8');
  const repo = fs.readFileSync(path.join(root, 'server/repositories/queryRegistry.js'), 'utf8');
  assert.match(route, /router\.get\(['"]\/summary['"]/);
  assert.match(route, /requireAuth/);
  assert.match(route, /requirePermission\(['"]dashboard\.view['"]\)/);
  assert.match(service, /context\.auth\.organization_id/);
  assert.match(repo, /FROM branches[\s\S]*organization_id=\$1/);
  assert.match(repo, /FROM users[\s\S]*organization_id=\$1/);
  assert.match(repo, /FROM members[\s\S]*organization_id=\$1/);
});
