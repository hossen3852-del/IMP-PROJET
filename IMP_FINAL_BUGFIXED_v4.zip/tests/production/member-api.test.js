'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const routes=read('server/routes/members.js');
const controller=read('server/controllers/members.js');
const service=read('server/services/membersService.js');
const repo=read('server/repositories/queryRegistry.js');
const app=read('server/app.js');
const migration=read('database/migrations/007_member_api.sql');
const frontend=read('js/members/member.js');

test('11.P.7 exposes member CRUD and child APIs in route layer',()=>{
  for(const method of ["router.get('/',","router.post('/',","router.get('/:id',","router.patch('/:id',","router.delete('/:id',"]){assert.match(routes,new RegExp(method.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));}
  for(const pathPart of ['/nominee','/documents','/activities','/family','/financial']) assert.ok(routes.includes(`'/:id${pathPart}`)||routes.includes(`/:id${pathPart}`));
  assert.match(controller,/require\(['"]\.\.\/services\/membersService\.js['"]\)/);
});
test('11.P.7 member routes are registered under /api/members',()=>assert.match(app,/app\.use\('\/api\/members', members\)/));
test('member service derives tenant from authenticated context',()=>{assert.match(service,/context\.auth\.organization_id/);assert.doesNotMatch(service,/req\.auth|tenantId\(req\)/);});
test('member list/detail queries are tenant scoped in repository',()=>{assert.match(repo,/SELECT \${MEMBER_LIST_COLUMNS} FROM members m LEFT JOIN member_nominees n.*WHERE m\.organization_id=\$1/);assert.match(repo,/SELECT \${MEMBER_COLUMNS} FROM members m WHERE m\.id=\$1 AND m\.organization_id=\$2/);});
test('member create never accepts client organization_id as authority',()=>{assert.doesNotMatch(service,/organization_id\s*:\s*z|context\.body\.organization_id/);assert.match(routes,/requireTenant/);});
test('member mutations enforce server permissions',()=>{assert.match(routes,/requirePermission\('member\.create'\)/);assert.match(routes,/requirePermission\('member\.update'\)/);assert.match(routes,/requirePermission\('member\.delete'\)/);});
test('branch assignment is verified against current tenant in repository',()=>assert.match(repo,/branches WHERE id=\$1 AND organization_id=\$2/));
test('member API migration adds server-backed profile fields',()=>{assert.match(migration,/ADD COLUMN IF NOT EXISTS personal_info JSONB/);assert.match(migration,/ADD COLUMN IF NOT EXISTS financial JSONB/);assert.match(migration,/ADD COLUMN IF NOT EXISTS family JSONB/);assert.match(migration,/007_member_api/);});
test('frontend MemberService uses IMP_API and not browser member storage as authority',()=>{assert.match(frontend,/IMP_API\.get\(`\/members/);assert.match(frontend,/IMP_API\.post\('\/members'/);assert.match(frontend,/IMP_API\.patch\(`\/members/);assert.doesNotMatch(frontend,/Storage\.get\(Storage\.KEYS\.MEMBERS/);assert.doesNotMatch(frontend,/Storage\.set\(Storage\.KEYS\.MEMBERS/);});
test('member document delete is server-side permission protected',()=>assert.match(routes,/requirePermission\('member\.document\.delete'\)/));

test('frontend member status values match PostgreSQL canonical status values',()=>{const status=read('database/migrations/002_core_domain.sql');for(const value of ['active','suspended','inactive']) assert.match(status,new RegExp(`['"]${value}['"]`));});

test('member update query accepts all 12 service parameters and persists branch/status',()=>{
  const match=repo.match(/\"membersService\.js:31:144\": \(\{\}\) => \(`([\s\S]*?)`\),/);
  assert.ok(match,'member update query must exist');
  const sql=match[1];
  const placeholders=[...sql.matchAll(/\$(\d+)/g)].map(m=>Number(m[1]));
  assert.equal(Math.max(...placeholders),12);
  assert.match(sql,/branch_id=\$1/);
  assert.match(sql,/status=COALESCE\(\$7,status\)/);
  assert.match(sql,/WHERE id=\$11 AND organization_id=\$12/);
});

test('member edit form sends selected branchId to update API',()=>{
  const form=read('js/members/member-form.js');
  assert.match(form,/branchId:\s*data\.branchId \|\| null/);
});
