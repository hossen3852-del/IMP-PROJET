'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '../..');

test('daily collection default date is anchored to Bangladesh time', () => {
  const service = fs.readFileSync(path.join(root, 'server/services/collectionsService.js'), 'utf8');
  assert.match(service, /timeZone:\s*'Asia\/Dhaka'/);
});

test('daily collection route-sheet exposes current due as installmentAmount', () => {
  const service = fs.readFileSync(path.join(root, 'server/services/collectionsService.js'), 'utf8');
  const repository = fs.readFileSync(path.join(root, 'server/repositories/queryRegistry.js'), 'utf8');
  assert.match(repository, /l\.installment_amount AS scheduled_installment_amount/);
  assert.match(service, /installmentAmount:\s*money\(l\.due_today\)/);
  assert.match(service, /dueTodayAmount:\s*money\(l\.due_today\)/);
});

test('daily collection frontend prefills the current due amount', () => {
  const js = fs.readFileSync(path.join(root, 'js/collections/daily-collection.js'), 'utf8');
  assert.match(js, /loan\.dueTodayAmount\s*\?\?\s*loan\.due_today_amount\s*\?\?\s*loan\.installmentAmount/);
  assert.match(js, /data-default-amount="\$\{defaultAmt\.toFixed\(2\)\}"/);
});

test('daily collection Baki clears installment and savings only', () => {
  const js = fs.readFileSync(path.join(root, 'js/collections/daily-collection.js'), 'utf8');
  const start = js.indexOf('function setBaki(row)');
  const end = js.indexOf('function getRowEntry(row)', start);
  const baki = js.slice(start, end);
  assert.match(baki, /savingsInput\.value\s*=\s*"0\.00"/);
  assert.match(baki, /savingsInput\.readOnly\s*=\s*true/);
  assert.doesNotMatch(baki, /insuranceInput|admissionFee/);
});

test('daily collection payload contains only installment and savings money fields', () => {
  const js = fs.readFileSync(path.join(root, 'js/collections/daily-collection.js'), 'utf8');
  assert.match(js, /savingsAmount:\s*status\s*===\s*"baki"\s*\?\s*0\s*:\s*savings/);
  assert.doesNotMatch(js, /insuranceAmount:/);
  assert.doesNotMatch(js, /admissionFeeAmount:/);
});

test('V6.0.8 daily collection enables Save Member after Baki click',()=>{const js=fs.readFileSync(path.join(root,'js/collections/daily-collection.js'),'utf8');assert.match(js,/row\.dataset\.status === "baki"/);assert.match(js,/saveButton\.disabled = false/);assert.match(js,/setBaki\(row\)/);assert.match(js,/Clicking Baki means the collector is explicitly recording/);});
test('V6.0.7 daily collection allows savings-only submit when installment balance is zero',()=>{const js=fs.readFileSync(path.join(root,'js/collections/daily-collection.js'),'utf8');assert.match(js,/status !== "baki"\s*&&\s*installment <= 0\s*&&\s*savings <= 0/);assert.match(js,/savingsAmount: status === "baki" \? 0 : savings/);const svc=fs.readFileSync(path.join(root,'server/services/collectionsService.js'),'utf8');assert.match(svc,/Installment payment exceeds the loan outstanding balance/);});


test('V6.0.9 daily collection supports configurable advance installment input',()=>{const js=fs.readFileSync(path.join(root,'js/collections/daily-collection.js'),'utf8');const svc=fs.readFileSync(path.join(root,'server/services/collectionsService.js'),'utf8');assert.match(js,/class=\"in-advance\"/);assert.match(js,/const installment = due \+ advance/);assert.match(js,/config\.allowAdvance/);assert.match(svc,/allowAdvance:\n    z\.boolean/);assert.match(svc,/const isAdvance = amount > dueToday/);assert.match(svc,/config\.allowAdvance/);});
test('V6.0.9 advance payment is allocated FIFO across future installments',()=>{const svc=fs.readFileSync(path.join(root,'server/services/collectionsService.js'),'utf8');const q=fs.readFileSync(path.join(root,'server/repositories/queryRegistry.js'),'utf8');assert.match(svc,/FIFO ALLOCATION/);assert.match(q,/ORDER BY\s+due_date,\s+installment_number/);assert.match(q,/allocation_type/);});
test('V6.0.9 settings expose allowAdvance for daily collection',()=>{const svc=fs.readFileSync(path.join(root,'server/services/collectionsService.js'),'utf8');const ui=fs.readFileSync(path.join(root,'js/settings/payment-settings.js'),'utf8');assert.match(svc,/allowAdvance: true/);assert.match(ui,/dc_allowAdvance/);});


test('V6.0.9 package version is synchronized',()=>{const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));const lock=JSON.parse(fs.readFileSync(path.join(root,'package-lock.json'),'utf8'));assert.match(pkg.version,/^1\.6\.\d+$/);assert.equal(lock.version,pkg.version);assert.equal(lock.packages[''].version,pkg.version);});
