$ErrorActionPreference = 'Stop'

if (Test-Path '.env') {
  Write-Host '.env already exists. No changes made.'
  exit 0
}

Copy-Item '.env.example' '.env'
Write-Host ''
Write-Host 'Created .env from .env.example.'
Write-Host 'IMPORTANT: edit .env and replace:'
Write-Host '  DATABASE_URL -> CHANGE_ME with your PostgreSQL password'
Write-Host '  SESSION_SECRET -> a long random secret'
Write-Host ''
Write-Host 'Then run: npm start'
