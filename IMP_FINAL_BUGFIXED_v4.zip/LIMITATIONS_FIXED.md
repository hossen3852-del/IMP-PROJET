# Limitations Fixed (2026-09-26)

## 1. Frequency lock — SERVER-SIDE
- audit_logs action `DAILY_COLLECTION_FREQUENCY_CLOSED`
- POST /collections/daily rejects with 409 if same org+date+branch+frequency already closed
- Route sheet returns `submittedFrequencies` so all devices see the lock
- localStorage kept as offline mirror only

## 2. Loan Idempotency-Key — SERVER-SIDE
- Reads `Idempotency-Key` / `idempotency-key` header on POST /loans
- Looks up prior LOAN_CREATED audit with same key → returns existing loan (200, idempotent:true)
- Stores key in LOAN_CREATED metadata on new create

## 3. Frequency default
- Default dropdown option is **সব সময়কাল (all)**
- Concrete daily/weekly/monthly still lock independently on server

## 4. Savings-only in Payments daily section
- Product rule unchanged: daily section aggregates **payments** (installment money)
- Savings posts to savings_transactions, not payments — by design
