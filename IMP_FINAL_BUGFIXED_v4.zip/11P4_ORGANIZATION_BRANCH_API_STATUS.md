# IMP — 11.P.4 Organization + Branch API

Status: Implemented

## API
- GET /api/organization
- PATCH /api/organization
- GET /api/branches
- GET /api/branches/:id
- POST /api/branches
- PATCH /api/branches/:id
- POST /api/branches/:id/deactivate

## Security
- All endpoints require the server-backed session.
- Permission checks are server-side.
- Every query is scoped by `req.auth.organization_id`.
- Organization update is restricted by `organization.update`.
- Branch mutation is restricted by `branch.create` / `branch.update`.
- Composite foreign keys prevent a branch ID from being attached to a different organization.
- Mutations create audit log records.

## Frontend cut-over
Organization and branch managers now use `IMP_API` and the HttpOnly session. They no longer treat localStorage as authoritative for organization or branch records.

## Important
Organization creation remains part of registration. Existing organization data is updated through the authenticated API.
