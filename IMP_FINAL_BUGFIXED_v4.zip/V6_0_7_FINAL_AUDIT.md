# V6.0.8 Final Audit

## Scope
This patch is based on V6.0.6 Member Edit Fix and addresses the requested member media/nominee visibility and daily collection workflow.

## Member fixes
- Member list now returns nominee data in the list query.
- Member list renders member photo, nominee name, nominee NID, and nominee photo.
- List query avoids returning photo BYTEA payloads; it exposes photo-exists flags and authenticated photo URLs.
- Member profile renders member photo, nominee NID, and nominee photo.

## Daily collection fixes
- Installment field is populated from the current collectible installment balance (`due_today`), including outstanding overdue installments through the selected date.
- Route sheet refresh after successful row save updates the displayed installment balance.
- Row-level `Save Member` is disabled when installment balance is zero.
- Members with zero installment balance can still enter savings and use the global `জমা দিন / Submit` action.
- Server rejects installment payments above the current due installment balance, preventing manual/API over-collection.

## Validation
- Production tests: 257 passed, 0 failed.
- JavaScript syntax: 209 files checked, 0 errors.
- Package version: 1.6.8 (package.json, package-lock.json, lock root synchronized).
- No live production PostgreSQL E2E was executed in this environment.
