# IMP V5.1 — Strict Production Layered Architecture Update

Target:
Browser → Express → Middleware → Route → Controller → Service → Repository → PostgreSQL

## Enforced boundaries
- Routes: composition only.
- Controllers: HTTP composition only; no PostgreSQL imports, pool access, or SQL.
- Services: application/business implementation; no direct PostgreSQL pool import.
- Repository: the only application-layer PostgreSQL gateway.
- Transaction boundary: repository.withTransaction().

## Implementation note
V5 is a strict runtime DB-boundary cut-over from V4. Existing domain behavior is retained inside application-service modules to minimize regression risk. The existing route registration is retained inside the service compatibility adapter; this keeps endpoint behavior stable while the persistence boundary is enforced.
