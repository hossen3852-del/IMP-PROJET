# V6.0.10 Release Status

Package version: **1.6.10**

## Fixed in this build

| # | Bug | Fix |
|---|-----|-----|
| 1 | `GET /api/payments` → `fields is not defined` | `PAYMENT_LIST_FILTER_FIELDS` |
| 2 | Payment INSERT `RETURNING p.*` without alias | `PAYMENT_RETURNING_COLUMNS` |
| 3 | New org lacks Commercial Expansion permissions | `026` updates `create_default_org_rbac` + backfill |
| 4 | Loan adjustment audit bind (5 vs 6 params) | Pass `entity_type='loan'` |
| 5 | Adjustment on draft/cancelled loans | Status guard `disbursed`/`active` |
| 6 | GL: receivable negative, interest income 0 | Payment trigger splits principal/interest |
| 7 | `statusCode` ignored by errorHandler | Accept `status` / `statusCode` / `httpStatus` |
| 8 | Baki without member/branch validation | Validate before audit |
| 9 | DATE timezone shift | `types.setTypeParser(1082, v => v)` |
| 10 | Password reset email enumeration via 503 | Generic success; log mail errors |
| 11 | Daily expense on fully failed batch | Save expense only if `successCount > 0` |

## Deploy steps

```bash
npm ci
npm run db:migrate
npm test
npm start
```

Live PostgreSQL E2E is still recommended after migrate.
