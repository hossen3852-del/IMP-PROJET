# IMP 11.P.13.1 — Frontend Final Cut-over & E2E Repair

Applied to the 11.P.13 Organization Admin registration-fixed source.

## Repairs
- Member edit now loads the record from the server before binding the form; direct URL loading no longer depends on an in-memory cache.
- Member add/edit enforce server-backed session and RBAC in the page bootstrap.
- Payment entry is API-only and requires `payment.create`; legacy localStorage balance/allocation services are no longer loaded by the payment-entry page.
- Payment details is API-only; allocations and receipt navigation use server response data.
- Payment receipt is API-only; receipt allocations come from `/api/payments/:id/receipt`.
- Payment history is API-only; no payment persistence is read from browser storage.
- Installment schedule no longer loads browser storage and now enforces authenticated `loan.view`.

## Authority
Browser storage is not authoritative for members, loans, installments, payments, allocations, receipts, or payment history. Financial mutations remain server-side PostgreSQL transactions.

## Validation
Static syntax and existing automated tests must be run after extraction. Real PostgreSQL E2E is still required for final PASS.
