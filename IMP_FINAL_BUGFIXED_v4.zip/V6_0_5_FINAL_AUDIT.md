# V6.0.5 Final Hardened Audit

Package version: 1.6.5
Build: V6.0.5 Final Hardened

## Automated validation

- Production regression tests: 248/248 PASS
- JavaScript syntax scan: 209/209 PASS
- HTML pages scanned: 53
- Missing local HTML assets: 0
- Tenant isolation regression: PASS
- Branch isolation regression: PASS
- Static project-root exposure regression: PASS
- Loan adjustment rollback regression: PASS
- Penalty calculation regression: PASS
- Loan-adjustment idempotency regression: PASS
- Notification atomic claim regression: PASS
- Notification provider message-id persistence regression: PASS
- Migration chain: 001 through 024 present and registered

## Final hardening changes

1. Loan adjustments require an Idempotency-Key header.
2. Loan adjustments persist a tenant-scoped idempotency key with a unique index.
3. Replayed adjustment requests return the original adjustment instead of applying the financial operation again.
4. Notification outbox workers atomically claim queued/stale-processing rows using `FOR UPDATE SKIP LOCKED`.
5. Notification processing supports a `processing` state and a 15-minute stale-claim lease.
6. Provider message IDs are persisted when returned by an adapter.
7. The notification provider contract explicitly returns `providerMessageId`.
8. Migration 024 adds the required schema hardening.
9. Package and lock versions are synchronized at 1.6.5.

## Environment limitation

A live PostgreSQL end-to-end financial test was not executed because a production `DATABASE_URL` was not available in the build environment. The supplied `db:validate` harness remains fail-closed and must be run against the deployment database before production release.

No claim of mathematical or operational impossibility of all future defects is made; this report records the validations actually executed on this build.
