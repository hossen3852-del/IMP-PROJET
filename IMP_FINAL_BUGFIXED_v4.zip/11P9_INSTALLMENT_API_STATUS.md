# IMP — 11.P.9 Installment API + Frontend Cut-over

Status: COMPLETED
Source: IMP_PRODUCTION_11P8_LOAN_API_FRONTEND_CUTOVER.zip

## Implemented
- Tenant-scoped GET /api/installments?loan_id=...
- Tenant-scoped GET /api/installments/:id
- Server-side POST /api/installments/generate
- Server-side PATCH /api/installments/:id/status
- RBAC enforced with loan.view and loan.schedule.update
- Schedule generation is transactional and server-authoritative
- Exact total_payable is preserved by residual adjustment on final installment
- Weekly, biweekly and monthly frequencies supported
- Duplicate schedule generation rejected
- Unsafe loan states rejected for schedule generation
- Installment status transitions enforced server-side
- Audit logging for schedule generation and status changes
- PostgreSQL tenant-safe loan/organization FK retained
- Frontend installment schedule switched from localStorage persistence to API authority
- Legacy loan-installments page now loads API-backed schedule manager

## Validation
- JavaScript syntax: PASS
- Full regression: 109/109 PASS
- PostgreSQL runtime migration execution: not available in this environment; run `npm run db:migrate` against staging/production PostgreSQL before deployment.

## Migration
- database/migrations/009_installment_api.sql
