# V6.0.17 — Settings & Dashboard Customization Final Repair

## Fixed
1. Organization Admin / Super Admin are guaranteed `settings.view`, `settings.update`, `dashboard.view`, and `dashboard.customize` permissions by migration 032.
2. Per-user UI visibility no longer interprets a missing custom visibility record as an empty list. Missing custom configuration now falls back to normal RBAC visibility.
3. Existing stable UI module keys remain supported.

## Required after deployment
Run:

```bash
npm ci
npm run db:migrate
npm run db:validate
npm test
npm start
```

After migration, log out and log back in so the session receives the repaired permission set.
