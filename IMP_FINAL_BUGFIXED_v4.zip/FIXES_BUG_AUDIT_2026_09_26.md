# Bug Audit Fixes — 2026-09-26

Fixes applied after the module-by-module audit of IMP_FINAL_LIMITATIONS_FIXED.

## 1. Loan creation idempotency — race condition closed
- **Before**: idempotency check for loan creation only looked up `audit_logs`
  metadata, outside any transaction/lock. Two concurrent double-submit
  requests with the same `Idempotency-Key` could both create a loan.
- **After**: `loans` table now has its own `idempotency_key` column with a
  DB-level unique index (`loans_org_idempotency_idx`, matching the existing
  pattern on `payments`, `loan_adjustments`, `savings_transactions`,
  `expense_entries`). The lookup happens inside the transaction with
  `FOR UPDATE`, and a concurrent duplicate now gets caught via Postgres
  unique-violation (`23505`) and returns `409 Idempotency key already used`
  instead of silently creating a second loan.
- Files: `database/migrations/035_loan_idempotency.sql`,
  `server/repositories/queryRegistry.js`, `server/services/loansService.js`.
- **Action required**: run `node server/db/migrate.js` (or your normal
  migration step) before deploying — this migration must run once against
  the database.

## 2. Unescaped error messages → stored/reflected XSS risk
- `js/payments/paymentReconciliationView.js`: error message inserted into
  `innerHTML` without escaping — now passed through `escapeReconciliationHTML()`.
- `js/loans/payment-receipt.js`: the page's `esc()` helper was declared
  inside the `try` block, so the `catch` (error) path used the raw,
  unescaped message. `esc()` is now declared before the `try` block and
  used in both paths.

## 3. Duplicate migration numbering
- `015_loan_interest_rate.sql` and `015_settings_photo_storage.sql` shared
  the same migration number. The runner keys on full filename so this
  never broke anything functionally, but it's confusing for future
  maintenance. Renamed to `015a_loan_interest_rate.sql` and
  `015b_settings_photo_storage.sql` (execution order unchanged), and
  updated the version string each file writes to `schema_migrations` to
  match.

## 4. Minor cleanup
- Removed a dead-code header lookup (`context.headers['Idempotency-Key']`)
  in `loansService.js` that could never match, since Express lowercases
  all incoming header names.
- Removed the now-unused legacy `audit_logs`-based idempotency lookup query
  from `queryRegistry.js`, superseded by the row-locked, constraint-backed
  lookup.

All modified/added JS files pass `node --check`.

---

# Second pass — hands-on manual audit, 2026-09-26 (core services)

Requested: manual, line-by-line audit of the core financial modules before
production sign-off. Findings below.

## 5. CRITICAL (fixed): cancelled/reversed payments never reversed their GL entries
- `trg_payment_gl` (added in migration 022, replaced in 026) posts a
  balanced double-entry journal (Cash/Bank ↔ Loan Receivable + Interest
  Income) on `AFTER INSERT ... WHEN (status='posted')`.
- `paymentsService.js`'s `changeStatus()` (used by both
  `POST /payments/:id/cancel` and `POST /payments/:id/reverse`) correctly
  restores the installment `outstanding_amount` and the loan's
  `outstanding_amount`, but there was **no trigger and no application code
  anywhere** that reversed the journal entry itself. Every cancelled or
  reversed payment left Cash/Bank permanently overstated and Loan
  Receivable / Interest Income permanently understated in the books —
  the General Ledger would never match the operational data once a single
  payment was cancelled.
- **Fixed**: `database/migrations/036_payment_cancellation_gl_reversal.sql`
  adds `trg_payment_gl_reversal`, an `AFTER UPDATE OF status` trigger that,
  on a `posted → cancelled/reversed` transition, finds the original journal
  entry and posts a mirrored entry with debit/credit swapped (standard
  reversal-entry practice — the original entry is left untouched for audit
  history). Idempotency-guarded so it can't double-post.
- **Action required**: run migrations before deploying (same as item 1).

## 6. OPEN — needs a product decision: manual installment amount isn't validated against installment count
- `calculateLoanValues()` (loansService.js) only checks
  `manualInstallment <= totalPayable`. It does not check that
  `manualInstallment × (installments − 1) ≤ totalPayable`.
- If a loan officer enters an installment amount that's too high for the
  chosen number of installments (e.g. 10 installments of ৳999 against a
  ৳1,000 total payable), the schedule generated at disbursement clamps the
  **last** installment to ৳0 and the first nine installments alone already
  exceed the total payable — i.e. the member would be billed far more than
  the calculated total.
- **Not auto-fixed** — this is a business-rule call (what tolerance is
  acceptable, whether to hard-reject or just warn). Recommend adding:
  `if (manualInstallment * (count - 1) > totalPayable) throw new Error(...)`
  in `calculateLoanValues`, alongside the existing check.

## 7. OPEN — needs a product decision: two different installment-generation formulas
- Automatic generation on disbursement (`loansService.js`, `transition()`)
  uses the loan officer's manually-entered `installment_amount` as the
  per-period base, with the **last** installment absorbing the rounding
  remainder against `total_payable`.
- The standalone `POST /installments/generate` endpoint
  (`installmentsService.js`, `post_generate_3` — a fallback/admin path for
  loans that reach `approved` status without going through the normal
  disbursement flow) instead recomputes an **even split**:
  `base = total_payable / count`, silently ignoring whatever installment
  amount was agreed with the borrower at loan creation.
- Both paths guard against regenerating an existing schedule, so they
  can't both fire for the same loan — but if `/installments/generate` is
  ever used as a fallback, the schedule it creates will not match what the
  borrower was told. **Not auto-fixed** — needs a decision on whether this
  endpoint should also read `installment_amount` (recommended, for
  consistency) or is intentionally a different, evenly-split mode.

## 6. FIXED: manual installment amount now validated against installment count
`calculateLoanValues()` in `loansService.js` now also rejects the
combination where `manualInstallment × (installments − 1) > totalPayable`,
with a clear error message, instead of allowing a schedule that would
clamp the last installment to ৳0 while overcollecting on the earlier ones.

## 7. FIXED: `/installments/generate` now uses the same formula as disbursement
`post_generate_3` in `installmentsService.js` now bases the per-installment
amount on the loan's actual agreed `installment_amount` (same as the
automatic disbursement-time generator in `loansService.js`), with an even
split of `total_payable` only as a defensive fallback for a loan record
that has no `installment_amount` stored. The last installment absorbs the
rounding remainder in both places, consistently.

## 8. FIXED (found while wiring up #6): `PATCH /loans/:id` was completely broken
While updating `calculateLoanValues()`'s call sites for fix #6, found that
the loan-edit endpoint (`patch_id_4`) called
`calculateLoanValues(amount, rate, count)` — **omitting the required 4th
argument, the manual installment amount**. Since that argument is
mandatory (`calculateLoanValues` throws `"Installment amount must be
entered manually"` when it's missing), **every call to `PATCH /loans/:id`
was failing**, regardless of what was sent in the request body.
Additionally, `installmentAmount` wasn't even part of the endpoint's
accepted request schema, so there was no way to specify or change it via
an edit.
- **Fixed**: added `installmentAmount` as an optional field to the update
  schema, with a fallback to the loan's existing `installment_amount` when
  not supplied (matching the existing fallback pattern already used for
  `loanAmount`, `interestRate`, and `numberOfInstallments` on this same
  endpoint), and passed it through to `calculateLoanValues()`.
- This also benefits from fix #6's new validation automatically, since
  both call the same function.

---

# Third pass — hands-on manual audit, 2026-09-26 (collectionsService.js)

Requested: full manual audit of `collectionsService.js` (daily field-officer
collection — the largest and most-used financial write path). Read in
full, line by line, alongside the queries it calls in `queryRegistry.js`.

## 9. FIXED: daily-collection "already submitted today" check had the same race-condition gap as the earlier loan-idempotency bug
- `POST /collections/daily` refuses to run again for the same
  organization/branch/date/frequency once it has succeeded once ("আজকের
  জন্য ... কালেকশন ইতিমধ্যে জমা দেওয়া হয়েছে"). The check queried
  `audit_logs` for a prior closure marker at the very **start** of the
  request, and only **wrote** that marker at the very **end**, after every
  entry in the batch (up to 500) had been processed one at a time.
  Neither the check nor the write was backed by a unique constraint or a
  lock.
- Each individual payment/savings entry inside the batch does have its own
  idempotency key protected by a real unique DB index — but that key is
  only guaranteed stable within a single browser page session (it's
  generated fresh per row on page load). If a field officer's submission
  stalls or fails to confirm (e.g. a flaky mobile connection), reloads the
  page, and re-enters/resubmits the same day's sheet while the first
  request is still processing on the server, the two requests would both
  pass the initial closure check and both process the full batch — every
  member in the sheet would be collected twice.
- **Fixed**: `database/migrations/037_daily_collection_lock.sql` adds a
  `daily_collection_locks` table with a unique constraint on
  `(organization_id, branch_key, collection_date, frequency)`. The slot is
  now reserved with a single atomic `INSERT ... ON CONFLICT DO NOTHING` at
  the very start of `post_daily_4`, before any entry is processed —
  whichever concurrent request's insert wins holds the slot for the rest
  of the batch; the other is rejected immediately with 409. If the batch
  that won ends up with zero successful entries, its row is deleted right
  after the entry loop (before any further, unguarded queries) so a
  genuine retry is never blocked.
- **Action required**: run migrations before deploying (now 3 pending:
  `035`, `036`, `037`).
- Note: if the server process crashes mid-batch (not a normal error path,
  which is caught per-entry), the reserved lock row would not be released
  automatically. This is an intentional fail-safe trade-off — better to
  require an admin to clear a stuck slot than to silently allow double
  processing — but worth knowing about operationally.

## Verified safe in collectionsService.js (checked, no bug found)
- `collectInstallment`: the loan row is locked with `SELECT ... FOR UPDATE`
  before the outstanding-balance check, so two concurrent collections
  against the *same loan* correctly serialize — no double-spend race there
  (this is a different code path from the batch-level issue above, which
  is about the whole daily-collection *submission*, not a single loan).
- FIFO installment allocation correctly walks schedule rows in order,
  clamps each allocation to that installment's outstanding amount, and
  updates status (`paid`/`partial`) consistently.
- Payment number / receipt number generation uses real Postgres
  `nextval()` sequences — atomic, no race possible.
- The payment INSERT this path uses hardcodes `status='posted'`, so it
  correctly triggers the GL posting trigger (fix #4 above therefore also
  covers payments created through daily collection).
- `collectSavings`: deposits are purely additive, no balance check needed,
  and its own idempotency key is backed by the same unique-indexed
  `savings_transactions.idempotency_key` column.

## Verified safe (checked, no bug found)
- Savings withdrawal/installment-payment: balance-sufficiency check is
  protected by `SELECT ... FOR UPDATE` on the member row acquired *before*
  the check, so two concurrent withdrawal requests for the same member
  correctly serialize (no double-spend race).
- Auth: argon2id password hashing, dedicated rate limiter on
  `/api/auth` writes (20 req / 15 min, GET exempted), general write rate
  limiting, stricter limiting on `/api/payments` writes.
- RBAC: system/protected roles are guarded against update/delete at three
  separate checkpoints in `rbacService.js`.
- Loan disbursement GL trigger correctly guards against re-firing
  (`NEW.status='disbursed' AND OLD.status IS DISTINCT FROM 'disbursed'`).
- Loan write-off/waiver/penalty adjustments (`commercialExpansionService.js`)
  already post their own correct, balanced GL entries at the application
  level.
