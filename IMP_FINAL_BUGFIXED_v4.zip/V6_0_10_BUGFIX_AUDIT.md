# V6.0.10 Bugfix Audit

## Critical fixes

1. **Payment History (`GET /api/payments`)** — `fields is not defined` → introduced `PAYMENT_LIST_FILTER_FIELDS`.
2. **Payment INSERT RETURNING** — `RETURNING p.id...` without table alias → `PAYMENT_RETURNING_COLUMNS` without `p.` prefix for INSERT.
3. **Commercial Expansion RBAC for new orgs** — migration `026` updates `create_default_org_rbac()` with expansion permissions and backfills existing orgs.
4. **Loan adjustment audit** — `commercialExpansion:audit` now receives all 6 parameters including `entity_type='loan'`.
5. **Loan adjustment status guard** — only `disbursed` / `active` loans accept adjustments.
6. **GL payment trigger** — proportional principal / interest split so Loan Receivable does not go negative and Interest Income (4000) is credited.
7. **errorHandler** — respects `err.status`, `err.statusCode`, and `err.httpStatus`.
8. **Baki daily collection** — member existence + branch scope validated before audit write.
9. **PostgreSQL DATE parser** — DATE values stay `YYYY-MM-DD` strings (no timezone shift).
10. **Password reset** — mail failure no longer returns 503 only for existing accounts (enumeration).
11. **Daily expense** — saved only when at least one collection entry succeeded.

## Migration

- `026_v6_0_9_bugfix_rbac_gl.sql` — run via `npm run db:migrate`.

## Validation

- `node --check` on modified JS files.
- `node --test tests/production/*.test.js`
