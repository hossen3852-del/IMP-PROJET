# IMP — 11.P.2 PostgreSQL Schema + Migration Architecture

## Status
Implemented as the next production layer after 11.P.1.

## Canonical decisions
- PostgreSQL is the system of record.
- Every tenant-owned domain table carries `organization_id`.
- Money uses `NUMERIC(18,2)`; JavaScript floating point is not the database representation.
- Tenant-scoped uniqueness is expressed as `(organization_id, business_key)`.
- Payment creation has an organization-scoped idempotency key.
- Payment allocation and receipt tables are separate financial records.
- Passwords are represented only by `password_hash`.
- Schema changes are ordered SQL migrations and are tracked by `schema_migrations`.
- Migrations are applied in a transaction by `server/db/migrate.js`.

## Migration files
- `001_production_foundation.sql` — organizations, users, sessions, RBAC primitives, audit log, migration registry.
- `002_core_domain.sql` — branches, members, member sub-resources, loans, installments, payments, allocations, receipts, settings, password reset records.

## Important boundary
Cross-row tenant consistency (for example, a member and branch must belong to the same organization) cannot be guaranteed by ordinary PostgreSQL CHECK constraints. The enforcement layer is intentionally reserved for 11.P.6, where server-side tenant guards/triggers will be added.

## Run
```bash
npm install
npm run db:migrate
npm test
```

For a real deployment, use a least-privileged PostgreSQL application user and a separate migration/deployment credential. Never commit `.env` or production secrets.

## Not yet migrated
The browser application still contains localStorage-based business logic. This schema is the server-side target and foundation; 11.P.3 onward migrates authentication, authorization, tenant isolation, and each business module without a big-bang rewrite.
