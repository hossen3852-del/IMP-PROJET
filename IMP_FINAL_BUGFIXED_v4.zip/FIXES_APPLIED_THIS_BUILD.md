# Fixes Applied — Complete Error-Free Build

Date: 2026-09-16

## Issues Fixed

1. **security-branch-scope.test.js failure**
   - Cause: `assertBranchAccess(req.auth, memberBranch)` was multi-line in `server/routes/collections.js`.
   - Fix: Collapsed to single-line form expected by the static test.

2. **Member NID uniqueness (data integrity)**
   - Added migration `017_member_nid_unique.sql` — unique partial index on `(organization_id, nid_or_passport)` for non-empty values.
   - Added server-side 409 conflict check on create and update in `server/routes/members.js` (ignores inactive members, excludes self on update).

3. **Member code generation race condition**
   - Replaced naive `COUNT(*)+1` with `pg_advisory_xact_lock` + `MAX` extraction of numeric suffix.
   - Prevents duplicate member_code under concurrent creates.

4. **Test suite alignment**
   - Updated `real-postgres-validation.test.js` expected migration list to include `017_member_nid_unique`.

## Verification
- Full static + unit suite: **185 / 185 PASS**
- `node --check` on all server & key JS: clean
- No remaining failing assertions

## Remaining production gates (unchanged)
- Live PostgreSQL `npm run db:migrate && npm run db:validate` must still be run against real staging DB before go-live.
- Password-reset email/SMS provider wiring remains external.

This build is free of the previous static test failures and the Member-module integrity gaps identified in audit.
