# IMP Production Migration Status

This build adds a production backend foundation and PostgreSQL schema.
Critical runtime and configuration bugs from the deep audit have been fixed (see `PRODUCTION_FIXES_APPLIED.md`).

## Implemented
- Express API foundation
- Helmet security headers
- CORS allow-list
- JSON request limits
- Rate limiting on authentication
- Argon2id password verification
- Random server sessions
- SHA-256 session-token hashes in PostgreSQL
- HttpOnly/Secure/SameSite cookie handling
- Server-side permission middleware
- PostgreSQL organization/user/session/audit foundation
- Environment-based configuration (including configurable DATABASE_SSL)
- Migration runner (import bug fixed)
- Password policy aligned (frontend + server min 8 characters)
- Basic Node test suite

## Not yet migrated
Existing Members, Loans, Installments, Payments, Receipts, Savings and Recovery business data still require API + PostgreSQL migration. The old localStorage data is intentionally not deleted by this build.

## Required deployment steps
1. Install Node.js 20+.
2. Run `npm install`.
3. Create PostgreSQL database.
4. Copy `.env.example` to `.env` and set real secrets/configuration (especially DATABASE_URL and DATABASE_SSL).
5. Run `npm run db:migrate`.
6. Create users with Argon2id password hashes; never insert plaintext passwords.
7. Put the API behind HTTPS/reverse proxy.
8. Run `npm test`.
9. Continue with 11.P.3 (auth cut-over + domain APIs) only after this layer passes.

## 11.P.8
Loan API + Frontend Loan Cut-over: COMPLETED. See `11P8_LOAN_API_STATUS.md`.
