# 11.P.15 — Dashboard UI + Organization Settings Customization — STATUS

## Scope delivered in this pass
Sub-gates 15.1 – 15.8 (backend contract + capital ledger + customization
storage + RBAC + clickable dashboard) are implemented. Sub-gates 15.9 – 15.13
(full navigation E2E, financial-integrity tests, security/tenant-isolation
audit, final production readiness sign-off) are **not** run in this pass —
this environment has no live PostgreSQL/network access to execute them.
They must be run against `imp_staging` before this gate is marked complete,
exactly like every previous 11.P.x gate.

## What was added (ADD — no existing table/route/file was replaced)

### Database
- `database/migrations/011_dashboard_capital.sql`
  - New table `capital_entries` (organization-scoped ledger: capital_in,
    admission_fee, insurance, capital_adjustment, capital_withdrawal).
  - New permissions: `capital.view`, `capital.manage`, `dashboard.customize`.
  - Grants added for existing organizations' `organization_admin` (full) and
    `accountant` (`capital.view` only) roles, and for `super_admin`.
  - `create_default_org_rbac()` updated so every **future** organization gets
    the same grants automatically.
  - Dashboard/Settings customization reuses the existing
    `organization_settings(organization_id, setting_key, setting_value)`
    table from `002_core_domain.sql` — no schema change needed for that part.

### Backend (Express/PostgreSQL — financial source of truth)
- `server/routes/capital.js` — `GET /api/capital/summary` (live-computed
  current capital breakdown), `GET/POST /api/capital/entries`,
  `DELETE /api/capital/entries/:id`. All tenant-scoped via `requireTenant`,
  all RBAC-gated via `capital.view` / `capital.manage`.
- `server/routes/dashboard.js` — `GET /api/dashboard/summary` (the 10 KPI
  cards from the spec, all computed live: members, loans, collection, due,
  capital, admission fee, insurance, today's collection, today's loan,
  overdue — plus closedLoans/cancelledLoans for the two hidden-by-default
  cards), `GET/PUT /api/dashboard/config` (per-organization KPI
  show/hide/order + section toggles).
- `server/app.js` — mounts `/api/dashboard` and `/api/capital`.

### Frontend
- `pages/dashboard/dashboard.html` + `js/app.js` — dashboard now renders all
  10 (+2 optional) KPI cards, **the entire card is a clickable `<a>`**
  linking to the relevant list/detail page (members, loans, payments,
  overdue list, capital), driven by the saved `/api/dashboard/config` order
  and visibility, and filtered by the viewer's RBAC permissions.
- `pages/capital/capital.html` + `js/capital/capital.js` + `css/capital.css`
  — Capital Management page: live current-capital breakdown, Capital Entry
  form (Date / Entry Type / Amount / Description as specified), and the
  capital ledger list with delete (capital.manage only).
- `pages/settings/dashboard-settings.html` + `js/settings/dashboard-settings.js`
  + `css/dashboard-settings.css` — Dashboard Customization page: drag-and-drop
  KPI card ordering, per-card show/hide checkboxes, section toggles, Save /
  Reset to Default. Gated behind `dashboard.customize`.
- `js/rbac/permissions.js` — added `DASHBOARD_CUSTOMIZE`, `CAPITAL_VIEW`,
  `CAPITAL_MANAGE` constants (descriptive only; server is authoritative).
- `css/dashboard.css` — clickable-card hover/focus styling, KPI grid layout.
- Sidebar links to "মূলধন" and "ড্যাশবোর্ড কাস্টমাইজ" added to
  `pages/dashboard/dashboard.html` (RBAC-gated via `data-permission`).

## Explicitly not touched
- Existing Members/Loans/Installments/Payments APIs, schema, and business
  logic — untouched. Payment Allocation remains the single source of truth
  for collection figures; capital.js only reads `payments`/`loans`, never
  writes to them.
- `pages/settings/organization-settings.html` (general org settings) — still
  uses the pre-existing `CompanySettingsManager` (localStorage-backed
  display preferences: currency symbol, date format, prefixes). This is a
  known pre-existing gap, out of scope for this pass, and unrelated to
  financial data — left as-is per the "don't replace working code without
  reason" rule.

## Known issue re-checked
The previously reported `missing FROM-clause entry for table "m"` PostgreSQL
error was searched for across `server/routes/*.js` (loans, members,
payments — every place a `m.` alias is used). All `loanColumns`/
`memberColumns` usages already carry the required `JOIN members m ...`. The
bug was **not reproducible in this build** and appears already resolved in
this `CONTEXT_REPAIRED_V2` snapshot. No fix was needed; flagging this so it
isn't re-investigated from scratch next time.

## Extension — Current Balance merge + Loan/Daily Collection/Savings/Insurance/Admission Fee/Expense cards (this pass)

Confirmed with the org owner before building, to avoid guessing on financial
formulas:
- "Current Balance" and "বর্তমান মূলধন" are **one merged card**, not two.
- "মোট বীমা" = `insurance` + `insurance_new` (two premium categories) minus
  conditional claim payouts (`insurance_claim`).
- "মোট ভর্তি ফি" = `admission_fee` + `admission_fee_new` (two fee categories).
- Re-loan and interest ride on the existing `loans` ledger (no new
  "is_reloan" flag — every disbursed loan already counts toward
  disbursement; `loans.interest_amount` already tracks interest).

### New (database/migrations/012_savings_expense_cards.sql)
- `savings_transactions` (per-member ledger: deposit, daily_deposit,
  withdrawal, installment_payment — the last is an internal savings→loan
  transfer, tied to a `loan_id`).
- `expense_entries` (office / travel / equipment / other).
- Widened `capital_entries.entry_type` to add `admission_fee_new`,
  `insurance_new`, `insurance_claim` (additive CHECK constraint change only).
- New permissions `savings.view/manage`, `expense.view/manage`, granted to
  existing orgs' roles and folded into `create_default_org_rbac()` for
  future orgs (admin: full; accountant: full; branch_manager: savings full,
  expense view; collector: savings full, no expense).

### New/changed routes
- `server/routes/savings.js` — `GET /api/savings/summary` (org-wide or
  `?memberId=`), `GET/POST /api/savings/transactions`,
  `DELETE /api/savings/transactions/:id`. Validates member/branch/loan
  belong to the tenant; blocks withdrawal/installment_payment past the
  member's actual savings balance.
- `server/routes/expenses.js` — `GET /api/expenses/summary`,
  `GET/POST /api/expenses/entries`, `DELETE /api/expenses/entries/:id`.
- `server/routes/capital.js` — `computeCapitalSummary()` now nets
  `insurance_new` into `insurance` and subtracts `insurance_claim`; folds
  `admission_fee_new` into `admissionFee`; adds savings deposits/withdrawals
  into the merged `currentCapital` figure.
- `server/routes/dashboard.js` — `/api/dashboard/summary` now also returns
  `loanOutstanding` (loan disbursed + interest − collection − savings
  installment-transfers), `totalSavings`, `totalExpense`, and
  `todayCollection` is now the full "আজকের কালেকশন" formula (today's
  installment collection + today's savings deposits + today's admission fee
  − today's total expense across all categories).
- `server/app.js` mounts `/api/savings` and `/api/expenses`.

### New/changed frontend
- `pages/savings/savings.html` + `js/savings/savings.js` + `css/savings.css`
  — member search (reuses `GET /api/members?q=`), per-member savings entry
  form, per-member ledger, org-wide total card.
- `pages/expenses/expenses.html` + `js/expenses/expenses.js` — expense entry
  form by category, ledger, category-wise + total breakdown.
- `pages/capital/capital.html` + `js/capital/capital.js` — new entry-type
  options (`admission_fee_new`, `insurance_new`, `insurance_claim`) and
  breakdown rows for insurance claim / savings deposits / savings
  withdrawals.
- `js/app.js` — two new clickable cards (`totalSavings` → সঞ্চয় page,
  `totalExpense` → খরচ page); "মোট লোন" card's subtitle now shows the new
  ledger-based Outstanding figure instead of the raw sum of loan amounts.
- `js/settings/dashboard-settings.js` — `totalSavings`/`totalExpense` added
  to the customizable KPI list (default: visible).
- `js/rbac/permissions.js` — added `SAVINGS_VIEW/MANAGE`,
  `EXPENSE_VIEW/MANAGE` constants.
- Dashboard sidebar — added "সঞ্চয়" and "খরচ" links (RBAC-gated).

### Still open (same caveat as the base 11.P.15 pass)
No live PostgreSQL in this environment to run migrations/tests. Before
go-live: run `012_savings_expense_cards.sql`, add tests under
`tests/production/` for `/api/savings/*` and `/api/expenses/*`, and manually
verify the savings insufficient-balance guard and the loan/member ownership
checks against real data.

## Required before go-live
1. `npm install` (no new dependencies were added — zod/pg/express already
   cover everything used here).
2. `npm run db:migrate` to apply `011_dashboard_capital.sql` **and**
   `012_savings_expense_cards.sql` against `imp_staging` / production, in
   that order.
3. `npm run db:validate` and `npm test` (existing suite) — then add
   dedicated tests for `/api/dashboard/summary`, `/api/dashboard/config`,
   and `/api/capital/*` under `tests/production/` before calling 15.11/15.12
   complete.
4. Manually verify, per role (organization_admin, branch_manager, collector,
   accountant, viewer), that dashboard cards and the Capital/Dashboard
   Customization sidebar links show/hide exactly as RBAC intends.
