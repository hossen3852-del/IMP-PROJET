# IMP — 11.P.3 Authentication API + Frontend Auth Cut-over

## Status

Implemented and statically tested.

## Server API

- `POST /api/auth/register` — creates organization + first organization admin + server session in one transaction.
- `POST /api/auth/login` — Argon2id password verification + HttpOnly session cookie.
- `GET /api/auth/me` — returns the authenticated server-side user/session context.
- `POST /api/auth/logout` — revokes the current session.
- `POST /api/auth/logout-all` — revokes all sessions for the current user.
- `POST /api/auth/password-reset/request` — creates a hashed, 15-minute reset token without revealing account existence.
- `POST /api/auth/password-reset/confirm` — consumes the reset token, changes the Argon2id password and revokes existing sessions.

## Frontend cut-over

- Added `js/core/api.js`.
- Login, registration, logout and password reset now call the API.
- The browser does not store the session token.
- The authoritative session is the server-side PostgreSQL session referenced by an HttpOnly cookie.
- `SessionManager` keeps only non-authoritative UI session data in memory.
- Authentication pages no longer use `Storage.KEYS.USERS` or browser-stored passwords.

## Database migration

`database/migrations/003_auth_api.sql`

- Adds `users.full_name`.
- Backfills existing user names from email local-parts when needed.
- Makes login email globally unique because the current login contract is email-only.
- Seeds current canonical permissions and maps them to `organization_admin` and `super_admin`.

## Security notes

- Passwords are never stored as plaintext.
- Session tokens are random and only their SHA-256 hashes are stored in PostgreSQL.
- Cookies are HttpOnly, SameSite=Lax and Secure in production.
- State-changing API requests are rejected when their `Origin` is not the configured CORS origin.
- Password reset tokens are hashed at rest and single-use.

## Remaining production dependency

Password-reset delivery is intentionally provider-neutral. In development, the API returns a `devToken` so the flow can be tested. In production, the token is not returned; an email/SMS delivery adapter must be connected before enabling user-facing password recovery.

## Test result

`npm test` → **40/40 PASS**

All JavaScript files in `server/` and `js/` also pass `node --check`.
