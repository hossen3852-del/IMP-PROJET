# Daily Collection + Language Fixes (2026-09-16)

## Daily Collection changes
1. **Default collected amount**  
   - Route-sheet API now returns `overdueAmount` and `dueOnDateAmount` in addition to `dueTodayAmount`.  
   - Frontend pre-fills the installment input with total due (overdue + today) by default.  
   - Input is **readonly** when there is no overdue (officer accepts the default).

2. **Edit button only for arrears**  
   - If a member has overdue installments (`overdueAmount > 0`), an **Edit** button appears.  
   - Clicking it unlocks the installment field so the officer can enter the actual collected amount (including arrears).  
   - Members with only today’s due (no arrears) stay locked to the default amount.

3. **UI polish**  
   - Overdue hint shown under the field.  
   - CSS for edit button and readonly state.

## Language (i18n) fixes
1. Daily Collection strings moved to `t()` / IMP_I18N so they switch with language.  
2. New dictionary entries for collection-related phrases.  
3. `imp:languagechange` listener re-renders the member list with translated labels.  
4. Existing MutationObserver + Settings language page continue to work.

## Verification
- `node --check` on changed files: OK  
- Full test suite: **185 / 185 PASS**

