# V6.0.9 Final Audit

## Scope
Daily Collection overdue/current/advance/Baki/savings-only behavior.

## Implemented
1. Added `allowAdvance` to Daily Collection configuration.
2. Added a separate Advance Installment input to the daily collection row.
3. Current due remains server-derived and read-only.
4. Row Save Member becomes enabled when current due exists or an advance amount is entered.
5. Baki remains a direct status action and enables Save Member.
6. Savings-only rows continue to be submitted through the global Submit button.
7. Server rejects advance payments unless the setting is enabled.
8. Server rejects any payment above the loan outstanding balance.
9. FIFO installment allocation naturally applies advance amounts to future unpaid installments.
10. Existing transaction/receipt/audit flow remains inside the same database transaction.

## Validation
- `node --test tests/production/*.test.js` → 260/260 passed.
- JavaScript syntax scan → 0 errors.
- No database migration was required because the implementation uses existing payment/allocation/installment columns and the existing transaction model.

## Environment limitation
No live production PostgreSQL DATABASE_URL was available in the execution environment, so live DB E2E was not claimed.
