# IMP Final Fixes Applied (Post-Audit)

Date: 2026-09-15

This package applies the audit recommendations that could be fixed safely without breaking existing server APIs or requiring a live database migration.

## 1. Canonical Storage Keys (Critical)

**File:** `js/core/storage.js`

- `INSTALLMENTS`: `imp_installment_schedules` → **`imp_installments`**
- `AUDIT`: `imp_payment_audits` → **`imp_audit_logs`**
- Added UI config keys: `LOAN_UI_CONFIG`, `PAYMENT_UI_CONFIG`, `MEMBER_REGISTRATION_UI`, `DASHBOARD_UI_CONFIG`, `UI_LANGUAGE`
- Added `Storage.migrateLegacyKeys()` — one-time, safe migration:
  - Copies old key data to new key only if target is empty
  - Removes retired keys (`currentUserId`, `imp_current_user_id`)
- Migration runs automatically when the module loads

## 2. Legacy Multi-Key Fallbacks Removed

**File:** `js/loans/loan-installments.js`

- Removed fallbacks: `"loans"`, `"loanData"`, `"members"`, `"memberData"`, `"installments"`, `"installmentData"`, `"loanInstallments"`, `"repayments"`
- Now uses only `Storage.KEYS.LOANS`, `MEMBERS`, `INSTALLMENTS`

## 3. Current User Resolution Hardened

**File:** `js/payments/payment.js`

- `getPaymentCurrentUserId()` no longer reads `currentUserId` / `imp_current_user_id` from Storage
- Authoritative source: `SessionManager.getUserId()` / `SessionManager.getUser()`
- Fallback: `"system"` only

## 4. Settings UI Routed Through Storage API

| File | Change |
|------|--------|
| `js/settings/loan-settings.js` | get/set via `Storage` (fallback to localStorage only if Storage missing) |
| `js/settings/payment-settings.js` | same |
| `js/settings/member-registration-settings.js` | fully rewritten to use Storage |
| `js/members/member-form.js` | reads registration UI config via Storage |
| `js/core/i18n.js` | language preference via Storage when available |
| `js/core/home-nav.js` | language read via Storage |
| `js/settings/settings-shell.js` | language get/set via Storage |

**Note:** UI preferences (language, form field visibility) remain browser-local by design. Business data (members, loans, payments) must go through the server API.

## 5. What Was NOT Changed (Intentionally)

- Server routes / PostgreSQL schema — already tenant-scoped and production-oriented
- Photo storage still base64 in DB (object storage is a deployment decision)
- Full offline collection sync — out of scope for this fix pass
- Complete removal of all client-side Storage for prototype-era modules that still support local demos

## 6. How to Verify

```bash
# 1. Hard refresh browser (Ctrl+F5) after deploying
# 2. Open DevTools → Application → Local Storage
#    - Old keys imp_installment_schedules / imp_payment_audits should migrate/disappear
# 3. Language switch, loan/payment/member registration settings should still save
# 4. Payment flow must use SessionManager (no currentUserId key)
```

## 7. Remaining Recommendations (Future Work)

1. Move photos to object storage (S3/MinIO)
2. Server-side settings API (org-scoped) instead of browser-only UI config
3. Expand production tests for payment concurrency + reverse/cancel
4. Complete frontend cutover so no business module reads Storage.KEYS for members/loans/payments when API is available

## Verdict

Audit blockers related to **canonical keys**, **legacy current-user keys**, and **raw localStorage in settings** are fixed in this package.

---

## 11.P.16 — Settings API + Photo Disk Storage (this pass)

### Settings (server-authoritative)
- New route: `GET/PUT /api/settings`, `GET/PUT /api/settings/:key`
- Keys: `loan_ui_config`, `payment_ui_config`, `member_registration_ui`, `dashboard_config`, `daily_collection_config`
- Stored in existing `organization_settings` (tenant-scoped, permission: `settings.view` / `settings.update`)
- Frontend: `js/settings/settings-api.js` + loan/payment/member-registration settings pages use API only

### Photos
- Migration `015_settings_photo_storage.sql` adds `photo_path` on members + member_nominees
- New writes save to disk under `uploads/{orgId}/members|nominees/` and store path
- Legacy BYTEA still readable via `resolvePhotoUrl` fallback
- Static serve: `/uploads` in `server/app.js`

### Deploy notes
1. Run `npm run db:migrate` (applies 015)
2. Ensure process can write to `uploads/`
3. Hard refresh frontend

---

## 11.P.16.1 — Dashboard cutover + BYTEA photo migration

### Dashboard settings
- `js/settings/dashboard-settings.js` now uses **SettingsAPI** (`dashboard_config`) first
- Falls back to `/api/dashboard/config` if SettingsAPI missing
- `PUT /api/settings/dashboard_config` accepts either `settings.update` **or** `dashboard.customize`

### Photo migration script
```bash
npm run migrate:photos:dry   # preview
npm run migrate:photos       # write files + update DB + clear BYTEA
```
- Skips rows that already have `photo_path`
- Safe to re-run
- Writes under `uploads/{orgId}/members|nominees/`

### Verify
1. `npm run db:migrate`
2. `npm run migrate:photos:dry` then `npm run migrate:photos`
3. Dashboard Settings page → save → reload
4. Member with old BYTEA photo should get `/uploads/...` URL after migration
