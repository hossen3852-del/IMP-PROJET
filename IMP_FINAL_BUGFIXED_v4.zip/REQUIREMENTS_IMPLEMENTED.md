# IMP — 5 Requirements Implemented (Final)

## 1. Loan Add — no duplicate + clear form + success message
- Submit button disables while saving (prevents double POST → two loans).
- Idempotency-Key on create request.
- On success: form fields cleared; success message shown **below** submit button.
- No auto-redirect to loan profile (stays on form for next entry).

## 2. Payment module — Daily Collection section UI
- Filters replaced with a **single search** (name / member code / loan id) + date range.
- Cards: **পরিশোধিত (Paid)** count and **বকেয়া / Baki** count.
- Arrears member list with **Show / Hide** (default **hidden**).
- API adds `arrearsMembers`, `paidMemberCount`, `bakiMemberCount` on collection-report.

## 3. Daily Collection — frequency dropdown + once per day
- Dropdown: **দৈনিক / সাপ্তাহিক / মাসিক** filters members by loan `installment_frequency`.
- After successful submit for a frequency on a given date, **জমা দিন** stays disabled for that frequency.
- Other frequencies remain enabled until submitted.
- Success list of submitted member names shown below.

## 4. Member list — Delete button rules
- Delete shown only when member has **no** open loan (`draft/pending/approved/disbursed/active`).
- New members and members with only **completed/cancelled** loans can be deleted.
- Server still enforces the same rule on DELETE.

## 5. Mobile sidebar icon position
- Menu (☰) moved to **top-right**, under profile area (`top: 56px; right: 12px`).
- No longer overlaps dashboard home icon on the left.

## Deploy
1. Unzip / overlay this package.
2. Restart API server.
3. Hard refresh browser (Ctrl+Shift+R).
