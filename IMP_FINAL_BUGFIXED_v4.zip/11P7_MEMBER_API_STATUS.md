# IMP 11.P.7 — Member API + Frontend Member Cut-over

Source of truth: IMP_PRODUCTION_11P6_TENANT_ISOLATION.zip

## Completed
- Server-authoritative Member CRUD under `/api/members`
- Tenant-scoped list/detail/create/update/delete
- Server-side member permissions
- Branch ownership validation against authenticated organization
- Nominee, document, activity, family and financial API endpoints
- PostgreSQL-backed member profile fields (`personal_info`, `financial`, `family`)
- Frontend MemberService switched from localStorage to `IMP_API`
- In-memory cache only for UI compatibility; not an authority
- Member add/edit/list/profile/child workflows updated for asynchronous API access
- Canonical member status aligned with database: `active`, `suspended`, `inactive`
- Audit events for core member mutations

## Validation
- JavaScript syntax: PASS
- Full regression: 86/86 PASS
- PostgreSQL runtime migration was not executed in this environment because no PostgreSQL server was available.

## Security
- Client `organization_id` is never trusted for tenant selection.
- Every member resource query is constrained by `req.auth.organization_id`.
- Child resources are constrained by both organization and parent member.
- Backend permission checks remain the final security boundary.

## Post-audit fixes (2026-09-16)
- NID uniqueness enforced (migration 017 + API 409 checks)
- Race-safe member_code generation with advisory lock
- All 185 tests PASS

