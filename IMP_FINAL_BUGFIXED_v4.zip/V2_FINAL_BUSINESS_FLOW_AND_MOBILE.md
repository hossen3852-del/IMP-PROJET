# IMP V2 — Final Business Flow + Mobile Responsive Repair

Source build:
`IMP_FINAL_MEMBER_ADMISSION_LOAN_INSURANCE_FLOW_V1.zip`

## Final transaction ownership

```text
Member Add
  -> Admission Fee ONLY

Loan Disbursement
  -> Insurance Premium ONLY

Daily Collection
  -> Installment + Savings ONLY
  -> NO Admission Fee
  -> NO Insurance Premium

Capital
  -> Opening Capital / Adjustment / Withdrawal ONLY
  -> NO manual Admission Fee
  -> NO manual Insurance Premium
```

## V2 repairs

- Capital POST API now accepts only `capital_in`, `capital_adjustment`, and `capital_withdrawal`.
- Capital UI exposes only those three manual entry types.
- Admission fee remains a server-created `capital_entries.entry_type = admission_fee` event owned by Member Add; it is not manually creatable from Capital.
- Insurance premium creation through the generic insurance transaction endpoint is disabled. Loan Disbursement remains the owner of premium creation.
- Insurance claims remain available through the insurance module and are not Capital entry types.
- Dashboard Daily Collection is now `installment + savings - daily expense` and no longer queries admission fee.
- Added a shared mobile responsive stylesheet to every HTML page.
- Added viewport metadata to every HTML page.
- Mobile forms, KPI cards, tables, modals and action controls receive responsive/touch-friendly behavior.

## Verification

- `npm test`: 199 PASS / 0 FAIL
- JavaScript syntax: 119 files checked / 0 errors
- HTML pages: 51
- HTML pages with mobile stylesheet: 51/51
- HTML pages with viewport metadata: 51/51

## Production note

This V2 package is a repaired application build. Real PostgreSQL staging E2E, live browser E2E, production SMTP, backup/restore and infrastructure validation remain separate production go-live gates.
