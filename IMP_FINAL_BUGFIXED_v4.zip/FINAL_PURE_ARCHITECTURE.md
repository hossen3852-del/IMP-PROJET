# IMP — Final Pure Layered Architecture

Build status: **Final Pure Architecture / V5.2**

## Boundary contract

```text
HTTP request
    ↓
Route
    ↓
Controller
    ↓
Service / Use Case
    ↓
Repository
    ↓
PostgreSQL
```

### Route
Route modules own Express router declarations, middleware composition, URL paths, and HTTP method registration. They do not contain SQL or direct database calls.

### Controller
Controller modules are the HTTP adapter. They convert `req` into a framework-neutral service context and convert application results back into HTTP responses. Direct PostgreSQL access and SQL are forbidden.

### Service
Services contain business rules and use-case orchestration. Services must not import Express, access `req`/`res`/`next`, declare router endpoints, or access the PostgreSQL pool directly.

### Repository
Repositories are the only application-layer PostgreSQL boundary. SQL, transactions, query registry entries, row locking, and database execution live here.

## Additional production boundaries

- Authentication/session database access is repository-owned.
- Tenant and branch scope decisions are derived from authenticated server context.
- Browser Storage is not authoritative for business records.
- Legacy `server/_v4_controllers/` compatibility code is removed.
- Controller adapters expose all service middleware guards used by route modules.

## Verification

The packaged build was verified with:

- Full automated suite: **217 tests passed, 0 failed**.
- JavaScript syntax check: **all JS files passed**.
- Static architecture scan: no HTTP leakage in Services, no SQL in Routes/Controllers, no direct DB imports outside repository/infrastructure, and no legacy V4 controller directory.

A live external PostgreSQL integration test was not executed in this build environment because no production database connection was available. Database migrations and repository SQL remain included for deployment-time validation.
