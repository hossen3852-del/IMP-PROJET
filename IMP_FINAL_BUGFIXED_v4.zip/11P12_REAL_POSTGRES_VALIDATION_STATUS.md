# IMP — 11.P.12 Real PostgreSQL Validation

## Status
**PARTIALLY COMPLETE — validation harness implemented; real PostgreSQL execution blocked by environment.**

## Source of truth
`IMP_PRODUCTION_11P11_PRODUCTION_HARDENED.zip`

## Added
- `scripts/validate-production-db.js`
- `tests/production/real-postgres-validation.test.js`
- `npm run db:validate`

## Validator coverage
- Requires a real `DATABASE_URL`; it cannot report success without a database.
- Connects using the production PostgreSQL client.
- Reports database/user/PostgreSQL version.
- Verifies migrations `001` through `010` are applied.
- Verifies required production tables.
- Verifies critical tenant foreign keys.
- Verifies payment idempotency unique index.
- Verifies money columns use `NUMERIC(18,2)`.
- Executes a transaction rollback smoke test.

## Environment result
The current execution environment has:
- no `psql` executable
- no `postgres` server executable
- no Docker runtime
- `127.0.0.1:5432` closed

Therefore **a real PostgreSQL migration/transaction test cannot honestly be marked PASS here**.

## Automated regression
`npm test` → **127/127 PASS**.

## Required external validation
Against a dedicated staging PostgreSQL database:

```text
npm run db:migrate
npm run db:validate
npm test
```

Then perform the same validation against production only after a verified backup and change window.

## Important
No fake PostgreSQL result has been inserted into the project. The validator intentionally fails when `DATABASE_URL` is absent.
