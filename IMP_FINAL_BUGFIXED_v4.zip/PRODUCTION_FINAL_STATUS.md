# Production Final Status — V6.0.9

Current package: `1.6.9`
Release: `V6.0.9`

## Daily Collection

- Current due/arrears balance is shown automatically from the route sheet.
- Baki click enables Save Member and records status without money movement.
- Savings-only collection remains supported when installment due is zero.
- Advance installment collection is configurable from Daily Collection settings.
- Advance amount is entered separately; the server combines current due + advance.
- Advance collection cannot exceed loan outstanding.
- When enabled, FIFO allocation applies the payment across unpaid installments in due-date order, including future installments.
- Optional note-on-advance setting remains supported.

## Validation

- Production/static regression tests: 260 passed, 0 failed.
- JavaScript syntax check: 0 errors.
- HTML local-asset scan: one existing dashboard query-string pseudo-link is reported by the generic scanner; it is not a missing runtime asset.
- Live PostgreSQL/provider/browser E2E validation requires the target environment.
