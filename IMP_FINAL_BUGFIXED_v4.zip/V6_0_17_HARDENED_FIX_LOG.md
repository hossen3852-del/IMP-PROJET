# V6.0.17 Hardened Fix Log

## Critical startup fix

Fixed the authentication controller startup failure:

`TypeError: service handler must be a function`

### Root cause
`server/controllers/auth.js` creates the controller adapter:

`handler(service.put_admin_credentials_8)`

but `server/services/authService.js` defined `put_admin_credentials_8` without exporting it.

### Fix
Added `put_admin_credentials_8` to `module.exports` in `server/services/authService.js`.

### Regression protection
Added a production test asserting that every authentication controller adapter has a corresponding service export.

## Verification
- `npm test`: 279 passed, 0 failed
- JavaScript syntax checks: passed for modified files
- ZIP integrity: verified after packaging
