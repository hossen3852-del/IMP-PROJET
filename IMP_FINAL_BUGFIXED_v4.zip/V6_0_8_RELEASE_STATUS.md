# V6.0.8 Release Status

## Daily Collection Baki behavior

- Clicking **Baki** directly changes the member row to `baki`.
- **Save Member** becomes enabled after the Baki action, even when installment balance is zero.
- Saving a Baki row records status only and performs no money movement.
- Paid rows retain the existing rule: Save Member is enabled only when an installment balance is due.
- Savings-only collection remains available through the global Submit action.

## Validation

- Package version: `1.6.8`
- Production regression tests: 257/257 expected after version-sync assertions.
- Live PostgreSQL E2E was not executed in this environment.
