# 11.P.13 — Organization Admin Registration Fix

The registration UI now explicitly shows `Organization Admin` as the first-user role. The role is read-only in the browser and is NOT trusted from the client. The server remains authoritative: `POST /api/auth/register` creates the organization, invokes `create_default_org_rbac(organization_id)`, resolves the tenant-scoped `organization_admin` role, assigns `users.role_id`, and creates the authenticated session transactionally.

## Test
1. Run `npm run db:migrate` against the staging PostgreSQL instance.
2. Open `pages/auth/register.html`.
3. Register a new organization with a new email.
4. Confirm the response user role is `organization_admin`.
5. Confirm `/api/auth/me` returns `role: organization_admin` and the expected organization.
6. Confirm the user row has a tenant-scoped `role_id` pointing to the organization's `organization_admin` role.
7. Confirm the dashboard loads without manually editing the database.

No client-supplied role is accepted by the registration API.
