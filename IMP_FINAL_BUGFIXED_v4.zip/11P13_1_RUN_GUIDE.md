# IMP 11.P.13.1 Run Guide

1. Copy `.env.example` to `.env`.
2. Put the real staging PostgreSQL password in `DATABASE_URL`; this build expects the local PostgreSQL port configured by the operator (the validated example is 3200).
3. Run `npm ci`.
4. Run `npm run db:migrate`.
5. Run `npm run db:validate`.
6. Run `npm test` (expected: 143 passing tests in this build).
7. Run `npm start`.
8. Test the browser flow: Register -> Login -> Organization -> Branch -> User/Role -> Member -> Loan -> Approve -> Disburse -> Installment -> Payment -> Allocation -> Receipt -> Payment History.

Do not commit or share `.env`. Real PostgreSQL E2E is still required before declaring production PASS.
