# V6.0.8 Release Status

## Scope
- Member list now exposes authenticated member and nominee photo URLs plus nominee NID.
- Member profile displays member photo, nominee NID and nominee photo.
- Daily collection pre-fills the current collectible installment balance and refreshes after save.
- Row-level **Save Member** is enabled only when installment balance is due.
- When installment balance is zero, savings can still be entered and saved through **জমা দিন / Submit**.
- Server rejects installment collection above the current due installment balance.

## Package
- Version: `1.6.8`
- Base: V6.0.6 Member Edit Fix
