# IMP Environment Setup

The application intentionally fails closed when `DATABASE_URL` is missing. This is a production-safety requirement, not a Register Form error.

## Windows PowerShell

From the `IMP_src` folder:

```powershell
.\SETUP_ENV.ps1
notepad .env
npm start
```

For the existing staging PostgreSQL setup, the expected connection shape is:

```text
postgresql://imp_staging_user:YOUR_PASSWORD@localhost:3200/imp_staging
```

Do not commit `.env` or share its password/secret.
