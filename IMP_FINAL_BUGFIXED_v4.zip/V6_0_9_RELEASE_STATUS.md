# V6.0.9 Release Status

## Daily Collection — Advance Installment Flow

- Added configurable daily-collection advance installment support.
- Current due remains read-only and visible.
- Collector enters excess amount in a separate Advance Installment field.
- Server is authoritative: advance is allowed only when enabled and total payment cannot exceed loan outstanding.
- FIFO allocation applies payment to unpaid installments in due-date order, including future installments for advance collection.
- Existing Baki and savings-only flows remain supported.
- Package version: 1.6.9.

Live PostgreSQL E2E validation still requires the target database environment.
