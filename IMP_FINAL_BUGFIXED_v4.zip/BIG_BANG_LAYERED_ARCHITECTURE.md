# IMP Big-Bang Layered Architecture

Browser -> Express -> Middleware -> Route -> Controller -> Service -> Repository -> PostgreSQL

- `server/routes/`: route composition only.
- `server/controllers/`: endpoint implementation and HTTP orchestration.
- `server/services/`: application service boundary used by controllers.
- `server/repositories/`: PostgreSQL access boundary.
- `server/middleware/`: authentication, RBAC, tenant and branch isolation.
- `server/db/`: migrations.

This is a big-bang structural cut-over. Existing endpoint behavior and financial rules are preserved; the HTTP implementation is moved behind controllers and persistence is routed through the service/repository boundary.
