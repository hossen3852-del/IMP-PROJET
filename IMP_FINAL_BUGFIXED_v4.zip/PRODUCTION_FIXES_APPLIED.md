# IMP Production Fixes Applied (Final Hardened Build)

Date: 2026-09-04

## Critical runtime bugs fixed

1. **Migration runner crash**
   - File: `server/db/migrate.js`
   - Problem: `const { pool } = require('../config/db')` while `db.js` exports the pool as default.
   - Fix: `const pool = require('../config/db');`
   - Impact: `npm run db:migrate` now loads correctly.

2. **Weak production SSL default**
   - Files: `server/config/db.js`, `server/config/env.js`, `.env.example`
   - Problem: Production always used `{ rejectUnauthorized: false }` (MITM risk).
   - Fix: Configurable `DATABASE_SSL` (`require` | `prefer` | `disable` | `no-verify`).
   - Default in production: `require` (certificate verification on).
   - `no-verify` kept only as explicit opt-in for environments without CA.

3. **Password policy inconsistency**
   - Files: `js/core/utils.js`, `js/auth/auth.js`, `js/company/organization-users.js`
   - Problem: Frontend accepted 6-character passwords; server required 8.
   - Fix: Frontend `isValidPassword` and all related error messages now require **minimum 8 characters**, matching server Zod rule.

## What this build is

- Canonical Core Storage (11.3.1) — single localStorage gateway.
- Production auth foundation (Argon2id, hashed sessions, HttpOnly cookies, rate limit).
- PostgreSQL schema 001 + 002 (tenant-aware, NUMERIC money, idempotency).
- Migration runner fixed and transactional.
- Security defaults hardened.

## What this build is NOT (remaining architectural work)

The following are intentional scope boundaries of the 11.P.2 layer, not bugs of this fix pass:

- Browser/localStorage still holds Members, Loans, Installments, Payments business data.
- Client-side AuthManager still stores password fields for the prototype UI path.
  Real production multi-tenant SaaS requires full cut-over to server auth + domain APIs (11.P.3+).
- No domain REST APIs yet beyond `/api/auth` and `/api/health`.
- Cross-row tenant integrity (member/branch same organization) is reserved for 11.P.6 triggers/guards.
- Full RBAC route enforcement and CSRF protection for future state-changing APIs still pending.

## How to run

```bash
npm install
cp .env.example .env   # set real DATABASE_URL and secrets
npm run db:migrate
npm test
npm start
```

## Test commands

```bash
node tests/storage.test.js
npm test
```

## Verdict

All identified **runtime and configuration bugs** from the deep audit have been fixed.
The package is a clean, hardened 11.P.2 production-foundation build ready for the next migration phase (authentication cut-over and domain APIs).
