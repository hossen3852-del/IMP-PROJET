# IMP — 11.P.11 Production Hardening Status

Status: COMPLETED (code hardening + static/regression validation)

Source of truth: IMP_PRODUCTION_11P10_PAYMENT_API_TRANSACTION.zip

## Implemented

- Strict production environment validation
- Production CORS cannot be wildcard and requires explicit CORS_ORIGIN
- Production DATABASE_SSL cannot be disabled
- Production session cookie is `__Host-imp_session`
- Configurable JSON body limit
- HTTP request timeout and server header/keep-alive hardening
- PostgreSQL statement/query timeouts
- PostgreSQL pool application name
- Request correlation ID via `X-Request-ID`
- Graceful SIGTERM/SIGINT shutdown with PostgreSQL pool close
- Migration advisory lock to prevent concurrent migration runners
- Production-safe error response without internal error details
- Global write rate limit plus stricter payment write rate limit
- Existing Helmet, HttpOnly, Secure production cookie, SameSite and same-origin controls preserved

## Validation

- JavaScript syntax checks: PASS
- Full regression: 124/124 PASS
- PostgreSQL runtime execution: NOT AVAILABLE in this execution environment

## Production deployment prerequisites

1. Set real `DATABASE_URL` and TLS configuration.
2. Set explicit production `CORS_ORIGIN`.
3. Keep `COOKIE_NAME=__Host-imp_session`.
4. Run `npm ci --omit=dev` (or equivalent locked install) on the server.
5. Run `npm run db:migrate` against a staging database first, then production after backup.
6. Verify HTTPS, reverse proxy and `TRUST_PROXY=1` only when exactly one trusted proxy is configured.
7. Configure PostgreSQL backups and restore testing.
8. Run the next real-DB validation phase (`11.P.12`).
