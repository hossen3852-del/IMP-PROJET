# IMP — Final Daily Collection Business Logic

1. **Member Add → Admission Fee**: admission fee is entered on the member registration form and posted to `capital_entries` inside the same PostgreSQL transaction as member creation.
2. **Loan Disbursement → Insurance**: insurance is entered when an approved loan is disbursed and posted to `member_insurance_transactions` linked to the member and loan.
3. **Daily Collection**: only installment and savings collection remain on the field collection form (plus daily expense).
4. **No double-counting**: disbursement insurance is not also inserted into `capital_entries`; dashboard capital already includes the member insurance ledger.
5. **Source of truth**: PostgreSQL/API remains authoritative for all balances and dashboard/reporting UI.
