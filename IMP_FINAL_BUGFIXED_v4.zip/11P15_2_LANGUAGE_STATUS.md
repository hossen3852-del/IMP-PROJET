# IMP 11.P.15.2 — Bangla / English Language Switch

## Implementation
- Added shared `js/core/i18n.js` for Bengali (default) and English UI switching.
- Added `css/i18n.css` language selector.
- Added the language module and stylesheet to all non-empty HTML UI pages.
- Language preference key: `imp_ui_language` (UI preference only; never an authentication, tenant, or financial authority).
- Added common dashboard, navigation, form, loan, payment, savings, insurance, capital, expense, RBAC and authentication translations.
- Dynamic DOM content is translated through a MutationObserver so dashboard KPI cards and runtime-rendered messages participate in the switch.
- Default language is Bengali; selecting English switches to English and persists across page navigation in the browser.

## Validation
- JavaScript syntax check: PASS
- i18n-specific tests: 3/3 PASS
- Full automated suite: 168/168 PASS
- Failed tests: 0

## Existing project note
Two legacy HTML files in the supplied project are empty (`pages/members/payment-audit.html` and `pages/settings/company-profile.html`). They are not active UI pages and were not repurposed as part of the language layer.

## Next production gate
Run against the user's PostgreSQL staging database:
`npm run db:validate`
Then start the application with the user's local `.env` and manually verify Bangla ↔ English on the dashboard and all protected modules.
