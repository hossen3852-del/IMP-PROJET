# V6.0.10 — Staging migration + smoke test

Run this against a **staging** database only — never production.

```bash
export DATABASE_URL=postgres://user:pass@staging-host:5432/imp_staging
npm install
npm run db:migrate
npm run db:smoke-test
```

## What each step does

1. `npm run db:migrate` — applies the full migration chain, including the
   new `027_v6_0_10_bugfix_daily_collection` migration (idempotency columns
   for savings/expense entries, and the new `written_off` loan status).
   This must run as its own process — it closes the shared DB connection
   pool when it finishes, so it cannot safely share a process with the
   smoke test.

2. `npm run db:smoke-test` — creates one isolated test organization
   (`SMOKE<timestamp>`), exercises the 9 bug scenarios from the audit
   against the real, patched service functions and a real transaction, and
   deletes everything it created afterward (success or failure). It prints
   a ✅/❌ line per scenario in Bengali, matching the original bug numbering,
   and exits non-zero if anything fails.

If the smoke test's cleanup step itself fails partway (rare — e.g. the
process is killed mid-run), it prints the leftover organization's UUID so
you can remove it manually:

```sql
-- only if the script's own cleanup could not finish
DELETE FROM organizations WHERE id = '<uuid printed by the script>';
```

## What this does *not* cover

- The CSP inline-handler fix (bug #8) needs a browser/DOM — it's verified
  by the static test suite (`npm test`) instead, and the smoke test just
  notes that.
- No maker-checker / dual-approval workflow for waiver or write-off exists
  yet — that's a larger feature, out of scope for this bugfix pass.
- This is not a load test. It runs each scenario once, sequentially.
