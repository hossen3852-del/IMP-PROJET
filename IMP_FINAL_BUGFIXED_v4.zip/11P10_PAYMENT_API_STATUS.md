# IMP 11.P.10 — Payment API + Transaction

Status: COMPLETED
Source of truth: IMP_PRODUCTION_11P9_INSTALLMENT_API_FRONTEND_CUTOVER.zip

Implemented:
- Tenant-scoped Payment API
- Atomic payment posting transaction
- FIFO installment allocation
- Advance allocation for permitted overpayment
- Installment paid/outstanding/status updates in same transaction
- Loan outstanding/completion update in same transaction
- Organization-scoped Idempotency-Key support
- Server-generated payment and receipt numbers
- Server-side receipt creation
- Payment cancellation and reversal with allocation rollback and receipt voiding
- RBAC: payment.view/payment.create/payment.cancel/payment.reverse
- Tenant-safe member/loan/collector validation
- Payment audit events
- API-backed payment entry/history/details/receipt frontend cut-over

Validation:
- Full regression: 118/118 PASS
- JavaScript syntax: all project JS files PASS
- Live PostgreSQL execution: not available in this environment; staging/production migration execution required.
