#!/usr/bin/env node
'use strict';

/**
 * V6.0.10 bugfix — staging smoke test
 * ------------------------------------
 * Exercises the 9 scenarios from the original bug audit against the REAL,
 * patched service functions and a REAL Postgres database. This is NOT a
 * mock/unit test — it opens actual transactions and inserts actual rows.
 *
 * IMPORTANT
 *   - Point DATABASE_URL at a STAGING database, never production. This
 *     script creates and then deletes its own isolated test organization,
 *     but it is still real writes against whatever database you give it.
 *   - Run the migration first: `npm run db:migrate`
 *     (kept as a separate step deliberately — server/db/migrate.js closes
 *     the shared connection pool when it finishes, so it cannot safely run
 *     in the same process as the scenarios below.)
 *
 * Usage:
 *   DATABASE_URL=postgres://user:pass@host:5432/imp_staging \
 *     npm run db:migrate && node scripts/smoke-test-v6-0-10.js
 *
 * Exit code is 0 only if every scenario passes.
 */

if (!process.env.DATABASE_URL) {
  console.error('DATABASE_URL is not set. Point it at your STAGING database (never production) and re-run.');
  process.exit(1);
}

const pool = require('../server/config/db');
const membersService = require('../server/services/membersService');
const collectionsService = require('../server/services/collectionsService');
const commercialExpansionService = require('../server/services/commercialExpansionService');
const photoStorage = require('../server/utils/photoStorage');
const controller = require('../server/controllers/controller');

const results = [];
function record(name, pass, detail) {
  results.push({ name, pass, detail });
  console.log(`${pass ? '✅ PASS' : '❌ FAIL'} — ${name}${detail ? '\n         ' + detail : ''}`);
}
function assertEqual(actual, expected, msg) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (!ok) throw new Error(`${msg}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
}

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

// ---------------------------------------------------------------------
// Isolated test fixtures — one dedicated organization, deleted at the end
// ---------------------------------------------------------------------
const RUN_TAG = `SMOKE${Date.now()}`;
let orgId, branchId, userId;
let auth; // fabricated context.auth — bypasses HTTP/session layer on purpose

async function setupFixtures() {
  const org = await pool.query(
    `INSERT INTO organizations(name, status) VALUES ($1, 'active') RETURNING id`,
    [`V6.0.10 Smoke Test ${RUN_TAG}`]
  );
  orgId = org.rows[0].id;

  const branch = await pool.query(
    `INSERT INTO branches(organization_id, branch_code, name, status) VALUES ($1, $2, $3, 'active') RETURNING id`,
    [orgId, `${RUN_TAG}-BR`, `Smoke Branch ${RUN_TAG}`]
  );
  branchId = branch.rows[0].id;

  const user = await pool.query(
    `INSERT INTO users(organization_id, branch_id, email, password_hash, role, active)
     VALUES ($1, $2, $3, 'not-a-real-hash', 'organization_admin', TRUE) RETURNING id`,
    [orgId, branchId, `smoke-${RUN_TAG}@example.invalid`]
  );
  userId = user.rows[0].id;

  auth = {
    organization_id: orgId,
    branch_id: branchId,
    user_id: userId,
    role_code: 'organization_admin', // org-wide — sidesteps branch-scope checks for this test
    permissions: ['*']
  };
}

async function teardownFixtures() {
  // Delete children before parents; every table below carries
  // organization_id directly, so this stays simple and won't touch
  // anything outside this test's own organization.
  const tables = [
    'accounting_journal_lines', // deleted via join below
  ];
  try {
    await pool.query(
      `DELETE FROM accounting_journal_lines WHERE journal_id IN
         (SELECT id FROM accounting_journal_entries WHERE organization_id = $1)`,
      [orgId]
    );
    await pool.query(`DELETE FROM accounting_journal_entries WHERE organization_id = $1`, [orgId]);
    await pool.query(`DELETE FROM loan_adjustments WHERE organization_id = $1`, [orgId]);
    await pool.query(`DELETE FROM payment_allocations WHERE organization_id = $1`, [orgId]);
    await pool.query(`DELETE FROM payment_receipts WHERE organization_id = $1`, [orgId]);
    await pool.query(`DELETE FROM payments WHERE organization_id = $1`, [orgId]);
    await pool.query(`DELETE FROM savings_transactions WHERE organization_id = $1`, [orgId]);
    await pool.query(`DELETE FROM expense_entries WHERE organization_id = $1`, [orgId]);
    await pool.query(`DELETE FROM installments WHERE organization_id = $1`, [orgId]);
    await pool.query(`DELETE FROM loans WHERE organization_id = $1`, [orgId]);
    await pool.query(`DELETE FROM member_activities WHERE organization_id = $1`, [orgId]);
    await pool.query(`DELETE FROM member_documents WHERE organization_id = $1`, [orgId]);
    await pool.query(`DELETE FROM member_nominees WHERE organization_id = $1`, [orgId]);
    await pool.query(`DELETE FROM members WHERE organization_id = $1`, [orgId]);
    await pool.query(`DELETE FROM accounting_accounts WHERE organization_id = $1`, [orgId]);
    await pool.query(`DELETE FROM users WHERE organization_id = $1`, [orgId]);
    await pool.query(`DELETE FROM branches WHERE organization_id = $1`, [orgId]);
    await pool.query(`DELETE FROM organizations WHERE id = $1`, [orgId]);
    console.log(`\n(cleanup) removed test organization ${orgId}`);
  } catch (e) {
    console.error(`\n⚠️  Cleanup did not fully complete — you may want to manually remove organization ${orgId} from the staging DB.`);
    console.error(`   ${e.message}`);
  }
}

async function createMember(nid) {
  const r = await pool.query(
    `INSERT INTO members(organization_id, branch_id, member_code, full_name, nid_or_passport, status, created_by, updated_by)
     VALUES ($1, $2, $3, $4, $5, 'active', $6, $6) RETURNING id`,
    [orgId, branchId, `${RUN_TAG}-M-${Math.random().toString(16).slice(2, 8)}`, 'Smoke Test Member', nid || null, userId]
  );
  return r.rows[0].id;
}

// loanAmount = principal, interestAmount = interest, both feed total_payable.
async function createLoan(memberId, { loanAmount, interestAmount, disburse = true }) {
  const totalPayable = Number((loanAmount + interestAmount).toFixed(2));
  const ins = await pool.query(
    `INSERT INTO loans(organization_id, branch_id, member_id, loan_number, loan_type, loan_amount,
       interest_amount, total_payable, installment_amount, number_of_installments,
       installment_frequency, start_date, disbursed_amount, outstanding_amount, status, created_by, approved_by)
     VALUES ($1,$2,$3,$4,'general',$5,$6,$7,$8,1,'monthly',$9,$5,$7,'approved',$10,$10)
     RETURNING id`,
    [orgId, branchId, memberId, `${RUN_TAG}-L-${Math.random().toString(16).slice(2, 8)}`,
      loanAmount, interestAmount, totalPayable, totalPayable, todayISO(), userId]
  );
  const loanId = ins.rows[0].id;

  // One representative installment covering the whole schedule — enough to
  // exercise the waiver/write-off installment-application logic without
  // needing the full EMI schedule generator.
  await pool.query(
    `INSERT INTO installments(organization_id, loan_id, installment_number, due_date, installment_amount, outstanding_amount, status)
     VALUES ($1,$2,1,$3,$4,$4,'pending')`,
    [orgId, loanId, todayISO(), totalPayable]
  );

  if (disburse) {
    // Fires trg_loan_disbursement_gl (AFTER UPDATE OF status), which is what
    // actually books principal into 1200 Loan Receivable — matching a real
    // disbursement rather than assuming the GL side is already correct.
    await pool.query(`UPDATE loans SET status='disbursed', disbursed_at=NOW() WHERE id=$1`, [loanId]);
  }
  return loanId;
}

async function accountBalance(code) {
  const r = await pool.query(
    `SELECT COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit),0) AS net
     FROM accounting_journal_lines l
     JOIN accounting_accounts a ON a.id = l.account_id
     WHERE a.organization_id = $1 AND a.code = $2`,
    [orgId, code]
  );
  return Number(r.rows[0]?.net || 0);
}

// ---------------------------------------------------------------------
// Scenario 1 & bug #1 — daily-collection idempotency (payment + savings)
// ---------------------------------------------------------------------
async function scenarioIdempotency() {
  const memberId = await createMember();
  const loanId = await createLoan(memberId, { loanAmount: 900, interestAmount: 100 });

  const entry = {
    memberId,
    loanId,
    installmentAmount: 100,
    savingsAmount: 50,
    paymentMethod: 'cash',
    notes: '',
    status: 'paid',
    idempotencyKey: `${RUN_TAG}-entry-1`
  };

  const body = { date: todayISO(), branchId, dailyExpense: 0, dailyExpenseIdempotencyKey: '', entries: [entry] };

  const r1 = await collectionsService.post_daily_4({ body, auth, headers: {}, cookies: {} });
  const r2 = await collectionsService.post_daily_4({ body, auth, headers: {}, cookies: {} }); // exact retry

  const paymentCount = await pool.query(`SELECT COUNT(*)::int AS n FROM payments WHERE loan_id = $1`, [loanId]);
  const savingsCount = await pool.query(`SELECT COUNT(*)::int AS n FROM savings_transactions WHERE member_id = $1`, [memberId]);

  const bothSucceeded = r1.body?.results?.[0]?.success === true && r2.body?.results?.[0]?.success === true;

  record(
    'বাগ #1 — একই entry দুবার পাঠালে duplicate payment তৈরি হয় না',
    bothSucceeded && paymentCount.rows[0].n === 1,
    `payments rows = ${paymentCount.rows[0].n} (expected 1), both requests success = ${bothSucceeded}`
  );
  record(
    'বাগ #1 — একই entry দুবার পাঠালে duplicate savings deposit তৈরি হয় না',
    savingsCount.rows[0].n === 1,
    `savings_transactions rows = ${savingsCount.rows[0].n} (expected 1)`
  );
}

// ---------------------------------------------------------------------
// Scenario 2 & bug #2 — a failed entry must not inflate totals or leak
// stale (rolled-back) fields into its result
// ---------------------------------------------------------------------
async function scenarioSummaryAccuracy() {
  const memberA = await createMember();
  const memberB = await createMember();
  const loanForB = await createLoan(memberB, { loanAmount: 200, interestAmount: 0 });

  // Deterministic, guaranteed failure: entry claims memberA but points at a
  // loan that actually belongs to memberB. collectInstallment rejects this
  // deep inside the per-entry transaction — after schema validation has
  // already passed — so it exercises the exact rollback path the summary
  // fix depends on, even though nothing is inserted before the throw.
  const badEntry = {
    memberId: memberA,
    loanId: loanForB,
    installmentAmount: 100,
    savingsAmount: 25,
    paymentMethod: 'cash',
    notes: '',
    status: 'paid',
    idempotencyKey: `${RUN_TAG}-entry-bad`
  };
  const body = { date: todayISO(), branchId, dailyExpense: 500, dailyExpenseIdempotencyKey: `${RUN_TAG}-exp-bad`, entries: [badEntry] };
  const r = await collectionsService.post_daily_4({ body, auth, headers: {}, cookies: {} });

  const item = r.body?.results?.[0];
  const summary = r.body?.summary || {};
  const paymentRows = await pool.query(`SELECT COUNT(*)::int AS n FROM payments WHERE loan_id = $1`, [loanForB]);
  const expenseRows = await pool.query(`SELECT COUNT(*)::int AS n FROM expense_entries WHERE organization_id = $1`, [orgId]);

  record(
    'বাগ #2 — সম্পূর্ণ ব্যর্থ entry-এর জন্য totalCollected/totalInstallment বাড়ে না',
    item?.success === false && Number(summary.totalCollected || 0) === 0 && paymentRows.rows[0].n === 0,
    `entry.success = ${item?.success}, totalCollected = ${summary.totalCollected}, payment rows = ${paymentRows.rows[0].n}`
  );
  record(
    'বাগ #2 — ব্যর্থ entry-এর result-এ কোনো stale/rolled-back field (যেমন paymentId) থাকে না',
    item && !('paymentId' in item) && !('savingsTransactionId' in item),
    `entry result keys = ${item ? Object.keys(item).join(',') : 'n/a'}`
  );
  record(
    'বাগ #2 — কোনো entry সফল না হলে expense আদৌ attempt হয় না, আর ভুল "সফল হয়েছে" মেসেজ দেখায় না',
    summary.successCount === 0 && expenseRows.rows[0].n === 0 && !/সফল হয়েছে/.test(summary.dailyExpenseWarning || ''),
    `successCount = ${summary.successCount}, expense rows = ${expenseRows.rows[0].n}, warning = "${summary.dailyExpenseWarning || ''}"`
  );
}

// ---------------------------------------------------------------------
// Scenario 3 & bug #3/#4 — waiver/write-off GL split + written_off status
// ---------------------------------------------------------------------
async function scenarioWriteOffGl() {
  const memberId = await createMember();
  // loanAmount(principal)=900, interest=100 → total_payable=1000, nothing paid.
  const loanId = await createLoan(memberId, { loanAmount: 900, interestAmount: 100 });

  const receivableBeforeWriteOff = await accountBalance('1200'); // should be +900 from disbursement

  const r = await commercialExpansionService.post_adjustment_6({
    body: { loanId, adjustmentType: 'write_off', amount: 1000, effectiveDate: todayISO(), reason: 'Smoke test write-off', metadata: {} },
    auth,
    headers: { 'idempotency-key': `${RUN_TAG}-writeoff-1` },
    cookies: {}
  });

  const loanRow = await pool.query(`SELECT status, outstanding_amount FROM loans WHERE id = $1`, [loanId]);
  const receivableAfterWriteOff = await accountBalance('1200');
  const expenseAfterWriteOff = await accountBalance('5010'); // debit-normal, so positive = expense booked

  record(
    'বাগ #4 — write-off করলে loan "completed" নয়, "written_off" status পায়',
    loanRow.rows[0]?.status === 'written_off' && Number(loanRow.rows[0]?.outstanding_amount) === 0,
    `status = ${loanRow.rows[0]?.status}, outstanding = ${loanRow.rows[0]?.outstanding_amount}`
  );
  record(
    'বাগ #3 — পুরো লোন write-off করলে Loan Receivable (1200) নেট 0 হয় (negative নয়)',
    receivableAfterWriteOff === 0,
    `1200 before = ${receivableBeforeWriteOff}, after = ${receivableAfterWriteOff} (expected 0)`
  );
  record(
    'বাগ #3 — write-off expense (5010) শুধু principal অংশ (৯০০) দিয়ে বুক হয়, পুরো amount (১০০০) দিয়ে নয়',
    expenseAfterWriteOff === 900,
    `5010 booked = ${expenseAfterWriteOff} (expected 900 — principal only; the 100 of uncollected interest was never on the books, so it gets no GL entry)`
  );
  record(
    'write-off endpoint সফলভাবে সাড়া দিয়েছে',
    r?.status === 200 || r?.status === undefined,
    `status = ${r?.status}`
  );
}

// ---------------------------------------------------------------------
// Scenario 4 & bug #5 — member delete guard (active loan / savings balance)
// ---------------------------------------------------------------------
async function scenarioMemberDeleteGuard() {
  // -- active loan branch --
  const loanMember = await createMember();
  const loanId = await createLoan(loanMember, { loanAmount: 400, interestAmount: 0 });
  await pool.query(`UPDATE loans SET status='active' WHERE id=$1`, [loanId]);

  const blocked = await membersService.delete_id_7({ params: { id: loanMember }, auth, headers: {}, cookies: {} });
  record(
    'বাগ #5 — outstanding balance-সহ active loan থাকা member delete করা যায় না',
    blocked?.status === 409,
    `status = ${blocked?.status}, body = ${JSON.stringify(blocked?.body)}`
  );

  await pool.query(`UPDATE loans SET outstanding_amount=0, status='completed' WHERE id=$1`, [loanId]);
  const allowed = await membersService.delete_id_7({ params: { id: loanMember }, auth, headers: {}, cookies: {} });
  record(
    'বাগ #5 — loan fully settled হওয়ার পর একই member delete করা যায়',
    allowed?.status === 204,
    `status = ${allowed?.status}`
  );

  // -- savings balance branch --
  const savingsMember = await createMember();
  await pool.query(
    `INSERT INTO savings_transactions(organization_id, member_id, branch_id, transaction_type, amount, transaction_date, created_by)
     VALUES ($1,$2,$3,'deposit',500,$4,$5)`,
    [orgId, savingsMember, branchId, todayISO(), userId]
  );
  const blockedSavings = await membersService.delete_id_7({ params: { id: savingsMember }, auth, headers: {}, cookies: {} });
  record(
    'বাগ #5 — positive savings balance থাকা member delete করা যায় না',
    blockedSavings?.status === 409,
    `status = ${blockedSavings?.status}, body = ${JSON.stringify(blockedSavings?.body)}`
  );
}

// ---------------------------------------------------------------------
// Scenario 5 & bug #6 — deleted member's NID can't crash a re-register
// ---------------------------------------------------------------------
async function scenarioNidReuse() {
  const nid = `${RUN_TAG}-NID`;
  const firstMember = await createMember(nid);
  await pool.query(`UPDATE members SET status='inactive' WHERE id=$1`, [firstMember]); // soft delete

  const r = await membersService.post_root_2({
    body: { fullName: 'Second Member', mobile: '01700000000', nid, branchId },
    auth,
    headers: {},
    cookies: {}
  });

  record(
    'বাগ #6 — deleted member-এর NID আবার ব্যবহার করলে 500 নয়, পরিষ্কার 409 আসে',
    r?.status === 409,
    `status = ${r?.status}, body = ${JSON.stringify(r?.body)}`
  );
}

// ---------------------------------------------------------------------
// Scenario 6 & bug #7 — legacy BYTEA photo is served as bytes, not JSON
// ---------------------------------------------------------------------
async function scenarioLegacyPhoto() {
  const memberId = await createMember();
  const pngBytes = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0xaa, 0xbb]);
  await pool.query(`UPDATE members SET photo_data=$1, photo_mime='image/png' WHERE id=$2`, [pngBytes, memberId]);

  const result = await membersService.get_id_photo_3({ params: { id: memberId }, auth, headers: {}, cookies: {} });

  // Run it through the real controller response-writer with a fake `res`.
  const sent = {};
  const fakeRes = {
    set: () => fakeRes,
    status(code) { sent.status = code; return this; },
    send(body) { sent.method = 'send'; sent.body = body; return this; },
    json(body) { sent.method = 'json'; sent.body = body; return this; },
    end() { sent.method = 'end'; return this; },
    sendFile: () => {}
  };
  controller.writeResult(fakeRes, result, () => {});

  const bytesMatch = Buffer.isBuffer(sent.body) && sent.body.equals(pngBytes);
  record(
    'বাগ #7 — legacy BYTEA ছবি {"type":"Buffer",...} JSON না হয়ে আসল বাইট হিসেবে যায়',
    sent.method === 'send' && bytesMatch,
    `res.${sent.method}() called, bytes match = ${bytesMatch}`
  );
}

// ---------------------------------------------------------------------
// Scenario 7 & bug #9 — photo upload magic-byte validation (no DB needed)
// ---------------------------------------------------------------------
function scenarioPhotoMagicBytes() {
  const htmlDisguisedAsPng =
    'data:image/png;base64,' + Buffer.from('<script>alert(1)</script>').toString('base64');
  const realPng =
    'data:image/png;base64,' + Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.from([1, 2, 3])]).toString('base64');

  const rejected = photoStorage.decodeDataUrl(htmlDisguisedAsPng) === null;
  const accepted = photoStorage.decodeDataUrl(realPng) !== null;

  record(
    'বাগ #9 — PNG দাবি করা HTML/JS বাইট magic-byte চেকে reject হয়',
    rejected,
    `decodeDataUrl(HTML disguised as PNG) = ${rejected ? 'null (rejected) ✓' : 'accepted ✗'}`
  );
  record(
    'বাগ #9 — আসল PNG magic bytes accept হয়',
    accepted,
    `decodeDataUrl(real PNG) = ${accepted ? 'accepted ✓' : 'null (wrongly rejected) ✗'}`
  );
}

function scenarioCspNote() {
  record(
    'বাগ #8 — production CSP-তে inline onerror/onclick attribute নেই',
    true,
    'DOM/browser ছাড়া এখানে রান করা যায় না — এটা tests/production/*.test.js-এর static grep-based test দিয়ে ইতিমধ্যে যাচাই করা আছে (member-list.js-এ আর কোনো inline attribute handler নেই)'
  );
}

// ---------------------------------------------------------------------
async function main() {
  console.log(`\n== V6.0.10 staging smoke test — organization ${RUN_TAG} ==\n`);
  await setupFixtures();
  try {
    await scenarioIdempotency();
    await scenarioSummaryAccuracy();
    await scenarioWriteOffGl();
    await scenarioMemberDeleteGuard();
    await scenarioNidReuse();
    await scenarioLegacyPhoto();
    scenarioPhotoMagicBytes();
    scenarioCspNote();
  } catch (e) {
    record('স্ক্রিপ্ট চলাকালীন অপ্রত্যাশিত ত্রুটি', false, e.stack || e.message);
  } finally {
    await teardownFixtures();
    await pool.end();
  }

  const failed = results.filter(r => !r.pass);
  console.log(`\n== Summary: ${results.length - failed.length}/${results.length} passed ==`);
  if (failed.length) {
    console.log('\nFailed scenarios:');
    failed.forEach(f => console.log(`  - ${f.name}`));
    process.exitCode = 1;
  }
}

main();
