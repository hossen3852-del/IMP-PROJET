'use strict';
const repository=require('../server/repositories');
const provider=require('../server/integrations/notificationProvider');
async function run(){
 const {rows}=await repository.queryNamed('commercialExpansion:notificationsClaim',[new Date().toISOString(),100],{});
 for(const n of rows){
  try{
   const notification={...n,templateCode:n.templateCode ?? n.template_code};
   const r=await provider.send(notification);
   await repository.queryNamed('commercialExpansion:notificationMark',[n.id,r.accepted?'sent':'failed',r.accepted?null:r.reason,r.accepted?new Date().toISOString():null,r.providerMessageId??r.provider_message_id??null],{});
  }catch(e){
   await repository.queryNamed('commercialExpansion:notificationMark',[n.id,'failed',e.message,null,null],{});
  }
 }
 await require('../server/config/db').end();
}
run().catch(e=>{console.error(e);process.exitCode=1;});
