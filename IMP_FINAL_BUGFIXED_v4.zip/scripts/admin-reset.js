'use strict';

const argon2 = require('argon2');
const readline = require('node:readline/promises');
const { stdin: input, stdout: output } = require('node:process');
const repository = require('../server/repositories');

function normalizeEmail(value) {
  return String(value || '').trim().toLowerCase();
}

function parseArgs(argv) {
  const args = {};
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (!token.startsWith('--')) continue;
    const key = token.slice(2);
    args[key] = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : true;
  }
  return args;
}

function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
}

async function askHidden(rl, question) {
  // readline cannot securely hide terminal input on every Windows shell.
  // Prefer an interactive prompt and never echo/store the password ourselves.
  if (process.stdin.isTTY && process.stdout.isTTY) {
    output.write(question);
    const chunks = [];
    input.setRawMode?.(true);
    return await new Promise((resolve) => {
      const onData = (chunk) => {
        const text = chunk.toString();
        if (text === '\u0003') {
          input.setRawMode?.(false);
          input.off('data', onData);
          output.write('\n');
          process.exit(130);
        }
        if (text === '\r' || text === '\n') {
          input.setRawMode?.(false);
          input.off('data', onData);
          output.write('\n');
          resolve(Buffer.concat(chunks).toString());
          return;
        }
        if (text === '\u007f') {
          if (chunks.length) chunks.pop();
          return;
        }
        chunks.push(Buffer.from(text));
      };
      input.on('data', onData);
    });
  }
  return rl.question(question);
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const rl = readline.createInterface({ input, output });
  const client = await repository.begin();

  try {
    const currentEmail = normalizeEmail(args.email || await rl.question('Current admin Gmail/email: '));
    if (!validateEmail(currentEmail)) throw new Error('Invalid current admin email.');

    const newEmailRaw = args['new-email'] !== undefined
      ? String(args['new-email'])
      : await rl.question('New admin Gmail/email (press Enter to keep current): ');
    const newEmail = normalizeEmail(newEmailRaw || currentEmail);
    if (!validateEmail(newEmail)) throw new Error('Invalid new admin email.');

    const password = args.password !== undefined
      ? String(args.password)
      : await askHidden(rl, 'New admin password (minimum 8 characters): ');
    if (password.length < 8 || password.length > 200) {
      throw new Error('Password must be between 8 and 200 characters.');
    }

    await client.begin();

    const userResult = await client.query(`
      SELECT u.id, u.organization_id, u.email, u.full_name, u.active,
             u.role, u.role_id, r.code AS role_code,
             o.name AS organization_name
      FROM users u
      LEFT JOIN roles r ON r.id = u.role_id
      JOIN organizations o ON o.id = u.organization_id
      WHERE lower(u.email) = $1
        AND (u.role = 'organization_admin' OR r.code = 'organization_admin')
      FOR UPDATE
    `, [currentEmail]);

    if (userResult.rowCount !== 1) {
      throw new Error('Exactly one active Organization Admin account must match the current email.');
    }

    const user = userResult.rows[0];
    if (!user.active) throw new Error('The Organization Admin account is inactive.');

    const duplicate = await client.query(
      'SELECT id FROM users WHERE lower(email) = $1 AND id <> $2 LIMIT 1',
      [newEmail, user.id]
    );
    if (duplicate.rowCount) throw new Error('The new email is already used by another account.');

    const passwordHash = await argon2.hash(password, { type: argon2.argon2id });

    const updated = await client.query(`
      UPDATE users
      SET email = $1,
          password_hash = $2,
          updated_at = NOW()
      WHERE id = $3
      RETURNING id, email, organization_id
    `, [newEmail, passwordHash, user.id]);

    const revoked = await client.query(`
      UPDATE sessions
      SET revoked_at = COALESCE(revoked_at, NOW())
      WHERE user_id = $1 AND revoked_at IS NULL
    `, [user.id]);

    await client.query(`
      INSERT INTO audit_logs (organization_id, user_id, action, entity_type, entity_id, metadata)
      VALUES ($1, $2, 'admin.credentials.reset', 'user', $2, $3::jsonb)
    `, [user.organization_id, user.id, JSON.stringify({
      previous_email: currentEmail,
      new_email: newEmail,
      sessions_revoked: revoked.rowCount,
      source: 'admin-reset-cli'
    })]);

    await client.commit();

    console.log('\nOrganization Admin credentials updated successfully.');
    console.log(`Organization: ${user.organization_name}`);
    console.log(`Login email: ${updated.rows[0].email}`);
    console.log(`Sessions revoked: ${revoked.rowCount}`);
    console.log('Use the new credentials at http://localhost:3000');
  } catch (error) {
    try { await client.rollback(); } catch (_) {}
    console.error(`\nAdmin reset failed: ${error.message}`);
    process.exitCode = 1;
  } finally {
    client.release();
    rl.close();
  }
}

main().catch((error) => {
  console.error(`Admin reset failed: ${error.message}`);
  process.exitCode = 1;
});
