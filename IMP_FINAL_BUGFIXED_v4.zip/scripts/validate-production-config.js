'use strict';
require('dotenv').config();

const production=String(process.env.NODE_ENV||'development').toLowerCase()==='production';
const missing=[];
if(!String(process.env.DATABASE_URL||'').trim()) missing.push('DATABASE_URL');
if(production){
  if(!String(process.env.CORS_ORIGIN||'').trim()) missing.push('CORS_ORIGIN');
  if(process.env.COOKIE_NAME!=='__Host-imp_session') missing.push('COOKIE_NAME=__Host-imp_session');
  if(String(process.env.DATABASE_SSL||'').toLowerCase()==='disable') missing.push('DATABASE_SSL must not be disable');
  for(const key of ['PASSWORD_RESET_BASE_URL','EMAIL_WEBHOOK_URL','EMAIL_FROM']) if(!String(process.env[key]||'').trim()) missing.push(key);
}
if(missing.length){
  console.error('Production configuration validation failed:');
  for(const item of missing) console.error(`- ${item}`);
  process.exit(1);
}
console.log(`Production configuration validation passed (${production?'production':'non-production'} mode).`);
