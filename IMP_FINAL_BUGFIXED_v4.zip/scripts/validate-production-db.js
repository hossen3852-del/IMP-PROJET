'use strict';

require('dotenv').config();
const fs = require('node:fs/promises');
const path = require('node:path');
const { Client } = require('pg');

const ROOT = path.resolve(__dirname, '..');
const MIGRATIONS = path.join(ROOT, 'database', 'migrations');

async function getMigrationVersions() {
  return (await fs.readdir(MIGRATIONS)).filter(f => f.endsWith('.sql')).sort().map(f => f.replace(/\.sql$/, ''));
}

async function validate() {
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required for real PostgreSQL validation');
  const client = new Client({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.DATABASE_SSL === 'require' ? { rejectUnauthorized: true } :
      process.env.DATABASE_SSL === 'no-verify' ? { rejectUnauthorized: false } : undefined,
    statement_timeout: Number(process.env.DB_STATEMENT_TIMEOUT_MS || 15000),
    query_timeout: Number(process.env.DB_QUERY_TIMEOUT_MS || 15000),
    application_name: 'imp-production-db-validator'
  });
  await client.connect();
  const checks = [];
  const check = async (name, sql, params = [], predicate = r => r.rowCount > 0) => {
    const r = await client.query(sql, params);
    if (!predicate(r)) throw new Error(`FAILED: ${name}`);
    checks.push(name);
  };
  try {
    const v = await client.query('SELECT current_database() AS database, current_user AS user_name, version() AS version');
    console.log(`Connected: ${v.rows[0].database} as ${v.rows[0].user_name}`);

    await check('schema_migrations table', `SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='schema_migrations'`);
    const expected = await getMigrationVersions();
    const applied = (await client.query('SELECT version FROM schema_migrations ORDER BY version')).rows.map(r => r.version);
    for (const version of expected) if (!applied.includes(version)) throw new Error(`FAILED: migration ${version} is not applied`);
    checks.push(`all ${expected.length} migrations applied`);

    const tables = ['organizations','users','sessions','roles','permissions','role_permissions','branches','members','member_nominees','member_documents','member_activities','loans','installments','payments','payment_allocations','payment_receipts','audit_logs','capital_entries','savings_transactions','expense_entries'];
    for (const table of tables) await check(`table ${table}`, `SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name=$1`, [table]);

    await check('tenant FK constraints', `SELECT 1 FROM pg_constraint WHERE conname IN ('users_role_id_fk','sessions_user_org_fk','members_branch_org_fk','loans_member_org_fk','installments_loan_org_fk','payments_loan_org_fk','payment_allocations_payment_org_fk','payment_receipts_payment_org_fk') GROUP BY 1 HAVING COUNT(*) >= 8`);
    await check('dashboard/savings/expense permissions', `SELECT COUNT(*) AS permission_count FROM permissions WHERE code IN ('capital.view','capital.manage','dashboard.customize','savings.view','savings.manage','expense.view','expense.manage') HAVING COUNT(*) = 7`);
    await check('payment idempotency unique index', `SELECT 1 FROM pg_indexes WHERE indexname='payments_org_idempotency_idx'`);
    await check('money NUMERIC(18,2)', `SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND column_name IN ('amount','loan_amount','total_payable','installment_amount') AND data_type='numeric' AND numeric_precision=18 AND numeric_scale=2 GROUP BY data_type HAVING COUNT(*) >= 4`);

    // Transaction rollback smoke test: a temporary table is isolated to this session.
    await client.query('BEGIN');
    try {
      await client.query('CREATE TEMP TABLE imp_p12_txn_probe(value integer) ON COMMIT DROP');
      await client.query('INSERT INTO imp_p12_txn_probe VALUES (1)');
      await client.query('ROLLBACK');
    } catch (e) { await client.query('ROLLBACK'); throw e; }
    const probe = await client.query("SELECT to_regclass('pg_temp.imp_p12_txn_probe') AS rel");
    if (probe.rows[0].rel !== null) throw new Error('FAILED: transaction rollback smoke test');
    checks.push('transaction rollback smoke test');

    await check('dashboard customization setting support', `SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='organization_settings' AND column_name IN ('organization_id','setting_key','setting_value') GROUP BY table_name HAVING COUNT(*) = 3`);
    await check('savings installment requires loan constraint', `SELECT 1 FROM pg_constraint WHERE conname='savings_installment_requires_loan'`);
    await check('capital insurance claim entry type', `SELECT 1 FROM pg_constraint WHERE conname='capital_entries_entry_type_check'`);
    await check('expense categories', `SELECT 1 FROM pg_constraint WHERE conname LIKE '%expense_entries%category%'`);

    console.log(`PASS: ${checks.length} PostgreSQL validation checks`);
  } finally {
    await client.end();
  }
}

if (require.main === module) validate().catch(err => { console.error(err.message); process.exitCode = 1; });
module.exports = { validate, getMigrationVersions };
