'use strict';
const {execFile}=require('node:child_process');
const {promisify}=require('node:util');
const fs=require('node:fs');
const path=require('node:path');
const exec=promisify(execFile);
async function main(){
 const dir=process.env.BACKUP_DIR||path.resolve(process.cwd(),'backups');fs.mkdirSync(dir,{recursive:true});
 const stamp=new Date().toISOString().replace(/[:.]/g,'-');const file=path.join(dir,`imp-${stamp}.dump`);
 const args=['-Fc','-f',file];if(process.env.DATABASE_URL)args.push(process.env.DATABASE_URL);else throw new Error('DATABASE_URL is required');
 await exec('pg_dump',args,{maxBuffer:1024*1024*20});console.log(`Backup created: ${file}`);
}
main().catch(e=>{console.error(e.message);process.exitCode=1;});
