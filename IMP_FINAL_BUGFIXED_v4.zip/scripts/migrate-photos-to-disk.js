#!/usr/bin/env node
/**
 * One-time migration: member/nominee BYTEA photos → disk (photo_path).
 *
 * Usage:
 *   node scripts/migrate-photos-to-disk.js
 *   node scripts/migrate-photos-to-disk.js --dry-run
 *   node scripts/migrate-photos-to-disk.js --limit=50
 *
 * Safe to re-run: skips rows that already have photo_path.
 * After successful write, clears photo_data/photo_mime to free DB space.
 */
'use strict';

require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const { Pool } = require('pg');

const args = process.argv.slice(2);
const dryRun = args.includes('--dry-run');
const limitArg = args.find(a => a.startsWith('--limit='));
const limit = limitArg ? Math.max(1, parseInt(limitArg.split('=')[1], 10) || 100) : null;

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error('Missing DATABASE_URL');
  process.exit(1);
}

const sslMode = String(process.env.DATABASE_SSL || 'disable').toLowerCase();
const ssl =
  sslMode === 'disable' ? false :
  sslMode === 'no-verify' ? { rejectUnauthorized: false } :
  { rejectUnauthorized: true };

const pool = new Pool({ connectionString: DATABASE_URL, ssl });
const UPLOAD_ROOT = path.join(__dirname, '..', 'uploads');

function extForMime(mime) {
  if (mime === 'image/png') return 'png';
  if (mime === 'image/webp') return 'webp';
  return 'jpg';
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function writePhoto(orgId, kind, entityId, mime, data) {
  const org = String(orgId).replace(/[^a-zA-Z0-9_-]/g, '');
  const safeKind = String(kind).replace(/[^a-zA-Z0-9_-]/g, '');
  const idPart = String(entityId).replace(/[^a-zA-Z0-9_-]/g, '');
  const dir = path.join(UPLOAD_ROOT, org, safeKind);
  ensureDir(dir);
  const filename = `${idPart}.${extForMime(mime || 'image/jpeg')}`;
  const abs = path.join(dir, filename);
  fs.writeFileSync(abs, data);
  return `/uploads/${org}/${safeKind}/${filename}`;
}

async function migrateMembers(client) {
  let sql = `
    SELECT id, organization_id, photo_data, photo_mime
    FROM members
    WHERE photo_data IS NOT NULL
      AND (photo_path IS NULL OR photo_path = '')
    ORDER BY created_at NULLS LAST
  `;
  if (limit) sql += ` LIMIT ${limit}`;
  const { rows } = await client.query(sql);
  let ok = 0, fail = 0;
  for (const row of rows) {
    try {
      const buf = Buffer.isBuffer(row.photo_data)
        ? row.photo_data
        : Buffer.from(row.photo_data);
      if (!buf.length) { fail++; continue; }
      const publicPath = writePhoto(row.organization_id, 'members', row.id, row.photo_mime, buf);
      if (!dryRun) {
        await client.query(
          `UPDATE members
           SET photo_path=$1, photo_data=NULL, photo_mime=NULL, updated_at=NOW()
           WHERE id=$2 AND organization_id=$3`,
          [publicPath, row.id, row.organization_id]
        );
      }
      ok++;
      console.log(`[member] ${row.id} → ${publicPath}${dryRun ? ' (dry-run)' : ''}`);
    } catch (e) {
      fail++;
      console.error(`[member] ${row.id} failed:`, e.message);
    }
  }
  return { total: rows.length, ok, fail };
}

async function migrateNominees(client) {
  let sql = `
    SELECT id, organization_id, member_id, photo_data, photo_mime
    FROM member_nominees
    WHERE photo_data IS NOT NULL
      AND (photo_path IS NULL OR photo_path = '')
    ORDER BY created_at NULLS LAST
  `;
  if (limit) sql += ` LIMIT ${limit}`;
  const { rows } = await client.query(sql);
  let ok = 0, fail = 0;
  for (const row of rows) {
    try {
      const buf = Buffer.isBuffer(row.photo_data)
        ? row.photo_data
        : Buffer.from(row.photo_data);
      if (!buf.length) { fail++; continue; }
      const publicPath = writePhoto(
        row.organization_id,
        'nominees',
        row.member_id || row.id,
        row.photo_mime,
        buf
      );
      if (!dryRun) {
        await client.query(
          `UPDATE member_nominees
           SET photo_path=$1, photo_data=NULL, photo_mime=NULL, updated_at=NOW()
           WHERE id=$2 AND organization_id=$3`,
          [publicPath, row.id, row.organization_id]
        );
      }
      ok++;
      console.log(`[nominee] ${row.id} → ${publicPath}${dryRun ? ' (dry-run)' : ''}`);
    } catch (e) {
      fail++;
      console.error(`[nominee] ${row.id} failed:`, e.message);
    }
  }
  return { total: rows.length, ok, fail };
}

async function main() {
  console.log(`Photo BYTEA → disk migration ${dryRun ? '(DRY RUN)' : ''}`);
  console.log(`Upload root: ${UPLOAD_ROOT}`);
  ensureDir(UPLOAD_ROOT);

  const client = await pool.connect();
  try {
    const members = await migrateMembers(client);
    const nominees = await migrateNominees(client);
    console.log('---');
    console.log('Members:', members);
    console.log('Nominees:', nominees);
    if (dryRun) console.log('Dry run only — no DB updates.');
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
